package com.example.shiftpay;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Inflater;

/**
 * 급여명세서 원본 PDF의 <b>디지털 텍스트</b>를 직접 읽는 추출기 (안드로이드·외부 라이브러리 비의존 순수 Java).
 *
 * 왜 필요한가: 명세서를 사진으로 찍어 OCR하면 조명·기울기·압축 노이즈 때문에 얇은 표 선과 작은 숫자를
 * 놓친다. 반면 회사가 발급한 원본 PDF에는 100% 디지털 문자열이 그대로 들어 있어, 글자를 '짐작'하지 않고
 * 그대로 복사할 수 있다. 이 클래스가 그 일을 한다.
 *
 * 처리 흐름
 *  ① 오브젝트 스캔 → ② FlateDecode 스트림 해제(Inflater) → ③ 페이지의 /Contents·/Resources(/Font) 확인
 *  → ④ 폰트별 /ToUnicode CMap 으로 2바이트 코드 → 유니코드 변환 → ⑤ 텍스트 오퍼레이터
 *     (Tj·TJ·'·")를 해석하며 Tm/Td 좌표를 따라가 각 셀의 위치를 얻는다 → ⑥ 좌표를 ML Kit 토큰과
 *     같은 형태(PayslipParser.Tok)로 내주어 기존 2차원 표 파서가 그대로 읽게 한다.
 *
 * 지원 범위: FlateDecode(비압축 스트림 포함), Type0/Identity-H + ToUnicode, 단순 폰트(WinAnsi).
 * 암호화된 PDF·이미지로만 된(스캔) PDF는 텍스트가 없으므로 호출측이 PdfRenderer+ML Kit로 넘어간다.
 */
public final class PdfTextExtractor {

    private PdfTextExtractor() {}

    /** 한 번의 텍스트 조각(셀) — PDF 좌표(포인트)와 페이지 번호. */
    public static final class Run {
        public String text = "";
        public float x, yTop, w, h;
        public int page;
    }

    /** 추출 결과 — 평문(줄 단위)과 좌표 토큰, 그리고 신뢰도 지표. */
    public static final class Out {
        public String fullText = "";
        public final List<PayslipParser.Tok> toks = new ArrayList<>();
        public final List<Run> runs = new ArrayList<>();
        public int pages;
        public int textChars;
        public boolean hasTextLayer;   // 디지털 텍스트를 실제로 얻었는가
    }

    // ── 내부 오브젝트 ─────────────────────────────────────────
    private static final class Obj {
        int num;
        String dict = "";
        int streamStart = -1, streamEnd = -1;
    }

    private static final float TOK_SCALE = 2.0f;   // 포인트 → 정수 좌표(반올림 오차 방지)
    private static final float PAGE_Y_GAP = 100000f;  // 페이지 간 y 충돌 방지

    // ══════════════════════════════════════════════════════════
    // 진입점
    // ══════════════════════════════════════════════════════════
    public static Out extract(byte[] data) {
        Out out = new Out();
        if (data == null || data.length < 8) return out;
        String head = new String(data, 0, Math.min(1024, data.length), StandardCharsets.ISO_8859_1);
        if (!head.contains("%PDF")) return out;

        String s = new String(data, StandardCharsets.ISO_8859_1);
        Map<Integer, Obj> objs = scanObjects(s, data);

        // 페이지 오브젝트 수집 (문서 순서 = 오브젝트 번호 순으로 정렬)
        TreeMap<Integer, Obj> pages = new TreeMap<>();
        for (Obj o : objs.values()) {
            if (Pattern.compile("/Type\\s*/Page(?![sA-Za-z])").matcher(o.dict).find()) pages.put(o.num, o);
        }
        out.pages = pages.size();
        if (pages.isEmpty()) return out;

        StringBuilder text = new StringBuilder();
        int pageIndex = 0;
        for (Obj pageObj : pages.values()) {
            float pageH = 842f;
            Matcher mb = Pattern.compile("/MediaBox\\s*\\[([^\\]]*)\\]").matcher(pageObj.dict);
            if (mb.find()) {
                String[] nums = mb.group(1).trim().split("\\s+");
                if (nums.length >= 4) {
                    try {
                        float y0 = Float.parseFloat(nums[1]), y1 = Float.parseFloat(nums[3]);
                        pageH = Math.abs(y1 - y0);
                    } catch (Exception ignored) {}
                }
            }

            // 폰트 이름 → ToUnicode 맵
            Map<String, Map<Integer, String>> fonts = new HashMap<>();
            String fontDict = findFontDict(pageObj.dict, s, objs);
            if (fontDict != null) {
                Matcher fm = Pattern.compile("/([A-Za-z0-9#_.\\-]+)\\s+(\\d+)\\s+0\\s+R").matcher(fontDict);
                while (fm.find()) {
                    String name = fm.group(1);
                    int ref = parseIntSafe(fm.group(2));
                    Map<Integer, String> cm = cmapOf(ref, s, objs, data);
                    if (cm != null) fonts.put(name, cm);
                }
            }

            // 페이지 콘텐츠 스트림(여러 개면 이어 붙인다)
            String content = contentOf(pageObj, s, objs, data);
            if (content == null || content.isEmpty()) { pageIndex++; continue; }

            List<Run> runs = mergeTouching(interpret(content, pageH, pageIndex, fonts));
            for (Run r : runs) out.runs.add(r);

            // 평문: y로 줄을 묶고 x 순으로 이어 붙인다
            List<List<Run>> lines = groupLines(runs);
            for (List<Run> line : lines) {
                StringBuilder sb = new StringBuilder();
                float prevEnd = Float.NaN;
                float size = 0;
                for (Run r : line) {
                    if (!Float.isNaN(prevEnd)) {
                        float gap = r.x - prevEnd;
                        if (gap > Math.max(2.0f, size * 0.30f)) sb.append(' ');
                    }
                    sb.append(r.text);
                    prevEnd = r.x + r.w;
                    size = Math.max(size, r.h);
                }
                String ln = sb.toString().trim();
                if (!ln.isEmpty()) { text.append(ln).append('\n'); out.textChars += ln.length(); }
            }
            text.append('\n');
            pageIndex++;
        }

        out.fullText = text.toString();
        // 좌표 토큰 (ML Kit Element 레벨과 같은 형태)
        for (Run r : out.runs) {
            if (r.text == null || r.text.trim().isEmpty()) continue;
            float top = r.yTop + r.page * PAGE_Y_GAP;
            int l = Math.round(r.x * TOK_SCALE);
            int t = Math.round(top * TOK_SCALE);
            int rr = Math.round((r.x + r.w) * TOK_SCALE);
            int b = Math.round((top + r.h) * TOK_SCALE);
            out.toks.add(new PayslipParser.Tok(r.text, l, t, rr, b, false));
        }
        out.hasTextLayer = out.textChars >= 40;
        return out;
    }

    // ══════════════════════════════════════════════════════════
    // ① 오브젝트 스캔
    // ══════════════════════════════════════════════════════════
    private static Map<Integer, Obj> scanObjects(String s, byte[] data) {
        Map<Integer, Obj> map = new HashMap<>();
        Matcher m = Pattern.compile("(?<![0-9])(\\d{1,6})\\s+(\\d{1,3})\\s+obj\\b").matcher(s);
        List<int[]> heads = new ArrayList<>();   // {objNum, dictStart}
        List<Integer> nums = new ArrayList<>();
        while (m.find()) {
            nums.add(parseIntSafe(m.group(1)));
            heads.add(new int[]{m.end()});
        }
        for (int i = 0; i < heads.size(); i++) {
            int dictStart = heads.get(i)[0];
            int endObj = s.indexOf("endobj", dictStart);
            if (endObj < 0) endObj = s.length();
            Obj o = new Obj();
            o.num = nums.get(i);
            int st = indexOfStreamKeyword(s, dictStart, endObj);
            if (st >= 0) {
                o.dict = s.substring(dictStart, st);
                int p = st + 6;                      // "stream"
                while (p < endObj && (s.charAt(p) == '\r' || s.charAt(p) == '\n')) p++;
                int len = -1;
                Matcher lm = Pattern.compile("/Length\\s+(\\d{1,9})(?!\\s+\\d+\\s+R)").matcher(o.dict);
                if (lm.find()) len = parseIntSafe(lm.group(1));
                if (len > 0 && p + len <= s.length()) {
                    int after = p + len;
                    // Length 뒤에 endstream 이 와야 신뢰 (아니면 endstream 탐색)
                    int probe = after;
                    while (probe < s.length() && (s.charAt(probe) == '\r' || s.charAt(probe) == '\n')) probe++;
                    if (s.startsWith("endstream", probe)) { o.streamStart = p; o.streamEnd = after; }
                }
                if (o.streamStart < 0) {
                    int es = s.indexOf("endstream", p);
                    if (es > p) {
                        int e = es;
                        while (e > p && (s.charAt(e - 1) == '\r' || s.charAt(e - 1) == '\n')) e--;
                        o.streamStart = p; o.streamEnd = e;
                    }
                }
            } else {
                o.dict = s.substring(dictStart, endObj);
            }
            map.put(o.num, o);
        }
        return map;
    }

    /** 사전 안의 "stream" 키워드(문자열 안의 것은 제외) */
    private static int indexOfStreamKeyword(String s, int from, int to) {
        int i = from;
        while (i < to) {
            int k = s.indexOf("stream", i);
            if (k < 0 || k >= to) return -1;
            if (k > 0 && s.charAt(k - 1) == 'd') { i = k + 6; continue; }   // endstream
            return k;
        }
        return -1;
    }

    // ══════════════════════════════════════════════════════════
    // ② 스트림 해제
    // ══════════════════════════════════════════════════════════
    private static byte[] streamBytes(Obj o, byte[] data) {
        if (o == null || o.streamStart < 0 || o.streamEnd <= o.streamStart) return null;
        byte[] raw = new byte[o.streamEnd - o.streamStart];
        System.arraycopy(data, o.streamStart, raw, 0, raw.length);
        if (o.dict.contains("FlateDecode")) {
            byte[] z = inflate(raw, false);
            if (z == null) z = inflate(raw, true);
            return z != null ? z : raw;
        }
        return raw;
    }

    private static byte[] inflate(byte[] in, boolean nowrap) {
        try {
            Inflater inf = new Inflater(nowrap);
            inf.setInput(in);
            ByteArrayOutputStream bos = new ByteArrayOutputStream(Math.max(1024, in.length * 4));
            byte[] buf = new byte[16384];
            while (!inf.finished()) {
                int n = inf.inflate(buf);
                if (n <= 0) {
                    if (inf.needsInput() || inf.needsDictionary()) break;
                    break;
                }
                bos.write(buf, 0, n);
            }
            inf.end();
            byte[] out = bos.toByteArray();
            return out.length > 0 ? out : null;
        } catch (Throwable t) {
            return null;
        }
    }

    // ══════════════════════════════════════════════════════════
    // ③ 페이지 자원
    // ══════════════════════════════════════════════════════════
    private static String findFontDict(String pageDict, String s, Map<Integer, Obj> objs) {
        // 페이지 사전 안에 직접 있는 경우: /Resources << /Font << ... >> >>
        int ri = pageDict.indexOf("/Font");
        if (ri < 0) {
            Matcher rm = Pattern.compile("/Resources\\s+(\\d+)\\s+0\\s+R").matcher(pageDict);
            if (rm.find()) {
                Obj res = objs.get(parseIntSafe(rm.group(1)));
                if (res != null) return subDict(res.dict, "/Font");
            }
            return null;
        }
        return subDict(pageDict, "/Font");
    }

    /** 사전 안 "/Key << ... >>" 의 내부를 반환 (중괄호 깊이 계산) */
    private static String subDict(String dict, String key) {
        int k = dict.indexOf(key);
        if (k < 0) return null;
        int i = k + key.length();
        while (i < dict.length() && Character.isWhitespace(dict.charAt(i))) i++;
        if (i + 1 >= dict.length() || dict.charAt(i) != '<' || dict.charAt(i + 1) != '<') {
            Matcher rm = Pattern.compile(key + "\\s+(\\d+)\\s+0\\s+R").matcher(dict);
            return rm.find() ? null : null;   // 참조형은 호출측이 별도 처리
        }
        int depth = 0;
        int start = i + 2;
        while (i < dict.length() - 1) {
            if (dict.charAt(i) == '<' && dict.charAt(i + 1) == '<') { depth++; i += 2; continue; }
            if (dict.charAt(i) == '>' && dict.charAt(i + 1) == '>') {
                depth--;
                if (depth == 0) return dict.substring(start, i);
                i += 2; continue;
            }
            i++;
        }
        return dict.substring(start);
    }

    private static String contentOf(Obj page, String s, Map<Integer, Obj> objs, byte[] data) {
        List<Integer> refs = new ArrayList<>();
        Matcher one = Pattern.compile("/Contents\\s+(\\d+)\\s+0\\s+R").matcher(page.dict);
        if (one.find()) {
            refs.add(parseIntSafe(one.group(1)));
        } else {
            Matcher arr = Pattern.compile("/Contents\\s*\\[([^\\]]*)\\]").matcher(page.dict);
            if (arr.find()) {
                Matcher r = Pattern.compile("(\\d+)\\s+0\\s+R").matcher(arr.group(1));
                while (r.find()) refs.add(parseIntSafe(r.group(1)));
            }
        }
        if (refs.isEmpty()) return null;
        StringBuilder sb = new StringBuilder();
        for (int ref : refs) {
            byte[] b = streamBytes(objs.get(ref), data);
            if (b != null) sb.append(new String(b, StandardCharsets.ISO_8859_1)).append('\n');
        }
        return sb.toString();
    }

    // ══════════════════════════════════════════════════════════
    // ④ ToUnicode CMap
    // ══════════════════════════════════════════════════════════
    private static Map<Integer, String> cmapOf(int fontObjNum, String s, Map<Integer, Obj> objs, byte[] data) {
        Obj f = objs.get(fontObjNum);
        if (f == null) return null;
        Matcher tm = Pattern.compile("/ToUnicode\\s+(\\d+)\\s+0\\s+R").matcher(f.dict);
        if (!tm.find()) return null;
        byte[] cmapBytes = streamBytes(objs.get(parseIntSafe(tm.group(1))), data);
        if (cmapBytes == null) return null;
        return parseCMap(new String(cmapBytes, StandardCharsets.ISO_8859_1));
    }

    private static Map<Integer, String> parseCMap(String cmap) {
        Map<Integer, String> map = new HashMap<>();
        Matcher bc = Pattern.compile("beginbfchar(.*?)endbfchar", Pattern.DOTALL).matcher(cmap);
        while (bc.find()) {
            Matcher pair = Pattern.compile("<([0-9A-Fa-f]+)>\\s*<([0-9A-Fa-f]+)>").matcher(bc.group(1));
            while (pair.find()) {
                map.put(hexInt(pair.group(1)), utf16be(pair.group(2)));
            }
        }
        Matcher br = Pattern.compile("beginbfrange(.*?)endbfrange", Pattern.DOTALL).matcher(cmap);
        while (br.find()) {
            String body = br.group(1);
            // 배열형 <lo> <hi> [ <d1> <d2> ... ]
            Matcher arr = Pattern.compile("<([0-9A-Fa-f]+)>\\s*<([0-9A-Fa-f]+)>\\s*\\[(.*?)\\]", Pattern.DOTALL).matcher(body);
            while (arr.find()) {
                int lo = hexInt(arr.group(1));
                Matcher d = Pattern.compile("<([0-9A-Fa-f]+)>").matcher(arr.group(3));
                int i = 0;
                while (d.find()) map.put(lo + i++, utf16be(d.group(1)));
            }
            // 단일형 <lo> <hi> <dst>
            String stripped = arr.replaceAll(" ");
            Matcher one = Pattern.compile("<([0-9A-Fa-f]+)>\\s*<([0-9A-Fa-f]+)>\\s*<([0-9A-Fa-f]+)>").matcher(stripped);
            while (one.find()) {
                int lo = hexInt(one.group(1));
                int hi = hexInt(one.group(2));
                String base = utf16be(one.group(3));
                if (hi < lo || hi - lo > 4000) continue;
                for (int k = 0; k <= hi - lo; k++) map.put(lo + k, incrementLast(base, k));
            }
        }
        return map.isEmpty() ? null : map;
    }

    private static String incrementLast(String base, int by) {
        if (base == null || base.isEmpty() || by == 0) return base;
        char[] c = base.toCharArray();
        c[c.length - 1] = (char) (c[c.length - 1] + by);
        return new String(c);
    }

    private static int hexInt(String hex) {
        try { return Integer.parseInt(hex.trim(), 16); } catch (Exception e) { return 0; }
    }

    private static String utf16be(String hex) {
        String h = hex.trim();
        if ((h.length() & 1) == 1) h = "0" + h;
        try {
            byte[] b = new byte[h.length() / 2];
            for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
            return new String(b, StandardCharsets.UTF_16BE);
        } catch (Exception e) {
            return "";
        }
    }

    // ══════════════════════════════════════════════════════════
    // ⑤ 콘텐츠 스트림 해석 (텍스트 오퍼레이터 + 좌표)
    // ══════════════════════════════════════════════════════════
    private static List<Run> interpret(String content, float pageH, int pageIndex,
                                       Map<String, Map<Integer, String>> fonts) {
        List<Run> runs = new ArrayList<>();
        float[] tm = {1, 0, 0, 1, 0, 0};
        float[] tlm = {1, 0, 0, 1, 0, 0};
        float[] ctm = {1, 0, 0, 1, 0, 0};
        ArrayList<float[]> gstack = new ArrayList<>();
        float fontSize = 12f;
        String fontName = null;
        Map<Integer, String> cmap = null;
        boolean twoByte = true;

        List<Object> stack = new ArrayList<>();
        int i = 0, n = content.length();
        while (i < n) {
            char c = content.charAt(i);
            if (c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\f' || c == 0) { i++; continue; }
            if (c == '%') { while (i < n && content.charAt(i) != '\r' && content.charAt(i) != '\n') i++; continue; }
            if (c == '(') {
                StringBuilder sb = new StringBuilder();
                i++;
                int depth = 1;
                while (i < n) {
                    char ch = content.charAt(i);
                    if (ch == '\\') {
                        i++;
                        if (i >= n) break;
                        char e = content.charAt(i);
                        switch (e) {
                            case 'n': sb.append('\n'); i++; break;
                            case 'r': sb.append('\r'); i++; break;
                            case 't': sb.append('\t'); i++; break;
                            case 'b': sb.append('\b'); i++; break;
                            case 'f': sb.append('\f'); i++; break;
                            case '(': sb.append('('); i++; break;
                            case ')': sb.append(')'); i++; break;
                            case '\\': sb.append('\\'); i++; break;
                            case '\r': i++; if (i < n && content.charAt(i) == '\n') i++; break;
                            case '\n': i++; break;
                            default:
                                if (e >= '0' && e <= '7') {
                                    int val = 0, cnt = 0;
                                    while (i < n && cnt < 3 && content.charAt(i) >= '0' && content.charAt(i) <= '7') {
                                        val = val * 8 + (content.charAt(i) - '0'); i++; cnt++;
                                    }
                                    sb.append((char) (val & 0xFF));
                                } else { sb.append(e); i++; }
                        }
                        continue;
                    }
                    if (ch == '(') { depth++; sb.append(ch); i++; continue; }
                    if (ch == ')') { depth--; i++; if (depth == 0) break; sb.append(ch); continue; }
                    sb.append(ch); i++;
                }
                stack.add(new PStr(sb.toString()));
                continue;
            }
            if (c == '<') {
                if (i + 1 < n && content.charAt(i + 1) == '<') { i += 2; continue; }   // 사전 무시
                int j = content.indexOf('>', i);
                if (j < 0) break;
                String hex = content.substring(i + 1, j).replaceAll("\\s", "");
                if ((hex.length() & 1) == 1) hex += "0";
                StringBuilder sb = new StringBuilder();
                for (int k = 0; k + 1 < hex.length(); k += 2) {
                    try { sb.append((char) Integer.parseInt(hex.substring(k, k + 2), 16)); }
                    catch (Exception ignored) {}
                }
                stack.add(new PStr(sb.toString()));
                i = j + 1;
                continue;
            }
            if (c == '>') { i += (i + 1 < n && content.charAt(i + 1) == '>') ? 2 : 1; continue; }
            if (c == '[') { stack.add(new PArr(true)); i++; continue; }
            if (c == ']') { closeArray(stack); i++; continue; }
            if (c == '/') {
                int j = i + 1;
                while (j < n && " \t\r\n\f/[]<>()%{}".indexOf(content.charAt(j)) < 0) j++;
                stack.add("/" + content.substring(i + 1, j));
                i = j;
                continue;
            }
            // 숫자 또는 연산자
            int j = i;
            while (j < n && " \t\r\n\f/[]<>()%{}".indexOf(content.charAt(j)) < 0) j++;
            String word = content.substring(i, j);
            i = (j > i) ? j : i + 1;
            Float num = tryParseFloat(word);
            if (num != null) { addToStack(stack, num); continue; }

            // ── 연산자 ──
            switch (word) {
                case "q": gstack.add(ctm.clone()); break;
                case "Q": if (!gstack.isEmpty()) ctm = gstack.remove(gstack.size() - 1); break;
                case "cm":
                    if (stack.size() >= 6) {
                        float[] m = new float[]{(float) numAt(stack, -6), (float) numAt(stack, -5), (float) numAt(stack, -4),
                                (float) numAt(stack, -3), (float) numAt(stack, -2), (float) numAt(stack, -1)};
                        ctm = mul(m, ctm);
                    }
                    break;
                case "BT": tm = new float[]{1, 0, 0, 1, 0, 0}; tlm = tm.clone(); break;
                case "Tf":
                    if (stack.size() >= 2) {
                        fontSize = (float) numAt(stack, -1);
                        Object fn = stack.size() >= 2 ? stack.get(stack.size() - 2) : null;
                        if (fn instanceof String) {
                            fontName = ((String) fn).substring(1);
                            cmap = fonts.get(fontName);
                            twoByte = true;   // ToUnicode가 있으면 2바이트 코드가 기본
                            if (cmap == null) twoByte = false;
                        }
                    }
                    break;
                case "Tm":
                    if (stack.size() >= 6) {
                        tm = new float[]{(float) numAt(stack, -6), (float) numAt(stack, -5), (float) numAt(stack, -4),
                                (float) numAt(stack, -3), (float) numAt(stack, -2), (float) numAt(stack, -1)};
                        tlm = tm.clone();
                    }
                    break;
                case "Td":
                    if (stack.size() >= 2) {
                        tlm[4] += (float) numAt(stack, -2);
                        tlm[5] += (float) numAt(stack, -1);
                        tm = tlm.clone();
                    }
                    break;
                case "TD":
                    if (stack.size() >= 2) {
                        float dy = (float) numAt(stack, -1);
                        tlm[4] += (float) numAt(stack, -2);
                        tlm[5] += dy;
                        tm = tlm.clone();
                    }
                    break;
                case "T*":
                    tlm[5] -= fontSize;
                    tm = tlm.clone();
                    break;
                case "TL":
                    if (stack.size() >= 1) { /* leading — T*에서만 사용 */ }
                    break;
                case "Tj":
                case "TJ":
                case "'":
                case "\"": {
                    // 스택의 문자열/배열을 모두 모아 하나의 런으로
                    StringBuilder sb = new StringBuilder();
                    float adv = 0;
                    for (Object o : stack) {
                        if (o instanceof PStr) {
                            String raw = ((PStr) o).s;
                            sb.append(decode(raw, cmap, twoByte));
                            adv += measure(raw, cmap, twoByte, fontSize);
                        } else if (o instanceof PArr) {
                            for (Object el : ((PArr) o).items) {
                                if (el instanceof PStr) {
                                    String raw = ((PStr) el).s;
                                    sb.append(decode(raw, cmap, twoByte));
                                    adv += measure(raw, cmap, twoByte, fontSize);
                                } else if (el instanceof Float) {
                                    adv -= ((Float) el) / 1000f * fontSize;
                                }
                            }
                        }
                    }
                    String txt = sb.toString();
                    if (!txt.isEmpty()) {
                        float x = tm[4] * ctm[0] + tm[5] * ctm[2] + ctm[4];
                        float y = tm[4] * ctm[1] + tm[5] * ctm[3] + ctm[5];
                        Run r = new Run();
                        r.text = txt;
                        r.x = x;
                        r.yTop = pageH - y - fontSize * 0.82f;
                        r.w = Math.max(1f, adv);
                        r.h = fontSize * 1.05f;
                        r.page = pageIndex;
                        runs.add(r);
                    }
                    // PDF 규칙: 글자를 그린 뒤 텍스트 행렬이 그 폭만큼 전진한다
                    //  (한 BT 안에서 Tj를 여러 번 쓰는 생성기 — iText 4.x — 를 정확히 따라가기 위해 필요)
                    tm[4] += adv * tm[0];
                    tm[5] += adv * tm[1];
                    break;
                }
                default: break;
            }
            stack.clear();
        }
        return runs;
    }

    private static final class PStr { final String s; PStr(String s) { this.s = s; } }
    private static final class PArr {
        final List<Object> items = new ArrayList<>();
        PArr(boolean open) {}
    }

    @SuppressWarnings("unchecked")
    private static void addToStack(List<Object> stack, Object v) {
        if (!stack.isEmpty()) {
            Object last = stack.get(stack.size() - 1);
            if (last instanceof PArr && isOpenArray(stack)) {
                ((PArr) last).items.add(v);
                return;
            }
        }
        stack.add(v);
    }

    /** 배열은 스택에서 열린 상태로 유지 — 뒤에 오는 숫자·문자열을 담기 위함 */
    private static boolean isOpenArray(List<Object> stack) {
        int opens = 0;
        for (int i = stack.size() - 1; i >= 0; i--) {
            Object o = stack.get(i);
            if (o instanceof PArr) { opens++; break; }
        }
        return opens > 0;
    }

    private static void closeArray(List<Object> stack) {
        // PArr 은 스택에 하나만 열려 있다고 가정 — 표시만 하고 그대로 둔다
        for (int i = stack.size() - 1; i >= 0; i--) {
            Object o = stack.get(i);
            if (o instanceof PArr) {
                // 배열을 스택의 해당 위치로 올려 이후 연산자 처리가 쉽도록
                return;
            }
        }
    }

    private static double numAt(List<Object> stack, int fromEnd) {
        int idx = stack.size() + fromEnd;
        if (idx < 0 || idx >= stack.size()) return 0;
        Object o = stack.get(idx);
        return (o instanceof Float) ? (Float) o : 0;
    }

    private static Float tryParseFloat(String w) {
        if (w == null || w.isEmpty()) return null;
        char c0 = w.charAt(0);
        if (!(c0 == '-' || c0 == '+' || c0 == '.' || (c0 >= '0' && c0 <= '9'))) return null;
        try { return Float.parseFloat(w); } catch (Exception e) { return null; }
    }

    private static float[] mul(float[] a, float[] b) {
        return new float[]{
                a[0] * b[0] + a[1] * b[2], a[0] * b[1] + a[1] * b[3],
                a[2] * b[0] + a[3] * b[2], a[2] * b[1] + a[3] * b[3],
                a[4] * b[0] + a[5] * b[2] + b[4], a[4] * b[1] + a[5] * b[3] + b[5]
        };
    }

    // ── 문자열 디코드 ────────────────────────────────────────
    /** PDF 가 공백을 줄바꿈 없는 공백(U+00A0)으로 넣는 경우가 흔하다 — 일반 공백으로 정규화 */
    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\u00a0', ' ').replace('\u2007', ' ').replace('\u202f', ' ');
    }

    private static String decode(String raw, Map<Integer, String> cmap, boolean twoByte) {
        if (raw == null || raw.isEmpty()) return "";
        if (cmap != null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i + 1 < raw.length(); i += 2) {
                int code = ((raw.charAt(i) & 0xFF) << 8) | (raw.charAt(i + 1) & 0xFF);
                String u = cmap.get(code);
                if (u != null) sb.append(u);
            }
            return clean(sb.toString());
        }
        if (twoByte) {
            // ToUnicode가 없는 Identity-H: 코드 = UCS-2 로 간주 (일부 생성기)
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i + 1 < raw.length(); i += 2) {
                sb.append((char) (((raw.charAt(i) & 0xFF) << 8) | (raw.charAt(i + 1) & 0xFF)));
            }
            return clean(sb.toString());
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char ch = raw.charAt(i);
            if (ch >= 32 && ch < 127) sb.append(ch);
            else if (ch == 10 || ch == 13) sb.append(' ');
        }
        return clean(sb.toString());
    }

    /** 글자 폭(포인트) 추정 — 한글·CJK 1.0em, 숫자 0.55em, 기호 0.28em */
    private static float measure(String raw, Map<Integer, String> cmap, boolean twoByte, float size) {
        float w = 0;
        if (cmap != null) {
            for (int i = 0; i + 1 < raw.length(); i += 2) {
                int code = ((raw.charAt(i) & 0xFF) << 8) | (raw.charAt(i + 1) & 0xFF);
                String u = cmap.get(code);
                if (u == null || u.isEmpty()) { w += size * 0.5f; continue; }
                for (int k = 0; k < u.length(); k++) w += charWidth(u.charAt(k), size);
            }
        } else if (twoByte) {
            w = (raw.length() / 2f) * size;
        } else {
            for (int i = 0; i < raw.length(); i++) w += charWidth(raw.charAt(i), size);
        }
        return w;
    }

    private static float charWidth(char ch, float size) {
        if (ch >= 0xAC00 && ch <= 0xD7A3) return size;            // 한글 음절
        if (ch >= 0x3130 && ch <= 0x318F) return size;            // 한글 자모
        if (ch >= 0x4E00 && ch <= 0x9FFF) return size;            // CJK
        if (ch >= 0xFF00 && ch <= 0xFF60) return size;            // 전각
        if (ch >= '0' && ch <= '9') return size * 0.556f;
        if (ch == ' ') return size * 0.25f;
        if (ch == '.' || ch == ',' || ch == ':' || ch == ';' || ch == '\'') return size * 0.28f;
        if (ch == '(' || ch == ')') return size * 0.33f;
        if (ch == '-' || ch == '/' || ch == '%') return size * 0.4f;
        return size * 0.52f;
    }

    /**
     * 한 셀을 여러 조각으로 그린 경우(예: "248." + "0", "정상(H" + ")")를 하나로 잇는다.
     * 생성기가 폰트나 커닝 때문에 문자열을 쪼개 출력하기 때문에, 이어 붙이지 않으면
     * 시간값·괄호 라벨이 토막 나 표 파서가 읽지 못한다.
     */
    private static List<Run> mergeTouching(List<Run> runs) {
        if (runs.size() < 2) return runs;
        List<Run> sorted = new ArrayList<>(runs);
        sorted.sort((a, b) -> {
            int cy = Float.compare(a.yTop + a.h * 0.5f, b.yTop + b.h * 0.5f);
            return cy != 0 ? cy : Float.compare(a.x, b.x);
        });
        List<Run> out = new ArrayList<>();
        for (Run r : sorted) {
            Run prev = out.isEmpty() ? null : out.get(out.size() - 1);
            if (prev != null) {
                float cyA = prev.yTop + prev.h * 0.5f, cyB = r.yTop + r.h * 0.5f;
                float size = Math.max(prev.h, r.h);
                float gap = r.x - (prev.x + prev.w);
                boolean sameRow = Math.abs(cyA - cyB) <= size * 0.75f;
                boolean touching = gap <= size * 0.22f && gap >= -size * 0.9f;
                // 앞 조각이 공백/구분자로 끝나면 셀이 다를 수 있으므로 잇지 않는다
                boolean glue = !prev.text.endsWith(" ") && !r.text.startsWith(" ");
                if (sameRow && touching && glue) {
                    prev.text = prev.text + r.text;
                    float right = Math.max(prev.x + prev.w, r.x + r.w);
                    prev.w = right - prev.x;
                    prev.yTop = Math.min(prev.yTop, r.yTop);
                    prev.h = Math.max(prev.h, r.h);
                    continue;
                }
            }
            out.add(r);
        }
        return out;
    }

    // ── 줄 묶기 ──────────────────────────────────────────────
    private static List<List<Run>> groupLines(List<Run> runs) {
        List<Run> sorted = new ArrayList<>(runs);
        sorted.sort((a, b) -> {
            int cy = Float.compare(a.yTop + a.h * 0.5f, b.yTop + b.h * 0.5f);
            return cy != 0 ? cy : Float.compare(a.x, b.x);
        });
        List<List<Run>> out = new ArrayList<>();
        List<Run> cur = new ArrayList<>();
        float curY = Float.NaN, curH = 0;
        for (Run r : sorted) {
            float cy = r.yTop + r.h * 0.5f;
            if (cur.isEmpty() || Math.abs(cy - curY) <= Math.max(1.6f, curH * 0.55f)) {
                cur.add(r);
                curY = cur.isEmpty() ? cy : curY;
                if (cur.size() == 1) curY = cy;
                curH = Math.max(curH, r.h);
            } else {
                cur.sort((a, b) -> Float.compare(a.x, b.x));
                out.add(cur);
                cur = new ArrayList<>();
                cur.add(r);
                curY = cy;
                curH = r.h;
            }
        }
        if (!cur.isEmpty()) { cur.sort((a, b) -> Float.compare(a.x, b.x)); out.add(cur); }
        return out;
    }

    private static int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }
}
