import com.example.shiftpay.AttendanceCore;
import com.example.shiftpay.PayCore;

import java.time.LocalDate;
import java.util.*;

/**
 * 사내 공식 근태 뱃지 · 조합설명회 · 조퇴 급여 연동 검증 하네스.
 *
 * 실제 앱에 들어가는 AttendanceCore.java(근태 → 근무 입력값 매핑)와
 * PayCore.java(급여 계산)를 그대로 컴파일해 실행한다.
 *
 *  · 조합설명회 2h / 3h — 정상 8h 를 채운 날이므로 설명회 시간은 기본급 100% 유급(조합 칸)으로
 *    들어가고, 당일 상주휴게(가급 1h)는 그대로 지급된다. (단협 제10조·제49조)
 *  · 조퇴 4h / 6h — 실근무가 8h 미만이므로 그날 가급 1h 는 자동 제외된다.
 *  · 반차 · 건강검진 · 교육 · 출장 · 예비군 · 경조 · 공무/포상 — 유급 100% 인정.
 *  · 병가 · 휴직 · 무급결근 — 인정시간 0.
 */
public class AttendanceBadgeTest {

    static int fail = 0;

    static void check(String name, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) < 0.0001;
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name
                + " → " + fmt(actual) + (ok ? "" : " (기대값 " + fmt(expected) + ")"));
    }

    static void checkStr(String name, String actual, String expected) {
        boolean ok = expected.equals(actual);
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name
                + " → \"" + actual + "\"" + (ok ? "" : " (기대값 \"" + expected + "\")"));
    }

    static String fmt(double v) {
        return (v == (long) v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    // ── 2026년 11월 (11/1 일요일) — 날짜별 근무 입력값 ─────────────────
    static final String[] MODE = new String[32];
    static final Double[][] MANUAL = new Double[32][9];
    static final Set<Integer> HOLIDAYS = new HashSet<>();

    static void reset() {
        for (int d = 1; d <= 30; d++) {
            // 주말 자동 유급 8h·주차 8h 가 섞이지 않도록 토·일은 무급(none)으로 비워 둔다
            int w = dow(d);
            MODE[d] = (w == 1 || w == 7) ? "none" : "auto";
            for (int i = 0; i < 9; i++) MANUAL[d][i] = null;
        }
    }

    /** 근태 코드를 실제 앱 저장값(mode + 정상·유급·조합)으로 풀어 하루에 넣는다 */
    static void put(int day, String code, double hours) {
        AttendanceCore.Spec sp = AttendanceCore.spec(code, hours);
        MODE[day] = sp.mode;
        MANUAL[day][0] = sp.normal > 0 ? sp.normal : null;
        MANUAL[day][1] = sp.paid > 0 ? sp.paid : null;
        MANUAL[day][3] = sp.union > 0 ? sp.union : null;
    }

    static int dow(int day) {
        return LocalDate.of(2026, 11, day).getDayOfWeek().getValue() % 7 + 1; // 1=일 … 7=토
    }

    static class Nov implements PayCore.DayData {
        public int daysInMonth() { return 30; }
        public double hours(int day, int idx) {
            boolean manual = MANUAL[day][idx] != null;
            boolean leave = "annual".equals(MODE[day]) || "summer".equals(MODE[day]);
            return PayCore.dayHours(idx, manual, manual ? MANUAL[day][idx] : 0.0,
                    MODE[day], dow(day), HOLIDAYS.contains(day), leave);
        }
        public String mode(int day) { return MODE[day]; }
    }

    static class Cfg implements PayCore.Settings {
        final Map<String, Double> v = new HashMap<>();
        Cfg() {
            v.put("base", 13653.0);      // 기본시급
            v.put("ordinary", 14939.0);  // 통상시급
            v.put("otRate", 1.5);
            v.put("holidayRate", 1.5);
            v.put("holidayOTRate", 2.0);
            v.put("nightRate", 0.5);
            v.put("tenure", 0.0);
            v.put("familySelf", 0.0);
            v.put("familyOther", 0.0);
            v.put("position", 0.0);
            v.put("duty", 0.0);
            v.put("summer", 0.0);
            v.put("other", 0.0);
            v.put("deduction", 0.0);
        }
        public double get(String k) { return v.containsKey(k) ? v.get(k) : 0.0; }
        public boolean isShiftWorker() { return false; }
        public boolean isSummerMonth() { return false; }
        public boolean isRetroActive() { return false; }
        public double retroAmount() { return 0; }
        public double deductionFor(double gross) { return 0; }
    }

    public static void main(String[] args) {
        double base = 13653.0;
        Cfg cfg = new Cfg();

        // ── 1. 조합설명회 2시간 (정상 8h + 설명회 2h) ─────────────────
        reset();
        put(5, AttendanceCore.UNION, 2);      // 11/5 목 — 평일
        Nov m1 = new Nov();
        double[] t1 = PayCore.totals(m1);
        check("설명회2h — 정상 인정시간", t1[PayCore.NORMAL], 8);
        check("설명회2h — 조합(유급 100%) 인정시간", t1[PayCore.UNION], 2);
        check("설명회2h — 평일연장으로 새지 않음", t1[PayCore.OT], 0);
        check("설명회2h — 가급 지급일수(실근무 8h 이상)", t1[PayCore.GAGEUB], 1);
        double[] a1 = PayCore.amounts(cfg, m1);
        check("설명회2h — 기본급 인정 10시간", a1[0], 10 * base);
        check("설명회2h — 평일연장수당 0원", a1[1], 0);
        check("설명회2h — 상주휴게(가급) 1일 지급", a1[5], 1 * base);

        // ── 2. 조합설명회 3시간 ─────────────────────────────────────
        reset();
        put(6, AttendanceCore.UNION, 3);      // 11/6 금
        Nov m2 = new Nov();
        double[] t2 = PayCore.totals(m2);
        check("설명회3h — 조합(유급) 인정시간", t2[PayCore.UNION], 3);
        check("설명회3h — 기본급 11시간 인정", PayCore.amounts(cfg, m2)[0], 11 * base);
        check("설명회3h — 가급 지급일수 유지", t2[PayCore.GAGEUB], 1);

        // ── 3. 설명회만 입력된 날 (정상 8h 없음) ──────────────────────
        reset();
        MODE[7] = "work";
        MANUAL[7][3] = 2.0;                   // 조합만 2h
        Nov m3 = new Nov();
        double[] t3 = PayCore.totals(m3);
        check("설명회만 2h — 조합 인정시간", t3[PayCore.UNION], 2);
        check("설명회만 2h — 실근무 0h 이므로 가급 제외", t3[PayCore.GAGEUB], 0);

        // ── 4. 조퇴 4시간 ───────────────────────────────────────────
        reset();
        put(9, AttendanceCore.EARLY, 4);      // 11/9 월
        Nov m4 = new Nov();
        double[] t4 = PayCore.totals(m4);
        check("조퇴4h — 정상 인정시간", t4[PayCore.NORMAL], 4);
        check("조퇴4h — 가급 지급일수 자동 제외", t4[PayCore.GAGEUB], 0);
        double[] a4 = PayCore.amounts(cfg, m4);
        check("조퇴4h — 기본급 4시간", a4[0], 4 * base);
        check("조퇴4h — 상주휴게 0원", a4[5], 0);

        // ── 5. 조퇴 6시간 ───────────────────────────────────────────
        reset();
        put(10, AttendanceCore.EARLY, 6);
        Nov m5 = new Nov();
        check("조퇴6h — 정상 인정시간", PayCore.totals(m5)[PayCore.NORMAL], 6);
        check("조퇴6h — 가급 지급일수 자동 제외", PayCore.totals(m5)[PayCore.GAGEUB], 0);

        // ── 6. 반차 (4h 근무 + 4h 연차) ─────────────────────────────
        reset();
        put(11, AttendanceCore.HALF, 4);
        Nov m6 = new Nov();
        double[] t6 = PayCore.totals(m6);
        check("반차 — 정상 4시간", t6[PayCore.NORMAL], 4);
        check("반차 — 유급 4시간", t6[PayCore.PAID], 4);
        check("반차 — 기본급 8시간 인정", PayCore.amounts(cfg, m6)[0], 8 * base);
        check("반차 — 가급 대상 아님(실근무 8h 미만)", t6[PayCore.GAGEUB], 0);

        // ── 7. 건강검진 4h / 교육 8h / 출장 8h / 예비군 8h ───────────
        reset();
        put(12, AttendanceCore.HEALTH, 4);
        put(13, AttendanceCore.TRAINING, 8);
        put(16, AttendanceCore.TRIP, 8);
        put(17, AttendanceCore.RESERVE, 8);
        double[] t7 = PayCore.totals(new Nov());
        check("유급 근태 4종 — 유급 인정 합계 28시간", t7[PayCore.PAID], 28);
        check("유급 근태 4종 — 정상근무 시간 0", t7[PayCore.NORMAL], 0);
        check("유급 근태 4종 — 가급 지급일수 0", t7[PayCore.GAGEUB], 0);

        // ── 8. 경조 · 공무/포상 ─────────────────────────────────────
        reset();
        put(18, AttendanceCore.CONGRAT, 8);
        put(19, AttendanceCore.CONDOL, 8);
        put(20, AttendanceCore.COMMEND, 8);
        check("경조·공무/포상 — 유급 24시간", PayCore.totals(new Nov())[PayCore.PAID], 24);

        // ── 9. 병가 · 휴직 · 무급결근 ────────────────────────────────
        reset();
        put(23, AttendanceCore.SICK, 0);
        put(24, AttendanceCore.LEAVEWORK, 0);
        put(25, AttendanceCore.ABSENT, 0);
        double[] t9 = PayCore.totals(new Nov());
        check("병가·휴직·무결 — 정상 0시간", t9[PayCore.NORMAL], 0);
        check("병가·휴직·무결 — 유급 0시간", t9[PayCore.PAID], 0);
        check("병가·휴직·무결 — 가급 0일", t9[PayCore.GAGEUB], 0);

        // ── 10. 유급결근(유결) ──────────────────────────────────────
        reset();
        put(26, AttendanceCore.ABSENT, 8);
        check("유결 — 유급 8시간 인정", PayCore.totals(new Nov())[PayCore.PAID], 8);

        // ── 11. 연차 · 하계휴가 ─────────────────────────────────────
        reset();
        put(27, AttendanceCore.ANNUAL, 8);
        put(30, AttendanceCore.SUMMER, 8);
        double[] t11 = PayCore.totals(new Nov());
        check("연차·휴가 — 기본급 인정 16시간", t11[PayCore.NORMAL], 16);
        check("연차·휴가 — 가급 대상 제외", t11[PayCore.GAGEUB], 0);

        // ── 12. 달력 뱃지 문구 ──────────────────────────────────────
        checkStr("뱃지 — 정상 8h + 설명회 2h", AttendanceCore.badge(AttendanceCore.UNION, 8, 0, 2), "8h+설명회2h");
        checkStr("뱃지 — 정상 8h + 설명회 3h", AttendanceCore.badge(AttendanceCore.UNION, 8, 0, 3), "8h+설명회3h");
        checkStr("뱃지 — 설명회만 2h", AttendanceCore.badge(AttendanceCore.UNION, 0, 0, 2), "설명회 2h");
        checkStr("뱃지 — 조퇴 4h", AttendanceCore.badge(AttendanceCore.EARLY, 4, 0, 0), "4h 조퇴");
        checkStr("뱃지 — 조퇴 6h", AttendanceCore.badge(AttendanceCore.EARLY, 6, 0, 0), "6h 조퇴");
        checkStr("뱃지 — 연차 8h", AttendanceCore.badge(AttendanceCore.ANNUAL, 8, 0, 0), "연차 8h");
        checkStr("뱃지 — 반차 4h", AttendanceCore.badge(AttendanceCore.HALF, 4, 4, 0), "반차 4h");
        checkStr("뱃지 — 휴가 8h", AttendanceCore.badge(AttendanceCore.SUMMER, 8, 0, 0), "휴가 8h");
        checkStr("뱃지 — 건강검진 4h", AttendanceCore.badge(AttendanceCore.HEALTH, 0, 4, 0), "건강검진 4h");
        checkStr("뱃지 — 교육 8h", AttendanceCore.badge(AttendanceCore.TRAINING, 0, 8, 0), "교육 8h");
        checkStr("뱃지 — 출장 8h", AttendanceCore.badge(AttendanceCore.TRIP, 0, 8, 0), "출장 8h");
        checkStr("뱃지 — 예비군 8h", AttendanceCore.badge(AttendanceCore.RESERVE, 0, 8, 0), "예비군 8h");
        checkStr("뱃지 — 축하 8h", AttendanceCore.badge(AttendanceCore.CONGRAT, 0, 8, 0), "축하 8h");
        checkStr("뱃지 — 기복 8h", AttendanceCore.badge(AttendanceCore.CONDOL, 0, 8, 0), "기복 8h");
        checkStr("뱃지 — 공무/포상 8h", AttendanceCore.badge(AttendanceCore.COMMEND, 0, 8, 0), "공무/포상 8h");
        checkStr("뱃지 — 지각", AttendanceCore.badge(AttendanceCore.LATE, 8, 0, 0), "8h 지각");
        checkStr("뱃지 — 외출", AttendanceCore.badge(AttendanceCore.OUTING, 8, 0, 0), "8h 외출");
        checkStr("뱃지 — 병가", AttendanceCore.badge(AttendanceCore.SICK, 0, 0, 0), "병가");
        checkStr("뱃지 — 유결 8h", AttendanceCore.badge(AttendanceCore.ABSENT, 0, 8, 0), "유결 8h");
        checkStr("뱃지 — 무결", AttendanceCore.badge(AttendanceCore.ABSENT, 0, 0, 0), "무결");
        checkStr("뱃지 — 휴직", AttendanceCore.badge(AttendanceCore.LEAVEWORK, 0, 0, 0), "휴직");
        checkStr("뱃지 — 종류 없음", AttendanceCore.badge("", 8, 0, 0), "");

        // ── 13. 기본값 · 4색 톤 · 내부 코드번호 미포함 ───────────────
        check("기본값 — 설명회 2h", AttendanceCore.defaultHours(AttendanceCore.UNION), 2);
        check("기본값 — 조퇴 4h", AttendanceCore.defaultHours(AttendanceCore.EARLY), 4);
        check("기본값 — 건강검진 4h", AttendanceCore.defaultHours(AttendanceCore.HEALTH), 4);
        check("4색 — 연차는 그린", AttendanceCore.tone(AttendanceCore.ANNUAL), AttendanceCore.TONE_GREEN);
        check("4색 — 경조는 그린", AttendanceCore.tone(AttendanceCore.CONDOL), AttendanceCore.TONE_GREEN);
        check("4색 — 설명회는 인디고", AttendanceCore.tone(AttendanceCore.UNION), AttendanceCore.TONE_INDIGO);
        check("4색 — 건강검진은 인디고", AttendanceCore.tone(AttendanceCore.HEALTH), AttendanceCore.TONE_INDIGO);
        check("4색 — 조퇴는 오렌지", AttendanceCore.tone(AttendanceCore.EARLY), AttendanceCore.TONE_ORANGE);
        check("4색 — 지각/외출은 오렌지", AttendanceCore.tone(AttendanceCore.OUTING), AttendanceCore.TONE_ORANGE);
        check("4색 — 병가는 슬레이트", AttendanceCore.tone(AttendanceCore.SICK), AttendanceCore.TONE_SLATE);
        check("4색 — 휴직은 슬레이트", AttendanceCore.tone(AttendanceCore.LEAVEWORK), AttendanceCore.TONE_SLATE);

        StringBuilder all = new StringBuilder();
        for (String c : new String[]{AttendanceCore.ANNUAL, AttendanceCore.SUMMER, AttendanceCore.HALF,
                AttendanceCore.CONGRAT, AttendanceCore.CONDOL, AttendanceCore.COMMEND, AttendanceCore.UNION,
                AttendanceCore.HEALTH, AttendanceCore.TRAINING, AttendanceCore.TRIP, AttendanceCore.RESERVE,
                AttendanceCore.EARLY, AttendanceCore.LATE, AttendanceCore.OUTING, AttendanceCore.SICK,
                AttendanceCore.ABSENT, AttendanceCore.LEAVEWORK}) {
            AttendanceCore.Spec sp = AttendanceCore.spec(c, AttendanceCore.defaultHours(c));
            all.append(AttendanceCore.label(c))
               .append(AttendanceCore.badge(c, sp.normal, sp.paid, sp.union))
               .append(sp.mode);
        }
        String dump = all.toString();
        boolean clean = !dump.matches(".*(품질보증|현대스틸파이프|\\b1[A-F]\\b|\\b[2-7][A-D]\\b).*");
        if (!clean) fail++;
        System.out.println((clean ? "  PASS  " : "  FAIL  ") + "근태 명칭 — 개인정보·내부 코드번호 0건");

        System.out.println(fail == 0
                ? "\n✅ 사내 공식 근태 뱃지 · 조합설명회 2h/3h · 조퇴 4h 급여 연동 전 항목 일치"
                : "\n❌ 불일치 " + fail + "건");
        if (fail != 0) System.exit(1);
    }
}
