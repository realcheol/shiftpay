import com.example.shiftpay.YearCore;

/**
 * v1.6.0 ③ — 연간 누적 · 연말정산 예측 코어 검증.
 *
 * 현행 소득세법(2026년 기준)의 근로소득공제·기본세율·근로소득세액공제·자녀세액공제·
 * 표준세액공제를 손으로 계산한 값과 1원 단위로 대조한다. 웹(index.html 의 yearCoreSettle)도
 * 같은 공식을 옮겨 쓰므로, 이 테스트가 곧 설치형 ↔ 웹 1원 일치의 기준이 된다.
 */
public class YearTaxCoreTest {

    static int fail = 0;

    static void check(String name, long actual, long expected) {
        boolean ok = actual == expected;
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name + " → " + actual
                + (ok ? "" : " (기대값 " + expected + ")"));
    }

    static void check(String name, boolean cond) {
        if (!cond) fail++;
        System.out.println((cond ? "  PASS  " : "  FAIL  ") + name);
    }

    static void checkD(String name, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) < 0.000001;
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name + " → " + actual
                + (ok ? "" : " (기대값 " + expected + ")"));
    }

    public static void main(String[] args) {
        System.out.println("── 1. 근로소득공제 구간 ──");
        check("총급여 500만", YearCore.earnedIncomeDeduction(5_000_000L), 3_500_000L);
        check("총급여 1,500만", YearCore.earnedIncomeDeduction(15_000_000L), 7_500_000L);
        check("총급여 4,500만", YearCore.earnedIncomeDeduction(45_000_000L), 12_000_000L);
        check("총급여 1억", YearCore.earnedIncomeDeduction(100_000_000L), 14_750_000L);
        check("총급여 1,200만 (3.5M + 700만×40%)", YearCore.earnedIncomeDeduction(12_000_000L), 6_300_000L);
        check("총급여 6,000만 (12M + 1,500만×5%)", YearCore.earnedIncomeDeduction(60_000_000L), 12_750_000L);
        check("총급여 2억 (14.75M + 1억×2%)", YearCore.earnedIncomeDeduction(200_000_000L), 16_750_000L);
        check("총급여 0", YearCore.earnedIncomeDeduction(0), 0);

        System.out.println("── 2. 기본세율 구간 ──");
        check("과세표준 1,400만", YearCore.basicTaxRate(14_000_000L), 840_000L);
        check("과세표준 5,000만", YearCore.basicTaxRate(50_000_000L), 6_240_000L);
        check("과세표준 8,800만", YearCore.basicTaxRate(88_000_000L), 15_360_000L);
        check("과세표준 1억 5천만", YearCore.basicTaxRate(150_000_000L), 37_060_000L);
        check("과세표준 3억", YearCore.basicTaxRate(300_000_000L), 94_060_000L);
        check("과세표준 5억", YearCore.basicTaxRate(500_000_000L), 174_060_000L);
        check("과세표준 10억", YearCore.basicTaxRate(1_000_000_000L), 384_060_000L);
        check("과세표준 3,825만", YearCore.basicTaxRate(38_250_000L), 4_477_500L);

        System.out.println("── 3. 근로소득세액공제 (55%/30% · 한도 74/66/50만) ──");
        check("산출세액 100만", YearCore.earnedIncomeTaxCredit(1_000_000L, 30_000_000L), 550_000L);
        check("산출세액 130만", YearCore.earnedIncomeTaxCredit(1_300_000L, 30_000_000L), 715_000L);
        check("산출세액 447.75만 · 총급여 6천만 (66만 한도)",
                YearCore.earnedIncomeTaxCredit(4_477_500L, 60_000_000L), 660_000L);
        check("산출세액 1,000만 · 총급여 2천만 (74만 한도)",
                YearCore.earnedIncomeTaxCredit(10_000_000L, 20_000_000L), 740_000L);
        check("산출세액 1,000만 · 총급여 8천만 (50만 한도)",
                YearCore.earnedIncomeTaxCredit(10_000_000L, 80_000_000L), 500_000L);
        check("산출세액 0", YearCore.earnedIncomeTaxCredit(0, 30_000_000L), 0);

        System.out.println("── 4. 자녀세액공제 (1명 15만 · 2명 35만 · 3명+ 30만 추가) ──");
        check("0명", YearCore.childTaxCreditOf(0), 0);
        check("1명", YearCore.childTaxCreditOf(1), 150_000L);
        check("2명", YearCore.childTaxCreditOf(2), 350_000L);
        check("3명", YearCore.childTaxCreditOf(3), 650_000L);
        check("4명", YearCore.childTaxCreditOf(4), 950_000L);

        System.out.println("── 5. 연말정산 전체 (총급여 6,000만 · 부양가족 4명 · 자녀 2명 · 4대보험 300만) ──");
        {
            YearCore.SettleIn in = new YearCore.SettleIn();
            in.gross = 60_000_000L;
            in.dependents = 4;
            in.children = 2;
            in.insurance = 3_000_000L;
            in.prepaidIncomeTax = 1_800_000L;
            in.prepaidLocalTax = 180_000L;
            YearCore.Settle s = YearCore.settle(in);
            check("근로소득공제", s.earnedDeduction, 12_750_000L);
            check("인적공제 (4×150만)", s.personalDeduction, 6_000_000L);
            check("4대보험 소득공제", s.insuranceDeduction, 3_000_000L);
            check("과세표준", s.taxBase, 38_250_000L);
            check("산출세액", s.calculatedTax, 4_477_500L);
            check("근로소득세액공제", s.earnedTaxCredit, 660_000L);
            check("자녀세액공제", s.childTaxCredit, 350_000L);
            check("표준세액공제 적용", s.appliedTaxCredit, 130_000L);
            check("표준세액공제 채택", !s.usedSpecialCredit);
            check("세액공제 합계", s.creditTotal, 1_140_000L);
            check("결정세액", s.determinedTax, 3_337_500L);
            check("지방소득세", s.localTax, 333_750L);
            check("총부담", s.totalBurden, 3_671_250L);
            check("기납부", s.prepaid, 1_980_000L);
            check("추가납부 (기납부 − 총부담)", s.settlement, -1_691_250L);
            check("환급 아님", !s.isRefund());
            checkD("실효세율", Math.floor(s.effectiveRate * 1000000) / 1000000, 0.061187);
        }

        System.out.println("── 6. 환급 시나리오 (같은 급여 · 기납부 400만) ──");
        {
            YearCore.SettleIn in = new YearCore.SettleIn();
            in.gross = 60_000_000L;
            in.dependents = 4;
            in.children = 2;
            in.insurance = 3_000_000L;
            in.prepaidIncomeTax = 3_600_000L;
            in.prepaidLocalTax = 360_000L;
            YearCore.Settle s = YearCore.settle(in);
            check("환급액 (396만 − 367.125만)", s.settlement, 288_750L);
            check("환급 판정", s.isRefund());
        }

        System.out.println("── 7. 특별세액공제가 표준 13만보다 큰 경우 ──");
        {
            YearCore.SettleIn in = new YearCore.SettleIn();
            in.gross = 60_000_000L;
            in.dependents = 4;
            in.children = 2;
            in.insurance = 3_000_000L;
            in.extraTaxCredit = 500_000L;
            YearCore.Settle s = YearCore.settle(in);
            check("특별세액공제 채택", s.usedSpecialCredit);
            check("적용 세액공제", s.appliedTaxCredit, 500_000L);
            check("세액공제 합계", s.creditTotal, 1_510_000L);
            check("결정세액", s.determinedTax, 2_967_500L);
            check("지방소득세", s.localTax, 296_750L);
        }

        System.out.println("── 8. 추가 소득공제 반영 ──");
        {
            YearCore.SettleIn in = new YearCore.SettleIn();
            in.gross = 60_000_000L;
            in.dependents = 4;
            in.children = 2;
            in.insurance = 3_000_000L;
            in.extraIncomeDeduction = 2_400_000L;      // 신용카드 소득공제 등
            YearCore.Settle s = YearCore.settle(in);
            check("과세표준 (3,825만 − 240만)", s.taxBase, 35_850_000L);
            check("산출세액", s.calculatedTax, 4_117_500L);
            check("결정세액", s.determinedTax, 2_977_500L);
            check("지방소득세", s.localTax, 297_750L);
        }

        System.out.println("── 9. 소액 급여(비과세 구간) ──");
        {
            YearCore.SettleIn in = new YearCore.SettleIn();
            in.gross = 8_000_000L;
            in.dependents = 1;
            in.children = 0;
            in.insurance = 700_000L;
            YearCore.Settle s = YearCore.settle(in);
            check("근로소득공제 (350만 + 300만×40%)", s.earnedDeduction, 4_700_000L);
            check("과세표준 (8M − 470만 − 150만 − 70만)", s.taxBase, 1_100_000L);
            check("산출세액 (6%)", s.calculatedTax, 66_000L);
            check("세액공제 합계 (36,300 + 표준 13만)", s.creditTotal, 166_300L);
            check("결정세액 0", s.determinedTax, 0);
            check("지방소득세 0", s.localTax, 0);
            check("기납부가 없으면 차액 0", s.settlement, 0L);
        }

        System.out.println("── 10. 절사 규칙 ──");
        check("과세표준 1,000원 미만 절사", YearCore.floor1000(38_250_999L), 38_250_000L);
        check("결정세액 10원 미만 절사", YearCore.floor10(3_337_517L), 3_337_510L);
        check("음수는 0", YearCore.floor10(-500L), 0);

        System.out.println("── 11. 연간 누적 집계 ──");
        {
            YearCore.MonthFigure[] ms = new YearCore.MonthFigure[13];
            for (int m = 1; m <= 12; m++) {
                YearCore.MonthFigure f = new YearCore.MonthFigure();
                f.month = m;
                f.hasData = (m <= 10);            // 1~10월 입력, 11~12월 미입력
                f.gross = 5_000_000L;
                f.incomeTax = 150_000L;
                f.localTax = 15_000L;
                f.pension = 225_000L;
                f.health = 177_250L;
                f.longterm = 22_954L;
                f.employ = 45_000L;
                f.unionFee = 46_000L;
                f.deduction = 681_204L;
                f.net = f.gross - f.deduction;
                f.lumpSum = (m == 9) ? 1_452_800L : 0;
                f.normalHours = 176;
                f.otHours = 34;
                f.holidayHours = 20;
                f.nightHours = (m <= 10 && m % 3 == 0) ? 63 : 0;
                f.paidHours = 248;
                f.gageubDays = 22;
                f.workDays = 22;
                ms[m] = f;
            }
            YearCore.Annual a = YearCore.annual(2026, ms);
            check("입력된 달 수", a.filledMonths, 10);
            check("마지막 입력 달", a.lastFilledMonth, 10);
            check("연간 세전 총지급액", a.gross, 50_000_000L);
            check("연간 기납부 소득세", a.incomeTax, 1_500_000L);
            check("연간 기납부 지방소득세", a.localTax, 150_000L);
            check("연간 4대보험 본인부담", a.insuranceTotal(), 4_702_040L);
            check("연간 공제 합계", a.deduction, 6_812_040L);
            check("연간 실수령액", a.net, 43_187_960L);
            check("연간 소급·일시금", a.lumpSum, 1_452_800L);
            check("연간 정취시간", (long) a.normalHours, 1_760L);
            check("연간 연장시간", (long) a.otHours, 340L);
            check("연간 휴일특근시간", (long) a.holidayHours, 200L);
            check("연간 출근일수", a.workDays, 220);
            check("보험료 합계 검산", a.pension + a.health + a.longterm + a.employ, 4_702_040L);
        }

        System.out.println("── 12. 화면 집계 → 연말정산 연결 ──");
        {
            YearCore.MonthFigure[] ms = new YearCore.MonthFigure[13];
            for (int m = 1; m <= 12; m++) {
                YearCore.MonthFigure f = new YearCore.MonthFigure();
                f.hasData = true;
                f.gross = 5_000_000L;
                f.incomeTax = 180_000L;
                f.localTax = 18_000L;
                f.pension = 225_000L;
                f.health = 177_250L;
                f.longterm = 22_954L;
                f.employ = 45_000L;
                f.deduction = 668_204L;
                f.net = f.gross - f.deduction;
                ms[m] = f;
            }
            YearCore.Annual a = YearCore.annual(2026, ms);
            YearCore.SettleIn in = new YearCore.SettleIn();
            in.gross = a.gross;
            in.dependents = 4;
            in.children = 2;
            in.insurance = a.insuranceTotal();
            in.prepaidIncomeTax = a.incomeTax;
            in.prepaidLocalTax = a.localTax;
            YearCore.Settle s = YearCore.settle(in);
            check("총급여 6,000만", s.gross, 60_000_000L);
            check("기납부 237.6만", s.prepaid, 2_376_000L);
            check("총부담 (4대보험 5,642,448원 반영)", s.totalBurden, 3_235_150L);
            check("차액 = 기납부 − 총부담", s.settlement, s.prepaid - s.totalBurden);
            check("추납 85.915만", s.settlement, -859_150L);
        }

        System.out.println(fail == 0
                ? "\n✅ 연간 누적 · 연말정산 예측 — 근로소득공제·기본세율·세액공제·환급 계산 전 항목 일치"
                : "\n❌ 불일치 " + fail + "건");
        if (fail != 0) System.exit(1);
    }
}
