package com.example.shiftpay;

import android.content.SharedPreferences;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Dependency-free XLSX writer/reader for ShiftPay backups and formal payroll reports. */
public final class ExcelBackup {
    private static final String NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

    private static String xml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static void put(ZipOutputStream z, String name, String value) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(value.getBytes("UTF-8"));
        z.closeEntry();
    }

    private static String cell(String address, String value) {
        return "<c r=\"" + address + "\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" + xml(value) + "</t></is></c>";
    }

    private static String col(int n) {
        String s = "";
        for (int i = n; i > 0; i = (i - 1) / 26) s = (char) ('A' + (i - 1) % 26) + s;
        return s;
    }

    private static String sheet(List<String[]> rows) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"" + NS + "\"><sheetData>");
        int r = 1;
        for (String[] row : rows) {
            s.append("<row r=\"").append(r).append("\">");
            for (int c = 0; c < row.length; c++) {
                s.append(cell(col(c + 1) + r, row[c] == null ? "" : row[c]));
            }
            s.append("</row>");
            r++;
        }
        return s.append("</sheetData></worksheet>").toString();
    }

    public static void write(OutputStream out, SharedPreferences prefs) throws IOException {
        TreeMap<String, ?> sorted = new TreeMap<>(prefs.getAll());
        List<String[]> records = new ArrayList<>(), settings = new ArrayList<>(), meta = new ArrayList<>();
        records.add(new String[]{"키", "값"});
        settings.add(new String[]{"키", "값"});
        meta.add(new String[]{"항목", "값"});
        meta.add(new String[]{"파일형식", "ShiftPay-XLSX-1"});
        meta.add(new String[]{"앱버전", MainActivity.CURRENT_VERSION_NAME});
        meta.add(new String[]{"백업시각", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREA).format(new Date())});

        for (Map.Entry<String, ?> e : sorted.entrySet()) {
            Object val = e.getValue();
            if (val == null) continue;
            String strVal = (val instanceof String) ? (String) val : String.valueOf(val);
            String k = e.getKey();
            (k.startsWith("setting_") || k.startsWith("user_") || k.startsWith("retro_") || "onboarding_shown".equals(k) ? settings : records).add(new String[]{k, strVal});
        }

        ZipOutputStream z = new ZipOutputStream(out);
        put(z, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet3.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
        put(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        put(z, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"" + NS + "\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"근무기록\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"급여설정\" sheetId=\"2\" r:id=\"rId2\"/><sheet name=\"백업정보\" sheetId=\"3\" r:id=\"rId3\"/></sheets></workbook>");
        put(z, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/><Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet3.xml\"/></Relationships>");
        put(z, "xl/worksheets/sheet1.xml", sheet(records));
        put(z, "xl/worksheets/sheet2.xml", sheet(settings));
        put(z, "xl/worksheets/sheet3.xml", sheet(meta));
        z.finish();
        z.flush();
    }

    public static void writePayrollReport(OutputStream out, String ym, String userInfo, List<String[]> dailyRows, String[] totalRow, List<String[]> cardRows, List<String[]> payRows, List<String[]> summaryRows, SharedPreferences prefs) throws IOException {
        List<String[]> report = new ArrayList<>();
        report.add(new String[]{"현대스틸파이프 나의 근무·급여 관리 (ShiftPay) - " + ym + " 급여명세서 및 근무대장"});
        report.add(new String[]{userInfo});
        report.add(new String[]{""});
        // ① 일자별 출근대장
        report.add(new String[]{"【 1. 일자별 상세 근무 현황표 】"});
        report.add(new String[]{"일자", "요일", "근무구분", "정상(h)", "평일연장(h)", "휴일특근(h)", "휴일가급(h)", "야간근로(h)", "비고"});
        report.addAll(dailyRows);
        report.add(totalRow);
        report.add(new String[]{""});
        // ② 출근카드 1:1 월간 집계 & 근무 통계 요약
        report.add(new String[]{"【 2. 출근카드 1:1 월간 집계 & 근무 통계 요약 】"});
        report.addAll(cardRows);
        report.add(new String[]{""});
        // ③ 단체협약 급여 수당별 상세 산출 계산식
        report.add(new String[]{"【 3. 단체협약 급여 수당별 상세 산출 계산식 】"});
        report.addAll(payRows);
        report.add(new String[]{""});
        // ④ 최종 정산 요약
        report.add(new String[]{"【 4. 최종 정산 요약 】"});
        report.addAll(summaryRows);

        // 데이터 백업 시트 (동시 복원 가능하도록 SharedPreferences 덤프 포함)
        TreeMap<String, ?> sorted = new TreeMap<>(prefs.getAll());
        List<String[]> records = new ArrayList<>();
        records.add(new String[]{"키", "값"});
        for (Map.Entry<String, ?> e : sorted.entrySet()) {
            Object val = e.getValue();
            if (val == null) continue;
            String strVal = (val instanceof String) ? (String) val : String.valueOf(val);
            records.add(new String[]{e.getKey(), strVal});
        }

        ZipOutputStream z = new ZipOutputStream(out);
        put(z, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
        put(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        put(z, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"" + NS + "\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"급여명세서\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"데이터백업\" sheetId=\"2\" r:id=\"rId2\"/></sheets></workbook>");
        put(z, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/></Relationships>");
        put(z, "xl/worksheets/sheet1.xml", sheet(report));
        put(z, "xl/worksheets/sheet2.xml", sheet(records));
        z.finish();
        z.flush();
    }

    private static Document doc(byte[] data) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Throwable ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Throwable ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Throwable ignored) {}
        return f.newDocumentBuilder().parse(new ByteArrayInputStream(data));
    }

    private static List<String[]> rows(byte[] data) throws Exception {
        List<String[]> list = new ArrayList<>();
        NodeList nodes = doc(data).getElementsByTagNameNS(NS, "row");
        for (int i = 0; i < nodes.getLength(); i++) {
            NodeList cs = ((Element) nodes.item(i)).getElementsByTagNameNS(NS, "c");
            String[] row = {"", ""};
            for (int j = 0; j < cs.getLength(); j++) {
                Element c = (Element) cs.item(j);
                String ref = c.getAttribute("r");
                int ix = ref.startsWith("A") ? 0 : ref.startsWith("B") ? 1 : -1;
                if (ix < 0) continue;
                NodeList t = c.getElementsByTagNameNS(NS, "t");
                if (t.getLength() > 0) row[ix] = t.item(0).getTextContent();
            }
            list.add(row);
        }
        return list;
    }

    public static Map<String, String> read(InputStream in) throws Exception {
        Map<String, byte[]> parts = new HashMap<>();
        ZipInputStream z = new ZipInputStream(in);
        ZipEntry e;
        int total = 0;
        while ((e = z.getNextEntry()) != null) {
            if (e.isDirectory()) continue;
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = z.read(buf)) != -1) {
                total += n;
                if (total > 5_000_000) throw new IOException("백업 파일 크기 제한 초과");
                b.write(buf, 0, n);
            }
            parts.put(e.getName(), b.toByteArray());
        }

        // 3시트 전체 백업(sheet1: 근무기록, sheet2: 급여설정 및 사용자정보)과 2시트 명세서 백업 완벽 동시 지원
        List<String> targetSheets = new ArrayList<>();
        if (parts.containsKey("xl/worksheets/sheet3.xml")) {
            // 3시트 백업: sheet1(근무기록)과 sheet2(급여설정·사용자정보)를 모두 읽어 온전히 합침
            if (parts.containsKey("xl/worksheets/sheet1.xml")) targetSheets.add("xl/worksheets/sheet1.xml");
            if (parts.containsKey("xl/worksheets/sheet2.xml")) targetSheets.add("xl/worksheets/sheet2.xml");
        } else if (parts.containsKey("xl/worksheets/sheet2.xml")) {
            // 2시트 명세서 백업: sheet2에 전체 백업 덤프가 존재
            targetSheets.add("xl/worksheets/sheet2.xml");
        } else if (parts.containsKey("xl/worksheets/sheet1.xml")) {
            targetSheets.add("xl/worksheets/sheet1.xml");
        }

        if (targetSheets.isEmpty()) throw new IOException("앱 백업 파일이 아닙니다");

        Map<String, String> result = new LinkedHashMap<>();
        for (String sheetPath : targetSheets) {
            byte[] data = parts.get(sheetPath);
            if (data == null) continue;
            List<String[]> rr = rows(data);
            for (int j = 1; j < rr.size(); j++) {
                String k = rr.get(j)[0], v = rr.get(j)[1];
                if (!k.matches("(setting_[A-Za-z0-9_]*|user_[A-Za-z0-9_]*|retro_[A-Za-z0-9_\\-]*|onboarding_shown|[0-9]{4}-[0-9]{2}-[0-9]{2}-[A-Za-z0-9_\\-]*|holiday_[0-9]{8})")) continue;
                result.put(k, v);
            }
        }
        if (result.isEmpty()) throw new IOException("복원할 데이터가 없습니다");
        return result;
    }
}
