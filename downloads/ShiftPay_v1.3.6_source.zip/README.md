# 현대스틸파이프 나의 근무·급여 관리 (ShiftPay) v1.3.6

교대근무자 및 일반직·기술직 임직원을 위한 실시간 근무 일정, 수당·단협 급여 자동 연산, 출근카드 및 급여명세서 스마트 OCR 대조, 엑셀 명세서 보고서 출력을 제공하는 안드로이드 앱입니다.

## 주요 기능
- **스마트 교대근무 캘린더**: 주간, 평일연장, 휴일특근, 연차 등 원터치 프리셋 입력 및 일괄/선택 삭제
- **2026 단체협약 급여 산출**: 기본시급, 통상시급, 연도별 임단협 시급 분리 관리, 직책수당, 하계건강지원비, 소급분 및 세전·세후 실수령액 실시간 정산
- **만 60세 정년 D-Day & 근속연차 계산**: 생년월일 및 입사일 기반 D-Day 카운트다운 및 잔여 연차 실시간 차감 추적
- **스마트 OCR 엔진 (ML Kit)**:
  - 종이 출근카드 자동 인식 및 날짜별 근무시간 일괄 저장
  - 급여명세서 촬영 인식, 앱 계산값과의 1:1 대조 및 잔여 연차/시급 원터치 역산 동기화
- **정규 엑셀 보고서 출력 및 백업**:
  - 1일~31일 일자별 근무현황표 및 단협 급여산출 영수증이 정리된 정식 엑셀 서식 파일 생성
  - SharedPreferences 전체 데이터(설정, 프로필, 근무기록, 사용자 휴일) 100% 백업 및 복원
- **공휴일 자동 탑재**: 대한민국 공식 공휴일, 대체공휴일, 노조창립일(4/19), 회사창립일(10/18) 순차 대체휴무 자동 지원

## 프로젝트 구조
- `app/src/main/java/com/example/shiftpay/MainActivity.java`: 메인 캘린더, 급여 정산, OCR 파서, UI 인터페이스
- `app/src/main/java/com/example/shiftpay/PayCore.java`: 단협 급여 계산 코어 (데스크톱 JVM 단위 검증용, 안드로이드 비의존)
- `app/src/main/java/com/example/shiftpay/DeductionCore.java`: 공제액 정밀 예측 코어 (4대보험 법정 요율 · 소득세 간이세액표 · 노조회비 공식 · 표준세액공제 세액공제 단계)
- `app/src/main/java/com/example/shiftpay/HolidayCore.java`: 단체협약 제52조 유급휴일·대체휴무 배정 코어 (2027~2028년 단위 검증)
- `app/src/main/java/com/example/shiftpay/ExcelBackup.java`: OOXML 엑셀 보고서 생성 및 3시트 전체 백업/복원 엔진 (sharedStrings·숫자셀 호환)
- `app/src/main/assets/`: 2026 단협 규정집, 사내 협약업체 목록, 지원제도 안내서

## 단위 테스트 (데스크톱 JVM)
`test/` — `PayCoreOctoberTest`(10월 실물 명세서 1원 대조) · `DeductionCoreTest`(공제 6항목) · `PayslipParserTest`(명세서 OCR 9종) · `TestExcelFourSection`(엑셀 4단 서식) · `HolidaySubstituteTest`(2027~2028 대체휴무) · `ExcelDeductionRestoreTest`(공제 설정 왕복 복원)

## GitHub Actions
`.github/workflows/build-apk.yml`을 통해 main 브랜치 푸시 또는 수동 트리거로 Debug APK를 자동 빌드할 수 있습니다.
