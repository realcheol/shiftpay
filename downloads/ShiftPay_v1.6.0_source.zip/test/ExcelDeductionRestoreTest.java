import com.example.shiftpay.ExcelBackup;

import android.content.SharedPreferences;

import java.io.*;
import java.lang.reflect.Proxy;
import java.util.*;

/**
 * v1.3.6 ⑥ — 엑셀 백업 왕복 복원 테스트 (공제 설정 ded_* 포함).
 *
 * ① 앱 → 엑셀 쓰기: ded_auto(Boolean)·ded_dependents(Int)·ded_advance_rate(Float)·ded_l_*(Long) 가
 *    모두 백업 파일에 실려야 한다.
 * ② 엑셀 → 앱 읽기: 허용 키 정규식이 ded_* 를 통과시켜야 한다.
 * ③ 복원 저장: ded_l_* = Long, ded_auto = Boolean, ded_dependents = Int, ded_advance_rate = Float
 *    로 원래 자료형이 보존되어야 한다.
 */
public class ExcelDeductionRestoreTest {
    static int fail = 0;

    static void check(String name, Object got, Object want) {
        boolean ok = (got == null ? want == null : got.equals(want));
        if (!ok) fail++;
        System.out.printf("%-46s 값 %-16s 기대 %-16s %s%n", name, String.valueOf(got), String.valueOf(want), ok ? "OK" : "FAIL");
    }

    /** 자료형까지 기록하는 가짜 SharedPreferences.Editor (Sink 검증용) */
    static class FakeSink implements ExcelBackup.Sink {
        final Map<String, Object> store = new LinkedHashMap<>();
        final Map<String, String> types = new LinkedHashMap<>();
        public void putString(String k, String v) { store.put(k, v); types.put(k, "String"); }
        public void putInt(String k, int v) { store.put(k, v); types.put(k, "Integer"); }
        public void putLong(String k, long v) { store.put(k, v); types.put(k, "Long"); }
        public void putFloat(String k, float v) { store.put(k, v); types.put(k, "Float"); }
        public void putBoolean(String k, boolean v) { store.put(k, v); types.put(k, "Boolean"); }
    }

    public static void main(String[] args) throws Exception {
        Map<String, Object> store = new LinkedHashMap<>();
        store.put("setting_base", "13653");
        store.put("setting_ordinary", "14939");
        store.put("setting_duty", "55000");
        store.put("ded_auto", Boolean.TRUE);
        store.put("ded_dependents", "2");
        store.put("ded_advance_rate", "1.0");
        store.put("ded_pension_base", "5262924");
        store.put("ded_health_base", "5262924");
        store.put("ded_l_total", 838690L);
        store.put("ded_l_gross", 5262924L);
        store.put("ded_l_income", 206810L);
        store.put("ded_l_local", 20680L);
        store.put("ded_l_health", 274300L);
        store.put("ded_l_pension", 245000L);
        store.put("ded_l_employ", 45900L);
        store.put("ded_l_union", 46000L);
        store.put("retro_fixed_amount", 1452800);
        store.put("retro_active_2026-11", Boolean.TRUE);
        store.put("2026-10-01-mode", "work");
        store.put("2026-10-01-normal", "8");

        SharedPreferences prefs = (SharedPreferences) Proxy.newProxyInstance(
                ExcelDeductionRestoreTest.class.getClassLoader(),
                new Class[]{SharedPreferences.class},
                (p, m, a) -> {
                    if ("getAll".equals(m.getName())) return new TreeMap<>(store);
                    Class<?> r = m.getReturnType();
                    if (r == boolean.class) return false;
                    if (r == int.class) return 0;
                    if (r == long.class) return 0L;
                    if (r == float.class) return 0f;
                    if (r == String.class) return a != null && a.length > 1 ? a[1] : null;
                    return null;
                });

        // 외부 환경 이식성: 고정 경로 대신 JVM 임시 폴더(java.io.tmpdir) 아래에 출력한다
        File dir = new File(System.getProperty("java.io.tmpdir"), "shiftpay_test");
        dir.mkdirs();
        File f = new File(dir, "ShiftPay_v136_백업검증.xlsx");
        try (OutputStream out = new FileOutputStream(f)) {
            ExcelBackup.write(out, prefs);
        }
        System.out.println("백업 파일: " + f.getAbsolutePath() + " (" + f.length() + " bytes)");

        Map<String, String> back;
        try (InputStream in = new FileInputStream(f)) {
            back = ExcelBackup.read(in);
        }
        System.out.println("\n[1. 엑셀 백업 → 다시 읽기]");
        check("ded_auto 포함", back.containsKey("ded_auto"), true);
        check("ded_dependents 포함", back.get("ded_dependents"), "2");
        check("ded_advance_rate 포함", back.get("ded_advance_rate"), "1.0");
        check("ded_l_total 포함", back.get("ded_l_total"), "838690");
        check("ded_l_gross 포함", back.get("ded_l_gross"), "5262924");
        for (String k : new String[]{"ded_l_income", "ded_l_local", "ded_l_health", "ded_l_pension", "ded_l_employ", "ded_l_union"}) {
            check(k + " 포함", back.containsKey(k), true);
        }
        check("setting_base 포함", back.get("setting_base"), "13653");
        check("근무기록 포함", back.get("2026-10-01-normal"), "8");
        check("허용 외 키는 제외", back.containsKey("evil_key"), false);

        System.out.println("\n[2. 복원 시 자료형 보존]");
        FakeSink sink = new FakeSink();
        ExcelBackup.restoreInto(back, sink);
        check("ded_auto 자료형", sink.types.get("ded_auto"), "Boolean");
        check("ded_l_total 자료형", sink.types.get("ded_l_total"), "Long");
        check("ded_l_union 자료형", sink.types.get("ded_l_union"), "Long");
        check("ded_dependents 자료형", sink.types.get("ded_dependents"), "Integer");
        check("ded_advance_rate 자료형", sink.types.get("ded_advance_rate"), "Float");
        check("ded_pension_base 자료형", sink.types.get("ded_pension_base"), "Long");
        check("setting_base 자료형", sink.types.get("setting_base"), "String");
        check("retro_active_* 자료형", sink.types.get("retro_active_2026-11"), "Boolean");
        check("ded_l_total 값", sink.store.get("ded_l_total"), 838690L);
        check("ded_dependents 값", sink.store.get("ded_dependents"), 2);
        check("ded_advance_rate 값", sink.store.get("ded_advance_rate"), 1.0f);
        check("ded_auto 값", sink.store.get("ded_auto"), Boolean.TRUE);

        // 엑셀에서 사람이 열었다 저장해 '문자열'로 바뀐 값도 잃지 않고 복원된다
        System.out.println("\n[3. 엑셀 편집 후 문자열화된 값 복원]");
        Map<String, String> edited = new LinkedHashMap<>();
        edited.put("ded_l_total", "838,690");
        edited.put("ded_auto", "true");
        edited.put("ded_dependents", "3");
        edited.put("ded_advance_rate", "1.2");
        edited.put("ded_health_base", "");
        FakeSink s2 = new FakeSink();
        ExcelBackup.restoreInto(edited, s2);
        check("콤마 포함 Long", s2.store.get("ded_l_total"), 838690L);
        check("부양가족 문자열→Int", s2.store.get("ded_dependents"), 3);
        check("빈 기준액은 문자열로 보존", s2.types.get("ded_health_base"), "String");

        System.out.println(fail == 0 ? "\n✅ 엑셀 왕복 복원(공제 설정 포함) 전 항목 통과" : "\n❌ 실패 " + fail + "건");
        if (fail > 0) System.exit(1);
    }
}
