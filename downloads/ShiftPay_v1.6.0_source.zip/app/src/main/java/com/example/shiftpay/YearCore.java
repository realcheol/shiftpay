package com.example.shiftpay;

/**
 * v1.6.0 ③ — 연간 누적 집계 · 연말정산 예측 코어 (안드로이드 비의존).
 *
 * 이 코어는 두 가지만 한다. 달마다 이미 계산된 금액을 받아 '연간'으로 더하고,
 * 그 연간 총급여에 현행 소득세법(2026년 기준)을 적용해 2월 연말정산 결과를 예측한다.
 *
 *  ── 연간 누적 ──
 *    화면은 1~12월 각 달을 PayCore.amounts() + DeductionCore.compute() 로 계산해
 *    MonthFigure 로 넘긴다. 이 코어는 세전·기납부세액·4대보험·실수령·근로시간을 합산한다.
 *
 *  ── 연말정산 예측 ──
 *    ① 근로소득공제      총급여 500만 이하 70% / 1,500만 40% / 4,500만 15% / 1억 5% / 초과 2%
 *    ② 종합소득공제      인적공제(부양가족 × 150만) + 4대보험 본인부담 연간액 + 추가 소득공제
 *    ③ 과세표준          총급여 − ① − ②   (1,000원 미만 절사)
 *    ④ 산출세액          기본세율 6/15/24/35/38/40/42/45%
 *    ⑤ 세액공제          근로소득세액공제(130만 이하 55% · 초과분 30%, 한도 74/66/50만)
 *                        + 자녀세액공제(1명 15만 · 2명 35만 · 3명+ 35만 + 초과 1명당 30만)
 *                        + 표준세액공제 13만 (입력한 특별세액공제와 자동 비교해 유리한 쪽)
 *    ⑥ 결정세액          max(0, ④ − ⑤)   (10원 미만 절사)
 *    ⑦ 지방소득세        결정세액 × 10%   (10원 미만 절사)
 *    ⑧ 환급/추납         연간 기납부(소득세+지방소득세) − (⑥ + ⑦)
 *
 * 같은 공식을 웹(index.html 의 yearCoreSettle)이 그대로 옮겨 써서 1원까지 같은 결과를 낸다.
 * 참고용 시뮬레이션이며, 실제 연말정산은 회사·국세청 확정 자료를 따른다.
 */
public final class YearCore {

    private YearCore() {}

    // ── 인적공제 ─────────────────────────────────────────────────────
    public static final long PERSONAL_DEDUCTION_PER_DEPENDENT = 1_500_000L;
    /** 표준세액공제 — 특별세액공제를 받지 않을 때 13만 원 */
    public static final long STANDARD_TAX_CREDIT = 130_000L;

    // ── 한 달치 집계 ──────────────────────────────────────────────────
    public static final class MonthFigure {
        public int month;
        public boolean hasData;
        public long gross;              // 세전 총지급액
        public long incomeTax;          // 기납부 소득세
        public long localTax;           // 기납부 지방소득세
        public long pension;            // 국민연금 (본인부담)
        public long health;             // 건강보험
        public long longterm;           // 장기요양보험
        public long employ;             // 고용보험
        public long unionFee;           // 노조회비
        public long deduction;          // 공제 합계 (위 6항목 + 노조회비)
        public long net;                // 실수령액
        public long lumpSum;            // 그 달에 포함된 소급·성과격려금 등 일시금
        public double normalHours;      // 정취
        public double otHours;          // 연장
        public double holidayHours;     // 휴일근로 + 휴일연장 (실제 특근시간)
        public double nightHours;       // 심야(교대조는 1일 7h 기준)
        public double paidHours;        // 급여 인정시간 (기본+연장+특근+가급)
        public double gageubDays;       // 상주휴게(가급) 일수
        public int workDays;            // 출근일수
    }

    // ── 연간 합계 ────────────────────────────────────────────────────
    public static final class Annual {
        public int year;
        public MonthFigure[] months = new MonthFigure[13];   // index 1..12
        public int filledMonths;
        public long gross, incomeTax, localTax, pension, health, longterm, employ, unionFee, deduction, net, lumpSum;
        public double normalHours, otHours, holidayHours, nightHours, paidHours, gageubDays;
        public int workDays;
        /** 그 해에 입력이 있는 마지막 달 (없으면 0) */
        public int lastFilledMonth;
        /** 4대보험 본인부담 연간 합계 */
        public long insuranceTotal() { return pension + health + longterm + employ; }
    }

    /** 12개월 집계 (months 는 index 1..12, null 허용) */
    public static Annual annual(int year, MonthFigure[] months) {
        Annual a = new Annual();
        a.year = year;
        for (int m = 1; m <= 12; m++) {
            MonthFigure f = (months != null && m < months.length) ? months[m] : null;
            if (f == null) {
                f = new MonthFigure();
                f.month = m;
                f.hasData = false;
            }
            f.month = m;
            a.months[m] = f;
            if (!f.hasData) continue;
            a.filledMonths++;
            a.lastFilledMonth = m;
            a.gross += f.gross;
            a.incomeTax += f.incomeTax;
            a.localTax += f.localTax;
            a.pension += f.pension;
            a.health += f.health;
            a.longterm += f.longterm;
            a.employ += f.employ;
            a.unionFee += f.unionFee;
            a.deduction += f.deduction;
            a.net += f.net;
            a.lumpSum += f.lumpSum;
            a.normalHours += f.normalHours;
            a.otHours += f.otHours;
            a.holidayHours += f.holidayHours;
            a.nightHours += f.nightHours;
            a.paidHours += f.paidHours;
            a.gageubDays += f.gageubDays;
            a.workDays += f.workDays;
        }
        return a;
    }

    // ── 연말정산 ──────────────────────────────────────────────────────
    public static final class SettleIn {
        /** 연간 총급여 (월별 세전 합계 + 연간 추가 지급액) */
        public long gross;
        /** 공제대상 부양가족 수 (본인 포함, 최소 1) */
        public int dependents = 1;
        /** 8~20세 자녀 수 */
        public int children = 0;
        /** 4대보험 본인부담 연간 합계 */
        public long insurance;
        /** 추가 소득공제 (신용카드·주택자금 등, 사용자가 금액으로 입력) */
        public long extraIncomeDeduction;
        /** 특별세액공제 (의료비·연금저축·교육비 등) — 표준세액공제 13만과 자동 비교 */
        public long extraTaxCredit;
        /** 연간 기납부 소득세 */
        public long prepaidIncomeTax;
        /** 연간 기납부 지방소득세 */
        public long prepaidLocalTax;
    }

    public static final class Settle {
        public long gross;
        public long earnedDeduction;      // 근로소득공제
        public long personalDeduction;    // 인적공제
        public long insuranceDeduction;   // 4대보험 소득공제
        public long extraDeduction;       // 추가 소득공제
        public long totalDeduction;       // 소득공제 합계 (근로소득공제 제외)
        public long taxBase;              // 과세표준
        public long calculatedTax;        // 산출세액
        public long earnedTaxCredit;      // 근로소득세액공제
        public long childTaxCredit;       // 자녀세액공제
        public long standardTaxCredit;    // 표준세액공제 (13만, 비교용)
        public long appliedTaxCredit;     // 실제 적용한 표준/특별세액공제
        public boolean usedSpecialCredit; // 표준 대신 특별세액공제를 썼는지
        public long creditTotal;          // 세액공제 합계
        public long determinedTax;        // 결정세액 (소득세)
        public long localTax;             // 지방소득세
        public long totalBurden;          // 총 부담 (결정세액 + 지방소득세)
        public long prepaid;              // 연간 기납부 (소득세 + 지방소득세)
        public long settlement;           // 기납부 − 총부담  (양수 = 환급, 음수 = 추가납부)
        public double effectiveRate;      // 실효세율 (총부담 ÷ 총급여)

        public boolean isRefund() { return settlement >= 0; }
    }

    /** 근로소득공제 — 소득세법 제47조 */
    public static long earnedIncomeDeduction(long gross) {
        if (gross <= 0) return 0;
        if (gross <= 5_000_000L) return (long) (gross * 0.70);
        if (gross <= 15_000_000L) return 3_500_000L + (long) ((gross - 5_000_000L) * 0.40);
        if (gross <= 45_000_000L) return 7_500_000L + (long) ((gross - 15_000_000L) * 0.15);
        if (gross <= 100_000_000L) return 12_000_000L + (long) ((gross - 45_000_000L) * 0.05);
        return 14_750_000L + (long) ((gross - 100_000_000L) * 0.02);
    }

    /** 기본세율 — 소득세법 제55조 제1항 (2026년 기준) */
    public static long basicTaxRate(long taxBase) {
        if (taxBase <= 0) return 0;
        if (taxBase <= 14_000_000L) return (long) (taxBase * 0.06);
        if (taxBase <= 50_000_000L) return 840_000L + (long) ((taxBase - 14_000_000L) * 0.15);
        if (taxBase <= 88_000_000L) return 6_240_000L + (long) ((taxBase - 50_000_000L) * 0.24);
        if (taxBase <= 150_000_000L) return 15_360_000L + (long) ((taxBase - 88_000_000L) * 0.35);
        if (taxBase <= 300_000_000L) return 37_060_000L + (long) ((taxBase - 150_000_000L) * 0.38);
        if (taxBase <= 500_000_000L) return 94_060_000L + (long) ((taxBase - 300_000_000L) * 0.40);
        if (taxBase <= 1_000_000_000L) return 174_060_000L + (long) ((taxBase - 500_000_000L) * 0.42);
        return 384_060_000L + (long) ((taxBase - 1_000_000_000L) * 0.45);
    }

    /**
     * 근로소득세액공제 — 소득세법 제59조.
     *  산출세액 130만 원 이하 55%, 초과분 30%. 총급여 3,300만 이하 74만 / 7,000만 이하 66만 / 초과 50만 한도.
     */
    public static long earnedIncomeTaxCredit(long calculatedTax, long gross) {
        if (calculatedTax <= 0) return 0;
        double credit;
        if (calculatedTax <= 1_300_000L) {
            credit = calculatedTax * 0.55;
        } else {
            credit = 1_300_000L * 0.55 + (calculatedTax - 1_300_000L) * 0.30;
        }
        long limit;
        if (gross <= 33_000_000L) limit = 740_000L;
        else if (gross <= 70_000_000L) limit = 660_000L;
        else limit = 500_000L;
        return Math.min((long) credit, limit);
    }

    /** 자녀세액공제 — 소득세법 제59조의2 (8세 이상 20세 이하) */
    public static long childTaxCreditOf(int children) {
        if (children <= 0) return 0;
        if (children == 1) return 150_000L;
        if (children == 2) return 350_000L;
        return 350_000L + (children - 2) * 300_000L;
    }

    /** 1,000원 미만 절사 (과세표준) */
    public static long floor1000(long v) {
        if (v <= 0) return 0;
        return (v / 1000L) * 1000L;
    }

    /** 10원 미만 절사 (결정세액·지방소득세) */
    public static long floor10(long v) {
        if (v <= 0) return 0;
        return (v / 10L) * 10L;
    }

    public static Settle settle(SettleIn in) {
        if (in == null) in = new SettleIn();
        Settle s = new Settle();
        s.gross = Math.max(0, in.gross);

        s.earnedDeduction = earnedIncomeDeduction(s.gross);
        int dep = Math.max(1, in.dependents);
        s.personalDeduction = dep * PERSONAL_DEDUCTION_PER_DEPENDENT;
        s.insuranceDeduction = Math.max(0, in.insurance);
        s.extraDeduction = Math.max(0, in.extraIncomeDeduction);
        s.totalDeduction = s.personalDeduction + s.insuranceDeduction + s.extraDeduction;

        long base = s.gross - s.earnedDeduction - s.totalDeduction;
        s.taxBase = floor1000(Math.max(0, base));

        s.calculatedTax = basicTaxRate(s.taxBase);
        s.earnedTaxCredit = earnedIncomeTaxCredit(s.calculatedTax, s.gross);
        s.childTaxCredit = childTaxCreditOf(Math.max(0, Math.min(20, in.children)));
        s.standardTaxCredit = STANDARD_TAX_CREDIT;
        long special = Math.max(0, in.extraTaxCredit);
        s.usedSpecialCredit = special > STANDARD_TAX_CREDIT;
        s.appliedTaxCredit = Math.max(STANDARD_TAX_CREDIT, special);

        s.creditTotal = s.earnedTaxCredit + s.childTaxCredit + s.appliedTaxCredit;
        s.determinedTax = floor10(Math.max(0, s.calculatedTax - s.creditTotal));
        s.localTax = floor10((long) Math.floor(s.determinedTax * 0.10));
        s.totalBurden = s.determinedTax + s.localTax;

        s.prepaid = Math.max(0, in.prepaidIncomeTax) + Math.max(0, in.prepaidLocalTax);
        s.settlement = s.prepaid - s.totalBurden;
        s.effectiveRate = s.gross > 0 ? (double) s.totalBurden / s.gross : 0;
        return s;
    }

    /**
     * 연말정산 입력값에 넣을 '연간 추가 지급액' 기본값.
     * 각 달 급여에 이미 포함된 소급·성과격려금·하계지원비를 더한 값 — 사용자가 직접 가감할 수 있다.
     */
    public static long lumpSumTotal(Annual a) {
        return a == null ? 0 : a.lumpSum;
    }
}
