import com.example.shiftpay.PayslipReviewCore;

/**
 * v1.4.3 ④ 급여명세서 인식 검토·교정 코어 검증.
 *
 * 교대조 실물 명세서에서 실제로 났던 두 유형(야간수당 가운데 0 탈락 506,898 → 56,898,
 * 지급총액 앞자리 누락 5,262,924 → 262,924)을 그대로 넣어 원복되는지 확인하고,
 * 정상 금액은 건드리지 않는지(오탐 0)까지 본다.
 */
public class PayslipReviewCoreTest {
    static int fail = 0;

    static void check(String name, long got, long want) {
        boolean ok = got == want;
        if (!ok) fail++;
        System.out.printf("%-40s 값 %,12d  기대 %,12d  %s%n", name, got, want, ok ? "OK" : "FAIL");
    }

    public static void main(String[] args) {
        System.out.println("[1. 사내 단협 공식 야간수당]");
        check("16,092원 × 63.0h × 0.5", PayslipReviewCore.nightPay(16092, 63.0), 506898);
        check("14,939원 × 63.0h × 0.5", PayslipReviewCore.nightPay(14939, 63.0), 470579);
        check("시급 0원이면 0", PayslipReviewCore.nightPay(0, 63.0), 0);

        System.out.println("\n[2. 자릿수 누락 복원]");
        check("야간 506,898 → 56,898", PayslipReviewCore.restoreDroppedDigits(56898, 506898), 506898);
        check("지급총액 5,262,924 → 262,924", PayslipReviewCore.restoreDroppedDigits(262924, 5262924), 5262924);
        check("공제 838,690 → 38,690", PayslipReviewCore.restoreDroppedDigits(38690, 838690), 838690);
        check("정상값은 복원 대상 아님", PayslipReviewCore.restoreDroppedDigits(506898, 506898), -1);
        check("끝자리가 다르면 복원 안 함", PayslipReviewCore.restoreDroppedDigits(56897, 506898), -1);

        System.out.println("\n[3. 이상치 판정과 원터치 제안]");
        check("정상값에는 칩 없음", PayslipReviewCore.suggest(506898, 506898, true), -1);
        check("탈락값 → 복원값 제안", PayslipReviewCore.suggest(56898, 506898, true), 506898);
        check("큰 오차 → 기대값 제안", PayslipReviewCore.suggest(56000, 506898, true), 506898);
        check("2% 이내는 이상치 아님", PayslipReviewCore.isOutlier(507000, 506898) ? 1 : 0, 0);
        check("2% 초과는 이상치", PayslipReviewCore.isOutlier(520000, 506898) ? 1 : 0, 1);
        check("총액은 오차만으로 제안하지 않음", PayslipReviewCore.suggest(5000000, 5262924, false), -1);

        System.out.println();
        if (fail == 0) System.out.println("✅ 명세서 검토·교정 코어 전 항목 일치");
        else System.out.println("❌ 실패 " + fail + "건");
        System.exit(fail == 0 ? 0 : 1);
    }
}
