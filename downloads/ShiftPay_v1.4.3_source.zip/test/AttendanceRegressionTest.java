import com.example.shiftpay.AttendanceCore;
import com.example.shiftpay.PayCore;

import java.time.LocalDate;
import java.util.*;

/**
 * v1.4.3 재빌드 ⑧ — 3사 교차검증에서 나온 5대 결함 가운데 4가지의 회귀 테스트.
 *
 *  ① 월 전체 초기화 · 선택 일괄 입력/삭제에서 근태 키(att·atth)가 남던 결함
 *     → 하루치 정리 키 목록(AttendanceCore.dayWipeKeys)으로 실제 저장소를 비워 확인한다.
 *  ② 일반 프리셋·공식 근태 적용 시 수동 주차(weekly)·가급(gageub)이 남던 결함
 *     → AttendanceCore.staleInputKeys 로 비운 뒤 급여 코어 집계가 요일 자동 인정과 겹치지 않는지 확인.
 *  ③ 경조(축하·기복)·공무/포상에서 4h 를 골라도 8h 로 고정되던 결함
 *     → AttendanceCore.spec 의 유급 인정시간이 고른 시간 그대로인지 확인.
 *  ④ 토·공휴일(유급휴일)에 8h+설명회를 넣으면 유급 8h 와 정상 8h 가 겹쳐 16h 가 되던 결함
 *     → 유급휴일에는 정상 0 + 설명회 시간만 남아 기본급 인정이 10h 인지 확인.
 *
 * 앱의 저장소(SharedPreferences / localStorage)는 데스크톱 JVM 에서 실행할 수 없으므로,
 * 같은 키 규약을 가진 Map 으로 하루치 상태를 재현하고 '앱이 실제로 호출하는 코어'를 그대로 쓴다.
 */
public class AttendanceRegressionTest {

    static int fail = 0;

    static void check(String name, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) < 0.0001;
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name
                + " → " + fmt(actual) + (ok ? "" : " (기대값 " + fmt(expected) + ")"));
    }

    static void checkStr(String name, String actual, String expected) {
        boolean ok = expected.equals(actual);
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name
                + " → \"" + actual + "\"" + (ok ? "" : " (기대값 \"" + expected + "\")"));
    }

    static void checkBool(String name, boolean actual, boolean expected) {
        boolean ok = (actual == expected);
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name + " → " + actual);
    }

    static String fmt(double v) {
        return (v == (long) v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    // ── 2026년 11월 하루치 저장소 시뮬레이션 ────────────────────────────
    static final int YEAR = 2026, MONTH = 11, DAYS = 30;
    static Map<Integer, Map<String, String>> store = new TreeMap<>();
    static final Set<Integer> HOLIDAYS = new HashSet<>();

    static Map<String, String> day(int d) {
        return store.computeIfAbsent(d, k -> new LinkedHashMap<>());
    }

    static void set(int d, String suffix, String value) {
        day(d).put(suffix, value);
    }

    /** 이번 달을 무급(none)으로 비워 토·일 자동 유급이 테스트 값을 흐리지 않게 한다 */
    static void clearMonth() {
        store = new TreeMap<>();
        HOLIDAYS.clear();
        for (int d = 1; d <= DAYS; d++) set(d, "mode", "none");
    }

    static int dow(int d) {
        return LocalDate.of(YEAR, MONTH, d).getDayOfWeek().getValue() % 7 + 1; // 1=일 … 7=토
    }

    /** 앱의 clearMonthWork / clearDayWork / 일괄 삭제와 같은 정리 (AttendanceCore.dayWipeKeys 사용) */
    static void wipeDay(int d) {
        for (String k : AttendanceCore.dayWipeKeys()) day(d).remove(k);
    }

    /** 앱의 applyPreset 흐름: 남은 시간·근태·수동 주차/가급를 비우고 프리셋 값만 남긴다 */
    static void applyPresetLikeApp(int d, String mode, double normal) {
        for (String k : AttendanceCore.TIME_KEYS) day(d).remove(k);
        for (String k : new String[]{"att", "atth", "memo"}) day(d).remove(k);
        for (String k : AttendanceCore.staleInputKeys()) day(d).remove(k);
        set(d, "mode", mode);
        if (normal > 0) set(d, "normal", fmt(normal));
    }

    /** 앱의 applyAtt 흐름: 근태 코어가 만든 mode·정상·유급·조합만 남긴다 */
    static void applyAttLikeApp(int d, String code, double hours) {
        boolean paidHoliday = AttendanceCore.isPaidHoliday(dow(d), HOLIDAYS.contains(d));
        AttendanceCore.Spec sp = AttendanceCore.spec(code, hours, paidHoliday);
        for (String k : AttendanceCore.TIME_KEYS) day(d).remove(k);
        for (String k : new String[]{"memo"}) day(d).remove(k);
        for (String k : AttendanceCore.staleInputKeys()) day(d).remove(k);
        set(d, "att", code);
        set(d, "atth", fmt(hours));
        set(d, "mode", sp.mode);
        if (sp.normal > 0) set(d, "normal", fmt(sp.normal));
        if (sp.paid > 0) set(d, "paid", fmt(sp.paid));
        if (sp.union > 0) set(d, "union", fmt(sp.union));
    }

    static class Month implements PayCore.DayData {
        public int daysInMonth() { return DAYS; }
        public double hours(int d, int idx) {
            Map<String, String> s = store.getOrDefault(d, Collections.emptyMap());
            String key = AttendanceCore.TIME_KEYS[idx];
            boolean manual = s.containsKey(key);
            String mode = s.getOrDefault("mode", "auto");
            boolean leave = "annual".equals(mode) || "summer".equals(mode);
            return PayCore.dayHours(idx, manual, manual ? Double.parseDouble(s.get(key)) : 0.0,
                    mode, dow(d), HOLIDAYS.contains(d), leave);
        }
        public String mode(int d) {
            return store.getOrDefault(d, Collections.emptyMap()).getOrDefault("mode", "auto");
        }
        public boolean has(int d, int idx) {
            return store.getOrDefault(d, Collections.emptyMap()).containsKey(AttendanceCore.TIME_KEYS[idx]);
        }
    }

    /** 기본급 인정 시간 = 정상 + 유급 + 주차 + 조합 */
    static double baseHours() {
        double[] t = PayCore.totals(new Month());
        return t[PayCore.NORMAL] + t[PayCore.PAID] + t[PayCore.WEEKLY] + t[PayCore.UNION];
    }

    static double[] totals() {
        return PayCore.totals(new Month());
    }

    public static void main(String[] args) {
        System.out.println("══ ① 월 초기화 · 일괄 입력/삭제에서 근태 키(att·atth) 잔존 ══");
        List<String> wipe = Arrays.asList(AttendanceCore.dayWipeKeys());
        checkBool("정리 키에 att 포함", wipe.contains("att"), true);
        checkBool("정리 키에 atth 포함", wipe.contains("atth"), true);
        checkBool("정리 키에 weekly 포함", wipe.contains("weekly"), true);
        checkBool("정리 키에 gageub 포함", wipe.contains("gageub"), true);
        checkBool("정리 키에 mode·memo 포함", wipe.contains("mode") && wipe.contains("memo"), true);
        checkBool("정리 키가 근무 시간 9종을 모두 포함",
                wipe.containsAll(Arrays.asList(AttendanceCore.TIME_KEYS)), true);

        clearMonth();
        set(5, "mode", "work");
        set(5, "normal", "8");
        set(5, "union", "2");
        set(5, "att", "union");
        set(5, "atth", "2");
        set(5, "weekly", "8");
        set(5, "gageub", "1");
        set(5, "memo", "월초기화 검증");
        wipeDay(5);
        checkBool("월 전체 초기화 후 남은 키 없음", day(5).isEmpty(), true);
        checkBool("월 전체 초기화 후 근태 코드 사라짐", !day(5).containsKey("att"), true);

        // 선택 일괄 입력: 이전 근태·수동 주차/가급이 남지 않고 프리셋 값만 남는다
        set(6, "att", "congrat");
        set(6, "atth", "4");
        set(6, "weekly", "8");
        set(6, "gageub", "2");
        applyPresetLikeApp(6, "work", 8);
        checkBool("일괄 입력 후 att 제거", !day(6).containsKey("att") && !day(6).containsKey("atth"), true);
        checkBool("일괄 입력 후 weekly·gageub 제거",
                !day(6).containsKey("weekly") && !day(6).containsKey("gageub"), true);
        check("일괄 입력 후 정상 8h", day(6).containsKey("normal") ? 8 : 0, 8);

        System.out.println("\n══ ② 프리셋·근태 적용 시 수동 weekly·gageub 잔존 ══");
        List<String> stale = Arrays.asList(AttendanceCore.staleInputKeys());
        checkBool("초기화 대상에 weekly·gageub", stale.contains("weekly") && stale.contains("gageub"), true);

        clearMonth();
        set(10, "mode", "work");
        set(10, "normal", "8");
        set(10, "weekly", "8");     // 수동 주차
        set(10, "gageub", "3");     // 수동 가급
        check("수동 주차·가급이 남아 있으면 기본급 인정 16h 로 과다", baseHours(), 16);
        applyPresetLikeApp(10, "work", 8);
        check("프리셋 적용 후 기본급 인정 8h", baseHours(), 8);
        check("프리셋 적용 후 가급은 요일 규칙대로 1일", totals()[PayCore.GAGEUB], 1);

        clearMonth();
        set(10, "att", "union");
        set(10, "atth", "2");
        set(10, "mode", "work");
        set(10, "normal", "8");
        set(10, "union", "2");
        set(10, "gageub", "2");
        applyAttLikeApp(10, AttendanceCore.UNION, 2);
        checkBool("근태 적용 후 수동 가급 제거", !day(10).containsKey("gageub"), true);
        checkBool("근태 적용 후 수동 주차 제거", !day(10).containsKey("weekly"), true);
        check("평일 설명회 2h 기본급 인정 10h", baseHours(), 10);
        check("평일 설명회는 가급 1일 유지", totals()[PayCore.GAGEUB], 1);

        System.out.println("\n══ ③ 경조·공무 4h 칩이 8h 로 고정되던 결함 ══");
        AttendanceCore.Spec c4 = AttendanceCore.spec(AttendanceCore.CONGRAT, 4);
        check("축하 4h → 유급 4h", c4.paid, 4);
        check("축하 4h → 정상 0h", c4.normal, 0);
        checkStr("축하 4h 뱃지", AttendanceCore.badge(AttendanceCore.CONGRAT, 0, c4.paid, 0), "축하 4h");
        check("기복 4h → 유급 4h", AttendanceCore.spec(AttendanceCore.CONDOL, 4).paid, 4);
        checkStr("기복 4h 뱃지", AttendanceCore.badge(AttendanceCore.CONDOL, 0, 4, 0), "기복 4h");
        check("공무/포상 4h → 유급 4h", AttendanceCore.spec(AttendanceCore.COMMEND, 4).paid, 4);
        checkStr("공무/포상 4h 뱃지", AttendanceCore.badge(AttendanceCore.COMMEND, 0, 4, 0), "공무/포상 4h");
        check("축하 8h → 유급 8h", AttendanceCore.spec(AttendanceCore.CONGRAT, 8).paid, 8);
        check("축하 3.5h → 유급 3.5h (직접입력)", AttendanceCore.spec(AttendanceCore.CONGRAT, 3.5).paid, 3.5);
        check("축하 0.2h → 0.5h 하한", AttendanceCore.spec(AttendanceCore.CONGRAT, 0.2).paid, 0.5);
        check("축하 12h → 8h 상한", AttendanceCore.spec(AttendanceCore.CONGRAT, 12).paid, 8);
        check("축하 시간 미선택(0) → 8h", AttendanceCore.spec(AttendanceCore.CONGRAT, 0).paid, 8);

        clearMonth();
        applyAttLikeApp(17, AttendanceCore.CONGRAT, 4);
        check("축하 4h 하루 기본급 인정 4h", baseHours(), 4);
        check("축하 4h 는 실근무가 아니라 가급 0일", totals()[PayCore.GAGEUB], 0);

        System.out.println("\n══ ④ 토·공휴일 8h+설명회 유급 8h 중복 ══");
        // 2026-11-14(토)
        check("토요일 판정", dow(14), 7);
        AttendanceCore.Spec sat = AttendanceCore.spec(AttendanceCore.UNION, 2, true);
        check("토요일 설명회 → 정상 0h", sat.normal, 0);
        check("토요일 설명회 → 조합 2h", sat.union, 2);
        clearMonth();
        applyAttLikeApp(14, AttendanceCore.UNION, 2);
        check("토요일 설명회 기본급 인정 10h (유급 8 + 설명회 2)", baseHours(), 10);
        checkStr("토요일 설명회 뱃지", AttendanceCore.badge(AttendanceCore.UNION,
                AttendanceCore.spec(AttendanceCore.UNION, 2, true).normal, 0, 2), "설명회 2h");

        // 일요일(주차 8h 자동)
        check("일요일 판정", dow(15), 1);
        clearMonth();
        applyAttLikeApp(15, AttendanceCore.UNION, 3);
        check("일요일 설명회 기본급 인정 11h (주차 8 + 설명회 3)", baseHours(), 11);

        // 평일 공휴일
        HOLIDAYS.add(20);
        clearMonth();
        HOLIDAYS.add(20);
        applyAttLikeApp(20, AttendanceCore.UNION, 2);
        check("평일 공휴일 설명회 기본급 인정 10h", baseHours(), 10);

        // 평일은 종전대로 8h + 설명회
        clearMonth();
        AttendanceCore.Spec tue = AttendanceCore.spec(AttendanceCore.UNION, 3, false);
        check("평일 설명회 → 정상 8h", tue.normal, 8);
        check("평일 설명회 → 조합 3h", tue.union, 3);
        applyAttLikeApp(10, AttendanceCore.UNION, 3);
        check("평일 설명회 3h 기본급 인정 11h", baseHours(), 11);
        checkStr("평일 설명회 뱃지", AttendanceCore.badge(AttendanceCore.UNION, 8, 0, 3), "8h+설명회3h");

        System.out.println(fail == 0
                ? "\n✅ v1.4.3 재빌드 ⑧ 회귀 테스트 전 항목 통과"
                : "\n❌ 실패 " + fail + "건");
        if (fail > 0) System.exit(1);
    }
}
