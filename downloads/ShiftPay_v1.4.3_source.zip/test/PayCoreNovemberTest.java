import com.example.shiftpay.DeductionCore;
import com.example.shiftpay.PayCore;

import java.time.LocalDate;
import java.util.*;

/**
 * 2026년 11월 가상 입력 검증 하네스 (v1.4.3).
 *
 * 실기기에서 보고된 "11월 예상 실수령액 이상" 결함의 재현·회귀 시험이다.
 *   1근 상주근무 · 사원(직책 0 + 직무 55,000) · 기본시급 13,653 / 통상시급 14,939
 *   11월 평일 21일 정상 8h + 평일연장 2h(42h), 토요일 특근 2일 8h(16h), 출근 23일
 *   → 세전 5,017,961원, 공제 708,490원, 예상 실수령 4,309,471원
 *   (v1.3.5 실측치 학습이 살아 있던 빌드에서는 소득세가 -312만원으로 튀어 실수령이 68만원까지 무너졌다)
 */
public class PayCoreNovemberTest {

    static int fail = 0;

    static void check(String name, double got, double want) {
        boolean ok = Math.abs(got - want) < 0.5;
        if (!ok) fail++;
        System.out.printf("%-34s 값 %,14.0f  기대 %,14.0f  %s%n", name, got, want, ok ? "OK" : "FAIL");
    }

    static final Set<Integer> HOLIDAYS = new HashSet<>();   // 2026년 11월은 공휴일 없음

    static final Set<Integer> WEEKDAY_WORK = new HashSet<>(Arrays.asList(
            2, 3, 4, 5, 6, 9, 10, 11, 12, 13, 16, 17, 18, 19, 20, 23, 24, 25, 26, 27, 30));
    static final Map<Integer, Double> HOLIDAY_WORK = new HashMap<>();
    static {
        HOLIDAY_WORK.put(7, 8.0);    // 토요일 특근 8h
        HOLIDAY_WORK.put(14, 8.0);   // 토요일 특근 8h
    }

    static int dow(int day) {
        return LocalDate.of(2026, 11, day).getDayOfWeek().getValue() % 7 + 1; // 1=일 … 7=토
    }

    static final String[] MODE = new String[32];
    static final Double[][] MANUAL = new Double[32][9];

    static void prepare() {
        for (int d = 1; d <= 30; d++) {
            MODE[d] = "auto";
            for (int i = 0; i < 9; i++) MANUAL[d][i] = null;
        }
        for (int d : WEEKDAY_WORK) {
            MODE[d] = "work";
            MANUAL[d][0] = 8.0;   // 정상 8h
            MANUAL[d][4] = 2.0;   // 평일연장 2h → 21일 × 2h = 42h
        }
        for (Map.Entry<Integer, Double> e : HOLIDAY_WORK.entrySet()) {
            MODE[e.getKey()] = "work";
            MANUAL[e.getKey()][5] = e.getValue();   // 휴일근로(특근)
        }
    }

    static class Day implements PayCore.DayData {
        public int daysInMonth() { return 30; }
        public double hours(int day, int idx) {
            boolean manual = MANUAL[day][idx] != null;
            boolean leave = "annual".equals(MODE[day]) || "summer".equals(MODE[day]);
            return PayCore.dayHours(idx, manual, manual ? MANUAL[day][idx] : 0.0,
                    MODE[day], dow(day), HOLIDAYS.contains(day), leave);
        }
        public String mode(int day) { return MODE[day]; }
    }

    static class Cfg implements PayCore.Settings {
        final Map<String, Double> v = new HashMap<>();
        Cfg() {
            v.put("base", 13653.0);
            v.put("ordinary", 14939.0);
            v.put("otRate", 1.5);
            v.put("holidayRate", 1.5);
            v.put("holidayOTRate", 2.0);
            v.put("nightRate", 0.5);
            v.put("tenure", 22500.0);
            v.put("familySelf", 20000.0);
            v.put("familyOther", 30000.0);
            v.put("position", 0.0);
            v.put("duty", 55000.0);
            v.put("summer", 45000.0);
            v.put("other", 0.0);
        }
        public double get(String k) { return v.containsKey(k) ? v.get(k) : 0.0; }
        public boolean isShiftWorker() { return false; }
        public boolean isSummerMonth() { return false; }
        public boolean isRetroActive() { return false; }
        public double retroAmount() { return 0; }
        /** v1.4.3 앱과 동일: 자동 예측 = 법정 요율·간이세액표 (부양가족 4명 · 자녀 2명) */
        public double deductionFor(double gross) {
            return DeductionCore.compute(Math.round(gross), 14939, 4, 2, 1.0, 0, 0, 0, null).total;
        }
    }

    public static void main(String[] args) {
        prepare();
        Day dd = new Day();
        double[] t = PayCore.totals(dd);

        System.out.println("[1. 11월 시간 집계]");
        check("정상(평일 21일 × 8h)", t[PayCore.NORMAL], 168);
        check("유급(토요일 4일 × 8h)", t[PayCore.PAID], 32);
        check("주차(일요일 5일 × 8h)", t[PayCore.WEEKLY], 40);
        check("평일연장 42h", t[PayCore.OT], 42);
        check("휴일근로(특근) 16h", t[PayCore.HOL], 16);
        check("상주휴게 지급일수 23일", t[PayCore.GAGEUB], 23);
        check("출근일수 23일", PayCore.countWorkDays(dd), 23);

        System.out.println("\n[2. 11월 지급 내역]");
        double[] a = PayCore.amounts(new Cfg(), dd);
        check("기본급(240h × 13,653)", a[0], 3276720);
        check("평일연장(42h × 22,409)", a[1], 941178);
        check("휴일근로(16h × 22,409)", a[2], 358544);
        check("휴일연장", a[3], 0);
        check("야간", a[4], 0);
        check("고정·상주휴게(23일 314,019 포함)", a[5], 441519);
        check("세전 총지급액", a[6], 5017961);

        System.out.println("\n[3. 11월 공제·실수령 (v1.4.3 정상화)]");
        DeductionCore.Result d = DeductionCore.compute(5017961L, 14939, 4, 2, 1.0, 0, 0, 0, null);
        check("소득세", d.incomeTax, 173270);
        check("지방소득세", d.localTax, 17320);
        check("국민연금", d.pension, 225810);
        check("건강보험", d.health, 177890);
        check("장기요양", d.longterm, 23040);
        check("고용보험", d.employ, 45160);
        check("노조회비", d.unionFee, 46000);
        check("예상 공제액", d.total, 708490);
        check("PayCore 경유 공제액", a[7], 708490);
        check("예상 실수령액", a[8], 4309471);

        System.out.println("\n[4. 회귀 — 오염된 실측치가 있어도 정상]");
        long[] polluted = {3120000, 312000, 1560000, 780000, 156000, 46000};
        DeductionCore.Result p = DeductionCore.compute(5017961L, 14939, 4, 2, 1.0, 0, 0, 5262924L, polluted);
        check("오염 실측치 무시 소득세", p.incomeTax, 173270);
        check("오염 실측치 무시 공제액", p.total, 708490);
        DeductionCore.Result p2 = DeductionCore.compute(Math.round(a[6]), 14939, 4, 2, 1.0, 0, 0, 5262924L, polluted, true);
        check("useLearned=true 도 차단", p2.total, 708490);

        System.out.println(fail == 0 ? "\n✅ 11월 5,017,961원 정상 산출 통과" : "\n❌ 실패 " + fail + "건");
        if (fail > 0) System.exit(1);
    }
}
