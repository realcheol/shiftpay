package com.example.shiftpay;

import java.text.DecimalFormat;

/**
 * 사내 공식 근태(근태계) 코드 → 근무 입력값·달력 뱃지 매핑 코어.
 *
 * 안드로이드 프레임워크에 의존하지 않는 순수 계산 코어이므로 데스크톱 JVM 단위 테스트로
 * 그대로 검증할 수 있다. MainActivity 가 이 코어를 호출해
 *  ① 바텀시트 [사내 공식 근태] 칩 → mode/정상·유급·조합 시간 자동 세팅
 *  ② 달력 날짜 칸 4색 뱃지 문구 생성
 * 을 담당한다. 웹 버전(index.html)도 같은 표를 1:1 로 옮겨 쓴다.
 *
 * 표기 원칙: 한글 명칭만 쓴다. 회사 근태계 양식의 내부 코드번호(1A·3C 등)나
 * 부서명·성명 등 특정 가능한 정보는 절대 넣지 않는다.
 */
public final class AttendanceCore {

    private AttendanceCore() {}

    // ── 공식 근태 코드 ──────────────────────────────────────────────
    public static final String ANNUAL = "annual";        // 연차 (유급 8h)
    public static final String SUMMER = "summer";        // 하계휴가 (유급 8h)
    public static final String HALF = "half";            // 반차 (4h 근무 + 4h 연차)
    public static final String CONGRAT = "congrat";      // 경조 — 축하
    public static final String CONDOL = "condol";        // 경조 — 기복
    public static final String COMMEND = "commend";      // 공무 / 포상
    public static final String UNION = "union";          // 조합설명회 (정상 유급 인정)
    public static final String HEALTH = "health";        // 건강검진 (유급)
    public static final String TRAINING = "training";    // 교육 (유급)
    public static final String TRIP = "trip";            // 출장 (유급)
    public static final String RESERVE = "reserve";      // 예비군훈련 (유급)
    public static final String EARLY = "early";          // 조퇴 (실근무 시간 기입)
    public static final String LATE = "late";            // 지각
    public static final String OUTING = "outing";        // 외출
    public static final String SICK = "sick";            // 병가
    public static final String ABSENT = "absent";        // 결근 (유결/무결)
    public static final String LEAVEWORK = "leavework";  // 휴직

    // ── 뱃지 4색 라인업 ─────────────────────────────────────────────
    public static final int TONE_GREEN = 0;    // 휴가·경조 계열
    public static final int TONE_INDIGO = 1;   // 유급·교육·행사 계열
    public static final int TONE_ORANGE = 2;   // 시간 공제·변동 계열
    public static final int TONE_SLATE = 3;    // 결근·휴직 계열

    /** 하루치 근무 입력값으로 풀어 놓은 결과 (mode + 정상·유급·조합 시간) */
    public static final class Spec {
        public final String mode;
        public final double normal;
        public final double paid;
        public final double union;

        public Spec(String mode, double normal, double paid, double union) {
            this.mode = mode;
            this.normal = normal;
            this.paid = paid;
            this.union = union;
        }
    }

    static String h(double v) {
        return new DecimalFormat("0.##").format(v);
    }

    /** 지원하는 공식 근태 코드인지 */
    public static boolean isCode(String code) {
        if (code == null) return false;
        switch (code) {
            case ANNUAL: case SUMMER: case HALF: case CONGRAT: case CONDOL: case COMMEND:
            case UNION: case HEALTH: case TRAINING: case TRIP: case RESERVE:
            case EARLY: case LATE: case OUTING: case SICK: case ABSENT: case LEAVEWORK:
                return true;
            default:
                return false;
        }
    }

    /** 뱃지·버튼에 쓰는 한글 명칭 */
    public static String label(String code) {
        if (code == null) return "";
        switch (code) {
            case ANNUAL: return "연차";
            case SUMMER: return "휴가";
            case HALF: return "반차";
            case CONGRAT: return "축하";
            case CONDOL: return "기복";
            case COMMEND: return "공무/포상";
            case UNION: return "설명회";
            case HEALTH: return "건강검진";
            case TRAINING: return "교육";
            case TRIP: return "출장";
            case RESERVE: return "예비군";
            case EARLY: return "조퇴";
            case LATE: return "지각";
            case OUTING: return "외출";
            case SICK: return "병가";
            case ABSENT: return "결근";
            case LEAVEWORK: return "휴직";
            default: return "";
        }
    }

    /** 뱃지 색 계열 */
    public static int tone(String code) {
        if (code == null) return TONE_GREEN;
        switch (code) {
            case ANNUAL: case SUMMER: case HALF: case CONGRAT: case CONDOL: case COMMEND:
                return TONE_GREEN;
            case UNION: case HEALTH: case TRAINING: case TRIP: case RESERVE:
                return TONE_INDIGO;
            case EARLY: case LATE: case OUTING:
                return TONE_ORANGE;
            case SICK: case ABSENT: case LEAVEWORK:
                return TONE_SLATE;
            default:
                return TONE_GREEN;
        }
    }

    /** 기본 시간 (설명회 2h · 조퇴 4h · 건강검진 4h 등) */
    public static double defaultHours(String code) {
        if (code == null) return 0;
        switch (code) {
            case ANNUAL: case SUMMER: case COMMEND:
            case CONGRAT: case CONDOL: case TRAINING: case TRIP: case RESERVE:
                return 8;
            case HALF: return 4;
            case UNION: return 2;
            case HEALTH: return 4;
            case EARLY: return 4;
            case LATE: case OUTING: return 8;
            case SICK: case LEAVEWORK: case ABSENT: return 0;
            default: return 0;
        }
    }

    /**
     * 근태 코드 + 사용자가 고른 시간 → 하루치 근무 입력값 (mode / 정상 / 유급 / 조합).
     *
     *  · 조합설명회: 정상 8h 를 채운 날에 설명회 2h(또는 3h)를 더한다. 설명회 시간은
     *    연장 할증이 아니라 기본급 100% 유급(조합 칸)으로 들어가고, 실근무 8h 를 채웠으므로
     *    당일 상주휴게(가급 1h)는 그대로 지급된다. (단협 제10조·제49조)
     *  · 조퇴: 실근무 시간을 정상 칸에 그대로 넣는다 → 8h 미만이면 가급이 자동 제외된다.
     *  · 건강검진·교육·출장·예비군·경조·공무: 유급(100%) 시간으로 인정한다.
     *  · 병가·휴직·무급결근: 무급(mode=none) → 당일 인정시간 0.
     */
    public static Spec spec(String code, double hours) {
        double h = hours;
        if (h < 0) h = 0;
        if (code == null) return new Spec("auto", 0, 0, 0);
        switch (code) {
            case ANNUAL:   return new Spec("annual", 8, 0, 0);
            case SUMMER:   return new Spec("summer", 8, 0, 0);
            case HALF:     return new Spec("half_am", 4, 4, 0);
            case CONGRAT:
            case CONDOL:
            case COMMEND:  return new Spec("work", 0, 8, 0);
            case HEALTH:
            case TRAINING:
            case TRIP:
            case RESERVE:  return new Spec("work", 0, h, 0);
            case UNION:    return new Spec("work", 8, 0, h);
            case EARLY:    return new Spec("work", h, 0, 0);
            case LATE:
            case OUTING:   return new Spec("work", 8, 0, 0);
            case SICK:
            case LEAVEWORK: return new Spec("none", 0, 0, 0);
            case ABSENT:   return h > 0 ? new Spec("work", 0, h, 0) : new Spec("none", 0, 0, 0);
            default:       return new Spec("auto", 0, 0, 0);
        }
    }

    /**
     * 달력 날짜 칸에 찍는 뱃지 문구. 실제 저장된 시간값에서 그대로 만들어
     * 사용자가 세부 입력으로 시간을 고쳐도 뱃지가 어긋나지 않는다.
     */
    public static String badge(String code, double normal, double paid, double union) {
        if (code == null || code.isEmpty()) return "";
        switch (code) {
            case UNION:
                if (union <= 0) return "설명회";
                return normal > 0 ? h(normal) + "h+설명회" + h(union) + "h" : "설명회 " + h(union) + "h";
            case EARLY:   return normal > 0 ? h(normal) + "h 조퇴" : "조퇴";
            case LATE:    return normal > 0 ? h(normal) + "h 지각" : "지각";
            case OUTING:  return normal > 0 ? h(normal) + "h 외출" : "외출";
            case ANNUAL:  return "연차 " + h(normal > 0 ? normal : 8) + "h";
            case SUMMER:  return "휴가 " + h(normal > 0 ? normal : 8) + "h";
            case HALF:    return "반차 " + h(paid > 0 ? paid : 4) + "h";
            case ABSENT:  return paid > 0 ? "유결 " + h(paid) + "h" : "무결";
            case SICK:    return "병가";
            case LEAVEWORK: return "휴직";
            case CONGRAT: return "축하 " + h(paid > 0 ? paid : 8) + "h";
            case CONDOL:  return "기복 " + h(paid > 0 ? paid : 8) + "h";
            case COMMEND: return "공무/포상 " + h(paid > 0 ? paid : 8) + "h";
            case HEALTH:  return "건강검진 " + h(paid > 0 ? paid : 4) + "h";
            case TRAINING: return "교육 " + h(paid > 0 ? paid : 8) + "h";
            case TRIP:    return "출장 " + h(paid > 0 ? paid : 8) + "h";
            case RESERVE: return "예비군 " + h(paid > 0 ? paid : 8) + "h";
            default:      return label(code);
        }
    }
}
