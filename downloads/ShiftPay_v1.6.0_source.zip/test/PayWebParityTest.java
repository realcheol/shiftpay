import com.example.shiftpay.PayCore;

import java.time.LocalDate;
import java.util.*;

/**
 * v1.5.0 — 웹(ShiftPay 웹앱)과 설치형(PayCore) 급여 1:1 대조용 픽스처.
 *
 * 2026년 10월, 상주근무 · 사원(직책 0 + 직무 55,000) 조건에서 웹 라이브 화면에
 * 똑같은 입력을 넣어 측정한 값과 이 코어의 계산값을 1원 단위로 비교한다.
 *   입력: 평일 19일 정상 8h+연장 2h / 휴일특근 10·17 8h, 10·19 10h, 10·24 8h, 10·31 8h
 *   설정: 기본 13,653 · 통상 14,939 · 근속 22,500 · 가족(본인) 20,000 · 가족 30,000
 *         직책 0 · 직무 55,000 · 하계 45,000(10월 미적용) · 공제 직접 948,470
 *   웹 화면 실측(2026-11-14): 기본급 3,385,944 / 평일연장 851,542 / 휴일근로 717,088
 *         / 휴일연장 59,756 / 고정+상주휴게 441,519 / 세전 5,455,849 / 실수령 4,507,379
 */
public class PayWebParityTest {

    static final Set<Integer> HOLIDAYS = new HashSet<>(Arrays.asList(3, 5, 9, 18, 19));
    static final Set<Integer> WEEKDAY_WORK = new HashSet<>(Arrays.asList(
            1, 2, 6, 7, 8, 12, 13, 14, 15, 16, 20, 21, 22, 23, 26, 27, 28, 29, 30));
    static final Map<Integer, Double> HOL_WORK = new HashMap<>();
    static {
        HOL_WORK.put(17, 8.0);
        HOL_WORK.put(19, 10.0);
        HOL_WORK.put(24, 8.0);
        HOL_WORK.put(31, 8.0);
    }

    static int dow(int day) {
        return LocalDate.of(2026, 10, day).getDayOfWeek().getValue() % 7 + 1;
    }

    static Double manualOf(int day, int idx) {
        if (WEEKDAY_WORK.contains(day)) {
            if (idx == PayCore.NORMAL) return 8.0;
            if (idx == PayCore.OT) return 2.0;
        }
        if (HOL_WORK.containsKey(day) && idx == PayCore.HOL) return HOL_WORK.get(day);
        return null;
    }

    /** 앱의 MainActivity.hours() 와 동일 — 자동 인정(토·일·공휴일 유급/주차) 규칙을 코어에 위임한다 */
    static class Month implements PayCore.DayData {
        public int daysInMonth() { return 31; }
        public double hours(int day, int idx) {
            Double manual = manualOf(day, idx);
            String mode = mode(day);
            boolean leave = "annual".equals(mode) || "summer".equals(mode);
            return PayCore.dayHours(idx, manual != null, manual != null ? manual : 0.0,
                    mode, dow(day), HOLIDAYS.contains(day), leave);
        }
        public String mode(int day) {
            return (WEEKDAY_WORK.contains(day) || HOL_WORK.containsKey(day)) ? "work" : "auto";
        }
        public boolean has(int day, int idx) { return manualOf(day, idx) != null; }
    }

    static class Cfg implements PayCore.Settings {
        final Map<String, Double> v = new HashMap<>();
        Cfg() {
            v.put("base", 13653.0); v.put("ordinary", 14939.0);
            v.put("otRate", 1.5); v.put("holidayRate", 1.5);
            v.put("holidayOTRate", 2.0); v.put("nightRate", 0.5);
            v.put("tenure", 22500.0); v.put("familySelf", 20000.0); v.put("familyOther", 30000.0);
            v.put("position", 0.0); v.put("duty", 55000.0);
            v.put("summer", 45000.0); v.put("other", 0.0); v.put("deduction", 948470.0);
        }
        public double get(String k) { return v.containsKey(k) ? v.get(k) : 0.0; }
        public boolean isShiftWorker() { return false; }
        public boolean isSummerMonth() { return false; }
        public boolean isRetroActive() { return false; }
        public double retroAmount() { return 0; }
    }

    static int fail = 0;

    static void check(String label, double actual, double expected) {
        boolean ok = Math.round(actual) == Math.round(expected);
        if (!ok) fail++;
        System.out.printf("  %s %-26s 앱 %12s · 웹 실측 %12s%n",
                ok ? "PASS" : "FAIL", label, String.format("%,.0f", actual), String.format("%,.0f", expected));
    }

    public static void main(String[] args) {
        Month m = new Month();
        Cfg s = new Cfg();
        double[] t = PayCore.totals(m);
        double[] a = PayCore.amounts(s, m);
        System.out.println("=== 2026년 10월 · 웹 라이브 입력 재현 (웹 ↔ 설치형 1:1) ===");
        System.out.printf("정상 %.0fh / 유급 %.0fh / 주차 %.0fh / 연장 %.0fh / 휴일 %.0fh / 휴일연장 %.0fh / 가급 %.0f일%n",
                t[0], t[1], t[2], Math.max(0, t[4] - t[3]), t[5], t[6], t[8]);
        check("기본급", a[0], 3385944);
        check("평일연장근로수당", a[1], 851542);
        check("휴일근로수당(특근)", a[2], 717088);
        check("휴일연장수당(가급)", a[3], 59756);
        check("야간 추가수당", a[4], 0);
        check("고정+상주휴게수당", a[5], 441519);
        check("세전 총지급액", a[6], 5455849);
        check("예상 공제액", a[7], 948470);
        check("실수령액", a[8], 4507379);
        System.out.println(fail == 0
                ? "\n✅ 웹 ↔ 설치형 급여 1:1 (10월 실측 입력) 전 항목 일치"
                : "\n❌ 불일치 " + fail + "건");
        if (fail > 0) System.exit(1);
    }
}
