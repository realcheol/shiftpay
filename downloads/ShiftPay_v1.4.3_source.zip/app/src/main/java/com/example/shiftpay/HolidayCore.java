package com.example.shiftpay;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Map;

/**
 * 단체협약 제52조 유급휴일·대체휴무 배정 코어 (안드로이드 비의존 — 데스크톱 JVM 단위 테스트 가능).
 *
 * 정부 대체공휴일 지정 여부와 무관하게, 유급휴일이 주말이나 다른 공휴일과 겹친 일수만큼
 * 익일 평일로 순차 밀어 회사 자체 대체휴무를 배정한다.
 *
 *  · 2027년 설날: 2/6(토)·2/7(일) 설날 연휴가 주말과 겹쳐 2일이 밀린다.
 *    정부가 2/9(화)를 설날 대체공휴일로 지정해도 회사 몫 2일은 그 뒤 평일인
 *    2/10(수)·2/11(목)에 '설날 대체휴무'로 배정되어 6일 연속 휴일이 된다.
 *  · 2025·2026년은 실물 명세서로 이미 확정된 달력이므로 종전 방식(창립일 2건)을 유지한다.
 */
public final class HolidayCore {

    private HolidayCore() {}

    /** 지정 연도의 공휴일 맵에 회사 자체 대체휴무를 배정한다 (맵을 직접 수정). */
    public static void applyCompanySubstituteHolidays(Map<String, String> map, int year) {
        if (map == null) return;
        if (year < 2027) {
            applySequentialSubHoliday(map, year, 4, 19, "노조창립일");
            applySequentialSubHoliday(map, year, 10, 18, "회사창립일");
            return;
        }
        String[] keys = map.keySet().toArray(new String[0]);
        Arrays.sort(keys);
        for (String key : keys) {
            String label = map.get(key);
            if (label == null) continue;
            if (label.contains("대체공휴일") || label.endsWith("대체휴무")) continue; // 이미 배정된 대체일은 기준에서 제외
            if (key.length() != 8) continue;
            int y, m, d;
            try {
                y = Integer.parseInt(key.substring(0, 4));
                m = Integer.parseInt(key.substring(4, 6));
                d = Integer.parseInt(key.substring(6, 8));
            } catch (Exception e) { continue; }

            // 같은 날짜에 두 개 이상의 유급휴일이 겹친 경우(예: 2028-10-03 추석·개천절)도 하루씩 밀린다
            String[] parts = label.split("·");
            int need = (parts.length > 1) ? parts.length - 1 : 0;
            int wd = weekdaySundayZero(y, m, d);
            if (wd == 0 || wd == 6) need += 1;
            if (need <= 0) continue;

            String baseName = parts[parts.length - 1].trim()
                    .replace(" 연휴", "").replace(" 임시공휴일", "").replace("임시공휴일", "").trim();
            if (baseName.isEmpty()) baseName = label.trim();
            String subLabel = baseName + " 대체휴무";

            for (int i = 0; i < need; i++) {
                Calendar c = new GregorianCalendar(y, m - 1, d);
                while (true) {
                    c.add(Calendar.DAY_OF_MONTH, 1);
                    int nwd = c.get(Calendar.DAY_OF_WEEK);
                    if (nwd == Calendar.SATURDAY || nwd == Calendar.SUNDAY) continue;
                    String nk = iso(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
                    if (map.containsKey(nk)) continue;   // 정부 대체공휴일·다른 휴일·앞서 배정한 회사 대체휴무는 건너뛴다
                    map.put(nk, subLabel);
                    break;
                }
            }
        }
    }

    /** 창립일 1건만 순차 대체하던 종전 방식 (2025·2026년 확정 달력 유지용) */
    public static void applySequentialSubHoliday(Map<String, String> map, int year, int m, int d, String label) {
        if (map == null) return;
        String subLabel = label + " 대체휴무";
        for (String v : map.values()) {
            if (subLabel.equals(v)) return; // 이미 대체휴무가 배정되어 있으면 중복 방지
        }
        int wd = weekdaySundayZero(year, m, d);
        if (wd == 0 || wd == 6) {
            Calendar c = new GregorianCalendar(year, m - 1, d);
            while (true) {
                c.add(Calendar.DAY_OF_MONTH, 1);
                int nextWd = c.get(Calendar.DAY_OF_WEEK);
                String nextIso = iso(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
                if (nextWd != Calendar.SATURDAY && nextWd != Calendar.SUNDAY && !map.containsKey(nextIso)) {
                    map.put(nextIso, subLabel);
                    break;
                }
            }
        }
    }

    /** 일요일 0 … 토요일 6 */
    public static int weekdaySundayZero(int y, int m, int d) {
        return LocalDate.of(y, m, d).getDayOfWeek().getValue() % 7;
    }

    public static String iso(int y, int m, int d) {
        return String.format(java.util.Locale.US, "%04d%02d%02d", y, m, d);
    }
}
