import com.example.shiftpay.PatternFillCore;

import java.util.*;

/**
 * v1.6.0 ② — 월간 패턴 자동 채우기 코어 검증.
 *
 *  · 2026년 11월 = 11/1(일) 시작 · 30일 · 공휴일 없음 → 평일(월~금)은 21일
 *  · 상주 패턴은 주말·공휴일·회사 대체휴무를 건너뛴다
 *  · 순환 패턴은 기준 시작일에서 센 주기 슬롯을 쓰고, 주말·공휴일 근무일은
 *    [휴일특근] 프리셋으로 바꾼다 (설정 OFF 면 주간/야간 프리셋 그대로)
 *  · '빈 날만 채우기' 기본 동작: 이미 입력된 날은 건드리지 않고 유지 일수로 보고한다
 *
 * v1.6.0 정정 — 회사는 4조 2교대가 아니라 2조 2교대 주야 맞교대(주5·비2·야5·비2, 14일).
 * 4조 프리셋은 없애고 2조 2교대(8+2h/10h) 와 그 8시간 변형(정5·비2·심5·비2)을 둔다.
 */
public class PatternFillTest {

    static int fail = 0;

    static void check(String name, long actual, long expected) {
        boolean ok = actual == expected;
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name + " → " + actual
                + (ok ? "" : " (기대값 " + expected + ")"));
    }

    static void check(String name, String actual, String expected) {
        boolean ok = Objects.equals(actual, expected);
        if (!ok) fail++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name + " → \"" + actual + "\""
                + (ok ? "" : " (기대값 \"" + expected + "\")"));
    }

    static void check(String name, boolean cond) {
        if (!cond) fail++;
        System.out.println((cond ? "  PASS  " : "  FAIL  ") + name);
    }

    static String[] presets(PatternFillCore.Plan p) {
        List<String> out = new ArrayList<>();
        for (int d = 1; d <= p.days; d++) out.add(p.preset[d] == null ? "-" : p.preset[d]);
        return out.toArray(new String[0]);
    }

    public static void main(String[] args) {
        System.out.println("── 1. 2026년 11월 상주 패턴 (평일 산정) ──");
        {
            PatternFillCore.Plan p = PatternFillCore.plan(2026, 11, "resident_ot", null,
                    new HashSet<>(), true, true, new boolean[32], null);
            check("11월 총 일수", p.days, 30);
            check("평일 8+2h 적용일수", p.applyDays, 21);
            check("1일(일) 미적용", p.preset[1] == null);
            check("2일(월) = 주간 8+2h", p.preset[2], PatternFillCore.OT);
            check("6일(금) = 주간 8+2h", p.preset[6], PatternFillCore.OT);
            check("7일(토) 미적용", p.preset[7] == null);
            check("30일(월) = 주간 8+2h", p.preset[30], PatternFillCore.OT);
            check("적용일 합계 == 평일 수", p.applyDays, 21);
        }

        System.out.println("── 2. 상주 정취(8h) · 공휴일 제외 ──");
        {
            Set<String> hols = new HashSet<>();
            hols.add("20261106");     // 금요일을 공휴일로 가정
            PatternFillCore.Plan p = PatternFillCore.plan(2026, 11, "resident_norm", null,
                    hols, true, true, new boolean[32], null);
            check("공휴일(6일) 미적용", p.preset[6] == null);
            check("공휴일 제외 적용일수", p.applyDays, 20);
            check("프리셋 = 정상 8h", p.preset[2], PatternFillCore.NORM);
            check("휴일 표시", p.holiday[6]);
        }

        System.out.println("── 3. 기존 입력 보존 (빈 날만 채우기 기본 ON) ──");
        {
            boolean[] has = new boolean[32];
            has[3] = true;      // 3일에 이미 연차/특근을 찍어 둔 상태
            has[12] = true;
            PatternFillCore.Plan keep = PatternFillCore.plan(2026, 11, "resident_ot", null,
                    new HashSet<>(), true, true, has, null);
            check("유지 일수", keep.keptDays, 2);
            check("실제 적용 일수", keep.applyDays, 19);
            check("3일은 적용 제외", !keep.applied[3]);
            check("3일 프리셋은 계획에 남음", keep.preset[3], PatternFillCore.OT);
            check("요약에 유지 표기", PatternFillCore.previewText(keep, true).contains("기존 입력 2일 유지"));

            PatternFillCore.Plan over = PatternFillCore.plan(2026, 11, "resident_ot", null,
                    new HashSet<>(), true, false, has, null);
            check("덮어쓰기 일수", over.overwriteDays, 2);
            check("덮어쓰기 시 적용 일수", over.applyDays, 21);
            check("요약에 덮어쓰기 표기", PatternFillCore.previewText(over, false).contains("덮어쓰기"));
        }

        System.out.println("── 4. 2조 2교대 주야 맞교대 주5·비2·야5·비2 (14일 · 기준 2026-11-02) ──");
        {
            PatternFillCore.Plan p = PatternFillCore.plan(2026, 11, "shift_5_2_5_2", "2026-11-02",
                    new HashSet<>(), true, true, new boolean[32], null);
            check("주기", p.cycle, 14);
            check("2일(월) 주간 8+2h 시작", p.preset[2], PatternFillCore.OT);
            check("6일(금) 주간 5일째", p.preset[6], PatternFillCore.OT);
            check("7일(토) 휴무(비2)", p.preset[7] == null);
            check("8일(일) 휴무(비2)", p.preset[8] == null);
            check("9일(월) 야간 시작", p.preset[9], PatternFillCore.NIGHT10);
            check("13일(금) 야간 5일째", p.preset[13], PatternFillCore.NIGHT10);
            check("14일(토) 휴무", p.preset[14] == null);
            check("15일(일) 휴무", p.preset[15] == null);
            check("16일(월) 다시 주간", p.preset[16], PatternFillCore.OT);
            check("30일(월) 주간", p.preset[30], PatternFillCore.OT);
            check("1일은 기준일 이전 주기의 휴무", presets(p)[0], "-");
            check("근무일 수 (14일당 10일)", p.fillDays, 21);
            check("주말 근무 없음 → 휴일특근 0일", p.holidayDays, 0);
        }

        System.out.println("── 5. 주말에 걸친 맞교대 → 휴일특근 자동 변환 (기준 2026-11-07 토요일) ──");
        {
            PatternFillCore.Plan on = PatternFillCore.plan(2026, 11, "shift_5_2_5_2", "2026-11-07",
                    new HashSet<>(), true, true, new boolean[32], null);
            check("7일(토) 주간 → 휴일특근 10h", on.preset[7], PatternFillCore.HOL10);
            check("8일(일) 주간 → 휴일특근 10h", on.preset[8], PatternFillCore.HOL10);
            check("9일(월) 주간 유지", on.preset[9], PatternFillCore.OT);
            check("14일(토) 야간 → 휴일 야간 10h", on.preset[14], PatternFillCore.HOLNIGHT10);
            check("15일(일) 야간 → 휴일 야간 10h", on.preset[15], PatternFillCore.HOLNIGHT10);
            check("16일(월) 야간 유지", on.preset[16], PatternFillCore.NIGHT10);
            check("1일(일) 야간 → 휴일 야간 10h (기준일 이전 주기)", on.preset[1], PatternFillCore.HOLNIGHT10);
            check("휴일특근 일수", on.holidayDays, 9);

            PatternFillCore.Plan off = PatternFillCore.plan(2026, 11, "shift_5_2_5_2", "2026-11-07",
                    new HashSet<>(), false, true, new boolean[32], null);
            check("변환 OFF — 7일 주간 그대로", off.preset[7], PatternFillCore.OT);
            check("변환 OFF — 14일 야간 그대로", off.preset[14], PatternFillCore.NIGHT10);
            check("변환 OFF — 휴일특근 0일", off.holidayDays, 0);
        }

        System.out.println("── 6. 2조 2교대 8시간 변형 정5·비2·심5·비2 (14일 · 기준 2026-11-02) ──");
        {
            PatternFillCore.Plan p = PatternFillCore.plan(2026, 11, "shift_5_2_5_2_norm", "2026-11-02",
                    new HashSet<>(), true, true, new boolean[32], null);
            check("주기", p.cycle, 14);
            check("2일(월) 정상 8h", p.preset[2], PatternFillCore.NORM);
            check("6일(금) 정상 8h", p.preset[6], PatternFillCore.NORM);
            check("7일(토) 휴무", p.preset[7] == null);
            check("9일(월) 야간 8h(심)", p.preset[9], PatternFillCore.NIGHT8);
            check("13일(금) 야간 8h(심)", p.preset[13], PatternFillCore.NIGHT8);
            check("16일(월) 정상 8h", p.preset[16], PatternFillCore.NORM);
            check("근무일 수 (14일당 10일)", p.fillDays, 21);

            PatternFillCore.Plan hol = PatternFillCore.plan(2026, 11, "shift_5_2_5_2_norm", "2026-11-07",
                    new HashSet<>(), true, true, new boolean[32], null);
            check("토요일 정상 8h → 휴일특근 8h", hol.preset[7], PatternFillCore.HOL8);
            check("토요일 야간 8h → 휴일 야간 8h", hol.preset[14], PatternFillCore.HOLNIGHT8);
        }

        System.out.println("── 7. 사용자 정의 문자열 ──");
        {
            String[] s = PatternFillCore.parseCustom("주주비비야야비비");
            check("주주비비야야비비 길이", s.length, 8);
            check("슬롯0 주간", s[0], PatternFillCore.OT);
            check("슬롯2 휴무", s[2] == null);
            check("슬롯4 야간", s[4], PatternFillCore.NIGHT10);
            check("정상 8h 문자", PatternFillCore.parseCustom("정정비")[0], PatternFillCore.NORM);
            check("심 = 야간 8h", PatternFillCore.parseCustom("심비")[0], PatternFillCore.NIGHT8);
            check("구분자 무시", PatternFillCore.parseCustom("주-주 비-비 야-야").length, 6);
            check("잘못된 글자 거부", PatternFillCore.parseCustom("주주X비") == null);
            check("전부 휴무 거부", PatternFillCore.parseCustom("비비비") == null);
            check("빈 문자열 거부", PatternFillCore.parseCustom("  ") == null);
            check("validCustom", PatternFillCore.validCustom("주야비"));

            PatternFillCore.Plan p = PatternFillCore.plan(2026, 11, "custom", "2026-11-02",
                    new HashSet<>(), true, true, new boolean[32], "주야비");
            check("사용자 주기", p.cycle, 3);
            check("2일 주간", p.preset[2], PatternFillCore.OT);
            check("3일 야간", p.preset[3], PatternFillCore.NIGHT10);
            check("4일 휴무", p.preset[4] == null);
            check("8일(일) 주간 → 휴일특근", p.preset[8], PatternFillCore.HOL10);
        }

        System.out.println("── 8. 기준 시작일이 다음 달인 경우(음수 오프셋 · 14일) ──");
        {
            // 기준일 2026-12-02 (주기 첫날) → 11월은 그 이전 주기로 역산된다
            PatternFillCore.Plan p = PatternFillCore.plan(2026, 11, "shift_5_2_5_2", "2026-12-02",
                    new HashSet<>(), false, true, new boolean[32], null);
            // 12-02 가 OT 이므로 11-18(14일 전) 또한 OT
            check("11-18 = 주간", p.preset[18], PatternFillCore.OT);
            check("11-22 = 주간 5일째", p.preset[22], PatternFillCore.OT);
            check("11-23 = 휴무", p.preset[23] == null);
            check("11-24 = 휴무", p.preset[24] == null);
            check("11-25 = 야간", p.preset[25], PatternFillCore.NIGHT10);
            check("11-29 = 야간 5일째", p.preset[29], PatternFillCore.NIGHT10);
            check("11-30 = 휴무", p.preset[30] == null);
        }

        System.out.println("── 9. 휴일 프리셋 매핑 ──");
        {
            check("ot→hol10", PatternFillCore.holidayVariant(PatternFillCore.OT), PatternFillCore.HOL10);
            check("norm→hol8", PatternFillCore.holidayVariant(PatternFillCore.NORM), PatternFillCore.HOL8);
            check("night8→holnight8", PatternFillCore.holidayVariant(PatternFillCore.NIGHT8), PatternFillCore.HOLNIGHT8);
            check("night10→holnight10", PatternFillCore.holidayVariant(PatternFillCore.NIGHT10), PatternFillCore.HOLNIGHT10);
            check("휴일 프리셋 그대로", PatternFillCore.holidayVariant(PatternFillCore.HOL10), PatternFillCore.HOL10);
            check("isHolidayPreset", PatternFillCore.isHolidayPreset(PatternFillCore.HOLNIGHT8));
        }

        System.out.println("── 10. 빈 달 · 근무일 없음 안내 ──");
        {
            Set<String> allHoliday = new HashSet<>();
            for (int d = 2; d <= 6; d++) allHoliday.add(String.format("202611%02d", d));
            PatternFillCore.Plan p = PatternFillCore.plan(2026, 11, "resident_ot", null,
                    allHoliday, true, true, new boolean[32], null);
            check("일부 공휴일", p.applyDays, 16);
            String txt = PatternFillCore.previewText(p, true);
            check("미리보기 문구", txt.startsWith("이번 달 총 16일 적용"));
        }

        System.out.println("── 11. 프리셋 구성 (4조 삭제 · 2조 2교대 5종) ──");
        {
            PatternFillCore.Pattern[] ps = PatternFillCore.PATTERNS;
            check("프리셋 개수", ps.length, 5);
            check("1번 = 상주조 기본", ps[0].id, "resident_ot");
            check("2번 = 상주조 정취", ps[1].id, "resident_norm");
            check("3번 = 2조 2교대 주야 맞교대", ps[2].id, "shift_5_2_5_2");
            check("4번 = 2조 2교대 8시간 변형", ps[3].id, "shift_5_2_5_2_norm");
            check("5번 = 사용자 정의", ps[4].id, "custom");
            boolean any4jo = false;
            for (PatternFillCore.Pattern p : ps) {
                if (p.label.contains("4조") || p.desc.contains("4조")) any4jo = true;
            }
            check("4조 프리셋 없음", !any4jo);
            check("2조 2교대 명칭 포함", ps[2].label.contains("2조 2교대") && ps[2].label.contains("주야 맞교대"));
            check("14일 주기 표기", ps[2].desc.contains("14일") && ps[3].desc.contains("14일"));
            check("사용자 정의 라벨에 심 포함", ps[4].label.contains("심"));
            check("알 수 없는 id → 첫 프리셋", PatternFillCore.pattern("shift_222").id, "resident_ot");
            check("주기 = 14", PatternFillCore.pattern("shift_5_2_5_2").slots.length, 14);
        }

        System.out.println(fail == 0
                ? "\n✅ 월간 패턴 자동 채우기 — 상주·2조 2교대(10h/8h)·사용자 정의·기존 입력 보존 전 항목 일치"
                : "\n❌ 불일치 " + fail + "건");
        if (fail != 0) System.exit(1);
    }
}
