package com.example.shiftpay;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.icu.util.ChineseCalendar;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.text.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import java.io.*;
import java.net.*;
import java.text.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.pdf.PdfRenderer;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity implements PayCore.DayData, PayCore.Settings {
    public static final int CURRENT_VERSION_CODE = 32;
    public static final String CURRENT_VERSION_NAME = "1.4.3";
    // 화면·안내 문구에 함께 표기하는 정식 라벨 (예: 1.3.3 (빌드 25))
    public static final String CURRENT_VERSION_LABEL = CURRENT_VERSION_NAME + " (빌드 " + CURRENT_VERSION_CODE + ")";
    // 앱 정보 → 안드로이드 전용 앱(APK) 안내에서 쓰는 배포 주소 (웹 버전과 동일)
    static final String APK_DOWNLOAD_URL = "https://realcheol.github.io/shiftpay/downloads/ShiftPay_v1.4.3.apk";
    // 인앱 업데이트 감지: GitHub Pages에 배포한 version.json을 읽어 설치 버전과 비교한다
    static final String VERSION_JSON_URL = "https://realcheol.github.io/shiftpay/version.json";
    static final String WEB_APP_URL = "https://realcheol.github.io/shiftpay/";
    /** 인앱 업데이트 다이얼로그가 여는 APK 주소는 공식 배포 도메인만 허용한다. */
    static final String OFFICIAL_HOST_PREFIX = "https://realcheol.github.io/";

    static boolean isOfficialApkUrl(String url) {
        if (url == null) return false;
        String u = url.trim();
        return u.startsWith(OFFICIAL_HOST_PREFIX) && u.toLowerCase().endsWith(".apk");
    }
    final String[] names = {
        "정상근무", "유급", "주차", "조합설명회(정상 인정)",
        "평일연장(조합설명회 포함)", "휴일근로", "휴일연장", "야간근로", "가급(상주휴게)"
    };
    final String[] keys = {
        "normal", "paid", "weekly", "union",
        "overtime", "holiday", "holidayOT", "night", "gageub"
    };
    // 출근카드 OCR 전용: 종이 카드 7번 열 '연차' 시간을 담는 rowVals 마지막 칸 (keys[] 밖)
    static final int OCR_ANNUAL = 9;
    final String[] settingsNames = {
        "기본시급", "통상시급", "평일연장 배율", "휴일근로 배율", "휴일연장 배율", "야간 추가 배율",
        "근속수당", "가족수당(본인)", "가족수당(가족)", "직책수당", "직무수당", "하계건강지원비 (7~9월)", "기타수당·소급분", "예상 공제액"
    };
    final String[] settingsKeys = {
        "base", "ordinary", "otRate", "holidayRate", "holidayOTRate", "nightRate",
        "tenure", "familySelf", "familyOther", "position", "duty", "summer", "other", "deduction"
    };
    final double[] defaults = {
        13653, 14939, 1.5, 1.5, 2.0, 0.5,
        22500, 20000, 30000, 0, 55000, 45000, 0, 948470
    };

    SharedPreferences prefs;
    Calendar month = Calendar.getInstance();
    LinearLayout root;
    FrameLayout mainContainer;
    View scrimView;
    ScrollView mainScrollView;          // 메인 스크롤 (v1.3.5: 스크롤 위치 유지·TOP 버튼)
    View topFloatBtn;                   // 우측 하단 [▲ TOP] 플로팅 버튼
    ScrollView subScreenScroll;         // v1.3.6: 서브 메뉴 스케일업 애니메이션 대상
    TextView heroNetTv, heroGrossTv, heroDedTv;   // v1.3.6: 소급 토글 시 핀포인트 갱신
    Button heroRetroBtn;
    View retroRowView, retroFormulaView;          // v1.3.6: 영수증·산출식 소급분 행
    // v1.4.0 스팟라이트 투어 대상 뷰 & 오버레이 상태
    View spotQuickBar, spotCalCell, spotStatsCard, spotHeroCard, spotMenuIcon;
    View spotRoot;
    RectF lastSpotHole;               // v1.4.3: 다음 타깃으로 트윈 이동하기 위한 이전 컷아웃
    int spotStep = 0;
    boolean spotTourActive = false;   // 투어 진행 중에만 오버레이를 그린다 (뒤로가기와 지연 그리기 경합 방지)
    // v1.4.0 온보딩 마법사 상태
    Dialog wizardDialog;
    int wizardStep = 1;                // v1.4.3: 현재 온보딩 단계 (뒤로가기 가드용)
    String wizardShiftType = "normal";
    LinearLayout wizCardNormal, wizCardShift;
    TextView wizCardNormalCheck, wizCardShiftCheck;
    EditText wizOrdinary, wizAnnual, wizDependents, wizChildren;
    String wizardRank = "";            // v1.4.3: 온보딩 1단계 직급 (user_rank 저장 전 임시값)
    final java.util.List<android.animation.Animator> wizardAnimators = new ArrayList<>();
    LinearLayout deductSectionHolder;             // v1.3.6: 공제 내역 부분 갱신 홀더
    int pendingScrollY = -1;            // 화면 재그리기 후 복원할 스크롤 위치
    boolean drawerDragMoved = false;
    int pendingCalSlide = 0;            // +1: 다음 달(오른쪽에서 진입), -1: 이전 달(왼쪽에서 진입)
    LinearLayout leftDrawerView;
    LinearLayout rightDrawerView;
    LinearLayout bottomSheetView;
    TextView sheetDateTitle, sheetCurrentStatus;
    LinearLayout sheetPresetGrid;
    int sheetDay = 1;
    View activeDrawer;
    LinearLayout calendarBlock;   // 캘린더(요일줄+날짜 그리드) 묶음 컨테이너 — 좌우 스와이프 영역
    boolean inSubScreen = false;
    boolean isMultiSelectMode = false;
    Set<Integer> selectedDays = new TreeSet<>();
    static final int[] TENURE_AMOUNTS = {
        2000, 12500, 22500, 32500, 42500, 50500, 58500, 65500, 72500, 78500, 84500, 89500
    };
    static final String[] TENURE_LABELS = {
        "1년 미만 (2,000원)", "1년 이상 (12,500원)", "2년 이상 (22,500원)", "3년 이상 (32,500원)",
        "5년 이상 (42,500원)", "7년 이상 (50,500원)", "9년 이상 (58,500원)", "11년 이상 (65,500원)",
        "13년 이상 (72,500원)", "15년 이상 (78,500원)", "17년 이상 (84,500원)", "20년 이상 (89,500원)"
    };

    static int getTenureAllowanceByYears(int fullYears) {
        if (fullYears < 1) return 2000;
        else if (fullYears < 2) return 12500;
        else if (fullYears < 3) return 22500;
        else if (fullYears < 5) return 32500;
        else if (fullYears < 7) return 42500;
        else if (fullYears < 9) return 50500;
        else if (fullYears < 11) return 58500;
        else if (fullYears < 13) return 65500;
        else if (fullYears < 15) return 72500;
        else if (fullYears < 17) return 78500;
        else if (fullYears < 20) return 84500;
        else return 89500;
    }

    int getCalculatedTenureAllowance(String joinStr) {
        try {
            String clean = normalizeDateString(joinStr);
            String[] parts = clean.split("-");
            if (parts.length == 3) {
                LocalDate join = LocalDate.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
                LocalDate today = LocalDate.now();
                if (!today.isBefore(join)) {
                    Period p = Period.between(join, today);
                    return getTenureAllowanceByYears(p.getYears());
                }
            }
        } catch (Exception ignored) {}
        return 22500;
    }

    LinearLayout summaryContainer;
    TextView heading;
    static final int EXPORT_XLSX = 901, IMPORT_XLSX = 902, OCR_CAMERA = 903, OCR_GALLERY = 904, PAYSLIP_CAMERA = 905, PAYSLIP_GALLERY = 906, EXPORT_REPORT_XLSX = 907, PAYSLIP_PDF = 908;
    Uri payslipCameraUri;
    Uri cameraUri;
    /** v1.4.3 ④ — 이번 명세서 인식의 입력 경로 (PDF 원본 / 사진). 검토창 안내문에 쓴다. */
    String payslipSourceLabel = "촬영한 명세서";
    int chosenDay;
    int topInset, bottomInset;

    // 테마 색상 팔레트 (라이트모드 & 다크모드)
    boolean isDark() {
        try {
            return prefs != null && prefs.getBoolean("setting_dark_mode", false);
        } catch (Exception e) {
            return false;
        }
    }
    int colorBg() { return isDark() ? Color.rgb(15, 23, 42) : Color.rgb(248, 250, 252); }
    int colorSurface() { return isDark() ? Color.rgb(30, 41, 59) : Color.WHITE; }
    int colorInk() { return isDark() ? Color.rgb(248, 250, 252) : Color.rgb(15, 23, 42); }
    int colorSub() { return isDark() ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139); }
    int colorBorder() { return isDark() ? Color.rgb(51, 65, 85) : Color.rgb(226, 232, 240); }
    int colorBlue() { return isDark() ? Color.rgb(56, 189, 248) : Color.rgb(0, 91, 172); }
    int colorRed() { return isDark() ? Color.rgb(248, 113, 113) : Color.rgb(220, 38, 38); }
    int colorGreen() { return isDark() ? Color.rgb(74, 222, 128) : Color.rgb(22, 163, 74); }

    boolean isWeekend(int day, int weekday) {
        return weekday == Calendar.SATURDAY || weekday == Calendar.SUNDAY;
    }

    int weekdaySundayZero(int year, int month1, int day) {
        return LocalDate.of(year, month1, day).getDayOfWeek().getValue() % 7;
    }

    int weekday(int day) {
        return weekdaySundayZero(month.get(Calendar.YEAR), month.get(Calendar.MONTH) + 1, day) + 1;
    }

    String dayMode(int day) {
        return prefs.getString(dayKey(day, "mode"), "auto");
    }

    boolean isLeave(int day) {
        String m = dayMode(day);
        return m.equals("annual") || m.equals("summer");
    }

    // 공휴일 목록 캐시 (dayHours가 하루에도 수백 번 호출되므로 JSON 재파싱 방지)
    private Map<String, String> dayHoursHolidayCache = null;
    private int dayHoursHolidayCacheYear = -9999;

    boolean isPaidHolidayDate(int day) {
        int y = month.get(Calendar.YEAR);
        if (dayHoursHolidayCache == null || dayHoursHolidayCacheYear != y) {
            dayHoursHolidayCache = holidayMap(y);
            dayHoursHolidayCacheYear = y;
        }
        String iso = String.format(Locale.US, "%04d%02d%02d", y, month.get(Calendar.MONTH) + 1, day);
        return dayHoursHolidayCache.containsKey(iso);
    }

    double dayHours(int day, int idx) {
        String key = dayKey(day, keys[idx]);
        boolean hasManual = prefs.contains(key);
        return PayCore.dayHours(idx, hasManual, hasManual ? num(key) : 0.0,
                dayMode(day), weekday(day), isPaidHolidayDate(day), isLeave(day));
    }

    void vibrateTick() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    v.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE));
                }
            } else {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.vibrate(18);
            }
        } catch (Exception ignored) {
            try {
                if (mainContainer != null) {
                    mainContainer.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                }
            } catch (Exception ignored2) {}
        }
    }

    // 자동백업 동시 쓰기 방지용 전역 락 (빠른 연속 입력 시 xlsx 손상 원천 차단)
    static final Object AUTO_BACKUP_LOCK = new Object();

    void triggerAutoBackup() {
        new Thread(() -> {
            synchronized (AUTO_BACKUP_LOCK) {
                try {
                    File dir = getExternalFilesDir("AutoBackup");
                    if (dir != null) {
                        dir.mkdirs();
                        File latest = new File(dir, "ShiftPay_자동백업_최신.xlsx");
                        File monthly = new File(dir, "ShiftPay_자동백업_" + ym() + ".xlsx");
                        // 임시 파일에 먼저 기록한 뒤 교체하여 반쯤 쓰인 파일이 남지 않게 한다
                        File tmp = new File(dir, "ShiftPay_자동백업_최신.xlsx.tmp");
                        try (OutputStream out = new FileOutputStream(tmp)) {
                            ExcelBackup.write(out, prefs);
                        }
                        if (!tmp.renameTo(latest)) {
                            try (OutputStream out = new FileOutputStream(latest)) {
                                ExcelBackup.write(out, prefs);
                            }
                            tmp.delete();
                        }
                        File tmpMonthly = new File(dir, "ShiftPay_자동백업_" + ym() + ".xlsx.tmp");
                        try (OutputStream out = new FileOutputStream(tmpMonthly)) {
                            ExcelBackup.write(out, prefs);
                        }
                        if (!tmpMonthly.renameTo(monthly)) {
                            try (OutputStream out = new FileOutputStream(monthly)) {
                                ExcelBackup.write(out, prefs);
                            }
                            tmpMonthly.delete();
                        }
                    }
                } catch (Throwable ignored) {}
            }
        }).start();
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            prefs = getSharedPreferences("shiftpay", MODE_PRIVATE);
            chosenDay = month.get(Calendar.DAY_OF_MONTH);
            topInset = dp(42);
            bottomInset = dp(50);

            int currentYear = month.get(Calendar.YEAR);
            // Clean up and migrate any improperly typed setting_* keys
            for (int i = 0; i < settingsKeys.length; i++) {
                String sk = "setting_" + settingsKeys[i];
                if (prefs.contains(sk)) {
                    try {
                        prefs.getString(sk, "");
                    } catch (ClassCastException e) {
                        try {
                            float f = prefs.getFloat(sk, (float)defaults[i]);
                            String s = (f == (long)f) ? String.valueOf((long)f) : String.valueOf(f);
                            prefs.edit().remove(sk).putString(sk, s).apply();
                        } catch (Exception ignored) {
                            prefs.edit().remove(sk).putString(sk, String.valueOf(defaults[i])).apply();
                        }
                    }
                }
            }

            // 연도별 설정 키(setting_YYYY_xxx)도 문자열 타입으로 정규화 (ClassCastException 방지)
            for (int i = 0; i < settingsKeys.length; i++) {
                for (int y = 2018; y <= 2036; y++) {
                    String yk = "setting_" + y + "_" + settingsKeys[i];
                    if (!prefs.contains(yk)) continue;
                    try {
                        prefs.getString(yk, "");
                    } catch (ClassCastException e) {
                        try {
                            float f = prefs.getFloat(yk, Float.NaN);
                            if (!Float.isNaN(f)) {
                                String s = (f == (long) f) ? String.valueOf((long) f) : String.valueOf(f);
                                prefs.edit().remove(yk).putString(yk, s).apply();
                            } else {
                                prefs.edit().remove(yk).putString(yk, String.valueOf(defaults[i])).apply();
                            }
                        } catch (Exception ignored) {
                            prefs.edit().remove(yk).putString(yk, String.valueOf(defaults[i])).apply();
                        }
                    }
                }
            }

            // ── v1.3.2 마이그레이션: 직책수당(setting_position) ↔ 직무수당(setting_duty) 완전 분리 ──
            // 이전 버전은 직급 선택이 setting_duty(직무수당 자리)를 직책수당 금액으로 덮어써서
            // 사원을 고르면 직무수당 55,000원이 사라졌다. 설치 기기의 기존 값을 한 번만 보정한다.
            if (!prefs.getBoolean("migrated_position_duty_v132", false)) {
                try {
                    SharedPreferences.Editor med = prefs.edit();
                    String rank = prefs.getString("user_rank", "");
                    int rankIdx = -1;
                    for (int i = 0; i < RANK_NAMES.length; i++) {
                        if (RANK_NAMES[i].equals(rank)) { rankIdx = i; break; }
                    }
                    int posAmt = rankIdx >= 0 ? RANK_POSITION_AMOUNTS[rankIdx] : 0;
                    if (!prefs.contains("setting_position")) {
                        med.putString("setting_position", String.valueOf(posAmt));
                    }
                    for (int y = 2018; y <= 2036; y++) {
                        String yk = "setting_" + y + "_position";
                        if (!prefs.contains(yk)) med.putString(yk, String.valueOf(posAmt));
                    }
                    // 기존 setting_duty 값이 직책수당 금액(0/5만/10만/20만)과 같으면 직무수당 기본값 55,000원으로 되살린다
                    if (prefs.contains("setting_duty")) {
                        String ds = getSettingStr("duty", "");
                        double dv = 55000;
                        try { if (ds != null && !ds.trim().isEmpty()) dv = Double.parseDouble(ds.trim()); } catch (Exception ignored) {}
                        if (dv == 0 || dv == 50000 || dv == 100000 || dv == 200000) med.putString("setting_duty", "55000");
                    } else {
                        med.putString("setting_duty", "55000");
                    }
                    for (int y = 2018; y <= 2036; y++) {
                        String dk = "setting_" + y + "_duty";
                        if (!prefs.contains(dk)) { med.putString(dk, "55000"); continue; }
                        String ds = getSettingStr(y + "_duty", "");
                        double dv = 55000;
                        try { if (ds != null && !ds.trim().isEmpty()) dv = Double.parseDouble(ds.trim()); } catch (Exception ignored) {}
                        if (dv == 0 || dv == 50000 || dv == 100000 || dv == 200000) med.putString(dk, "55000");
                    }
                    if (!prefs.contains("setting_duty")) med.putString("setting_duty", "55000");
                    med.putBoolean("migrated_position_duty_v132", true);
                    med.apply();
                } catch (Exception ignored) {}
            }

            // ── v1.4.3: 오염된 공제 실측치(ded_l_*) 자동 초기화 ──
            //  v1.3.5 시절 명세서 OCR이 다른 칸(기본급·지급계)을 공제 칸으로 잘못 읽어 저장한 값이
            //  남아 있으면 [예상 공제액]이 급여를 잠식한다(예: 소득세 -312만원 → 실수령 68만원).
            //  소득세 100만원 초과(|부호 반전 포함|) 또는 공제 합계 200만원 초과, 그 밖의 항목 200만원 초과는
            //  정상 명세서에서 나올 수 없으므로 학습값 7개 키를 통째로 지운다. 앱을 삭제했다 다시 설치해도
            //  자동 백업/복원으로 되살아난 shared_prefs 까지 이 자리에서 정화된다.
            try {
                long badIncome = Math.abs(prefs.getLong("ded_l_income", 0));
                long badTotal = Math.abs(prefs.getLong("ded_l_total", 0));
                long worstItem = 0;
                for (String k : new String[]{"ded_l_local", "ded_l_health", "ded_l_pension", "ded_l_employ", "ded_l_union"}) {
                    worstItem = Math.max(worstItem, Math.abs(prefs.getLong(k, 0)));
                }
                if (badIncome > 1000000L || badTotal > 2000000L || worstItem > 2000000L) {
                    prefs.edit()
                            .remove("ded_l_income").remove("ded_l_local").remove("ded_l_health")
                            .remove("ded_l_pension").remove("ded_l_employ").remove("ded_l_union")
                            .remove("ded_l_gross").remove("ded_l_total")
                            .putBoolean("ded_l_cleared_v143", true)
                            .apply();
                }
            } catch (Exception ignored) {}

            // v1.4.3 공제 자동 예측 기본값: 실측치 유무와 무관하게 자동 예측(법정 요율·간이세액표)이 기본.
            //  기존에 직접 입력해 둔 공제액이 있으면 그 값을 그대로 존중한다.
            if (!prefs.contains("ded_auto")) {
                boolean hasManual = false;
                try {
                    String dv = prefs.getString("setting_deduction", "");
                    hasManual = dv != null && !dv.trim().isEmpty() && Double.parseDouble(dv.trim()) > 0;
                } catch (Exception ignored) {}
                prefs.edit().putBoolean("ded_auto", !hasManual).apply();
            }

            // v1.3.6 가족수당 ↔ 부양가족 수 기본 연동: 본인 외 1인당 10,000원.
            //  기존에 입력해 둔 가족수당이 1만원 단위면 그 금액에 맞춰 부양가족 수(본인 포함)를 맞춰
            //  업그레이드만으로 금액이 바뀌지 않게 하고, 1만원 단위가 아니면 직접 입력값을 그대로 둔다.
            if (!prefs.contains("setting_family_link")) {
                boolean link = true;
                try {
                    if (prefs.contains("setting_familyOther")) {
                        long fam = Math.round(get("familyOther"));
                        if (fam > 0 && fam % 10000 == 0) {
                            int implied = (int) (fam / 10000) + 1;
                            if (implied > getDeductionDependents()) {
                                prefs.edit().putString("ded_dependents", String.valueOf(implied)).apply();
                            }
                        } else if (fam > 0) {
                            link = false;   // 1만원 단위가 아닌 기존 입력은 독립 유지
                        }
                    }
                } catch (Throwable ignored) {}
                prefs.edit().putBoolean("setting_family_link", link).apply();
            }

            if (prefs.getInt("app_version_code", 0) < CURRENT_VERSION_CODE || !prefs.getString("official_2026", "").contains("제헌절") || !prefs.getString("official_2027", "").contains("설날 연휴")) {
                // v1.3.1 버전 갱신: 공휴일 완벽 동기화 및 엑셀 복원/연차 계산 안정화
                injectOfficialHolidays(2025);
                injectOfficialHolidays(2026);
                injectOfficialHolidays(2027);
                injectOfficialHolidays(2028);
                prefs.edit().putInt("app_version_code", CURRENT_VERSION_CODE).apply();
            }
            triggerAutoBackup();

            // 최상단 상태표시줄 및 최하단 시스템 내비게이션 바와 화면 내용 겹침 방지 (안전 여백 자동 확보)
            try {
                getWindow().getDecorView().setOnApplyWindowInsetsListener((v, insets) -> {
                    try {
                        if (insets != null) {
                            int top = insets.getSystemWindowInsetTop();
                            int bottom = insets.getSystemWindowInsetBottom();
                            topInset = Math.max(top + dp(6), dp(42));
                            bottomInset = Math.max(bottom + dp(12), dp(50));
                            if (root != null) {
                                root.setPadding(dp(12), topInset, dp(12), bottomInset + dp(24));
                            }
                        }
                    } catch (Exception ignored) {}
                    return v.onApplyWindowInsets(insets);
                });
            } catch (Exception ignored) {}

            showPicoSplash();
            try {
                new android.os.Handler(getMainLooper()).postDelayed(() -> checkForUpdate(false), 5000);
            } catch (Throwable ignored) {}
        } catch (Exception e) {
            ScrollView sv = new ScrollView(this);
            TextView tv = new TextView(this);
            tv.setText("오류 발생:\n" + e.toString());
            sv.addView(tv);
            setContentView(sv);
        }
    }

    int dp(int n) {
        return (int) (getResources().getDisplayMetrics().density * n + .5f);
    }

    // 전체 글자 크기(폰트 포인트) 확대 및 촘촘한 줄간격 적용 (가독성 향상)
    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size + 2);
        t.setTextColor(colorInk());
        t.setLineSpacing(dp(1), 0.94f);
        t.setPadding(dp(4), dp(2), dp(4), dp(2));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    TextView textDirect(String s, int exactSp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(exactSp);
        t.setTextColor(colorInk());
        t.setLineSpacing(dp(1), 0.94f);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    Button button(String s, Runnable r) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(colorInk());
        b.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setOnClickListener(v -> { if (r != null) r.run(); });
        return b;
    }

    LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(colorBg());
        l.setPadding(dp(12), topInset, dp(12), bottomInset + dp(24));
        return l;
    }

    LinearLayout subHeaderBar;

    void start(String title) {
        inSubScreen = true;
        closeDrawers(null);

        FrameLayout subHolder = new FrameLayout(this);
        subHolder.setBackgroundColor(colorBg());
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(colorBg());
        root = vertical();
        scroll.addView(root);
        subHolder.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        setContentView(subHolder);

        // v1.3.6 ④: 메뉴에서 연 서브 창이 화면 중앙에서 0.9 → 1.0 으로 0.2초 만에 스르륵 커지며 페이드인
        subScreenScroll = scroll;
        scroll.setScaleX(0.9f);
        scroll.setScaleY(0.9f);
        scroll.setAlpha(0f);
        scroll.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(200)
                .setInterpolator(new DecelerateInterpolator()).start();

        // 서브화면 공통 상단 헤더: 뒤로가기 버튼(←) + 화면 타이틀 + 우측 액션 영역
        LinearLayout headerBar = new LinearLayout(this);
        headerBar.setOrientation(LinearLayout.HORIZONTAL);
        headerBar.setGravity(Gravity.CENTER_VERTICAL);
        headerBar.setPadding(0, 0, 0, dp(12));

        TextView backBtn = textDirect("←", 22, true);
        backBtn.setTextColor(colorBlue());
        backBtn.setPadding(dp(4), dp(4), dp(12), dp(4));
        backBtn.setOnClickListener(v -> leaveSubScreen());
        headerBar.addView(backBtn);

        TextView titleTv = textDirect(title, 20, true);
        titleTv.setTextColor(colorInk());
        headerBar.addView(titleTv, new LinearLayout.LayoutParams(0, -2, 1));

        subHeaderBar = headerBar;
        root.addView(headerBar);
    }

    String ym() {
        return String.format(Locale.US, "%04d-%02d", month.get(Calendar.YEAR), month.get(Calendar.MONTH) + 1);
    }

    String dayKey(int day, String key) {
        return ym() + "-" + String.format(Locale.US, "%02d", day) + "-" + key;
    }

    String getSettingStr(String k, String def) {
        String fullKey = "setting_" + k;
        if (prefs == null || !prefs.contains(fullKey)) return def;
        try {
            return prefs.getString(fullKey, def);
        } catch (ClassCastException e) {
            try {
                float f = prefs.getFloat(fullKey, Float.NaN);
                if (!Float.isNaN(f)) {
                    String s = (f == (long)f) ? String.valueOf((long)f) : String.valueOf(f);
                    prefs.edit().remove(fullKey).putString(fullKey, s).apply();
                    return s;
                }
            } catch (Exception ignored) {}
            try {
                int n = prefs.getInt(fullKey, Integer.MIN_VALUE);
                if (n != Integer.MIN_VALUE) {
                    String s = String.valueOf(n);
                    prefs.edit().remove(fullKey).putString(fullKey, s).apply();
                    return s;
                }
            } catch (Exception ignored) {}
            return def;
        } catch (Exception e) {
            return def;
        }
    }

    // ── PayCore 연동 (순수 계산 코어가 화면·설정값을 그대로 읽도록 위임) ──
    @Override public int daysInMonth() { return month.getActualMaximum(Calendar.DAY_OF_MONTH); }
    @Override public double hours(int day, int idx) { return dayHours(day, idx); }
    @Override public String mode(int day) { return dayMode(day); }
    @Override public boolean has(int day, int idx) {
        return prefs != null && prefs.contains(dayKey(day, keys[idx]));
    }

    /**
     * 다른 달(통계 월 이동)의 근무 기록을 PayCore가 같은 규칙으로 읽도록 감싼 어댑터.
     * 이번 달 화면(dayHours)과 완전히 같은 계산(PayCore.dayHours)을 쓰므로 값이 어긋나지 않는다.
     */
    class MonthAdapter implements PayCore.MonthData {
        final int y, m1;
        final String prefix;
        final Map<String, String> hols;

        MonthAdapter(int y, int m1) {
            this.y = y;
            this.m1 = m1;
            this.prefix = String.format(Locale.US, "%04d-%02d-", y, m1);
            this.hols = holidayMap(y);
        }

        @Override public int daysInMonth() { return LocalDate.of(y, m1, 1).lengthOfMonth(); }

        @Override public String mode(int day) {
            return prefs.getString(prefix + String.format(Locale.US, "%02d", day) + "-mode", "auto");
        }

        @Override public boolean has(int day, int idx) {
            return prefs.contains(prefix + String.format(Locale.US, "%02d", day) + "-" + keys[idx]);
        }

        @Override public double hours(int day, int idx) {
            String k = prefix + String.format(Locale.US, "%02d", day) + "-" + keys[idx];
            boolean manual = prefs.contains(k);
            String mode = mode(day);
            int dow = LocalDate.of(y, m1, day).getDayOfWeek().getValue() % 7 + 1; // 1=일 … 7=토
            boolean hol = hols.containsKey(String.format(Locale.US, "%04d%02d%02d", y, m1, day));
            boolean leave = "annual".equals(mode) || "summer".equals(mode);
            return PayCore.dayHours(idx, manual, manual ? num(k) : 0.0, mode, dow, hol, leave);
        }
    }

    /** 이번 달 출근카드 1:1 집계 */
    double[] cardBreakdown() {
        return PayCore.cardBreakdown(this, isShiftWorker());
    }

    /** 특정 연·월 출근카드 1:1 집계 (통계 월 이동) */
    double[] cardBreakdown(int y, int m1) {
        return PayCore.cardBreakdown(new MonthAdapter(y, m1), isShiftWorker());
    }
    @Override public boolean isSummerMonth() {
        int m = month.get(Calendar.MONTH);
        return m >= 6 && m <= 8;
    }
    @Override public boolean isRetroActive() { return isRetroActiveThisMonth(); }
    @Override public double retroAmount() { return getRetroPayAmount(); }

    @Override
    public double get(String k) {
        int y = month.get(Calendar.YEAR);
        String yearVal = getSettingStr(y + "_" + k, null);
        String val = (yearVal != null && !yearVal.trim().isEmpty()) ? yearVal : getSettingStr(k, null);
        for (int i = 0; i < settingsKeys.length; i++) {
            if (settingsKeys[i].equals(k)) {
                if (val == null || val.trim().isEmpty()) return defaults[i];
                try {
                    return Double.parseDouble(val.trim());
                } catch (Exception e) {
                    return defaults[i];
                }
            }
        }
        return 0;
    }

    double num(String k) {
        try {
            return Double.parseDouble(prefs.getString(k, "0"));
        } catch (Exception e) {
            return 0;
        }
    }

    double[] totals() {
        return PayCore.totals(this);
    }

    // ── v1.3.5 공제액 정밀 예측 ─────────────────────────────
    //  4대보험 법정 요율 + 소득세 간이세액표(부양가족 수·선공제율) + 노조회비 공식.
    //  직전 급여명세서를 OCR로 읽어 두었으면 그 실측 6개 항목을 세전 급여에 맞춰 보정한다.
    boolean isAutoDeduction() {
        return prefs == null || prefs.getBoolean("ded_auto", true);
    }

    int getDeductionDependents() {
        try { return Math.max(1, Integer.parseInt(prefStr("ded_dependents", "1").trim())); }
        catch (Exception e) { return 1; }
    }

    /** v1.4.2: 8세~20세 자녀 수 (자녀 세액공제용 · 기본 0명) */
    int getDeductionChildren() {
        try { return Math.max(0, Math.min(10, Integer.parseInt(prefStr("ded_children", "0").trim()))); }
        catch (Exception e) { return 0; }
    }

    /** 설정 화면 표기용 자녀 세액공제액 (예: −45,830원) */
    String childCreditText() {
        long c = DeductionCore.childCredit(getDeductionChildren());
        return c > 0 ? "−" + won(c) : "해당 없음";
    }

    double getDeductionAdvanceRate() {
        try {
            double v = Double.parseDouble(prefStr("ded_advance_rate", "1.0").trim());
            return (v == 80 || v == 120 || v == 100) ? v / 100.0 : Math.max(0.5, Math.min(1.5, v));
        } catch (Exception e) { return 1.0; }
    }

    long getDeductionPensionBase() {
        try { return Long.parseLong(prefStr("ded_pension_base", "0").trim().replace(",", "")); }
        catch (Exception e) { return 0; }
    }

    long getDeductionHealthBase() {
        try { return Long.parseLong(prefStr("ded_health_base", "0").trim().replace(",", "")); }
        catch (Exception e) { return 0; }
    }

    /**
     * v1.3.6 ⑥: 엑셀 복원에서 ded_dependents(int)·ded_advance_rate(float)·ded_pension_base(long)처럼
     * 자료형이 바뀌어 저장되어도 값을 읽을 수 있게 문자열로 되돌린다.
     */
    String prefStr(String key, String def) {
        if (prefs == null) return def;
        try {
            return prefs.getString(key, def);
        } catch (ClassCastException e1) {
            try { return String.valueOf(prefs.getInt(key, Integer.parseInt(def.trim()))); } catch (Exception e2) {}
            try { return String.valueOf(prefs.getFloat(key, Float.parseFloat(def.trim()))); } catch (Exception e3) {}
            try { return String.valueOf(prefs.getLong(key, Long.parseLong(def.trim()))); } catch (Exception e4) {}
            return def;
        }
    }

    /** v1.3.6: 가족수당(가족)을 부양가족 수와 연동 중인지 (setting_family_link) */
    boolean isFamilyAllowanceLinked() {
        return prefs == null || prefs.getBoolean("setting_family_link", true);
    }

    /** 연동 시 부양가족 수(본인 포함) → 가족수당(가족) = (부양가족 수 − 1) × 10,000원 */
    double linkedFamilyAllowance() {
        return PayCore.familyAllowanceFor(getDeductionDependents());
    }

    /** 설정 화면에 보여 주는 연동 계산식 설명 (예: 부양가족 4명(본인 포함) → 가족 3명 × 10,000원 = 30,000원) */
    String familyAllowanceNote() {
        int n = getDeductionDependents();
        int fam = Math.max(0, n - 1);
        return "부양가족 " + n + "명(본인 포함) → 가족 " + fam + "명 × 10,000원 = "
                + won(PayCore.familyAllowanceFor(n));
    }

    long[] getLearnedDeduction() {
        if (prefs == null) return null;
        long total = prefs.getLong("ded_l_total", 0);
        if (total <= 0) return null;
        return new long[]{
                prefs.getLong("ded_l_income", 0), prefs.getLong("ded_l_local", 0),
                prefs.getLong("ded_l_health", 0), prefs.getLong("ded_l_pension", 0),
                prefs.getLong("ded_l_employ", 0), prefs.getLong("ded_l_union", 0)
        };
    }

    long getLearnedDeductionGross() { return prefs == null ? 0 : prefs.getLong("ded_l_gross", 0); }

    /**
     * v1.4.3: 자동 예측은 언제나 법정 요율·국세청 간이세액표로만 계산한다.
     *  v1.3.5의 실측치 학습(hasLearned)이 간이세액표를 덮어쓰던 경로는 useLearned=false로 전면 차단하고,
     *  실측치는 참고용(learnedAvailable / learnedIgnored)으로만 남긴다.
     */
    DeductionCore.Result deductionResult(double gross) {
        return DeductionCore.compute(Math.round(gross), get("ordinary"), getDeductionDependents(),
                getDeductionChildren(), getDeductionAdvanceRate(), getDeductionPensionBase(), getDeductionHealthBase(),
                getLearnedDeductionGross(), getLearnedDeduction(), false);
    }

    @Override
    public double deductionFor(double gross) {
        if (!isAutoDeduction()) return get("deduction");
        return deductionResult(gross).total;
    }

    String won(double v) {
        return NumberFormat.getNumberInstance(Locale.KOREA).format(Math.round(v)) + "원";
    }

    /** 차액 표기: 증가는 + 부호를 붙인다 */
    String signedWon(long v) {
        return (v > 0 ? "+" : "") + won(v);
    }

    String hours(double v) {
        return new DecimalFormat("0.##").format(v) + "시간";
    }

    String hoursShort(double v) {
        return new DecimalFormat("0.##").format(v);
    }

    int countWorkDays() {
        return PayCore.countWorkDays(this);
    }

    double[] amounts() {
        return PayCore.amounts(this, this);
    }


    // 현대스틸파이프 공장 공식명칭 및 드론 항공사진
    static final String[] FACTORY_NAMES = {
        "본사 / 울산 1공장 (ERW)",
        "울산 2공장 (LSAW)",
        "울산 3공장 (SPIRAL)"
    };
    static final String[] FACTORY_FILES = {
        "factories/factory_1.jpg",
        "factories/factory_2.jpg",
        "factories/factory_3.jpg"
    };

    static final String[] RANK_NAMES = {
        "기술직 - 사원 (직책수당: 0원)",
        "기술직 - 주임 (직책수당: 50,000원)",
        "기술직 - 계장 (직책수당: 100,000원)",
        "기술직 - 기장 (직책수당: 200,000원)",
        "일반직 - G1 매니저",
        "일반직 - G2 매니저",
        "일반직 - G3 책임매니저",
        "일반직 - G4 책임매니저"
    };
    static final int[] RANK_POSITION_AMOUNTS = {
        0, 50000, 100000, 200000,
        0, 0, 0, 0
    };
    static final String[] SHIFT_TYPE_NAMES = {
        "🏢 상주근무 (주간 전담 • 상주휴게수당 적용)",
        "🔄 교대근무 (주야 격주 • 교대수당 20만원 적용)"
    };

    // 임단협 타결 소급분 연동 헬퍼 (제작자 요청)
    boolean isRetroActiveThisMonth() {
        if (prefs == null) return false;
        String key = "retro_active_" + ym();
        if (prefs.contains(key)) {
            return prefs.getBoolean(key, false);
        }
        int y = month.get(Calendar.YEAR), m = month.get(Calendar.MONTH) + 1;
        int targetM = prefs.getInt("retro_target_month", 9);
        int targetY = prefs.getInt("retro_target_year", 2026);
        return (y == targetY && m == targetM);
    }

    void toggleRetroActiveThisMonth() {
        if (prefs == null) return;
        boolean curr = isRetroActiveThisMonth();
        prefs.edit().putBoolean("retro_active_" + ym(), !curr).apply();
    }

    double getRetroPayAmount() {
        if (prefs == null) return 1452800;
        return prefs.getInt("retro_fixed_amount", 1452800);
    }

    void showRetroPaySettingsDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(10), dp(20), dp(10));

        TextView infoTv = textDirect("💰 2026 임단협 타결 소급분 설정\n• 시급 인상분: 516원\n• 소급 기간: 1월~8월 (8개월 누적)\n• 타결 적용월: 9월 급여 반영\n• 기준 산정액: 1,452,800원 (2026 단협 공식 산출 기준)", 13, false);
        infoTv.setPadding(0, 0, 0, dp(12));
        l.addView(infoTv);

        TextView lbl1 = textDirect("소급분 지급액 (원 단위 직접 수정 가능):", 12, true);
        l.addView(lbl1);
        EditText amtEt = new EditText(this);
        amtEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        amtEt.setText(String.valueOf((int)getRetroPayAmount()));
        l.addView(amtEt);

        new AlertDialog.Builder(this)
            .setTitle("💰 임단협 소급분 상세 설정")
            .setView(l)
            .setPositiveButton("저장", (d, w) -> {
                try {
                    int amt = Integer.parseInt(amtEt.getText().toString().trim());
                    prefs.edit().putInt("retro_fixed_amount", amt).apply();
                    vibrateTick();
                    showMain();
                } catch (Exception ignored) {}
            })
            .setNeutralButton("2026 기본값(145만) 복원", (d, w) -> {
                prefs.edit().putInt("retro_fixed_amount", 1452800).apply();
                vibrateTick();
                showMain();
            })
            .setNegativeButton("취소", null)
            .show();
    }

    @Override
    public boolean isShiftWorker() {
        return prefs != null && "shift".equals(prefs.getString("user_shift_type", "normal"));
    }

    String getShiftTypeName() {
        return isShiftWorker() ? "교대근무" : "상주근무";
    }

    void showShiftTypeSelectorDialog(Button triggerBtn) {
        new AlertDialog.Builder(this)
            .setTitle("근무 형태 선택 (수당 자동 연동)")
            .setSingleChoiceItems(SHIFT_TYPE_NAMES, isShiftWorker() ? 1 : 0, (d, which) -> {
                vibrateTick();
                String val = (which == 1) ? "shift" : "normal";
                prefs.edit().putString("user_shift_type", val).apply();
                if (triggerBtn != null) {
                    triggerBtn.setText(which == 1 ? "🔄 교대근무 (주야 10h • 교대수당 20만원) ▾" : "🏢 상주근무 (주간 8h • 상주휴게수당) ▾");
                }
                d.dismiss();
                Toast.makeText(this, (which == 1 ? "교대근무(교대수당 20만원 연동)" : "상주근무(상주휴게수당 연동)") + "로 설정되었습니다.", Toast.LENGTH_SHORT).show();
                closeDrawers(this::showMain);
            })
            .setNegativeButton("취소", null)
            .show();
    }


    int getFactoryIndex() {
        if (prefs == null) return 1;
        try {
            return prefs.getInt("user_factory_idx", 1);
        } catch (ClassCastException e) {
            try {
                String s = prefs.getString("user_factory_idx", "1");
                int val = Integer.parseInt(s.trim());
                prefs.edit().remove("user_factory_idx").putInt("user_factory_idx", val).apply();
                return val;
            } catch (Exception ignored) {
                return 1;
            }
        } catch (Exception e) {
            return 1;
        }
    }
    String getFactoryName() {
        int idx = getFactoryIndex();
        if (idx >= 1 && idx <= 3) return FACTORY_NAMES[idx - 1];
        return FACTORY_NAMES[0];
    }
    void setFactoryIndex(int idx) {
        if (prefs != null) prefs.edit().putInt("user_factory_idx", idx).apply();
    }

    Drawable getFactoryBannerDrawable(int minHeightDp, boolean isTopBar) {
        int idx = getFactoryIndex();
        String assetPath = (idx >= 1 && idx <= 3) ? FACTORY_FILES[idx - 1] : FACTORY_FILES[0];
        try (InputStream is = getAssets().open(assetPath)) {
            Bitmap orig = BitmapFactory.decodeStream(is);
            if (orig != null) {
                Bitmap result = Bitmap.createBitmap(orig.getWidth(), orig.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(result);
                canvas.drawBitmap(orig, 0, 0, null);
                Paint p = new Paint();
                int alpha = isDark() ? 175 : 140;
                int tint = isDark() ? Color.rgb(10, 18, 32) : Color.rgb(15, 30, 60);
                p.setColor(Color.argb(alpha, Color.red(tint), Color.green(tint), Color.blue(tint)));
                canvas.drawRect(0, 0, orig.getWidth(), orig.getHeight(), p);
                return new BitmapDrawable(getResources(), result);
            }
        } catch (Exception ignored) {}
        return cellBg(isDark() ? Color.rgb(20, 30, 48) : Color.rgb(235, 243, 252), colorBorder(), dp(1));
    }

    void showFactorySelectorDialog() {
        new AlertDialog.Builder(this)
            .setTitle("근무 공장 선택")
            .setSingleChoiceItems(FACTORY_NAMES, getFactoryIndex() - 1, (d, which) -> {
                vibrateTick();
                setFactoryIndex(which + 1);
                d.dismiss();
                Toast.makeText(this, FACTORY_NAMES[which] + "으로 설정되었습니다.", Toast.LENGTH_SHORT).show();
                if (inSubScreen) {
                    showSettings();
                } else {
                    closeDrawers(this::showMain);
                }
            })
            .setNegativeButton("취소", null)
            .show();
    }

    String getRankShortTitle() {
        String full = prefs != null ? prefs.getString("user_rank", "") : "";
        if (full.contains("사원")) return "사원";
        if (full.contains("주임")) return "주임";
        if (full.contains("계장")) return "계장";
        if (full.contains("기장")) return "기장";
        if (full.contains("G1")) return "G1 매니저";
        if (full.contains("G2")) return "G2 매니저";
        if (full.contains("G3")) return "G3 책임";
        if (full.contains("G4")) return "G4 책임";
        return full.isEmpty() ? "" : full;
    }


    // 날짜 문자열 정규화 (8자리 숫자 '19800101' -> '1980-01-01' 자동 변환 및 인식) (v1.2.7)
    String normalizeDateString(String input) {
        if (input == null) return "";
        String s = input.trim();
        String digits = s.replaceAll("[^0-9]", "");
        if (digits.length() == 8) {
            return digits.substring(0, 4) + "-" + digits.substring(4, 6) + "-" + digits.substring(6, 8);
        }
        if (digits.length() > 8) {
            digits = digits.substring(0, 8);
            return digits.substring(0, 4) + "-" + digits.substring(4, 6) + "-" + digits.substring(6, 8);
        }
        String clean = s.replace(".", "-").replace("/", "-");
        String[] parts = clean.split("-");
        if (parts.length == 3) {
            try {
                int y = Integer.parseInt(parts[0].trim());
                int m = Integer.parseInt(parts[1].trim());
                int d = Integer.parseInt(parts[2].trim());
                return String.format(Locale.US, "%04d-%02d-%02d", y, m, d);
            } catch (Exception ignored) {}
        }
        return s;
    }

    static class DateAutoHyphenWatcher implements TextWatcher {
        private final EditText editText;
        private final Runnable onChange;
        private boolean isFormatting = false;

        DateAutoHyphenWatcher(EditText editText, Runnable onChange) {
            this.editText = editText;
            this.onChange = onChange;
        }

        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void afterTextChanged(Editable s) {
            if (isFormatting) return;
            isFormatting = true;

            String raw = s.toString();
            String digits = raw.replaceAll("[^0-9]", "");
            if (digits.length() > 8) digits = digits.substring(0, 8);

            StringBuilder formatted = new StringBuilder();
            int len = digits.length();
            if (len <= 4) {
                formatted.append(digits);
            } else if (len <= 6) {
                formatted.append(digits.substring(0, 4)).append("-").append(digits.substring(4));
            } else {
                formatted.append(digits.substring(0, 4)).append("-")
                         .append(digits.substring(4, 6)).append("-")
                         .append(digits.substring(6));
            }

            String result = formatted.toString();
            if (!raw.equals(result)) {
                editText.setText(result);
                editText.setSelection(result.length());
            }

            isFormatting = false;
            if (onChange != null) onChange.run();
        }
    }

    String getJoinDateStr() {
        return normalizeDateString(prefs != null ? prefs.getString("user_join_date", "") : "");
    }

    int getYearsOfService() {
        try {
            String clean = normalizeDateString(getJoinDateStr());
            String[] parts = clean.split("-");
            if (parts.length == 3) {
                LocalDate join = LocalDate.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
                LocalDate today = LocalDate.now();
                Period p = Period.between(join, today);
                return Math.max(1, p.getYears() + 1);
            }
        } catch (Exception ignored) {}
        return 1;
    }

    String getJoinServiceCountdownText(String joinStr) {
        try {
            String clean = normalizeDateString(joinStr);
            if (clean.length() < 10) {
                return "입사년월일을 입력하시면 입사 년차 및 근속일수가 계산됩니다.";
            }
            String[] parts = clean.split("-");
            if (parts.length != 3) return "입사년월일(8자리 숫자)을 입력해 주세요.";
            int y = Integer.parseInt(parts[0]);
            int m = Integer.parseInt(parts[1]);
            int d = Integer.parseInt(parts[2]);

            LocalDate join = LocalDate.of(y, m, d);
            LocalDate today = LocalDate.now();

            if (today.isBefore(join)) {
                return "🌱 입사 예정일 이전입니다.";
            }

            long totalDays = ChronoUnit.DAYS.between(join, today);
            Period p = Period.between(join, today);
            int serviceYear = p.getYears() + 1;

            return "🌱 입사 " + serviceYear + "년차 (" + p.getYears() + "년 " + p.getMonths() + "개월 " + p.getDays() + "일 - " + totalDays + "일) 입니다.";
        } catch (Exception e) {
            return "입사년월일 형식(YYYY-MM-DD)을 확인해 주세요.";
        }
    }

    float getBaseAnnualLeave() {
        return prefs != null ? prefs.getFloat("user_annual_leave_base", 15.0f) : 15.0f;
    }

    float getUsedAnnualLeaveDays() {
        return getUsedAnnualLeaveDays(Calendar.getInstance().get(Calendar.YEAR));
    }

    // 연차 사용일수: 연차 1일, 오전/오후 반차는 0.5일로 집계 (11-09 일괄 입력 반차 차감 누락 패치)
    float getUsedAnnualLeaveDays(int targetYear) {
        if (prefs == null) return 0f;
        float count = 0f;
        String yearPrefix = targetYear + "-";
        Map<String, ?> all = prefs.getAll();
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            String k = entry.getKey();
            if (k.startsWith(yearPrefix) && k.endsWith("-mode")) {
                Object val = entry.getValue();
                if ("annual".equals(val)) {
                    count += 1f;
                } else if ("half_am".equals(val) || "half_pm".equals(val)) {
                    count += 0.5f;
                }
            }
        }
        return count;
    }

    float getRemainingAnnualLeave() {
        return getRemainingAnnualLeave(Calendar.getInstance().get(Calendar.YEAR));
    }

    float getRemainingAnnualLeave(int targetYear) {
        float base = getBaseAnnualLeave();
        float used = getUsedAnnualLeaveDays(targetYear);
        float rem = base - used;
        return rem < 0 ? 0 : rem;
    }

    String getRemainingAnnualLeaveText() {
        float rem = getRemainingAnnualLeave();
        String remStr = (rem == (long)rem) ? String.valueOf((long)rem) : String.format(Locale.US, "%.1f", rem);
        return "현재 남은 연차 일수 총 " + remStr + "일";
    }

    String getUserSummaryLine() {
        String name = prefs != null ? prefs.getString("user_name", "") : "";
        if (name.trim().isEmpty()) {
            return "기본정보 미입력 (터치하여 설정)";
        }
        String rank = getRankShortTitle();
        String prefix = rank.isEmpty() ? name + "님" : rank + " " + name + "님";
        String shift = isShiftWorker() ? "교대" : "상주";
        int serviceYear = getYearsOfService();
        float rem = getRemainingAnnualLeave();
        String remStr = (rem == (long)rem) ? String.valueOf((long)rem) : String.format(Locale.US, "%.1f", rem);
        String joinStr = getJoinDateStr();
        if (joinStr.isEmpty()) {
            return prefix + "  •  " + shift + "  •  남은 연차 " + remStr + "일";
        }
        return prefix + "  •  " + shift + "  •  입사 " + serviceYear + "년차  •  남은 연차 " + remStr + "일";
    }

    String getUserSummaryMultiline() {
        String name = prefs != null ? prefs.getString("user_name", "") : "";
        if (name.trim().isEmpty()) {
            return "기본정보 미입력\n터치하여 설정";
        }
        String rank = getRankShortTitle();
        String prefix = rank.isEmpty() ? name + "님" : rank + " " + name + "님";
        int serviceYear = getYearsOfService();
        float rem = getRemainingAnnualLeave();
        String remStr = (rem == (long)rem) ? String.valueOf((long)rem) : String.format(Locale.US, "%.1f", rem);
        String joinStr = getJoinDateStr();
        if (joinStr.isEmpty()) {
            return prefix + "\n남은 연차수 " + remStr + "일";
        }
        return prefix + "\n입사 " + serviceYear + "년차\n남은 연차수 " + remStr + "일";
    }

    String getCombinedDdayBannerText(String birthStr, String joinStr) {
        StringBuilder sb = new StringBuilder();
        sb.append(getRetirementCountdownText(birthStr)).append("\n");
        sb.append(getJoinServiceCountdownText(joinStr)).append("\n");
        sb.append("🌴 " + getRemainingAnnualLeaveText());
        return sb.toString();
    }

    String getRetirementCountdownText(String birthStr) {
        try {
            String clean = normalizeDateString(birthStr);
            if (clean.length() < 10) {
                return "생년월일을 입력하시면 만 60세 정년 퇴직 D-Day가 계산됩니다.";
            }
            String[] parts = clean.split("-");
            if (parts.length != 3) return "생년월일(8자리 숫자)을 입력해 주세요.";
            int y = Integer.parseInt(parts[0]);
            int m = Integer.parseInt(parts[1]);
            int d = Integer.parseInt(parts[2]);

            LocalDate birth = LocalDate.of(y, m, d);
            // 단체협약 제28조: 정년은 만 60세에 도달하는 해의 말일(12월 31일)로 한다
            LocalDate retireDate = LocalDate.of(birth.getYear() + 60, 12, 31);
            LocalDate today = LocalDate.now();

            if (today.isAfter(retireDate) || today.isEqual(retireDate)) {
                return "🎉 명예로운 만 60세 정년을 축하드립니다!";
            }

            long totalDays = ChronoUnit.DAYS.between(today, retireDate);
            Period p = Period.between(today, retireDate);

            return "⏳ 만 60세 정년 퇴직까지 " + p.getYears() + "년 " + p.getMonths() + "개월 " + p.getDays() + "일 남았습니다. (D-" + totalDays + "일)";
        } catch (Exception e) {
            return "생년월일 형식(YYYY-MM-DD)을 확인해 주세요.";
        }
    }

    // 메인 화면 (좌우 서랍 슬라이드 및 상업용 카드 레이아웃 적용)
    void showMain() {
        inSubScreen = false;
        activeDrawer = null;
        spotTourActive = false;   // v1.4.0: 화면을 다시 그리면 스팟라이트 오버레이는 걷어낸다
        removeSpotOverlay();

        // 좌·우 서랍을 화면 끝에서 밀어 여닫는 갤러리식 터치 제스처 (v1.3.5)
        mainContainer = new FrameLayout(this) {
            float downX, downY, dragBase;
            boolean tracking = false, dragging = false;
            int dragSide = 0;   // -1: 왼쪽 서랍, +1: 오른쪽 OCR 서랍
            VelocityTracker vt;

            @Override
            public boolean dispatchTouchEvent(MotionEvent ev) {
                try {
                    final float screenW = getWidth() > 0 ? getWidth() : getResources().getDisplayMetrics().widthPixels;
                    switch (ev.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX = ev.getX(); downY = ev.getY();
                            dragging = false;
                            tracking = false;
                            try { vt = VelocityTracker.obtain(); if (vt != null) vt.addMovement(ev); } catch (Throwable ignored) {}
                            if (activeDrawer == leftDrawerView) { tracking = true; dragSide = -1; dragBase = leftDrawerView.getTranslationX(); }
                            else if (activeDrawer == rightDrawerView) { tracking = true; dragSide = 1; dragBase = rightDrawerView.getTranslationX(); }
                            else if (activeDrawer == null) {
                                if (downX <= dp(30)) { tracking = true; dragSide = -1; dragBase = -Math.min((int) (screenW * 0.82), dp(320)); }
                                else if (downX >= screenW - dp(30)) { tracking = true; dragSide = 1; dragBase = Math.min((int) (screenW * 0.82), dp(320)); }
                            }
                            break;
                        case MotionEvent.ACTION_MOVE:
                            if (vt != null) vt.addMovement(ev);
                            if (tracking && !dragging) {
                                float dx = ev.getX() - downX, dy = ev.getY() - downY;
                                boolean horizontal = Math.abs(dx) > dp(6) && Math.abs(dx) > Math.abs(dy) * 1.2f;
                                boolean opening = (dragSide == -1) ? (dx > 0) : (dx < 0);
                                boolean anyMove = (activeDrawer == leftDrawerView || activeDrawer == rightDrawerView);
                                if (horizontal && (opening || anyMove)) {
                                    dragging = true;
                                    View dv = (dragSide == -1) ? leftDrawerView : rightDrawerView;
                                    if (activeDrawer == null) {
                                        int w = Math.min((int) (getResources().getDisplayMetrics().widthPixels * 0.82), dp(320));
                                        dv.getLayoutParams().width = w;
                                        dv.setTranslationX(dragSide == -1 ? -w : w);
                                        dv.setVisibility(View.VISIBLE);
                                        scrimView.setVisibility(View.VISIBLE);
                                        scrimView.setAlpha(0f);
                                        activeDrawer = dv;
                                    }
                                    dragBase = dv.getTranslationX();
                                } else if (Math.abs(dx) > dp(8) && Math.abs(dy) > Math.abs(dx)) {
                                    tracking = false;   // 세로 스크롤로 판정 → 스크롤에 양보
                                }
                            }
                            if (dragging) {
                                View dv = (dragSide == -1) ? leftDrawerView : rightDrawerView;
                                float w = Math.max(dp(200), dv.getWidth());
                                float nx = dragBase + (ev.getX() - downX);
                                nx = (dragSide == -1) ? Math.max(-w, Math.min(0, nx)) : Math.max(0, Math.min(w, nx));
                                dv.setTranslationX(nx);
                                scrimView.setAlpha(Math.max(0f, Math.min(1f, 0.6f * (1f - Math.abs(nx) / w))));
                                return true;
                            }
                            break;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            float upDx = ev.getX() - downX;
                            float upDy = ev.getY() - downY;
                            // v1.3.6 ③: 짧게 튕기기만 해도 열리고 닫히도록 플링 속도를 함께 본다
                            float vx = 0f;
                            if (vt != null) {
                                try {
                                    vt.addMovement(ev);
                                    vt.computeCurrentVelocity(1000);
                                    vx = vt.getXVelocity();
                                } catch (Throwable ignored) {}
                                try { vt.recycle(); } catch (Throwable ignored) {}
                                vt = null;
                            }
                            boolean flicking = Math.abs(vx) > dp(500);
                            float flickDist = dp(45);
                            boolean horizontalFlick = Math.abs(upDx) >= flickDist
                                    && Math.abs(upDx) > Math.abs(upDy) * 1.2f;
                            if (dragging) {
                                View dv = (dragSide == -1) ? leftDrawerView : rightDrawerView;
                                float w = Math.max(dp(200), dv.getWidth());
                                float x = dv.getTranslationX();
                                boolean open;
                                if (flicking) {
                                    open = (dragSide == -1) ? (vx > 0) : (vx < 0);
                                } else {
                                    open = (dragSide == -1) ? (x > -w * 0.28f) : (x < w * 0.28f);
                                    if (horizontalFlick) {
                                        boolean towardOpen = (dragSide == -1) ? (upDx > 0) : (upDx < 0);
                                        if (towardOpen) open = true;
                                    }
                                }
                                drawerDragMoved = true;
                                if (open) {
                                    dv.animate().translationX(0).setDuration(220)
                                            .setInterpolator(new DecelerateInterpolator()).start();
                                    scrimView.animate().alpha(1f).setDuration(220).start();
                                    activeDrawer = dv;
                                } else {
                                    final View closing = dv;
                                    dv.animate().translationX(dragSide == -1 ? -w : w).setDuration(240)
                                            .setInterpolator(new DecelerateInterpolator()).withEndAction(() -> {
                                                closing.setVisibility(View.GONE);
                                                scrimView.setVisibility(View.GONE);
                                                if (activeDrawer == closing) activeDrawer = null;
                                            }).start();
                                    scrimView.animate().alpha(0f).setDuration(200).start();
                                }
                                dragging = false; tracking = false;
                                return true;
                            } else if (tracking && horizontalFlick) {
                                // 화면 끝에서 살짝 튕기면(이동 40~50dp) 손을 떼는 순간 바로 열린다
                                boolean wantOpen = (dragSide == -1) ? (upDx > 0) : (upDx < 0);
                                if (wantOpen && activeDrawer == null) {
                                    if (dragSide == -1) showMenu(); else showOcrOptions();
                                } else if (!wantOpen) {
                                    View dv = (dragSide == -1) ? leftDrawerView : rightDrawerView;
                                    if (activeDrawer == dv) closeDrawers(null);
                                }
                            }
                            tracking = false;
                            break;
                    }
                } catch (Throwable ignored) {}
                return super.dispatchTouchEvent(ev);
            }
        };
        mainContainer.setBackgroundColor(colorBg());

        ScrollView scroll = new ScrollView(this);
        mainScrollView = scroll;
        scroll.setBackgroundColor(colorBg());
        // v1.3.6 ①: 자식 뷰의 포커스 이동으로 스크롤이 튀지 않도록 포커스 탐색을 차단한다
        scroll.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        root = vertical();
        scroll.addView(root);
        mainContainer.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        // 반투명 어두운 스크림 배경 (서랍 열릴 때 페이드인)
        scrimView = new View(this);
        scrimView.setBackgroundColor(Color.argb(150, 0, 0, 0));
        scrimView.setVisibility(View.GONE);
        scrimView.setOnClickListener(v -> closeDrawers(null));
        mainContainer.addView(scrimView, new FrameLayout.LayoutParams(-1, -1));

        // 왼쪽 서랍 메뉴 (좌측 상단 아이콘 터치 시 왼쪽에서 오른쪽으로 슬라이드)
        leftDrawerView = buildLeftDrawer();
        leftDrawerView.setVisibility(View.GONE);
        int drawerWidth = Math.min((int)(getResources().getDisplayMetrics().widthPixels * 0.82), dp(320));
        FrameLayout.LayoutParams leftLp = new FrameLayout.LayoutParams(drawerWidth, -1, Gravity.LEFT);
        mainContainer.addView(leftDrawerView, leftLp);

        // 오른쪽 카메라 서랍 메뉴 (우측 상단 아이콘 터치 시 오른쪽에서 왼쪽으로 대칭 슬라이드)
        rightDrawerView = buildRightDrawer();
        rightDrawerView.setVisibility(View.GONE);
        int cameraWidth = Math.min((int)(getResources().getDisplayMetrics().widthPixels * 0.82), dp(320));
        FrameLayout.LayoutParams rightLp = new FrameLayout.LayoutParams(cameraWidth, -1, Gravity.RIGHT);
        mainContainer.addView(rightDrawerView, rightLp);

        // 우측 하단 [▲ TOP] 플로팅 버튼 (스크롤을 내리면 스르륵 나타난다)
        TextView topBtn = textDirect("▲ TOP", 12, true);
        topBtn.setTextColor(Color.WHITE);
        topBtn.setGravity(Gravity.CENTER);
        topBtn.setBackground(cellBg(Color.rgb(20, 83, 153), Color.rgb(30, 110, 200), dp(1)));
        topBtn.setElevation(dp(10));
        topBtn.setAlpha(0f);
        topBtn.setVisibility(View.GONE);
        topBtn.setClickable(true);
        topBtn.setOnClickListener(v -> {
            vibrateTick();
            if (mainScrollView != null) mainScrollView.smoothScrollTo(0, 0);
        });
        topFloatBtn = topBtn;
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(dp(68), dp(38), Gravity.BOTTOM | Gravity.RIGHT);
        // v1.3.6 ②: 안드로이드 3버튼 시스템 내비게이션 바에 가려지지 않도록 바닥에서 80dp 위로 올린다
        topLp.setMargins(0, 0, dp(16), Math.max(dp(80), bottomInset + dp(24)));
        mainContainer.addView(topBtn, topLp);

        // 스크롤 위치에 따라 [▲ TOP] 표시/숨김
        scroll.setOnScrollChangeListener((v, sx, sy, oldSx, oldSy) -> {
            if (topFloatBtn == null) return;
            if (spotTourActive) {           // v1.4.3: 투어 중에는 다시 나타나지 않는다
                hideTopButtonForTour();
                return;
            }
            boolean show = sy > dp(320);
            if (show && topFloatBtn.getVisibility() != View.VISIBLE) {
                topFloatBtn.setVisibility(View.VISIBLE);
                topFloatBtn.animate().alpha(1f).translationY(0).setDuration(220).start();
            } else if (!show && topFloatBtn.getVisibility() == View.VISIBLE) {
                topFloatBtn.animate().alpha(0f).translationY(dp(8)).setDuration(180)
                        .withEndAction(() -> { if (topFloatBtn != null) topFloatBtn.setVisibility(View.GONE); }).start();
            }
        });

        // 하단 1초 원터치 퀵 프리셋 바텀시트
        bottomSheetView = buildBottomSheet();
        bottomSheetView.setVisibility(View.GONE);
        FrameLayout.LayoutParams sheetLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        mainContainer.addView(bottomSheetView, sheetLp);

        setContentView(mainContainer);

        if (pendingScrollY >= 0) {
            final int restoreY = pendingScrollY;
            pendingScrollY = -1;
            scroll.post(() -> scroll.scrollTo(0, restoreY));
        }

        // 상단 타이틀 바 (공장 드론 항공사진 배너 배경 및 간편 다크모드 원터치 토글)
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setBackground(getFactoryBannerDrawable(dp(82), true));
        top.setPadding(dp(8), topInset + dp(4), dp(8), dp(10));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView menuIcon = new ImageView(this);
        menuIcon.setImageResource(R.drawable.ic_menu_shiftpay);
        menuIcon.setColorFilter(Color.WHITE);
        menuIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        menuIcon.setContentDescription("메뉴 열기");
        menuIcon.setOnClickListener(v -> showMenu());
        topRow.addView(menuIcon, new LinearLayout.LayoutParams(dp(44), dp(44)));
        spotMenuIcon = menuIcon;   // v1.4.0 스팟라이트 5번 대상 (좌측 드로어)

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setGravity(Gravity.CENTER);

        TextView appTitle = textDirect("나의 근무·급여 관리", 18, true);
        appTitle.setTextColor(Color.WHITE);
        appTitle.setShadowLayer(dp(3), 0, dp(1), Color.argb(200, 0, 0, 0));
        appTitle.setGravity(Gravity.CENTER);
        titleCol.addView(appTitle);

        LinearLayout factorySubRow = new LinearLayout(this);
        factorySubRow.setOrientation(LinearLayout.HORIZONTAL);
        factorySubRow.setGravity(Gravity.CENTER);
        factorySubRow.setOnClickListener(v -> showFactorySelectorDialog());

        ImageView factoryIcon = new ImageView(this);
        factoryIcon.setImageResource(R.drawable.ic_factory_white);
        factoryIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams fiLp = new LinearLayout.LayoutParams(dp(12), dp(12));
        fiLp.setMargins(0, 0, dp(4), 0);
        factorySubRow.addView(factoryIcon, fiLp);

        TextView factorySub = textDirect(getFactoryName() + " ▾", 11, false);
        factorySub.setTextColor(Color.rgb(215, 235, 255));
        factorySub.setShadowLayer(dp(2), 0, dp(1), Color.argb(180, 0, 0, 0));
        factorySubRow.addView(factorySub);

        titleCol.addView(factorySubRow);

        topRow.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));

        // 간편 다크모드 원터치 토글 버튼
        ImageView darkToggleBtn = new ImageView(this);
        darkToggleBtn.setImageResource(isDark() ? R.drawable.ic_theme_light : R.drawable.ic_theme_dark);
        darkToggleBtn.setScaleType(ImageView.ScaleType.FIT_CENTER);
        darkToggleBtn.setPadding(dp(6), dp(6), dp(6), dp(6));
        darkToggleBtn.setContentDescription("다크모드 전환");
        darkToggleBtn.setOnClickListener(v -> {
            vibrateTick();
            prefs.edit().putBoolean("setting_dark_mode", !isDark()).apply();
            showMain();
        });
        topRow.addView(darkToggleBtn, new LinearLayout.LayoutParams(dp(36), dp(36)));

        ImageView cameraIcon = new ImageView(this);
        cameraIcon.setImageResource(R.drawable.ic_camera_shiftpay);
        cameraIcon.setBackground(bg(Color.argb(200, 20, 83, 153)));
        cameraIcon.setPadding(dp(8), dp(8), dp(8), dp(8));
        cameraIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        cameraIcon.setContentDescription("출근카드 OCR 입력");
        cameraIcon.setOnClickListener(v -> showOcrOptions());
        LinearLayout.LayoutParams cameraLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        cameraLp.setMargins(dp(6), 0, 0, 0);
        topRow.addView(cameraIcon, cameraLp);

        top.addView(topRow);

        // 메인 공장배너사진 하단 글래스모피즘 바: 사용자 기본정보 바 (전문가 개선 1)
        LinearLayout userBannerRow = new LinearLayout(this);
        userBannerRow.setGravity(Gravity.CENTER);
        userBannerRow.setPadding(dp(14), dp(4), dp(14), dp(4));
        userBannerRow.setBackground(cellBg(Color.argb(175, 12, 24, 48), Color.argb(140, 255, 255, 255), dp(1)));

        TextView userInfoTv = textDirect(getUserSummaryLine(), 12, true);
        userInfoTv.setTextColor(Color.WHITE);
        userInfoTv.setShadowLayer(dp(2), 0, dp(1), Color.argb(220, 0, 0, 0));
        userInfoTv.setGravity(Gravity.CENTER);
        userBannerRow.addView(userInfoTv);

        userBannerRow.setOnClickListener(v -> {
            vibrateTick();
            showSettings();
        });

        LinearLayout.LayoutParams ubLp = new LinearLayout.LayoutParams(-2, -2);
        ubLp.gravity = Gravity.CENTER_HORIZONTAL;
        ubLp.setMargins(0, dp(6), 0, 0);
        top.addView(userBannerRow, ubLp);

        root.addView(top);

        // 기본정보 미입력 시 시작 안내 가이드 배너 표시
        if (prefs.getString("user_name", "").trim().isEmpty()) {
            LinearLayout guideBanner = new LinearLayout(this);
            guideBanner.setOrientation(LinearLayout.HORIZONTAL);
            guideBanner.setGravity(Gravity.CENTER_VERTICAL);
            guideBanner.setBackground(cellBg(isDark() ? Color.rgb(28, 44, 72) : Color.rgb(232, 242, 255), colorBlue(), dp(1)));
            guideBanner.setPadding(dp(12), dp(9), dp(12), dp(9));
            guideBanner.setOnClickListener(v -> {
                vibrateTick();
                showOnboardingGuide();
            });

            TextView tipIcon = textDirect("💡", 16, false);
            tipIcon.setPadding(0, 0, dp(8), 0);
            guideBanner.addView(tipIcon);

            TextView tipText = textDirect("처음이신가요? 3단계 이용안내 확인 및 기본정보 입력하기 ❯", 12, true);
            tipText.setTextColor(colorBlue());
            guideBanner.addView(tipText, new LinearLayout.LayoutParams(0, -2, 1f));

            LinearLayout.LayoutParams guideLp = new LinearLayout.LayoutParams(-1, -2);
            guideLp.setMargins(0, dp(4), 0, dp(6));
            root.addView(guideBanner, guideLp);
        }

        // 월 전환 내비게이션 바 (좌: 리셋, 중: ◀ 년월 ▾ ▶ 센터, 우: 오늘) — v1.3.4 슬림화
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), dp(4), dp(4), dp(8));

        // [좌측 영역] 리셋 버튼
        LinearLayout leftBox = new LinearLayout(this);
        leftBox.setOrientation(LinearLayout.HORIZONTAL);
        leftBox.setGravity(Gravity.CENTER_VERTICAL);

        // 리셋 버튼: 작고 세련된 디자인 (오클릭 방지 유지)
        Button resetMonthBtn = button("↺", () -> {
            vibrateTick();
            new AlertDialog.Builder(this)
                .setTitle("🗑️ " + ym() + "월 근무 기록 일괄 삭제")
                .setMessage("현재 보고 계신 " + ym() + "월의 모든 근무 시간(출근카드 자동인식 및 수동입력)을 모두 삭제하고 기본 상태로 초기화하시겠습니까?\n\n(※ 기존 기록은 안전하게 자동 엑셀 백업됩니다)")
                .setPositiveButton("일괄 삭제", (d, w) -> {
                    vibrateTick();
                    clearMonthWork();
                })
                .setNegativeButton("취소", null)
                .show();
        });
        resetMonthBtn.setMinWidth(0);
        resetMonthBtn.setMinimumWidth(0);
        resetMonthBtn.setMinHeight(0);
        resetMonthBtn.setMinimumHeight(0);
        resetMonthBtn.setTextColor(colorRed());
        resetMonthBtn.setTextSize(13);
        resetMonthBtn.setPadding(dp(7), dp(4), dp(7), dp(4));
        resetMonthBtn.setBackground(cellBg(isDark() ? Color.rgb(36, 24, 28) : Color.rgb(255, 238, 240), colorRed(), dp(1)));
        leftBox.addView(resetMonthBtn);

        // v1.3.4: 소급 ON/OFF 토글은 메인 하단 [예상 실수령액] 카드 내부 우측으로 이동
        //        (상단 바는 리셋 · 월 넘김 · 오늘만 남겨 슬림하게 유지)

        bar.addView(leftBox, new LinearLayout.LayoutParams(-2, -2));

        // [중앙 가변 공백 1]
        View spacer1 = new View(this);
        bar.addView(spacer1, new LinearLayout.LayoutParams(0, 0, 1f));

        // [중앙 영역] ◀ 2026-09 ▾ ▶ (화면 정중앙 배치)
        LinearLayout centerBox = new LinearLayout(this);
        centerBox.setOrientation(LinearLayout.HORIZONTAL);
        centerBox.setGravity(Gravity.CENTER);

        Button prevBtn = button("◀", () -> { vibrateTick(); changeMonth(-1); });
        prevBtn.setMinWidth(0);
        prevBtn.setMinimumWidth(0);
        prevBtn.setMinHeight(0);
        prevBtn.setMinimumHeight(0);
        prevBtn.setPadding(dp(9), dp(5), dp(9), dp(5));
        prevBtn.setTextSize(13);
        centerBox.addView(prevBtn);

        LinearLayout yearMonthBtn = new LinearLayout(this);
        yearMonthBtn.setOrientation(LinearLayout.HORIZONTAL);
        yearMonthBtn.setGravity(Gravity.CENTER_VERTICAL);
        yearMonthBtn.setBackground(cellBg(isDark() ? Color.rgb(24, 38, 62) : Color.rgb(232, 242, 255), colorBlue(), dp(1)));
        yearMonthBtn.setPadding(dp(9), dp(5), dp(7), dp(5));
        yearMonthBtn.setClickable(true);
        yearMonthBtn.setOnClickListener(v -> {
            vibrateTick();
            showMonthYearPicker();
        });

        heading = textDirect(ym(), 16, true);
        heading.setTextColor(colorBlue());
        yearMonthBtn.addView(heading);

        TextView arrowTv = textDirect(" ▾", 12, true);
        arrowTv.setTextColor(colorBlue());
        yearMonthBtn.addView(arrowTv);

        LinearLayout.LayoutParams ymBtnLp = new LinearLayout.LayoutParams(-2, -2);
        ymBtnLp.setMargins(dp(2), 0, dp(2), 0);
        centerBox.addView(yearMonthBtn, ymBtnLp);

        Button nextBtn = button("▶", () -> { vibrateTick(); changeMonth(1); });
        nextBtn.setMinWidth(0);
        nextBtn.setMinimumWidth(0);
        nextBtn.setMinHeight(0);
        nextBtn.setMinimumHeight(0);
        nextBtn.setPadding(dp(9), dp(5), dp(9), dp(5));
        nextBtn.setTextSize(13);
        centerBox.addView(nextBtn);

        bar.addView(centerBox, new LinearLayout.LayoutParams(-2, -2));

        // [중앙 가변 공백 2]
        View spacer2 = new View(this);
        bar.addView(spacer2, new LinearLayout.LayoutParams(0, 0, 1f));

        // [우측 영역] 오늘 버튼 — v1.3.4: 통계 버튼은 [출근카드 1:1] 카드 헤더로 이동
        LinearLayout rightBox = new LinearLayout(this);
        rightBox.setOrientation(LinearLayout.HORIZONTAL);
        rightBox.setGravity(Gravity.CENTER_VERTICAL);

        Button todayBtn = button("오늘", () -> {
            vibrateTick();
            month = Calendar.getInstance();
            chosenDay = month.get(Calendar.DAY_OF_MONTH);
            showMain();
        });
        todayBtn.setMinWidth(0);
        todayBtn.setMinimumWidth(0);
        todayBtn.setMinHeight(0);
        todayBtn.setMinimumHeight(0);
        todayBtn.setTextColor(colorBlue());
        todayBtn.setTextSize(12);
        todayBtn.setPadding(dp(9), dp(5), dp(9), dp(5));
        todayBtn.setBackground(cellBg(isDark() ? Color.rgb(22, 34, 54) : Color.rgb(236, 244, 255), colorBlue(), dp(1)));
        rightBox.addView(todayBtn, new LinearLayout.LayoutParams(-2, -2));
        bar.addView(rightBox, new LinearLayout.LayoutParams(-2, -2));

        root.addView(bar);

        // 캘린더 영역 컨테이너 (좌우 스와이프로 월 넘기기 제스처 대상)
        calendarBlock = new LinearLayout(this);
        calendarBlock.setOrientation(LinearLayout.VERTICAL);
        root.addView(calendarBlock, new LinearLayout.LayoutParams(-1, -2));

        // 캘린더 그리드 렌더링
        renderCalendar();

        // 캘린더 바로 아래 엄지 최적화 퀵 액션 바 (빠른 입력 + 퀵 OCR 스캔) (전문가 개선 4)
        LinearLayout quickActionBar = new LinearLayout(this);
        quickActionBar.setOrientation(LinearLayout.HORIZONTAL);
        quickActionBar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams qaLp = new LinearLayout.LayoutParams(-1, -2);
        qaLp.setMargins(0, dp(6), 0, dp(10));

        // 3개 퀵 액션 버튼: 높이·폰트·1줄 텍스트 완전 통일 (웹 버전 3버튼 체제와 1:1 일치)
        final int quickBtnH = dp(44);
        final float quickBtnSp = 12.5f;

        Button inputBtn = button("빠른 근무 입력 (" + chosenDay + "일)", () -> {
            vibrateTick();
            showBottomSheet(chosenDay);
        });
        styleQuickActionButton(inputBtn, colorBlue(), true, quickBtnH, quickBtnSp);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, quickBtnH, 1.20f);
        inputLp.setMargins(0, 0, dp(6), 0);
        quickActionBar.addView(inputBtn, inputLp);

        // ⚡ 선택 모드: 롱클릭 없이 탭 한 번으로 다중 선택 모드 진입 / 해제 토글
        Button multiToggleBtn = button(isMultiSelectMode ? "✕ 선택 취소" : "⚡ 선택 모드", () -> {
            vibrateTick();
            toggleMultiSelectMode();
        });
        styleQuickActionButton(multiToggleBtn, isMultiSelectMode ? colorRed() : colorBlue(), false, quickBtnH, quickBtnSp);
        LinearLayout.LayoutParams multiToggleLp = new LinearLayout.LayoutParams(0, quickBtnH, 1.00f);
        multiToggleLp.setMargins(0, 0, dp(6), 0);
        quickActionBar.addView(multiToggleBtn, multiToggleLp);

        // 📸 스마트 OCR 복원 (v1.3.4): 캘린더 바로 아래에서 한 손으로 1초 만에 사진 스캔 진입
        Button ocrQuickBtn = button("📸 스마트 OCR", () -> {
            vibrateTick();
            showOcrOptions();
        });
        styleQuickActionButton(ocrQuickBtn, colorBlue(), false, quickBtnH, quickBtnSp);
        quickActionBar.addView(ocrQuickBtn, new LinearLayout.LayoutParams(0, quickBtnH, 1.00f));

        if (isMultiSelectMode) {
            LinearLayout multiBar = new LinearLayout(this);
            multiBar.setOrientation(LinearLayout.HORIZONTAL);
            multiBar.setGravity(Gravity.CENTER_VERTICAL);
            multiBar.setBackground(cellBg(isDark() ? Color.rgb(30, 41, 59) : Color.rgb(15, 23, 42), Color.rgb(51, 65, 85), dp(2)));
            multiBar.setPadding(dp(12), dp(8), dp(12), dp(8));
            LinearLayout.LayoutParams mbLp = new LinearLayout.LayoutParams(-1, -2);
            mbLp.setMargins(0, dp(6), 0, dp(4));

            TextView countTv = textDirect(selectedDays.isEmpty() ? "날짜를 터치해 선택" : "선택 " + selectedDays.size() + "일", 13, true);
            countTv.setTextColor(Color.WHITE);
            countTv.setSingleLine(true);
            countTv.setEllipsize(TextUtils.TruncateAt.END);
            multiBar.addView(countTv, new LinearLayout.LayoutParams(0, -2, 1f));

            if (!selectedDays.isEmpty()) {
                Button applyBtn = button("⚡ 일괄 입력 (" + selectedDays.size() + ")", () -> showMultiApplyDialog());
                applyBtn.setBackground(cellBg(Color.rgb(2, 132, 199), Color.rgb(3, 105, 161), dp(1)));
                applyBtn.setTextColor(Color.WHITE);
                applyBtn.setTextSize(12);
                applyBtn.setSingleLine(true);
                applyBtn.setMinWidth(0);
                applyBtn.setMinimumWidth(0);
                applyBtn.setPadding(dp(9), dp(8), dp(9), dp(8));
                LinearLayout.LayoutParams applyLp = new LinearLayout.LayoutParams(-2, -2);
                applyLp.setMargins(dp(6), 0, 0, 0);
                multiBar.addView(applyBtn, applyLp);

                Button delBtn = button("🗑️ 일괄 삭제 (" + selectedDays.size() + ")", () -> confirmMultiDelete());
                delBtn.setBackground(cellBg(Color.rgb(220, 38, 38), Color.rgb(185, 28, 28), dp(1)));
                delBtn.setTextColor(Color.WHITE);
                delBtn.setTextSize(12);
                delBtn.setSingleLine(true);
                delBtn.setMinWidth(0);
                delBtn.setMinimumWidth(0);
                delBtn.setPadding(dp(9), dp(8), dp(9), dp(8));
                LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(-2, -2);
                delLp.setMargins(dp(6), 0, 0, 0);
                multiBar.addView(delBtn, delLp);
            }

            root.addView(multiBar, mbLp);
        }
        root.addView(quickActionBar, qaLp);
        spotQuickBar = quickActionBar;   // v1.4.0 스팟라이트 1번 대상 (3버튼 바)

        // 상업용 카드형 요약 섹션 컨테이너
        summaryContainer = new LinearLayout(this);
        summaryContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(summaryContainer);
        refreshSummary();

        // v1.4.3: 최초 설치 시 4스텝 대화형 온보딩 마법사를 자동 실행한다.
        //  이미 앱을 쓰던 사용자(onboarding_shown=true)는 업데이트 시 메인 화면이 바로 뜨고,
        //  좌측 메뉴 [❓ 온보딩 & 기능 투어 다시보기]로 언제든 다시 띄울 수 있다.
        if (!prefs.getBoolean("onboarding_v14_completed", false) && !prefs.getBoolean("onboarding_shown", false)) {
            prefs.edit().putBoolean("onboarding_shown", true).apply();
            root.postDelayed(this::showOnboardingWizard, 420);
        }

        // 월 넘김 슬라이드: 새 달력이 진행 방향 반대편에서 부드럽게 들어온다
        if (pendingCalSlide != 0 && calendarBlock != null) {
            final int dir = pendingCalSlide;
            pendingCalSlide = 0;
            final LinearLayout cal = calendarBlock;
            cal.post(() -> {
                int w = cal.getWidth() > 0 ? cal.getWidth()
                        : getResources().getDisplayMetrics().widthPixels;
                cal.setTranslationX(dir * w * 0.55f);
                cal.setAlpha(0.15f);
                cal.animate().translationX(0).alpha(1f).setDuration(230)
                        .setInterpolator(new DecelerateInterpolator()).start();
            });
        }
    }

    // 왼쪽 상단 아이콘 눌렀을 때 서랍 슬라이드 애니메이션 (요청사항 2 반영)
    /**
     * v1.3.6 ①: 소급 ON/OFF 는 화면 전체를 다시 그리지 않는다.
     * 예상 실수령액·세전·공제 금액 텍스트와 소급분 행, 공제 내역 블록만 제자리에서 갱신하므로
     * 스크롤 위치가 1px도 움직이지 않고 포커스도 이동하지 않는다(0.1~0.2초 미세 튐 제로).
     */
    void refreshRetroInPlace() {
        try {
            double[] a = amounts();
            boolean on = isRetroActiveThisMonth();
            if (heroNetTv != null) heroNetTv.setText(won(a[8]));
            if (heroGrossTv != null) heroGrossTv.setText("세전 총지급액: " + won(a[6]));
            if (heroDedTv != null) heroDedTv.setText("예상 공제액: -" + won(a[7]));
            if (heroRetroBtn != null) {
                heroRetroBtn.setText(on ? "소급 ON" : "소급 OFF");
                if (on) {
                    heroRetroBtn.setTextColor(Color.rgb(180, 100, 0));
                    heroRetroBtn.setBackground(cellBg(isDark() ? Color.rgb(44, 34, 18) : Color.rgb(255, 246, 224), Color.rgb(230, 160, 40), dp(1)));
                } else {
                    heroRetroBtn.setTextColor(colorSub());
                    heroRetroBtn.setBackground(cellBg(isDark() ? Color.rgb(24, 28, 36) : Color.rgb(240, 243, 248), colorBorder(), dp(1)));
                }
            }
            if (retroRowView != null) retroRowView.setVisibility(on ? View.VISIBLE : View.GONE);
            if (retroFormulaView != null) retroFormulaView.setVisibility(on ? View.VISIBLE : View.GONE);
            if (deductSectionHolder != null) {
                deductSectionHolder.removeAllViews();
                addDeductionSection(deductSectionHolder, Math.round(a[6]));
            }
        } catch (Throwable ignored) {}
    }

    /** v1.3.6 ④: 서브 창을 닫을 때도 1.0 → 0.9 로 작아지며 사라진 뒤 메인으로 돌아간다. */
    void leaveSubScreen() {
        final View v = subScreenScroll;
        subScreenScroll = null;
        inSubScreen = false;
        if (v == null) {
            showMain();
            return;
        }
        v.animate().scaleX(0.9f).scaleY(0.9f).alpha(0f).setDuration(150)
                .setInterpolator(new AccelerateInterpolator())
                .withEndAction(() -> showMain()).start();
    }

    void showMenu() {
        if (activeDrawer != null) return;
        int drawerWidth = Math.min((int)(getResources().getDisplayMetrics().widthPixels * 0.82), dp(320));
        leftDrawerView.getLayoutParams().width = drawerWidth;
        leftDrawerView.setTranslationX(-drawerWidth);
        leftDrawerView.setVisibility(View.VISIBLE);
        scrimView.setVisibility(View.VISIBLE);
        scrimView.setAlpha(0f);
        scrimView.animate().alpha(1f).setDuration(260).start();
        leftDrawerView.animate().translationX(0).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
        activeDrawer = leftDrawerView;
    }

    // 오른쪽 카메라 아이콘 눌렀을 때 대칭 서랍 슬라이드 애니메이션 (요청사항 5 반영)
    void showOcrOptions() {
        if (activeDrawer != null) return;
        int cameraWidth = Math.min((int)(getResources().getDisplayMetrics().widthPixels * 0.82), dp(320));
        rightDrawerView.getLayoutParams().width = cameraWidth;
        rightDrawerView.setTranslationX(cameraWidth);
        rightDrawerView.setVisibility(View.VISIBLE);
        scrimView.setVisibility(View.VISIBLE);
        scrimView.setAlpha(0f);
        scrimView.animate().alpha(1f).setDuration(260).start();
        rightDrawerView.animate().translationX(0).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
        activeDrawer = rightDrawerView;
    }

    // 서랍 닫기 애니메이션
    void closeDrawers(Runnable onClosed) {
        if (activeDrawer == null) {
            if (onClosed != null) onClosed.run();
            return;
        }
        final View closing = activeDrawer;
        activeDrawer = null;
        scrimView.animate().alpha(0f).setDuration(220).start();
        if (closing == leftDrawerView) {
            int w = closing.getWidth() > 0 ? closing.getWidth() : dp(320);
            closing.animate().translationX(-w).setDuration(240).setInterpolator(new DecelerateInterpolator()).withEndAction(() -> {
                closing.setVisibility(View.GONE);
                scrimView.setVisibility(View.GONE);
                if (onClosed != null) onClosed.run();
            }).start();
        } else if (closing == rightDrawerView) {
            int w = closing.getWidth() > 0 ? closing.getWidth() : dp(320);
            closing.animate().translationX(w).setDuration(240).setInterpolator(new DecelerateInterpolator()).withEndAction(() -> {
                closing.setVisibility(View.GONE);
                scrimView.setVisibility(View.GONE);
                if (onClosed != null) onClosed.run();
            }).start();
        } else if (closing == bottomSheetView) {
            int h = closing.getHeight() > 0 ? closing.getHeight() : dp(420);
            closing.animate().translationY(h).setDuration(220).setInterpolator(new AccelerateInterpolator()).withEndAction(() -> {
                closing.setVisibility(View.GONE);
                scrimView.setVisibility(View.GONE);
                if (onClosed != null) onClosed.run();
            }).start();
        }
    }

    @Override
    public void onBackPressed() {
        if (spotRoot != null) {          // v1.4.0: 스팟라이트 투어는 언제든 즉시 종료
            endSpotTour();
            return;
        }
        if (wizardDialog != null && wizardDialog.isShowing()) {
            // v1.4.3 ⑤: 온보딩 도중 뒤로가기는 완료 처리(markOnboardingDone)를 하지 않는다.
            //  앞 단계가 있으면 한 단계 되돌아가고, 1단계에서는 창만 닫는다.
            //  온보딩 완료는 오직 마지막 [시작하기] 버튼에서만 기록된다.
            if (wizardStep > 1) showWizardStep(wizardStep - 1);
            else closeWizard();
            return;
        }
        if (isMultiSelectMode) {
            isMultiSelectMode = false;
            selectedDays.clear();
            showMain();
            return;
        }
        if (activeDrawer != null) {
            closeDrawers(null);
            return;
        }
        if (inSubScreen) {
            leaveSubScreen();
            return;
        }
        super.onBackPressed();
    }

    // 왼쪽 서랍 메뉴 빌더 (세련된 상용 앱 스타일 사이드 드로어)
    LinearLayout buildLeftDrawer() {
        LinearLayout drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(colorSurface());
        drawer.setElevation(dp(16));
        drawer.setClickable(true);

        // 드로어 헤더: 로고 + 타이틀 + 버전 + 공장 드론 배너 배경 + 다크모드 토글 + 공장 명칭 동적 연동
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackground(getFactoryBannerDrawable(dp(110), false));
        header.setPadding(dp(16), topInset + dp(10), dp(16), dp(14));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        // 신규 아이콘: 드로어 헤더에서는 둥근 모서리 버전을 사용
        logo.setImageResource(R.mipmap.ic_launcher_round);
        topRow.addView(logo, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(10), 0, 0, 0);

        TextView title = textDirect("ShiftPay", 19, true);
        title.setTextColor(Color.WHITE);
        title.setShadowLayer(dp(2), 0, dp(1), Color.argb(180, 0, 0, 0));
        titleCol.addView(title);

        TextView sub = textDirect("나의 근무·급여 관리 v" + CURRENT_VERSION_LABEL, 12, false);
        sub.setTextColor(Color.rgb(215, 235, 255));
        sub.setShadowLayer(dp(2), 0, dp(1), Color.argb(180, 0, 0, 0));
        titleCol.addView(sub);
        topRow.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));

        // 서랍 내 간편 다크모드 원터치 토글
        ImageView darkToggleDrawer = new ImageView(this);
        darkToggleDrawer.setImageResource(isDark() ? R.drawable.ic_theme_light : R.drawable.ic_theme_dark);
        darkToggleDrawer.setScaleType(ImageView.ScaleType.FIT_CENTER);
        darkToggleDrawer.setPadding(dp(6), dp(6), dp(6), dp(6));
        darkToggleDrawer.setOnClickListener(v -> {
            vibrateTick();
            prefs.edit().putBoolean("setting_dark_mode", !isDark()).apply();
            closeDrawers(this::showMain);
        });
        topRow.addView(darkToggleDrawer, new LinearLayout.LayoutParams(dp(32), dp(32)));

        TextView closeBtn = textDirect("✕", 18, false);
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setPadding(dp(6), dp(6), dp(6), dp(6));
        closeBtn.setOnClickListener(v -> closeDrawers(null));
        topRow.addView(closeBtn);
        header.addView(topRow);

        // 공장 공식 명칭 뱃지 (좌측) + 우측 토글스위치 아래 3줄 우측정렬 기본정보 (요청사항 4 반영)
        LinearLayout headerBottomRow = new LinearLayout(this);
        headerBottomRow.setOrientation(LinearLayout.HORIZONTAL);
        headerBottomRow.setGravity(Gravity.BOTTOM);
        LinearLayout.LayoutParams hbLp = new LinearLayout.LayoutParams(-1, -2);
        hbLp.setMargins(0, dp(8), 0, 0);

        LinearLayout companyBadge = new LinearLayout(this);
        companyBadge.setOrientation(LinearLayout.HORIZONTAL);
        companyBadge.setGravity(Gravity.CENTER_VERTICAL);
        companyBadge.setBackground(cellBg(Color.argb(180, 15, 30, 60), Color.argb(200, 100, 160, 240), dp(1)));
        companyBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        companyBadge.setOnClickListener(v -> showFactorySelectorDialog());

        ImageView cbIcon = new ImageView(this);
        cbIcon.setImageResource(R.drawable.ic_factory_white);
        cbIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams cbIconLp = new LinearLayout.LayoutParams(dp(12), dp(12));
        cbIconLp.setMargins(0, 0, dp(4), 0);
        companyBadge.addView(cbIcon, cbIconLp);

        TextView cbText = textDirect(getFactoryName() + " ▾", 11, true);
        cbText.setTextColor(Color.WHITE);
        companyBadge.addView(cbText);

        headerBottomRow.addView(companyBadge, new LinearLayout.LayoutParams(-2, -2));

        TextView drawerUserInfoTv = textDirect(getUserSummaryMultiline(), 11, true);
        drawerUserInfoTv.setTextColor(Color.WHITE);
        drawerUserInfoTv.setShadowLayer(dp(2), 0, dp(1), Color.argb(200, 0, 0, 0));
        drawerUserInfoTv.setGravity(Gravity.RIGHT);
        drawerUserInfoTv.setLineSpacing(dp(1), 1.05f);
        drawerUserInfoTv.setPadding(dp(8), dp(4), dp(4), dp(4));
        drawerUserInfoTv.setClickable(true);
        drawerUserInfoTv.setFocusable(true);
        drawerUserInfoTv.setOnClickListener(v -> {
            vibrateTick();
            closeDrawers(this::showSettings);
        });
        LinearLayout.LayoutParams userInfoLp = new LinearLayout.LayoutParams(0, -2, 1f);
        userInfoLp.gravity = Gravity.BOTTOM;
        headerBottomRow.addView(drawerUserInfoTv, userInfoLp);

        header.addView(headerBottomRow, hbLp);

        drawer.addView(header);

        // 메뉴 항목 목록
        ScrollView menuScroll = new ScrollView(this);
        menuScroll.setVerticalScrollBarEnabled(false);
        LinearLayout menuList = new LinearLayout(this);
        menuList.setOrientation(LinearLayout.VERTICAL);
        menuList.setPadding(dp(12), dp(10), dp(12), bottomInset + dp(20));

        // 1. 급여 및 데이터 관리
        addDrawerSectionHeader(menuList, "급여 및 데이터 관리");
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_settings, "급여 및 화면 설정", "시급/수당 2열 재배분 & 다크모드 설정", () -> closeDrawers(this::showSettings));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_bonus, "2026년 성과·격려금 계산기", "임단협 250%+550만 타결 공식 모의계산", () -> closeDrawers(this::showBonusCalculator));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_stats, "근무 통계 & 분석 차트", "정상·연장·특근 도넛 차트 + 요일별 누적 막대", () -> closeDrawers(this::showStatsModal));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_data, "데이터 통합 관리", "엑셀·전체 백업·복원 3종 원터치 카드", () -> closeDrawers(this::showDataManage));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_holidays, "공휴일 데이터 갱신", "2025~2027 공휴일 및 대체휴무 갱신", () -> closeDrawers(this::refreshHolidays));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_edit_holiday, "휴일 수동 설정", "특정 날짜의 휴일 명칭 직접 등록", () -> closeDrawers(this::editHoliday));

        // 2. 사내 복지 & 협약
        addDrawerSectionHeader(menuList, "사내 복지 & 협약");
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_cba, "2026년 노사단체협약", "전문 35p 요약 및 원본 HWP 다운로드", () -> closeDrawers(this::showCbaViewer));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_support, "현대스틸파이프 지원제도", "학자금·사내대출·의료비 등 12개 제도", () -> closeDrawers(this::showSupportViewer));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_partners, "회사 제휴업체 통합현황", "울산·전국 28개 숙박/의료/레저 할인 혜택", () -> closeDrawers(this::showPartnersViewer));

        // 3. 앱 정보
        addDrawerSectionHeader(menuList, "앱 정보");
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_apk, "안드로이드 전용 앱(APK) 안내", "최신 버전 다운로드 · 웹 버전 바로가기", () -> closeDrawers(this::showApkInfo));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_onboarding, "처음 사용자 이용 가이드", "3단계 핵심 급여 관리 워크플로우 안내", () -> closeDrawers(this::showOnboardingGuide));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_onboarding, "❓ 온보딩 & 기능 투어 다시보기", "4스텝 설정 마법사 + 스팟라이트 5곳 투어", () -> closeDrawers(this::showOnboardingWizard));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_company, "회사 소개 및 연혁", "1975년 경일공업부터 현재까지의 연혁", () -> closeDrawers(this::showCompany));
        addDrawerMenuItem(menuList, R.drawable.ic_drawer_history, "버전 업데이트 내역", "v" + CURRENT_VERSION_NAME + " 연월·온보딩·검토교정", () -> closeDrawers(this::showHistory));

        menuScroll.addView(menuList);
        drawer.addView(menuScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        return drawer;
    }

    void addDrawerSectionHeader(LinearLayout parent, String title) {
        TextView tv = textDirect(title, 12, true);
        tv.setTextColor(colorSub());
        tv.setPadding(dp(6), dp(12), dp(6), dp(4));
        parent.addView(tv);
    }

    void addDrawerMenuItem(LinearLayout parent, int iconResId, String title, String sub, Runnable onClick) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.setMargins(0, dp(3), 0, dp(3));

        FrameLayout badgeBox = new FrameLayout(this);
        GradientDrawable bbg = new GradientDrawable();
        bbg.setColor(isDark() ? Color.rgb(20, 36, 64) : Color.rgb(238, 245, 255));
        bbg.setCornerRadius(dp(17));
        bbg.setStroke(dp(1), isDark() ? Color.rgb(35, 65, 115) : Color.rgb(186, 220, 255));
        badgeBox.setBackground(bbg);

        ImageView iconView = new ImageView(this);
        iconView.setImageResource(iconResId);
        iconView.setColorFilter(colorBlue());
        iconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams ivLp = new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER);
        badgeBox.addView(iconView, ivLp);

        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        badgeLp.setMargins(0, 0, dp(12), 0);
        row.addView(badgeBox, badgeLp);

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        textCol.setPadding(0, 0, dp(4), 0);

        TextView titleTv = textDirect(title, 14, true);
        titleTv.setTextColor(colorInk());
        textCol.addView(titleTv);

        if (sub != null && !sub.isEmpty()) {
            TextView subTv = textDirect(sub, 11, false);
            subTv.setTextColor(colorSub());
            subTv.setMaxLines(1);
            subTv.setEllipsize(TextUtils.TruncateAt.END);
            textCol.addView(subTv);
        }
        row.addView(textCol, new LinearLayout.LayoutParams(0, -2, 1));

        TextView arrow = textDirect("›", 18, false);
        arrow.setTextColor(colorSub());
        arrow.setPadding(dp(4), 0, 0, 0);
        row.addView(arrow);

        row.setOnClickListener(v -> {
            vibrateTick();
            onClick.run();
        });
        parent.addView(row, rowLp);
    }

    // 오른쪽 서랍 메뉴 빌더 (출근카드 & 급여명세서 스마트 OCR 스캐너)
    LinearLayout buildRightDrawer() {
        LinearLayout drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(colorSurface());
        drawer.setElevation(dp(16));
        drawer.setClickable(true);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackground(getFactoryBannerDrawable(dp(110), false));
        header.setPadding(dp(16), topInset + dp(10), dp(16), dp(14));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView cameraIcon = new ImageView(this);
        cameraIcon.setImageResource(R.drawable.ic_camera_shiftpay);
        cameraIcon.setBackground(bg(Color.rgb(20, 83, 153)));
        cameraIcon.setPadding(dp(8), dp(8), dp(8), dp(8));
        topRow.addView(cameraIcon, new LinearLayout.LayoutParams(dp(38), dp(38)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(10), 0, 0, 0);

        TextView title = textDirect("스마트 OCR 스캐너", 18, true);
        title.setTextColor(Color.WHITE);
        title.setShadowLayer(dp(2), 0, dp(1), Color.argb(180, 0, 0, 0));
        titleCol.addView(title);

        TextView sub = textDirect("출근카드 & 급여명세서 인식", 12, false);
        sub.setTextColor(Color.rgb(215, 235, 255));
        sub.setShadowLayer(dp(2), 0, dp(1), Color.argb(180, 0, 0, 0));
        titleCol.addView(sub);
        topRow.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));

        // 우측 서랍 내 간편 다크모드 원터치 토글
        ImageView darkToggleRight = new ImageView(this);
        darkToggleRight.setImageResource(isDark() ? R.drawable.ic_theme_light : R.drawable.ic_theme_dark);
        darkToggleRight.setScaleType(ImageView.ScaleType.FIT_CENTER);
        darkToggleRight.setPadding(dp(6), dp(6), dp(6), dp(6));
        darkToggleRight.setOnClickListener(v -> {
            vibrateTick();
            prefs.edit().putBoolean("setting_dark_mode", !isDark()).apply();
            closeDrawers(this::showMain);
        });
        topRow.addView(darkToggleRight, new LinearLayout.LayoutParams(dp(32), dp(32)));

        TextView closeBtn = textDirect("✕", 18, false);
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setPadding(dp(6), dp(6), dp(6), dp(6));
        closeBtn.setOnClickListener(v -> closeDrawers(null));
        topRow.addView(closeBtn);
        header.addView(topRow);

        // 하단: 공장 뱃지 + 우측 토글스위치 아래 3줄 우측 정렬 기본정보 (요청사항 4 대칭 반영)
        LinearLayout rHeaderBottomRow = new LinearLayout(this);
        rHeaderBottomRow.setOrientation(LinearLayout.HORIZONTAL);
        rHeaderBottomRow.setGravity(Gravity.BOTTOM);
        LinearLayout.LayoutParams rhbLp = new LinearLayout.LayoutParams(-1, -2);
        rhbLp.setMargins(0, dp(8), 0, 0);

        LinearLayout rCompanyBadge = new LinearLayout(this);
        rCompanyBadge.setOrientation(LinearLayout.HORIZONTAL);
        rCompanyBadge.setGravity(Gravity.CENTER_VERTICAL);
        rCompanyBadge.setBackground(cellBg(Color.argb(180, 15, 30, 60), Color.argb(200, 100, 160, 240), dp(1)));
        rCompanyBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        rCompanyBadge.setOnClickListener(v -> showFactorySelectorDialog());

        ImageView rcbIcon = new ImageView(this);
        rcbIcon.setImageResource(R.drawable.ic_factory_white);
        rcbIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams rcbIconLp = new LinearLayout.LayoutParams(dp(12), dp(12));
        rcbIconLp.setMargins(0, 0, dp(4), 0);
        rCompanyBadge.addView(rcbIcon, rcbIconLp);

        TextView rcbText = textDirect(getFactoryName() + " ▾", 11, true);
        rcbText.setTextColor(Color.WHITE);
        rCompanyBadge.addView(rcbText);

        rHeaderBottomRow.addView(rCompanyBadge, new LinearLayout.LayoutParams(-2, -2));

        TextView rDrawerUserInfoTv = textDirect(getUserSummaryMultiline(), 11, true);
        rDrawerUserInfoTv.setTextColor(Color.WHITE);
        rDrawerUserInfoTv.setShadowLayer(dp(2), 0, dp(1), Color.argb(200, 0, 0, 0));
        rDrawerUserInfoTv.setGravity(Gravity.RIGHT);
        rDrawerUserInfoTv.setLineSpacing(dp(1), 1.05f);
        rDrawerUserInfoTv.setPadding(dp(8), dp(4), dp(4), dp(4));
        rDrawerUserInfoTv.setClickable(true);
        rDrawerUserInfoTv.setFocusable(true);
        rDrawerUserInfoTv.setOnClickListener(v -> {
            vibrateTick();
            closeDrawers(this::showSettings);
        });
        LinearLayout.LayoutParams rUserInfoLp = new LinearLayout.LayoutParams(0, -2, 1f);
        rUserInfoLp.gravity = Gravity.BOTTOM;
        rHeaderBottomRow.addView(rDrawerUserInfoTv, rUserInfoLp);

        header.addView(rHeaderBottomRow, rhbLp);

        drawer.addView(header);

        ScrollView bodyScroll = new ScrollView(this);
        bodyScroll.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(12), dp(14), bottomInset + dp(20));

        // ------------------ 섹션 1: 종이 출근카드 OCR ------------------
        TextView sec1 = textDirect("종이 출근카드 자동 입력", 14, true);
        sec1.setTextColor(colorBlue());
        sec1.setPadding(dp(4), dp(4), dp(4), dp(6));
        body.addView(sec1);

        // 출근카드 촬영
        LinearLayout camOpt1 = new LinearLayout(this);
        camOpt1.setOrientation(LinearLayout.HORIZONTAL);
        camOpt1.setGravity(Gravity.CENTER_VERTICAL);
        camOpt1.setPadding(dp(12), dp(11), dp(12), dp(11));
        camOpt1.setBackground(cellBg(isDark() ? Color.rgb(28, 44, 72) : Color.rgb(230, 242, 255), colorBlue(), dp(1)));
        camOpt1.setOnClickListener(v -> closeDrawers(() -> {
            try {
                File photo = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "ocr_temp.jpg");
                cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(i, OCR_CAMERA);
            } catch (Exception ex) {
                Toast.makeText(this, "카메라 실행 실패: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        }));

        ImageView ic1 = new ImageView(this);
        ic1.setImageResource(R.drawable.ic_camera_shiftpay);
        ic1.setColorFilter(colorBlue());
        ic1.setScaleType(ImageView.ScaleType.FIT_CENTER);
        camOpt1.addView(ic1, new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout tc1 = new LinearLayout(this);
        tc1.setOrientation(LinearLayout.VERTICAL);
        tc1.setPadding(dp(10), 0, 0, 0);
        TextView t1 = textDirect("출근카드 카메라 촬영", 14, true);
        t1.setTextColor(colorInk());
        tc1.addView(t1);
        TextView s1 = textDirect("종이 출근카드를 촬영하여 근무시간 자동 입력", 11, false);
        s1.setTextColor(colorSub());
        tc1.addView(s1);
        camOpt1.addView(tc1, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(camOpt1, new LinearLayout.LayoutParams(-1, -2));

        // 출근카드 갤러리
        LinearLayout galOpt1 = new LinearLayout(this);
        galOpt1.setOrientation(LinearLayout.HORIZONTAL);
        galOpt1.setGravity(Gravity.CENTER_VERTICAL);
        galOpt1.setPadding(dp(12), dp(11), dp(12), dp(11));
        galOpt1.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        galOpt1.setOnClickListener(v -> closeDrawers(() -> {
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(i, OCR_GALLERY);
        }));

        ImageView ic2 = new ImageView(this);
        ic2.setImageResource(R.drawable.ic_drawer_gallery);
        ic2.setColorFilter(colorBlue());
        ic2.setScaleType(ImageView.ScaleType.FIT_CENTER);
        galOpt1.addView(ic2, new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout tc2 = new LinearLayout(this);
        tc2.setOrientation(LinearLayout.VERTICAL);
        tc2.setPadding(dp(10), 0, 0, 0);
        TextView t2 = textDirect("출근카드 앨범에서 선택", 14, true);
        t2.setTextColor(colorInk());
        tc2.addView(t2);
        TextView s2 = textDirect("갤러리에 저장된 출근카드 사진 불러오기", 11, false);
        s2.setTextColor(colorSub());
        tc2.addView(s2);
        galOpt1.addView(tc2, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams galLp1 = new LinearLayout.LayoutParams(-1, -2);
        galLp1.setMargins(0, dp(6), 0, dp(16));
        body.addView(galOpt1, galLp1);

        // ------------------ 섹션 2: 급여명세서 OCR 역산 및 대조 ------------------
        TextView sec2 = textDirect("급여명세서 역산 & 1:1 대조", 14, true);
        sec2.setTextColor(colorBlue());
        sec2.setPadding(dp(4), dp(4), dp(4), dp(6));
        body.addView(sec2);

        // 명세서 촬영
        LinearLayout camOpt2 = new LinearLayout(this);
        camOpt2.setOrientation(LinearLayout.HORIZONTAL);
        camOpt2.setGravity(Gravity.CENTER_VERTICAL);
        camOpt2.setPadding(dp(12), dp(11), dp(12), dp(11));
        camOpt2.setBackground(cellBg(isDark() ? Color.rgb(32, 48, 36) : Color.rgb(236, 253, 245), isDark() ? Color.rgb(34, 197, 94) : Color.rgb(16, 185, 129), dp(1)));
        camOpt2.setOnClickListener(v -> closeDrawers(() -> {
            try {
                File photo = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "payslip_temp.jpg");
                payslipCameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                i.putExtra(MediaStore.EXTRA_OUTPUT, payslipCameraUri);
                i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(i, PAYSLIP_CAMERA);
            } catch (Exception ex) {
                Toast.makeText(this, "카메라 실행 실패: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        }));

        ImageView ic3 = new ImageView(this);
        ic3.setImageResource(R.drawable.ic_camera_shiftpay);
        ic3.setColorFilter(colorGreen());
        ic3.setScaleType(ImageView.ScaleType.FIT_CENTER);
        camOpt2.addView(ic3, new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout tc3 = new LinearLayout(this);
        tc3.setOrientation(LinearLayout.VERTICAL);
        tc3.setPadding(dp(10), 0, 0, 0);
        TextView t3 = textDirect("급여명세서 카메라 촬영", 14, true);
        t3.setTextColor(colorInk());
        tc3.addView(t3);
        TextView s3 = textDirect("실물 급여명세서를 촬영해 출근카드와 1:1 역산 대조", 11, false);
        s3.setTextColor(colorSub());
        tc3.addView(s3);
        camOpt2.addView(tc3, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(camOpt2, new LinearLayout.LayoutParams(-1, -2));

        // 명세서 갤러리
        LinearLayout galOpt2 = new LinearLayout(this);
        galOpt2.setOrientation(LinearLayout.HORIZONTAL);
        galOpt2.setGravity(Gravity.CENTER_VERTICAL);
        galOpt2.setPadding(dp(12), dp(11), dp(12), dp(11));
        galOpt2.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        galOpt2.setOnClickListener(v -> closeDrawers(() -> {
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(i, PAYSLIP_GALLERY);
        }));

        ImageView ic4 = new ImageView(this);
        ic4.setImageResource(R.drawable.ic_drawer_report);
        ic4.setColorFilter(colorGreen());
        ic4.setScaleType(ImageView.ScaleType.FIT_CENTER);
        galOpt2.addView(ic4, new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout tc4 = new LinearLayout(this);
        tc4.setOrientation(LinearLayout.VERTICAL);
        tc4.setPadding(dp(10), 0, 0, 0);
        TextView t4 = textDirect("급여명세서 앨범에서 선택", 14, true);
        t4.setTextColor(colorInk());
        tc4.addView(t4);
        TextView s4 = textDirect("캡처/저장된 급여명세서 이미지 불러오기", 11, false);
        s4.setTextColor(colorSub());
        tc4.addView(s4);
        galOpt2.addView(tc4, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams galLp2 = new LinearLayout.LayoutParams(-1, -2);
        galLp2.setMargins(0, dp(6), 0, dp(14));
        body.addView(galOpt2, galLp2);

        // v1.4.3 ④-PDF: 원본 PDF 를 바로 불러와 디지털 텍스트로 인식 (사진 OCR 보다 정확)
        LinearLayout pdfOpt = new LinearLayout(this);
        pdfOpt.setOrientation(LinearLayout.HORIZONTAL);
        pdfOpt.setGravity(Gravity.CENTER_VERTICAL);
        pdfOpt.setPadding(dp(12), dp(11), dp(12), dp(11));
        pdfOpt.setBackground(cellBg(isDark() ? Color.rgb(30, 42, 66) : Color.rgb(235, 244, 255), colorBlue(), dp(1)));
        pdfOpt.setOnClickListener(v -> closeDrawers(this::openPayslipPdfPicker));

        ImageView ic5 = new ImageView(this);
        ic5.setImageResource(R.drawable.ic_drawer_report);
        ic5.setColorFilter(colorBlue());
        ic5.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pdfOpt.addView(ic5, new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout tc5 = new LinearLayout(this);
        tc5.setOrientation(LinearLayout.VERTICAL);
        tc5.setPadding(dp(10), 0, 0, 0);
        TextView t5 = textDirect("📄 PDF 명세서 불러오기", 14, true);
        t5.setTextColor(colorInk());
        tc5.addView(t5);
        TextView s5 = textDirect("회사가 준 원본 PDF 그대로 — 디지털 텍스트라 인식 오차 0%", 11, false);
        s5.setTextColor(colorSub());
        tc5.addView(s5);
        pdfOpt.addView(tc5, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams pdfLp = new LinearLayout.LayoutParams(-1, -2);
        pdfLp.setMargins(0, 0, 0, dp(10));
        body.addView(pdfOpt, pdfLp);

        // 하단 안내 카드
        LinearLayout guideCard = new LinearLayout(this);
        guideCard.setOrientation(LinearLayout.VERTICAL);
        guideCard.setBackground(cellBg(isDark() ? Color.rgb(20, 30, 48) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        guideCard.setPadding(dp(10), dp(8), dp(10), dp(8));
        TextView gTitle = textDirect("촬영 가이드", 12, true);
        gTitle.setTextColor(colorBlue());
        guideCard.addView(gTitle);
        TextView gDesc = textDirect("• 📄 원본 PDF 가 있으면 [PDF 명세서 불러오기]가 가장 정확합니다 — 글자가 디지털이라 흔들리지 않습니다.\n• 문서가 빛에 반사되지 않도록 수평을 유지해 주세요.\n• 명세서 하단의 '기본시급, 통상시급'이 함께 나오면 정확한 역산이 가능합니다.", 11, false);
        gDesc.setTextColor(colorSub());
        gDesc.setPadding(0, dp(2), 0, 0);
        guideCard.addView(gDesc);
        body.addView(guideCard);

        bodyScroll.addView(body);
        drawer.addView(bodyScroll, new LinearLayout.LayoutParams(-1, -1));

        return drawer;
    }

    void downloadAsset(String assetName, String outFileName, String mimeType) {
        try {
            File dest = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), outFileName);
            try (InputStream in = getAssets().open(assetName);
                 OutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }

            // Android 10(Q) 이상 공용 다운로드 미디어스토어 안전 복사
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, outFileName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri downloadUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (downloadUri != null) {
                        try (InputStream in = getAssets().open(assetName);
                             OutputStream out = getContentResolver().openOutputStream(downloadUri)) {
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = in.read(buf)) != -1) {
                                out.write(buf, 0, n);
                            }
                        }
                    }
                } catch (Exception ignored) {}
            }

            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", dest);

            new AlertDialog.Builder(this)
                .setTitle("다운로드 완료")
                .setMessage("스마트폰에 파일이 저장되었습니다:\n\n" + dest.getName() + "\n\n저장 위치: 다운로드(Download) 폴더")
                .setPositiveButton("열기", (d, w) -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(uri, mimeType);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    } catch (Exception ex) {
                        Toast.makeText(this, "연결된 뷰어 앱이 없어 파일 위치에 저장만 완료되었습니다.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNeutralButton("공유", (d, w) -> {
                    try {
                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType(mimeType);
                        share.putExtra(Intent.EXTRA_STREAM, uri);
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(share, "파일 공유"));
                    } catch (Exception ignored) {}
                })
                .setNegativeButton("확인", null)
                .show();
        } catch (Exception e) {
            Toast.makeText(this, "다운로드 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void showCbaViewer() {
        start("📜 2026년 노사단체협약");
        root.addView(text("현대스틸파이프㈜ & 전국금속노동조합 현대스틸파이프지회\n체결일: 2026년 9월 10일 (유효기간: 2028년 3월 31일까지)", 14, false));

        Button dlBtn = button("💾 단체협약 원본 HWP 다운로드", () -> {
            downloadAsset("cba_2026.hwp", "2026_현대스틸파이프_노사단체협약.hwp", "application/x-hwp");
        });
        dlBtn.setBackground(bg(Color.rgb(20, 83, 153)));
        dlBtn.setTextColor(Color.WHITE);
        root.addView(dlBtn);

        root.addView(text("【 2026년 임단협 타결 및 주요 조항 요약 】", 16, true));

        String summaryText =
            "■ 제116조【유효기간 연장】\n" +
            "• 2026년 3월 31일 → ★ 2028년 3월 31일까지 연장\n\n" +
            "■ 2026년 기본급 및 임금 인상 타결\n" +
            "• 기본급 76,000원 + 제도개선분 49,400원 = 총 125,400원 인상\n" +
            "• 시급 환산 516원 인상 (월 243시간 기준, 2026.01.01 소급)\n" +
            "• 소급분: 516원 × 월평균 340h × 8개월 = 약 1,450,000원\n\n" +
            "■ 제90조【진료비 지원 대폭 확대】(2027년부 시행)\n" +
            "• 본인 입원 진료 시: 본인부담금 정산 후 ★ 본인부담금 전액 지원 (10만 원 초과 제한 폐지)\n" +
            "• 가족(배우자·자녀·양가부모): 연간 누계 100만 원 이하 반액, ★ 100만 원 초과분 전액 지원\n\n" +
            "■ 제49조 & 제51조【노동시간 및 휴게·수당】\n" +
            "• 상주근무자: 08:30 ~ 17:30 (휴게 1시간 유급 상주휴게수당 가급 인정)\n" +
            "• 교대근무자: 실근무 10시간 (기본 8h + 연장 2h, 고정 교대수당 20만 원)\n" +
            "• 야간(심야) 할증 인정: 22:00~06:00 중 휴게 1시간 제외 1일 7.0h × 50% 가산\n" +
            "• 연장근로: 150% / 야간근로(22~06시): 50% 가산\n" +
            "• 휴일근로(8시간 이내): 150% / ★ 휴일연장근로(8시간 초과): 200%\n\n" +
            "■ 상주조 돌발여비 및 현장 수당 신설 (2026년부)\n" +
            "• ★ 상주조 돌발여비: 소정근로 외 돌발 대응 시 심야(22~06시) 7만 원/건, 그 외 5만 원/건\n" +
            "• 보수쿠폰: 1일 6시간 이상 보수작업 투입 시 2,000원/장\n\n" +
            "■ 제91조【복리후생비 및 통상임금 전원합의체 판결 반영】\n" +
            "• 귀향여비 설·추석 각 80만 원(연 160만), 하계휴가비 80만 원, 하계건강지원비\n" +
            "• 대법원 전원합의체 판결(2020다247190) 취지에 따라 통상임금에 전액 산입\n" +
            "  (통상시급 고열 933원, 비고열 878원 상승 반영)\n\n" +
            "■ 제52조【유급휴일 및 대체휴무】\n" +
            "• 주휴일(일), 노동절(5/1), 설·추석 연휴, 국경일·공휴일\n" +
            "• 회사창립일(10/18), 노조창립일(4/19)\n" +
            "• 유급휴일 중복 시 익일 순차 대체휴일 100% 보장\n\n" +
            "■ 제10조【조합원 교육 및 조합활동】\n" +
            "• 연 8시간 유급 인정 (조합설명회 2시간 정상 인정)\n" +
            "• 상급단체(금속노조, 울산지부) 정기 대의원대회 추가 8시간 유급 인정";

        root.addView(text(summaryText, 13, false));
        root.addView(button("돌아가기", this::showMain));
    }

    void showSupportViewer() {
        start("🏢 현대스틸파이프 지원제도");
        root.addView(text("현대스틸파이프 복리후생 종합 안내\n2026년 별도합의 신설 복지 & 종합 지원제도", 14, false));

        Button dlBtn = button("💾 지원제도 원본 HWP 다운로드", () -> {
            downloadAsset("support_2026.hwp", "현대스틸파이프_지원제도_20260922.hwp", "application/x-hwp");
        });
        dlBtn.setBackground(bg(Color.rgb(20, 83, 153)));
        dlBtn.setTextColor(Color.WHITE);
        root.addView(dlBtn);

        root.addView(text("【 2026 별도합의 신설 복지 & 지원제도 요약 】", 16, true));

        String supportText =
            "★ [2026년 별도합의 신설 복지]\n\n" +
            "1. 선택형 복지포인트제 신설 (연 60만 P)\n" +
            "• 사내근로복지기금 주체, 연간 총 60만 포인트 지급\n" +
            "• 지급 시기: 5월(가정의 달) 30만 P, 8월(혹서기) 30만 P (해당 월 첫째 주 금요일 지급)\n\n" +
            "2. 자녀 출산 및 첫 등교 바우처 신설\n" +
            "• 초등학교 첫 등교: 첫째 50만, 둘째 100만, 셋째 이상 150만 포인트 (2026년 입학 자녀부터)\n" +
            "• 자녀 출산: 첫째 50만, 둘째 100만, 셋째 이상 150만 포인트 (타결일 이후 출산 자녀)\n\n" +
            "3. 차량구입 지원제도 개선\n" +
            "• 첫 차 구입 지원: 할인율 17% → ★ 18% (그룹사 할인 5% 포함)\n" +
            "• 재구입연한 및 의무보유기간: 5년 → ★ 4년으로 단축\n" +
            "• 전기차 구입지원 확대: 현대 IONIQ9, 기아 EV9 추가\n\n" +
            "4. 국내출장 운영 기준 개선\n" +
            "• 국내출장 여비: 40,000원/일 (출장일 무관, 사업장 간 출장 동일)\n" +
            "• 숙박비: 80,000원/박 한도 내 실비 정산\n\n" +
            "-----------------------------------------\n" +
            "★ [사내 핵심 지원제도 종합]\n\n" +
            "5. 의료비 및 종합건강검진\n" +
            "• 2027년부터 본인 입원비 전액 지원, 가족 100만 원 초과분 전액 지원 (제90조)\n" +
            "• 난임 시술비 월 100만 원 한도 실비 지원 신설\n" +
            "• 만 35세 이상 본인/배우자 종합검진 전액 지원\n\n" +
            "6. 자녀 학자금 지원\n" +
            "• 유치원/초중고/대학교 실비 지원 (장애인 자녀 교육비 연령 제한 폐지)\n\n" +
            "7. 주택자금 사내대출 지원\n" +
            "• 주택구입 및 전세보증금: 한도 3,000만 원, 금리 연 2.0%\n\n" +
            "8. 장기근속 포상\n" +
            "• 10년, 15년, 20년, 25년, 30년 근속 시\n" +
            "• 순금메달 또는 현금(지급 시점 한국금거래소 살 때 시세) 선택권 보장\n\n" +
            "9. 상주조 돌발여비 & 보수쿠폰 (현장 지원)\n" +
            "• 소정근로 외 돌발 출동: 심야 7만 원/건, 주간 5만 원/건\n" +
            "• 6시간 이상 보수작업 투입: 보수쿠폰 2,000원/장";

        root.addView(text(supportText, 13, false));
        root.addView(button("돌아가기", this::showMain));
    }

    void showPartnersViewer() {
        start("🤝 회사 제휴업체 통합현황");
        root.addView(text("현대스틸파이프 임직원 제휴 혜택\n기준일: 2026년 9월 15일 (총 28개 제휴처)", 14, false));

        Button dlBtn = button("💾 제휴업체 원본 XLSX 다운로드", () -> {
            downloadAsset("partners_2026.xlsx", "현대스틸파이프_제휴업체현황_20260915.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        });
        dlBtn.setBackground(bg(Color.rgb(20, 83, 153)));
        dlBtn.setTextColor(Color.WHITE);
        root.addView(dlBtn);

        root.addView(text("【 28개 제휴업체 혜택 요약 】", 16, true));

        String partnersText =
            "■ 울산 지역 숙박 & 레저\n" +
            "• 라한호텔 울산: 객실 정상가 대비 특별 기업할인 (052-250-6000)\n" +
            "• 신라스테이 울산: 임직원 전용 우대가 적용 (052-990-1000)\n" +
            "• 롯데호텔 울산: 주중/주말 객실 우대 및 F&B 할인 (052-960-1000)\n" +
            "• 타니베이 호텔: 동구 일산지 오션뷰 객실 특가 (052-234-8888)\n\n" +
            "■ 전국 숙박 & 리조트\n" +
            "• 켄싱턴 리조트 (경주, 지리산, 설악 등 전국 지점 기업회원가)\n" +
            "• 한화리조트 / 소노호텔앤리조트 무기명 회원대우 예약\n" +
            "• 아난티 (남해, 부산 기장 코브) 임직원 패키지\n\n" +
            "■ 여행 & 항공 & 라이프스타일\n" +
            "• 인천·김포·김해공항 스카이허브/마티나 라운지 30% 할인 (기업코드: KITA308)\n" +
            "• 아이코젠(ICOGEN): 전국 1,500여 피트니스·수영·사우나 통합 멤버십 할인\n\n" +
            "■ 의료 및 치과 혜택 (울산)\n" +
            "• CK치과병원 (울산 남구 삼산동): 임플란트, 교정 비급여 15~20% 할인\n" +
            "• 현대하이치과의원 (동구 전하동): 임직원 및 직계가족 비급여 우대\n" +
            "• 엘리야병원 (북구 신천동): 종합검진 및 비급여 진료비 10% 감면";

        root.addView(text(partnersText, 13, false));
        root.addView(button("돌아가기", this::showMain));
    }

    GradientDrawable bg(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(8));
        return d;
    }

    GradientDrawable cellBg(int bgColor, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(bgColor);
        d.setCornerRadius(dp(8));
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor);
        return d;
    }

    static final Map<String, String> SOLAR_TERMS = new HashMap<>();
    static {
        // 2025년 24절기
        SOLAR_TERMS.put("20250105", "소한"); SOLAR_TERMS.put("20250120", "대한");
        SOLAR_TERMS.put("20250204", "입춘"); SOLAR_TERMS.put("20250218", "우수");
        SOLAR_TERMS.put("20250305", "경칩"); SOLAR_TERMS.put("20250320", "춘분");
        SOLAR_TERMS.put("20250404", "청명"); SOLAR_TERMS.put("20250420", "곡우");
        SOLAR_TERMS.put("20250505", "입하"); SOLAR_TERMS.put("20250521", "소만");
        SOLAR_TERMS.put("20250605", "망종"); SOLAR_TERMS.put("20250621", "하지");
        SOLAR_TERMS.put("20250707", "소서"); SOLAR_TERMS.put("20250722", "대서");
        SOLAR_TERMS.put("20250807", "입추"); SOLAR_TERMS.put("20250823", "처서");
        SOLAR_TERMS.put("20250907", "백로"); SOLAR_TERMS.put("20250923", "추분");
        SOLAR_TERMS.put("20251008", "한로"); SOLAR_TERMS.put("20251023", "상강");
        SOLAR_TERMS.put("20251107", "입동"); SOLAR_TERMS.put("20251122", "소설");
        SOLAR_TERMS.put("20251207", "대설"); SOLAR_TERMS.put("20251221", "동지");

        // 2026년 24절기
        SOLAR_TERMS.put("20260105", "소한"); SOLAR_TERMS.put("20260120", "대한");
        SOLAR_TERMS.put("20260204", "입춘"); SOLAR_TERMS.put("20260218", "우수");
        SOLAR_TERMS.put("20260305", "경칩"); SOLAR_TERMS.put("20260320", "춘분");
        SOLAR_TERMS.put("20260405", "청명"); SOLAR_TERMS.put("20260420", "곡우");
        SOLAR_TERMS.put("20260505", "입하"); SOLAR_TERMS.put("20260521", "소만");
        SOLAR_TERMS.put("20260605", "망종"); SOLAR_TERMS.put("20260621", "하지");
        SOLAR_TERMS.put("20260707", "소서"); SOLAR_TERMS.put("20260723", "대서");
        SOLAR_TERMS.put("20260807", "입추"); SOLAR_TERMS.put("20260823", "처서");
        SOLAR_TERMS.put("20260907", "백로"); SOLAR_TERMS.put("20260923", "추분");
        SOLAR_TERMS.put("20261008", "한로"); SOLAR_TERMS.put("20261023", "상강");
        SOLAR_TERMS.put("20261107", "입동"); SOLAR_TERMS.put("20261122", "소설");
        SOLAR_TERMS.put("20261207", "대설"); SOLAR_TERMS.put("20261222", "동지");

        // 2027년 24절기
        SOLAR_TERMS.put("20270105", "소한"); SOLAR_TERMS.put("20270120", "대한");
        SOLAR_TERMS.put("20270204", "입춘"); SOLAR_TERMS.put("20270219", "우수");
        SOLAR_TERMS.put("20270306", "경칩"); SOLAR_TERMS.put("20270321", "춘분");
        SOLAR_TERMS.put("20270405", "청명"); SOLAR_TERMS.put("20270420", "곡우");
        SOLAR_TERMS.put("20270506", "입하"); SOLAR_TERMS.put("20270521", "소만");
        SOLAR_TERMS.put("20270606", "망종"); SOLAR_TERMS.put("20270621", "하지");
        SOLAR_TERMS.put("20270707", "소서"); SOLAR_TERMS.put("20270723", "대서");
        SOLAR_TERMS.put("20270808", "입추"); SOLAR_TERMS.put("20270823", "처서");
        SOLAR_TERMS.put("20270908", "백로"); SOLAR_TERMS.put("20270923", "추분");
        SOLAR_TERMS.put("20271008", "한로"); SOLAR_TERMS.put("20271024", "상강");
        SOLAR_TERMS.put("20271107", "입동"); SOLAR_TERMS.put("20271122", "소설");
        SOLAR_TERMS.put("20271207", "대설"); SOLAR_TERMS.put("20271222", "동지");

        // 2028년 24절기
        SOLAR_TERMS.put("20280106", "소한"); SOLAR_TERMS.put("20280121", "대한");
        SOLAR_TERMS.put("20280204", "입춘"); SOLAR_TERMS.put("20280219", "우수");
        SOLAR_TERMS.put("20280305", "경칩"); SOLAR_TERMS.put("20280320", "춘분");
        SOLAR_TERMS.put("20280404", "청명"); SOLAR_TERMS.put("20280419", "곡우");
        SOLAR_TERMS.put("20280505", "입하"); SOLAR_TERMS.put("20280520", "소만");
        SOLAR_TERMS.put("20280605", "망종"); SOLAR_TERMS.put("20280621", "하지");
        SOLAR_TERMS.put("20280707", "소서"); SOLAR_TERMS.put("20280722", "대서");
        SOLAR_TERMS.put("20280807", "입추"); SOLAR_TERMS.put("20280823", "처서");
        SOLAR_TERMS.put("20280907", "백로"); SOLAR_TERMS.put("20280922", "추분");
        SOLAR_TERMS.put("20281008", "한로"); SOLAR_TERMS.put("20281023", "상강");
        SOLAR_TERMS.put("20281107", "입동"); SOLAR_TERMS.put("20281122", "소설");
        SOLAR_TERMS.put("20281207", "대설"); SOLAR_TERMS.put("20281221", "동지");
    }

    String getSolarTerm(int y, int m, int d) {
        String key = iso(y, m, d);
        return SOLAR_TERMS.getOrDefault(key, "");
    }

    boolean isSolarTerm(int y, int m, int d) {
        return !getSolarTerm(y, m, d).isEmpty();
    }

    // 음력 1일, 15일 및 24절기 전용 표기 (제작자 요청 반영)
    String getLunarOrSolarTerm(int y, int m, int d) {
        String term = getSolarTerm(y, m, d);
        if (!term.isEmpty()) return term;

        try {
            Calendar solar = new GregorianCalendar(y, m - 1, d);
            ChineseCalendar lunar = new ChineseCalendar();
            lunar.setTimeInMillis(solar.getTimeInMillis());
            int lunM = lunar.get(ChineseCalendar.MONTH) + 1;
            int lunD = lunar.get(ChineseCalendar.DAY_OF_MONTH);
            if (lunD == 1) {
                return lunM + ".1";
            } else if (lunD == 15) {
                return lunM + ".15";
            }
        } catch (Exception ignored) {}
        return "";
    }

    String lunar(int y, int m, int d) {
        try {
            Calendar solar = new GregorianCalendar(y, m - 1, d);
            ChineseCalendar lunar = new ChineseCalendar();
            lunar.setTimeInMillis(solar.getTimeInMillis());
            return (lunar.get(ChineseCalendar.MONTH) + 1) + "/" + lunar.get(ChineseCalendar.DAY_OF_MONTH);
        } catch (Exception e) {
            return "";
        }
    }

    String iso(int y, int m, int d) {
        return String.format(Locale.US, "%04d%02d%02d", y, m, d);
    }

    // 공식 공휴일 데이터 자동 생성 및 탑재 (사용자 API 키 없이 즉시 동작)
    void injectOfficialHolidays(int year) {
        dayHoursHolidayCache = null; // 공휴일 변경 시 자동인정 캐시 무효화
        JSONObject obj = new JSONObject();
        try {
            if (year == 2026) {
                obj.put("20260101", "신정");
                obj.put("20260216", "설날 연휴");
                obj.put("20260217", "설날");
                obj.put("20260218", "설날 연휴");
                obj.put("20260301", "삼일절");
                obj.put("20260302", "삼일절 대체공휴일");
                obj.put("20260419", "노조창립일");
                obj.put("20260501", "근로자의 날");
                obj.put("20260505", "어린이날");
                obj.put("20260524", "부처님오신날");
                obj.put("20260525", "부처님오신날 대체공휴일");
                obj.put("20260603", "지방선거");
                obj.put("20260606", "현충일");
                obj.put("20260717", "제헌절"); // 2026년 공휴일법 개정 국경일 공휴일 재지정
                obj.put("20260815", "광복절");
                obj.put("20260817", "광복절 대체공휴일");
                obj.put("20260924", "추석 연휴");
                obj.put("20260925", "추석");
                obj.put("20260926", "추석 연휴");
                obj.put("20260928", "추석 대체공휴일"); // 단협 제52조: 공휴일 토·일 겹침 시 익일 평일 대체휴무
                obj.put("20261003", "개천절");
                obj.put("20261005", "개천절 대체공휴일");
                obj.put("20261009", "한글날");
                obj.put("20261018", "회사창립일");
                obj.put("20261225", "성탄절");
            } else if (year == 2025) {
                obj.put("20250101", "신정");
                obj.put("20250127", "설날 임시공휴일");
                obj.put("20250128", "설날 연휴");
                obj.put("20250129", "설날");
                obj.put("20250130", "설날 연휴");
                obj.put("20250301", "삼일절");
                obj.put("20250303", "삼일절 대체공휴일");
                obj.put("20250419", "노조창립일");
                obj.put("20250501", "근로자의 날");
                obj.put("20250505", "어린이날");
                obj.put("20250506", "부처님오신날 대체공휴일");
                obj.put("20250603", "선거 임시공휴일");
                obj.put("20250606", "현충일");
                obj.put("20250815", "광복절");
                obj.put("20251003", "개천절");
                obj.put("20251005", "추석 연휴");
                obj.put("20251006", "추석");
                obj.put("20251007", "추석 연휴");
                obj.put("20251008", "추석 대체공휴일");
                obj.put("20251009", "한글날");
                obj.put("20251018", "회사창립일");
                obj.put("20251225", "성탄절");
            } else if (year == 2027) {
                obj.put("20270101", "신정");
                obj.put("20270206", "설날 연휴");
                obj.put("20270207", "설날");
                obj.put("20270208", "설날 연휴");
                obj.put("20270209", "설날 대체공휴일");
                obj.put("20270301", "삼일절");
                obj.put("20270419", "노조창립일");
                obj.put("20270501", "근로자의 날");
                obj.put("20270505", "어린이날");
                obj.put("20270513", "부처님오신날");
                obj.put("20270606", "현충일"); // 현충일은 법정 대체공휴일 제외
                obj.put("20270717", "제헌절");
                obj.put("20270719", "제헌절 대체공휴일"); // 토요일 제헌절 국경일 대체공휴일 적용
                obj.put("20270815", "광복절");
                obj.put("20270816", "광복절 대체공휴일");
                obj.put("20270914", "추석 연휴");
                obj.put("20270915", "추석");
                obj.put("20270916", "추석 연휴");
                obj.put("20271003", "개천절");
                obj.put("20271004", "개천절 대체공휴일");
                obj.put("20271009", "한글날");
                obj.put("20271011", "한글날 대체공휴일");
                obj.put("20271018", "회사창립일");
                obj.put("20271225", "성탄절");
                obj.put("20271227", "성탄절 대체공휴일"); // 토요일 크리스마스 대체공휴일 적용
            } else if (year == 2028) {
                obj.put("20280101", "신정");
                obj.put("20280126", "설날 연휴");
                obj.put("20280127", "설날");
                obj.put("20280128", "설날 연휴");
                obj.put("20280301", "삼일절");
                obj.put("20280412", "제23대 국회의원선거");
                obj.put("20280419", "노조창립일");
                obj.put("20280501", "근로자의 날");
                obj.put("20280502", "부처님오신날");
                obj.put("20280505", "어린이날");
                obj.put("20280606", "현충일");
                obj.put("20280717", "제헌절");
                obj.put("20280815", "광복절");
                obj.put("20281002", "추석 연휴");
                obj.put("20281003", "추석·개천절"); // 같은 날 중복 저장 덮어쓰기 방지
                obj.put("20281004", "추석 연휴");
                obj.put("20281005", "추석·개천절 대체공휴일");
                obj.put("20281009", "한글날");
                obj.put("20281018", "회사창립일");
                obj.put("20281225", "성탄절");
            } else {
                // 2029년 이후 양력 법정 고정 공휴일 및 창립일 자동 계산 생성
                obj.put(year + "0101", "신정");
                obj.put(year + "0301", "삼일절");
                obj.put(year + "0419", "노조창립일");
                obj.put(year + "0501", "근로자의 날");
                obj.put(year + "0505", "어린이날");
                obj.put(year + "0606", "현충일");
                obj.put(year + "0717", "제헌절");
                obj.put(year + "0815", "광복절");
                obj.put(year + "1003", "개천절");
                obj.put(year + "1009", "한글날");
                obj.put(year + "1018", "회사창립일");
                obj.put(year + "1225", "성탄절");
            }
            prefs.edit().putString("official_" + year, obj.toString()).apply();
        } catch (Exception ignored) {}
    }

    void refreshHolidays() {
        dayHoursHolidayCache = null;
        int year = month.get(Calendar.YEAR);
        injectOfficialHolidays(year);
        injectOfficialHolidays(year - 1);
        injectOfficialHolidays(year + 1);
        new AlertDialog.Builder(this)
            .setTitle("공휴일 데이터 갱신 완료")
            .setMessage(year + "년 대한민국 공식 공휴일, 대체공휴일 및 회사 단협 기념일(노조창립일 4/19, 회사창립일 10/18 순차 대체휴무 포함) 데이터가 정상 갱신되었습니다.")
            .setPositiveButton("확인", (d, w) -> showMain())
            .show();
    }

    Map<String, String> holidayMap(int year) {
        Map<String, String> map = new HashMap<>();
        try {
            String json = prefs.getString("official_" + year, "{}");
            JSONObject obj = new JSONObject(json);
            Iterator<String> it = obj.keys();
            while (it.hasNext()) {
                String k = it.next();
                map.put(k, obj.getString(k));
            }
        } catch (Exception ignored) {}

        Map<String, ?> all = prefs.getAll();
        for (String k : all.keySet()) {
            if (k.startsWith("holiday_" + year)) {
                map.put(k.substring(8), all.get(k).toString());
            }
        }


    // 회사 단협 제52조 — 유급휴일이 주말·다른 공휴일과 겹친 일수만큼 익일 평일로 순차 대체휴무 배정
        applyCompanySubstituteHolidays(map, year);

        return map;
    }

    /**
     * 단협 제52조 — 유급휴일이 주말이나 다른 공휴일과 중복된 일수만큼,
     * 정부 대체공휴일 지정 여부와 무관하게 익일 평일로 순차 밀어 회사 자체 대체휴무를 배정한다.
     *
     *  · 2027년 설날: 2/6(토)·2/7(일) 설날 연휴가 주말과 겹쳐 2일이 밀린다.
     *    정부가 2/9(화)를 설날 대체공휴일로 지정해도 회사 몫 2일은 그 뒤 평일인
     *    2/10(수)·2/11(목)에 '설날 대체휴무'로 배정되어 6일 연속 휴일이 된다.
     *  · 2025·2026년은 실물 명세서로 이미 확정된 달력이므로 종전 방식(창립일 2건)을 유지한다.
     *    과거 월의 급여·특근 판정을 새 규칙으로 다시 쓰지 않기 위함이다.
     */
    void applyCompanySubstituteHolidays(Map<String, String> map, int year) {
        // v1.3.6 ⑧: 알고리즘을 순수 코어(HolidayCore)로 분리해 2027~2028년 배정을 단위 테스트로 영구 검증한다
        HolidayCore.applyCompanySubstituteHolidays(map, year);
    }

    /** 창립일 1건만 순차 대체하던 종전 방식 (2025·2026년 확정 달력 유지용) */
    void applySequentialSubHoliday(Map<String, String> map, int year, int m, int d, String label) {
        HolidayCore.applySequentialSubHoliday(map, year, m, d, label);
    }

    void editHoliday() {
        EditText input = new EditText(this);
        input.setHint("YYYYMMDD");
        EditText name = new EditText(this);
        name.setHint("휴일 명칭 (예: 노조창립일)");
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.addView(input);
        l.addView(name);
        new AlertDialog.Builder(this)
            .setTitle("휴일 수동 등록")
            .setView(l)
            .setPositiveButton("저장", (d, w) -> {
                // 하이픈·점·슬래시를 모두 제거해 캘린더 키 형식(20261120)으로 정규화
                String k = input.getText().toString().replaceAll("[^0-9]", "");
                if (k.length() != 8) {
                    Toast.makeText(this, "날짜는 YYYYMMDD 8자리로 입력해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.edit().putString("holiday_" + k, name.getText().toString().trim()).apply();
                dayHoursHolidayCache = null;
                triggerAutoBackup();
                Toast.makeText(this, k + " 휴일이 등록되었습니다.", Toast.LENGTH_SHORT).show();
                showMain();
            }).show();
    }

        // 이번 달 근무 기록 전체 일괄 삭제 / 초기화
    void clearMonthWork() {
        int maxDay = month.getActualMaximum(Calendar.DAY_OF_MONTH);
        SharedPreferences.Editor ed = prefs.edit();
        for (int d = 1; d <= maxDay; d++) {
            ed.remove(dayKey(d, "mode"));
            ed.remove(dayKey(d, "memo"));
            for (String k : keys) {
                ed.remove(dayKey(d, k));
            }
        }
        ed.apply();
        triggerAutoBackup();
        Toast.makeText(this, ym() + "월 근무 기록이 모두 초기화되었습니다.", Toast.LENGTH_SHORT).show();
        showMain();
    }

    // 특정 날짜 근무 기록 삭제
    void clearDayWork(int day) {
        SharedPreferences.Editor ed = prefs.edit();
        ed.remove(dayKey(day, "mode"));
        ed.remove(dayKey(day, "memo"));
        ed.remove(ym() + "-" + String.format(Locale.US, "%02d", day) + "-memo");
        for (String k : keys) {
            ed.remove(dayKey(day, k));
        }
        ed.apply();
        triggerAutoBackup();
    }

    // 캘린더 아래 퀵 액션 버튼 공통 스타일 (동일 높이·동일 폰트·1줄 고정 → 줄바꿈으로 높이가 깨지던 결함 해결)
    void styleQuickActionButton(Button b, int accent, boolean filled, int heightPx, float sp) {
        b.setBackground(cellBg(
            filled ? (isDark() ? Color.rgb(28, 48, 80) : Color.rgb(224, 236, 252))
                   : (isDark() ? Color.rgb(32, 45, 70) : Color.rgb(236, 244, 255)),
            accent, dp(1)));
        b.setTextColor(accent);
        b.setTextSize(sp);
        b.setSingleLine(true);
        b.setMaxLines(1);
        b.setEllipsize(TextUtils.TruncateAt.END);
        b.setIncludeFontPadding(false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(3), 0, dp(3), 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
    }

    // [⚡ 선택 모드] 버튼: 롱클릭 없이 즉시 다중 선택 모드 진입/해제
    void toggleMultiSelectMode() {
        isMultiSelectMode = !isMultiSelectMode;
        selectedDays.clear();
        if (isMultiSelectMode) {
            Toast.makeText(this, "날짜를 톡톡 터치해 여러 날을 선택하세요.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "선택 모드가 해제되었습니다.", Toast.LENGTH_SHORT).show();
        }
        showMain();
    }

    // 선택 일괄 입력: 시스템 AlertDialog(수직 목록) → 2열 카드형 프리셋 바텀시트로 전면 교체
    void showMultiApplyDialog() {
        if (selectedDays.isEmpty()) {
            Toast.makeText(this, "캘린더에서 날짜를 먼저 선택해 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        final int dayCount = selectedDays.size();

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        sheet.setClickable(true);
        sheet.setPadding(dp(16), dp(10), dp(16), dp(18));

        View handle = new View(this);
        handle.setBackground(bg(colorSub()));
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(38), dp(4));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.setMargins(0, 0, 0, dp(10));
        sheet.addView(handle, handleLp);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);

        TextView multiTitle = textDirect("⚡ 선택 " + dayCount + "일 일괄 근무 입력", 17, true);
        multiTitle.setTextColor(colorInk());
        titleCol.addView(multiTitle);

        TextView multiDesc = textDirect("선택하신 " + dayCount + "개 날짜에 적용할 근무 형태를 고르세요.", 12, false);
        multiDesc.setTextColor(colorBlue());
        titleCol.addView(multiDesc);

        headerRow.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView multiCloseX = textDirect("✕", 18, false);
        multiCloseX.setTextColor(colorSub());
        multiCloseX.setPadding(dp(8), dp(8), dp(8), dp(8));
        multiCloseX.setOnClickListener(v -> dialog.dismiss());
        headerRow.addView(multiCloseX);

        sheet.addView(headerRow);

        TextView presetHeader = textDirect("⚡ 1초 원터치 퀵 프리셋 (탭 즉시 저장)", 13, true);
        presetHeader.setTextColor(colorSub());
        presetHeader.setPadding(0, dp(10), 0, dp(6));
        sheet.addView(presetHeader);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        sheet.addView(grid);

        final boolean batchShift = isShiftWorker();

        // ── 상주/교대 전용 3행 6대 카드 (단일 날짜 시트와 1:1 동일 구조) ──
        if (batchShift) {
            LinearLayout mr1 = presetRow();
            addBatchTintCard(mr1, "⚡ 주간 10h", "8h + 연장 2h", TONE_BLUE, "ot", dialog);
            addBatchTintCard(mr1, "🌙 야간 10h", "8h+2h + 심야 7.5h", TONE_PURPLE, "night_ot", dialog);
            grid.addView(mr1);

            LinearLayout mr2 = presetRow();
            addBatchTintCard(mr2, "🔥 주간특근 10h", "8h 150% + 2h 200%", TONE_RED, "holiday_10", dialog);
            addBatchTintCard(mr2, "🔥🌙 야간특근 10h", "8h+2h + 심야 3.5h", TONE_RED, "holiday_night_10", dialog);
            grid.addView(mr2);

            LinearLayout mr3 = presetRow();
            addBatchTintCard(mr3, "🌴 연차 유급", "유급 8h 차감", TONE_MINT, "annual", dialog);
            addBatchTintCard(mr3, "🗑️ 입력 내용 삭제", "선택 날짜 기록 삭제", TONE_DELETE, "delete", dialog);
            grid.addView(mr3);

            LinearLayout body = addAccordion(grid, "기타 및 8h 정상근무");
            LinearLayout b1 = presetRow();
            addBatchTintCard(b1, "● 주간 정상 (8h)", "기본 8시간 인정", TONE_BLUE, "normal", dialog);
            addBatchTintCard(b1, "🌙 야간 정상 (8h)", "심야할증 6.0h 인정", TONE_PURPLE, "night_normal", dialog);
            body.addView(b1);

            LinearLayout b1b = presetRow();
            addBatchTintCard(b1b, "🔥 주간특근 (8h)", "휴일근로 8h 150%", TONE_RED, "holiday", dialog);
            addBatchTintCard(b1b, "🔥🌙 야간특근 (8h)", "특근 8h + 심야 6.0h", TONE_RED, "holiday_night_8", dialog);
            body.addView(b1b);

            LinearLayout b2 = presetRow();
            addBatchTintCard(b2, "🌗 반차 (4h)", "4h 근무 + 4h 연차", TONE_MINT, "half_am", dialog);
            addBatchTintCard(b2, "🏖️ 하계휴가 (8h)", "유급 인정", TONE_MINT, "summer", dialog);
            body.addView(b2);

            LinearLayout b3 = presetRow();
            addBatchTintCard(b3, "↺ 기본값(자동인정)", "주말 유급 자동복구", TONE_PLAIN, "auto", dialog);
            addBatchTintCard(b3, "✕ 근무 없음(무급)", "인정시간 0시간", TONE_PLAIN, "none", dialog);
            body.addView(b3);
        } else {
            LinearLayout mr1 = presetRow();
            addBatchTintCard(mr1, "● 주간 정상 (8h)", "기본 8시간 인정", TONE_BLUE, "normal", dialog);
            addBatchTintCard(mr1, "⚡ 주간 10h", "8h + 연장 2h", TONE_BLUE, "ot", dialog);
            grid.addView(mr1);

            LinearLayout mr2 = presetRow();
            addBatchTintCard(mr2, "🔥 휴일특근 (8h)", "휴일근로 150%", TONE_RED, "holiday", dialog);
            addBatchTintCard(mr2, "🔥 휴일특근 10h", "8h 150% + 2h 200%", TONE_RED, "holiday_10", dialog);
            grid.addView(mr2);

            LinearLayout mr3 = presetRow();
            addBatchTintCard(mr3, "🌴 연차 유급", "유급 8h 차감", TONE_MINT, "annual", dialog);
            addBatchTintCard(mr3, "🗑️ 입력 내용 삭제", "선택 날짜 기록 삭제", TONE_DELETE, "delete", dialog);
            grid.addView(mr3);

            LinearLayout body = addAccordion(grid, "기타 및 교대조 근무");
            LinearLayout b1 = presetRow();
            addBatchTintCard(b1, "🌗 반차 (4h)", "4h 근무 + 4h 연차", TONE_MINT, "half_am", dialog);
            addBatchTintCard(b1, "🏖️ 하계휴가 (8h)", "유급 인정", TONE_MINT, "summer", dialog);
            body.addView(b1);

            LinearLayout b2 = presetRow();
            addBatchTintCard(b2, "🌙 야간 10h", "대타 투입 · 심야 7.5h", TONE_PURPLE, "night_ot", dialog);
            addBatchTintCard(b2, "🔥🌙 야간특근 10h", "대타 · 8h+2h+심야 3.5h", TONE_RED, "holiday_night_10", dialog);
            body.addView(b2);

            LinearLayout b3 = presetRow();
            addBatchTintCard(b3, "↺ 기본값(자동인정)", "주말 유급 자동복구", TONE_PLAIN, "auto", dialog);
            addBatchTintCard(b3, "✕ 근무 없음(무급)", "인정시간 0시간", TONE_PLAIN, "none", dialog);
            body.addView(b3);
        }

        TextView multiNote = textDirect("• 이미 기록된 날짜는 선택한 프리셋으로 대체됩니다.", 11, false);
        multiNote.setTextColor(colorSub());
        multiNote.setPadding(0, dp(10), 0, dp(2));
        sheet.addView(multiNote);

        Button multiCloseBtn = button("닫기", () -> dialog.dismiss());
        multiCloseBtn.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        multiCloseBtn.setTextColor(colorSub());
        multiCloseBtn.setTextSize(13);
        multiCloseBtn.setPadding(dp(10), dp(11), dp(10), dp(11));
        LinearLayout.LayoutParams multiCloseLp = new LinearLayout.LayoutParams(-1, -2);
        multiCloseLp.setMargins(0, dp(8), 0, 0);
        sheet.addView(multiCloseBtn, multiCloseLp);

        dialog.setContentView(sheet);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dialog.getWindow().setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams wlp = dialog.getWindow().getAttributes();
            wlp.dimAmount = 0.45f;
            dialog.getWindow().setAttributes(wlp);
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.setOnShowListener(di -> {
            sheet.setTranslationY(dp(360));
            sheet.animate().translationY(0).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
        });
        dialog.show();
    }

    // 2열 틴트 카드형 프리셋 (단일 날짜 시트의 addTintCard 와 같은 룩)
    void addBatchTintCard(LinearLayout row, String cardTitle, String cardSub, int tone, String preset, Dialog dialog) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackground(cellBg(toneBg(tone), toneBorder(tone), dp(1)));
        card.setPadding(dp(10), dp(9), dp(10), dp(9));
        card.setClickable(true);

        TextView t = textDirect(cardTitle, 12, true);
        t.setTextColor(toneInk(tone));
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        card.addView(t);

        TextView s = textDirect(cardSub, 10, false);
        s.setTextColor(isDark() ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.END);
        s.setPadding(0, dp(2), 0, 0);
        card.addView(s);

        card.setOnClickListener(v -> applyBatchPresetToSelection(preset, dialog));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(card, lp);
    }

    // 선택한 날짜 전체에 프리셋을 기록하고 선택 모드를 종료한다
    void applyBatchPresetToSelection(String preset, Dialog dialog) {
        if (selectedDays.isEmpty()) {
            if (dialog != null) dialog.dismiss();
            return;
        }
        vibrateTick();
        int cnt = selectedDays.size();
        if ("delete".equals(preset)) {          // 🗑️ 선택 날짜 기록 완전 삭제
            SharedPreferences.Editor del = prefs.edit();
            for (int dDay : new ArrayList<>(selectedDays)) {
                del.remove(dayKey(dDay, "mode"));
                del.remove(dayKey(dDay, "memo"));
                for (String k : keys) del.remove(dayKey(dDay, k));
            }
            del.apply();
            triggerAutoBackup();
            isMultiSelectMode = false;
            selectedDays.clear();
            if (dialog != null) dialog.dismiss();
            Toast.makeText(this, cnt + "개 날짜의 근무 기록이 삭제되었습니다.", Toast.LENGTH_SHORT).show();
            showMain();
            return;
        }
        SharedPreferences.Editor ed = prefs.edit();
        for (int dDay : new ArrayList<>(selectedDays)) {
            writeBatchPreset(ed, dDay, preset);
        }
        ed.apply();
        triggerAutoBackup();
        isMultiSelectMode = false;
        selectedDays.clear();
        if (dialog != null) dialog.dismiss();
        Toast.makeText(this, cnt + "개 날짜에 근무가 일괄 입력되었습니다.", Toast.LENGTH_SHORT).show();
        showMain();
    }

    // 일괄 입력: 단일 프리셋 applyPreset() 과 100% 동일한 키 규약(keys[] = normal/overtime/holiday/holidayOT/night/paid)과
    // 모드명(work / annual / summer / half_am)으로 하루치를 기록한다. (11-09 norm·ot·hol 오키 결함 패치)
    void writeBatchPreset(SharedPreferences.Editor ed, int day, String preset) {
        // 이전 입력 흔적을 먼저 모두 지워 선택한 프리셋만 남긴다 (메모 포함)
        for (String k : keys) {
            ed.remove(dayKey(day, k));
        }
        ed.remove(dayKey(day, "memo"));

        String mode = "work";
        String normal = null, paid = null, overtime = null, holiday = null, holidayOT = null, night = null;

        if ("normal".equals(preset)) {                 // ● 주간 정상
            normal = "8";
        } else if ("ot".equals(preset)) {              // ⚡ 주간 10h (8h + 2h 연장)
            normal = "8";
            overtime = "2";
        } else if ("night_ot".equals(preset)) {        // 🌙 야간 10h (8+2+심야 7.5)
            normal = "8";
            overtime = "2";
            night = "7.5";
        } else if ("night_normal".equals(preset)) {    // 🌙 야간 정상 (8+심야 6.0)
            normal = "8";
            night = "6";
        } else if ("holiday".equals(preset)) {         // 🔥 휴일 특근 8h
            holiday = "8";
        } else if ("holiday_10".equals(preset)) {     // 🔥 주간특근 10h (8h 150% + 2h 200%)
            holiday = "8";
            holidayOT = "2";
        } else if ("holiday_night_10".equals(preset)) { // 🔥🌙 야간특근 10h (8h 특근 + 2h 연장 + 심야 3.5h)
            holiday = "8";
            holidayOT = "2";
            night = "3.5";
        } else if ("holiday_night_8".equals(preset)) {  // 🔥🌙 야간특근 8h (8h 특근 + 심야 6.0h)
            holiday = "8";
            night = "6";
        } else if ("annual".equals(preset)) {          // 🌴 연차 휴가 (isLeave 가 8h 자동 인정)
            mode = "annual";
        } else if ("summer".equals(preset)) {          // 🏖️ 하계휴가 (isLeave 가 8h 자동 인정)
            mode = "summer";
        } else if ("half_am".equals(preset)) {         // 🌗 오전 반차 (4h 근무 + 4h 유급)
            mode = "half_am";
            normal = "4";
            paid = "4";
        } else if ("auto".equals(preset)) {            // ↺ 기본값(자동인정)
            mode = "auto";
        } else if ("none".equals(preset)) {            // ✕ 근무 없음(무급)
            mode = "none";
        }

        ed.putString(dayKey(day, "mode"), mode);
        putOrRemove(ed, dayKey(day, keys[0]), normal);
        putOrRemove(ed, dayKey(day, keys[1]), paid);
        putOrRemove(ed, dayKey(day, keys[4]), overtime);
        putOrRemove(ed, dayKey(day, keys[5]), holiday);
        putOrRemove(ed, dayKey(day, keys[6]), holidayOT);
        putOrRemove(ed, dayKey(day, keys[7]), night);
    }

    void putOrRemove(SharedPreferences.Editor ed, String key, String val) {
        if (val != null) {
            ed.putString(key, val);
        } else {
            ed.remove(key);
        }
    }

    void confirmMultiDelete() {
        if (selectedDays.isEmpty()) return;
        new AlertDialog.Builder(this)
            .setTitle("선택 날짜 일괄 삭제")
            .setMessage("선택한 " + selectedDays.size() + "개 날짜의 근무 기록을 모두 삭제하시겠습니까?")
            .setPositiveButton("삭제", (d, w) -> {
                vibrateTick();
                int cnt = selectedDays.size();
                for (int dDay : selectedDays) {
                    clearDayWork(dDay);
                }
                isMultiSelectMode = false;
                selectedDays.clear();
                Toast.makeText(this, cnt + "개 날짜의 근무 기록이 삭제되었습니다.", Toast.LENGTH_SHORT).show();
                showMain();
            })
            .setNegativeButton("취소", null)
            .show();
    }

    // 캘린더 날짜 롱클릭 시 해당 날짜 위치 위에 오버레이 [🗑️ 내용삭제] 플로팅 버튼 표시
    void showCellDeleteOverlay(View anchorCell, int day) {
        PopupWindow popup = new PopupWindow(this);
        LinearLayout popLayout = new LinearLayout(this);
        popLayout.setOrientation(LinearLayout.HORIZONTAL);
        popLayout.setGravity(Gravity.CENTER);
        popLayout.setBackground(cellBg(Color.rgb(220, 53, 69), Color.rgb(180, 30, 40), dp(1)));
        popLayout.setPadding(dp(10), dp(7), dp(10), dp(7));
        popLayout.setElevation(dp(8));

        TextView tv = textDirect("🗑️ " + day + "일 내용삭제", 12, true);
        tv.setTextColor(Color.WHITE);
        popLayout.addView(tv);

        popup.setContentView(popLayout);
        popup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setFocusable(true);
        popup.setOutsideTouchable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        popLayout.setOnClickListener(pv -> {
            vibrateTick();
            clearDayWork(day);
            popup.dismiss();
            Toast.makeText(this, day + "일 근무 내용이 삭제되었습니다.", Toast.LENGTH_SHORT).show();
            showMain();
        });

        int[] loc = new int[2];
        anchorCell.getLocationOnScreen(loc);
        int cellW = anchorCell.getWidth();
        int cellH = anchorCell.getHeight();
        int popW = dp(100);
        int popH = dp(36);
        int x = loc[0] + (cellW - popW) / 2;
        int y = loc[1] + (cellH - popH) / 2;

        try {
            popup.showAtLocation(anchorCell, Gravity.NO_GRAVITY, Math.max(dp(8), x), Math.max(dp(8), y));
        } catch (Exception e) {
            popup.showAsDropDown(anchorCell, 0, -cellH);
        }
    }

    // 처음 사용자 3단계 핵심 이용안내 및 기본정보 마법사
    void showOnboardingGuide() {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackgroundColor(colorSurface());

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView title = textDirect("👋 ShiftPay 시작 안내", 19, true);
        title.setTextColor(colorBlue());
        l.addView(title);

        TextView sub = textDirect("현대스틸파이프 임직원 맞춤형 급여 관리 3단계", 13, false);
        sub.setTextColor(colorSub());
        sub.setPadding(0, dp(4), 0, dp(14));
        l.addView(sub);

        l.addView(buildStepGuideCard("1️⃣ 1단계 : 기본정보 & 시급 설정 (최초 1회)",
            "• 성명, 생년월일(만 60세 정년 D-Day 카운트다운), 근무공장(1·2·3공장 드론뷰), 직급, 기본시급을 설정합니다.\n• 2026년 단협 최신 기준(기본시급 13,653원, 통상시급 14,939원)이 기본 적용되어 있습니다.",
            colorBlue()));

        l.addView(buildStepGuideCard("2️⃣ 2단계 : 월간 근무 입력 & 출근카드 OCR (월중~월말)",
            "• 캘린더 날짜를 터치해 1초 퀵 프리셋(주간 정상/연장/특근/연차)으로 간편 입력합니다.\n• 월말에는 종이 출근카드를 사진 촬영하여 한 번에 100% 자동 입력할 수 있습니다.",
            colorInk()));

        l.addView(buildStepGuideCard("3️⃣ 3단계 : 급여명세서 OCR 1:1 역산 대조 (매월 10일)",
            "• 매월 10일 월급날 회사 급여명세서를 촬영하면 예상 급여와 1원 단위까지 1:1 대조·검증하고 실제 시급/공제액을 자동 동기화합니다.",
            colorGreen()));

        Button setupBtn = button("⚙️ 지금 내 기본정보 설정하기", () -> {
            vibrateTick();
            prefs.edit().putBoolean("onboarding_shown", true).apply();
            d.dismiss();
            showSettings();
        });
        setupBtn.setBackground(cellBg(Color.rgb(20, 83, 153), Color.rgb(10, 60, 120), dp(1)));
        setupBtn.setTextColor(Color.WHITE);
        setupBtn.setTextSize(14);
        setupBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams setupLp = new LinearLayout.LayoutParams(-1, -2);
        setupLp.setMargins(0, dp(14), 0, dp(8));
        l.addView(setupBtn, setupLp);

        Button startBtn = button("둘러보기 (2026 단협 기본값으로 시작)", () -> {
            vibrateTick();
            prefs.edit().putBoolean("onboarding_shown", true).apply();
            d.dismiss();
        });
        startBtn.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        startBtn.setTextColor(colorSub());
        startBtn.setTextSize(13);
        startBtn.setPadding(dp(14), dp(10), dp(14), dp(10));
        l.addView(startBtn);

        sv.addView(l);
        d.setContentView(sv);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int w = (int)(getResources().getDisplayMetrics().widthPixels * 0.90);
            d.getWindow().setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    LinearLayout buildStepGuideCard(String titleText, String descText, int accentColor) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(245, 248, 253), colorBorder(), dp(1)));
        c.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));

        TextView t = textDirect(titleText, 13, true);
        t.setTextColor(accentColor);
        c.addView(t);

        TextView d = textDirect(descText, 12, false);
        d.setTextColor(colorInk());
        d.setPadding(0, dp(4), 0, 0);
        d.setLineSpacing(dp(2), 1.05f);
        c.addView(d);

        c.setLayoutParams(lp);
        return c;
    }


    // 하단 원터치 퀵 프리셋 바텀시트 빌더
    LinearLayout buildBottomSheet() {
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        sheet.setElevation(dp(20));
        sheet.setClickable(true);
        sheet.setPadding(dp(16), dp(10), dp(16), bottomInset + dp(16));

        View handle = new View(this);
        handle.setBackground(bg(colorSub()));
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(38), dp(4));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.setMargins(0, 0, 0, dp(10));
        sheet.addView(handle, handleLp);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);

        sheetDateTitle = textDirect("2026-11-03 (화) 근무 입력", 17, true);
        sheetDateTitle.setTextColor(colorInk());
        titleCol.addView(sheetDateTitle);

        sheetCurrentStatus = textDirect("현재 상태: 미입력", 12, false);
        sheetCurrentStatus.setTextColor(colorBlue());
        titleCol.addView(sheetCurrentStatus);

        headerRow.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView closeBtn = textDirect("✕", 18, false);
        closeBtn.setTextColor(colorSub());
        closeBtn.setPadding(dp(8), dp(8), dp(8), dp(8));
        closeBtn.setOnClickListener(v -> closeDrawers(null));
        headerRow.addView(closeBtn);

        sheet.addView(headerRow);

        TextView presetHeader = textDirect("⚡ 1초 원터치 퀵 프리셋 (탭 즉시 저장)", 13, true);
        presetHeader.setTextColor(colorSub());
        presetHeader.setPadding(0, dp(10), 0, dp(6));
        sheet.addView(presetHeader);

        sheetPresetGrid = new LinearLayout(this);
        sheetPresetGrid.setOrientation(LinearLayout.VERTICAL);
        sheet.addView(sheetPresetGrid);

        Button detailBtn = button("세부 시간 직접 입력 및 메모 (5대 영역별)", () -> {
            vibrateTick();
            closeDrawers(() -> showDay(sheetDay));
        });
        detailBtn.setBackground(cellBg(isDark() ? Color.rgb(20, 36, 64) : Color.rgb(238, 245, 255), colorBlue(), dp(1)));
        detailBtn.setTextColor(colorBlue());
        detailBtn.setTextSize(13);
        detailBtn.setPadding(dp(10), dp(11), dp(10), dp(11));
        LinearLayout.LayoutParams detailLp = new LinearLayout.LayoutParams(-1, -2);
        detailLp.setMargins(0, dp(10), 0, 0);
        sheet.addView(detailBtn, detailLp);

        return sheet;
    }

    void showBottomSheet(int day) {
        if (activeDrawer != null) return;
        chosenDay = day;
        updateBottomSheetContent(day);
        bottomSheetView.setVisibility(View.VISIBLE);
        bottomSheetView.post(() -> {
            int h = bottomSheetView.getHeight() > 0 ? bottomSheetView.getHeight() : dp(420);
            bottomSheetView.setTranslationY(h);
            scrimView.setVisibility(View.VISIBLE);
            scrimView.setAlpha(0f);
            scrimView.animate().alpha(1f).setDuration(240).start();
            bottomSheetView.animate().translationY(0).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
            activeDrawer = bottomSheetView;
        });
    }

    void updateBottomSheetContent(int day) {
        sheetDay = day;
        String[] dayNames = {"일", "월", "화", "수", "목", "금", "토"};
        int wd = weekdaySundayZero(month.get(Calendar.YEAR), month.get(Calendar.MONTH) + 1, day);
        sheetDateTitle.setText(ym() + "-" + String.format(Locale.US, "%02d", day) + " (" + dayNames[wd] + ")");

        double normal = dayHours(day, 0);
        double ot = dayHours(day, 4);
        double hol = dayHours(day, 5);
        double holOt = dayHours(day, 6);
        String mode = dayMode(day);

        double nightH = dayHours(day, 7);
        String statusStr = "현재 상태: 미입력 (자동인정)";
        if (hol + holOt > 0) {
            statusStr = "현재 상태: 특근 " + hoursShort(hol + holOt) + "시간" + (nightH > 0 ? " (야간 " + hoursShort(nightH) + "h)" : "");
        } else if (ot > 0 && nightH > 0) {
            statusStr = "현재 상태: 야간 " + hoursShort(normal + ot) + "시간 (정상 " + hoursShort(normal) + " + 연장 " + hoursShort(ot) + " + 야간 " + hoursShort(nightH) + "h)";
        } else if (ot > 0) {
            statusStr = "현재 상태: 정상 " + hoursShort(normal) + "시간 + 연장 " + hoursShort(ot) + "시간";
        } else if (normal > 0 && nightH > 0) {
            statusStr = "현재 상태: 야간 정상 " + hoursShort(normal) + "시간 (야간할증 " + hoursShort(nightH) + "h)";
        } else if (normal > 0) {
            statusStr = "현재 상태: 정상 " + hoursShort(normal) + "시간";
        } else if (mode.equals("annual")) {
            statusStr = "현재 상태: 연차 유급 8시간";
        } else if (mode.equals("summer")) {
            statusStr = "현재 상태: 하계휴가 8시간";
        } else if (wd == 6 && mode.equals("auto")) {
            statusStr = "현재 상태: 토요일 자동 유급 8시간";
        } else if (wd == 0 && mode.equals("auto")) {
            statusStr = "현재 상태: 일요일 자동 주차 8시간";
        }
        sheetCurrentStatus.setText(statusStr);

        sheetPresetGrid.removeAllViews();
        final boolean isShift = isShiftWorker();

        // ── 상주/교대 전용 3행 6대 퀵 카드 (v1.3.3) ──────────────────────────
        //  매일 쓰는 카드만 큼직하게 6개 노출하고, 대타·특이 근무는 [기타] 아코디언에 접어 둔다.
        if (isShift) {
            // 교대조: 평일 맞교대(주간 10h · 야간 10h) → 휴일 맞특근 → 휴가/삭제
            LinearLayout r1 = presetRow();
            addTintCard(r1, "⚡ 주간 10h (8+2h)", "8h + 연장 2h", TONE_BLUE,
                    () -> applyPreset(day, "work", 8, 2, 0, 0, 0));
            addTintCard(r1, "🌙 야간 10h (8+2h)", "8h+2h + 심야 7.5h", TONE_PURPLE,
                    () -> applyPreset(day, "work", 8, 2, 0, 0, 7.5));
            sheetPresetGrid.addView(r1);

            LinearLayout r2 = presetRow();
            addTintCard(r2, "🔥 주간특근 10h", "8h 150% + 2h 200%", TONE_RED,
                    () -> applyPreset(day, "work", 0, 0, 8, 2, 0));
            addTintCard(r2, "🔥🌙 야간특근 10h", "8h+2h + 심야 3.5h", TONE_RED,
                    () -> applyPreset(day, "work", 0, 0, 8, 2, 3.5));
            sheetPresetGrid.addView(r2);

            LinearLayout r3 = presetRow();
            addTintCard(r3, "🌴 연차 유급 (8h)", "유급 8h 차감", TONE_MINT,
                    () -> applyPreset(day, "annual", 8, 0, 0, 0));
            addTintCard(r3, "🗑️ 입력 내용 삭제", "이 날짜 기록 완전 삭제", TONE_DELETE, () -> {
                clearDayWork(day);
                Toast.makeText(this, day + "일 근무 내용이 삭제되었습니다.", Toast.LENGTH_SHORT).show();
                closeDrawers(this::showMain);
            });
            sheetPresetGrid.addView(r3);

            // 접힌 영역: 8h 정상근무 · 반차 · 하계휴가 · 기본값 · 무급
            LinearLayout body = addAccordion(sheetPresetGrid, "기타 및 8h 정상근무");
            LinearLayout a1 = presetRow();
            addTintCard(a1, "● 주간 정상 (8h)", "기본 8시간 인정", TONE_BLUE,
                    () -> applyPreset(day, "work", 8, 0, 0, 0, 0));
            addTintCard(a1, "🌙 야간 정상 (8h)", "심야할증 6.0h 인정", TONE_PURPLE,
                    () -> applyPreset(day, "work", 8, 0, 0, 0, 6.0));
            body.addView(a1);

            // v1.4.1 ③ — 교대조가 주간 교대로 들어와 토요일 8시간 특근할 때 쓸 8h 특근 카드 (정상 8h와 대칭 배치)
            LinearLayout a1b = presetRow();
            addTintCard(a1b, "🔥 주간특근 (8h)", "휴일근로 8h 150%", TONE_RED,
                    () -> applyPreset(day, "work", 0, 0, 8, 0, 0));
            addTintCard(a1b, "🔥🌙 야간특근 (8h)", "특근 8h + 심야 6.0h", TONE_RED,
                    () -> applyPreset(day, "work", 0, 0, 8, 0, 6.0));
            body.addView(a1b);

            LinearLayout a2 = presetRow();
            addTintCard(a2, "🌗 반차 (4h)", "4h 근무 + 4h 연차", TONE_MINT, () -> applyHalfDay(day));
            addTintCard(a2, "🏖️ 하계휴가 (8h)", "유급 인정", TONE_MINT,
                    () -> applyPreset(day, "summer", 8, 0, 0, 0));
            body.addView(a2);

            LinearLayout a3 = presetRow();
            addTintCard(a3, "↺ 기본값(자동인정)", "주말 유급 자동복구", TONE_PLAIN,
                    () -> applyPreset(day, "auto", 0, 0, 0, 0));
            addTintCard(a3, "✕ 근무 없음(무급)", "인정시간 0시간", TONE_PLAIN,
                    () -> applyPreset(day, "none", 0, 0, 0, 0));
            body.addView(a3);
        } else {
            // 상주조: 평일 기본(주간 정상 8h · 주간 10h) → 휴일 특근 → 휴가/삭제
            LinearLayout r1 = presetRow();
            addTintCard(r1, "● 주간 정상 (8h)", "기본 8시간 인정", TONE_BLUE,
                    () -> applyPreset(day, "work", 8, 0, 0, 0, 0));
            addTintCard(r1, "⚡ 주간 10h (8+2h)", "8h + 연장 2h", TONE_BLUE,
                    () -> applyPreset(day, "work", 8, 2, 0, 0, 0));
            sheetPresetGrid.addView(r1);

            LinearLayout r2 = presetRow();
            addTintCard(r2, "🔥 휴일특근 (8h)", "휴일근로 150%", TONE_RED,
                    () -> applyPreset(day, "work", 0, 0, 8, 0, 0));
            addTintCard(r2, "🔥 휴일특근 10h (8+2h)", "8h 150% + 2h 200%", TONE_RED,
                    () -> applyPreset(day, "work", 0, 0, 8, 2, 0));
            sheetPresetGrid.addView(r2);

            LinearLayout r3 = presetRow();
            addTintCard(r3, "🌴 연차 유급 (8h)", "유급 8h 차감", TONE_MINT,
                    () -> applyPreset(day, "annual", 8, 0, 0, 0));
            addTintCard(r3, "🗑️ 입력 내용 삭제", "이 날짜 기록 완전 삭제", TONE_DELETE, () -> {
                clearDayWork(day);
                Toast.makeText(this, day + "일 근무 내용이 삭제되었습니다.", Toast.LENGTH_SHORT).show();
                closeDrawers(this::showMain);
            });
            sheetPresetGrid.addView(r3);

            // 접힌 영역: 대타 투입(교대조 근무) · 반차 · 하계휴가 · 기본값 · 무급
            LinearLayout body = addAccordion(sheetPresetGrid, "기타 및 교대조 근무");
            LinearLayout a1 = presetRow();
            addTintCard(a1, "🌗 반차 (4h)", "4h 근무 + 4h 연차", TONE_MINT, () -> applyHalfDay(day));
            addTintCard(a1, "🏖️ 하계휴가 (8h)", "유급 인정", TONE_MINT,
                    () -> applyPreset(day, "summer", 8, 0, 0, 0));
            body.addView(a1);

            LinearLayout a2 = presetRow();
            addTintCard(a2, "🌙 야간 10h (8+2h)", "대타 투입 · 심야 7.5h", TONE_PURPLE,
                    () -> applyPreset(day, "work", 8, 2, 0, 0, 7.5));
            addTintCard(a2, "🔥🌙 야간특근 10h", "대타 · 8h+2h+심야 3.5h", TONE_RED,
                    () -> applyPreset(day, "work", 0, 0, 8, 2, 3.5));
            body.addView(a2);

            LinearLayout a3 = presetRow();
            addTintCard(a3, "↺ 기본값(자동인정)", "주말 유급 자동복구", TONE_PLAIN,
                    () -> applyPreset(day, "auto", 0, 0, 0, 0));
            addTintCard(a3, "✕ 근무 없음(무급)", "인정시간 0시간", TONE_PLAIN,
                    () -> applyPreset(day, "none", 0, 0, 0, 0));
            body.addView(a3);
        }
    }


    // ── 4색 프리미엄 시인성 컬러 시스템 (토스/애플 스타일 소프트 파스텔 틴트) ──
    static final int TONE_BLUE = 0;    // ☀️ 주간 (Ocean Blue)
    static final int TONE_PURPLE = 1;  // 🌙 야간 (Soft Purple)
    static final int TONE_RED = 2;     // 🔥 특근·휴일 (Coral Red)
    static final int TONE_MINT = 3;    // 🌴 휴가 (Mint Green)
    static final int TONE_DELETE = 4;  // 🗑️ 삭제
    static final int TONE_PLAIN = 5;   // ↺ 기본값 / ✕ 무급

    int toneBg(int tone) {
        if (isDark()) {
            switch (tone) {
                case TONE_BLUE:   return Color.rgb(17, 38, 66);
                case TONE_PURPLE: return Color.rgb(38, 22, 56);
                case TONE_RED:    return Color.rgb(48, 22, 25);
                case TONE_MINT:   return Color.rgb(12, 42, 34);
                default:          return Color.rgb(30, 41, 55);
            }
        }
        switch (tone) {
            case TONE_BLUE:   return 0xFFEFF6FF;
            case TONE_PURPLE: return 0xFFFAF5FF;
            case TONE_RED:    return 0xFFFEF2F2;
            case TONE_MINT:   return 0xFFECFDF5;
            default:          return 0xFFF8FAFC;
        }
    }

    int toneBorder(int tone) {
        if (isDark()) {
            switch (tone) {
                case TONE_BLUE:   return Color.rgb(29, 78, 216);
                case TONE_PURPLE: return Color.rgb(107, 33, 168);
                case TONE_RED:    return Color.rgb(153, 27, 27);
                case TONE_MINT:   return Color.rgb(4, 120, 87);
                case TONE_DELETE: return Color.rgb(100, 116, 139);
                default:          return Color.rgb(71, 85, 105);
            }
        }
        switch (tone) {
            case TONE_BLUE:   return 0xFF93C5FD;
            case TONE_PURPLE: return 0xFFC084FC;
            case TONE_RED:    return 0xFFF87171;
            case TONE_MINT:   return 0xFF6EE7B7;
            default:          return 0xFFE2E8F0;
        }
    }

    int toneInk(int tone) {
        if (isDark()) {
            switch (tone) {
                case TONE_BLUE:   return Color.rgb(147, 197, 253);
                case TONE_PURPLE: return Color.rgb(216, 180, 254);
                case TONE_RED:    return Color.rgb(252, 165, 165);
                case TONE_MINT:   return Color.rgb(110, 231, 183);
                case TONE_DELETE: return Color.rgb(248, 113, 113);
                default:          return Color.rgb(148, 163, 184);
            }
        }
        switch (tone) {
            case TONE_BLUE:   return 0xFF1D4ED8;
            case TONE_PURPLE: return 0xFF6B21A8;
            case TONE_RED:    return 0xFFB91C1C;
            case TONE_MINT:   return 0xFF047857;
            case TONE_DELETE: return 0xFFEF4444;
            default:          return 0xFF64748B;
        }
    }

    LinearLayout presetRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    // 퀵 카드 1장: 아이콘 + 제목 + 소제목을 소프트 틴트 카드로 (2열 대칭)
    void addTintCard(LinearLayout row, String title, String sub, int tone, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackground(cellBg(toneBg(tone), toneBorder(tone), dp(1)));
        card.setPadding(dp(9), dp(8), dp(9), dp(8));
        card.setClickable(true);

        TextView t = textDirect(title, 12, true);
        t.setTextColor(toneInk(tone));
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        card.addView(t);

        TextView s = textDirect(sub, 10, false);
        s.setTextColor(isDark() ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.END);
        s.setPadding(0, dp(2), 0, 0);
        card.addView(s);

        card.setOnClickListener(v -> action.run());

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(card, lp);
    }

    // 접힌 영역 [기타 및 ... ▾] — 탭하면 아코디언으로 펼쳐진다 (기본은 접힘)
    LinearLayout addAccordion(LinearLayout parent, String label) {
        final LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setVisibility(View.GONE);

        final TextView head = textDirect(label + "  ▾", 12, true);
        head.setTextColor(colorSub());
        head.setGravity(Gravity.CENTER);
        head.setPadding(dp(8), dp(10), dp(8), dp(10));
        head.setBackground(cellBg(isDark() ? Color.rgb(22, 32, 48) : Color.rgb(241, 245, 249), colorBorder(), dp(1)));
        head.setClickable(true);
        head.setOnClickListener(v -> {
            vibrateTick();
            boolean open = body.getVisibility() == View.VISIBLE;
            body.setVisibility(open ? View.GONE : View.VISIBLE);
            head.setText(label + (open ? "  ▾" : "  ▴"));
        });
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(-1, -2);
        hLp.setMargins(dp(3), dp(6), dp(3), dp(3));
        parent.addView(head, hLp);
        parent.addView(body, new LinearLayout.LayoutParams(-1, -2));
        return body;
    }

    void addPresetButton(LinearLayout row, String title, String sub, int accentColor, Runnable action) {
        LinearLayout btn = new LinearLayout(this);
        btn.setOrientation(LinearLayout.VERTICAL);
        btn.setBackground(cellBg(isDark() ? Color.rgb(24, 36, 56) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        btn.setPadding(dp(8), dp(7), dp(8), dp(7));

        TextView t = textDirect(title, 13, true);
        t.setTextColor(accentColor);
        btn.addView(t);

        TextView s = textDirect(sub, 10, false);
        s.setTextColor(colorSub());
        btn.addView(s);

        btn.setOnClickListener(v -> action.run());

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(btn, lp);
    }

    void applyPreset(int day, String mode, double normal, double ot, double holiday, double holidayOt) {
        applyPreset(day, mode, normal, ot, holiday, holidayOt, 0);
    }

    // 🌗 반차: 4시간 근무 + 4시간 유급 연차 (mode=half_am 은 급여 코어가 4h 근무 + 4h 연차로 읽는다)
    void applyHalfDay(int day) {
        applyPreset(day, "half_am", 4, 0, 0, 0, 0, 4);
    }

    void applyPreset(int day, String mode, double normal, double ot, double holiday, double holidayOt, double night) {
        applyPreset(day, mode, normal, ot, holiday, holidayOt, night, 0);
    }

    void applyPreset(int day, String mode, double normal, double ot, double holiday, double holidayOt, double night, double paid) {
        vibrateTick();
        SharedPreferences.Editor ed = prefs.edit();
        ed.putString(dayKey(day, "mode"), mode);
        if (normal > 0) ed.putString(dayKey(day, keys[0]), Double.toString(normal));
        else ed.remove(dayKey(day, keys[0]));

        if (ot > 0) ed.putString(dayKey(day, keys[4]), Double.toString(ot));
        else ed.remove(dayKey(day, keys[4]));

        if (holiday > 0) ed.putString(dayKey(day, keys[5]), Double.toString(holiday));
        else ed.remove(dayKey(day, keys[5]));

        if (holidayOt > 0) ed.putString(dayKey(day, keys[6]), Double.toString(holidayOt));
        else ed.remove(dayKey(day, keys[6]));

        if (night > 0) ed.putString(dayKey(day, keys[7]), Double.toString(night));
        else ed.remove(dayKey(day, keys[7]));

        if (paid > 0) ed.putString(dayKey(day, keys[1]), Double.toString(paid));
        else ed.remove(dayKey(day, keys[1]));

        ed.remove(dayKey(day, keys[3]));
        ed.apply();

        triggerAutoBackup();

        Toast.makeText(this, day + "일 근무가 저장되었습니다.", Toast.LENGTH_SHORT).show();
        closeDrawers(this::showMain);
    }

    // 캘린더 렌더링
    void renderCalendar() {
        LinearLayout calParent = calendarBlock != null ? calendarBlock : root;
        int y = month.get(Calendar.YEAR), m = month.get(Calendar.MONTH);
        Map<String, String> holidays = holidayMap(y);

        LinearLayout weekdays = new LinearLayout(this);
        weekdays.setBackground(cellBg(isDark() ? Color.rgb(20, 30, 48) : Color.rgb(238, 243, 250), colorBorder(), dp(1)));
        weekdays.setPadding(0, dp(4), 0, dp(4));

        String[] labels = {"일", "월", "화", "수", "목", "금", "토"};
        for (int i = 0; i < 7; i++) {
            TextView t = textDirect(labels[i], 13, true);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(i == 0 ? colorRed() : i == 6 ? colorBlue() : colorInk());
            weekdays.addView(t, new LinearLayout.LayoutParams(0, dp(28), 1));
        }
        calParent.addView(weekdays);

        int offset = weekdaySundayZero(y, m + 1, 1);
        int last = month.getActualMaximum(Calendar.DAY_OF_MONTH);
        int rows = (offset + last + 6) / 7;

        for (int r = 0; r < rows; r++) {
            LinearLayout row = new LinearLayout(this);
            for (int c = 0; c < 7; c++) {
                int day = r * 7 + c - offset + 1;
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
                cell.setPadding(dp(2), dp(2), dp(2), dp(2));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(86), 1);
                lp.setMargins(dp(1), dp(1), dp(1), dp(1));
                row.addView(cell, lp);

                if (day < 1 || day > last) continue;

                String holiday = holidays.get(iso(y, m + 1, day));
                int color = holiday != null ? colorRed() : c == 0 ? colorRed() : c == 6 ? colorBlue() : colorInk();

                double normal = dayHours(day, 0);
                double ot = dayHours(day, 4);
                double hol = dayHours(day, 5);
                double holOt = dayHours(day, 6);
                double totalWork = normal + ot + hol + holOt;
                String mode = dayMode(day);
                boolean hasManual = prefs.contains(dayKey(day, "mode")) || prefs.contains(dayKey(day, keys[0])) || prefs.contains(dayKey(day, keys[4])) || prefs.contains(dayKey(day, keys[5]));

                if (day == chosenDay) spotCalCell = cell;   // v1.4.0 스팟라이트 2번 대상 (캘린더 날짜 셀)
                if (isMultiSelectMode && selectedDays.contains(day)) {
                    cell.setBackground(cellBg(isDark() ? Color.rgb(65, 20, 26) : Color.rgb(254, 242, 242), Color.rgb(239, 68, 68), dp(2)));
                } else if (day == chosenDay) {
                    cell.setBackground(cellBg(isDark() ? Color.rgb(37, 72, 120) : Color.rgb(212, 231, 250), colorBlue(), dp(2)));
                } else if (hasManual || totalWork > 0) {
                    cell.setBackground(cellBg(isDark() ? Color.rgb(24, 46, 78) : Color.rgb(229, 240, 252), isDark() ? Color.rgb(50, 90, 150) : Color.rgb(164, 198, 234), dp(1)));
                } else if (holiday != null) {
                    cell.setBackground(cellBg(isDark() ? Color.rgb(55, 25, 30) : Color.rgb(254, 234, 234), isDark() ? Color.rgb(130, 45, 55) : Color.rgb(245, 195, 195), dp(1)));
                } else {
                    cell.setBackground(cellBg(isDark() ? (c == 0 || c == 6 ? Color.rgb(20, 27, 40) : Color.rgb(25, 33, 48)) : (c == 0 || c == 6 ? Color.rgb(246, 248, 250) : Color.WHITE), colorBorder(), dp(1)));
                }

                LinearLayout dateHeader = new LinearLayout(this);
                dateHeader.setOrientation(LinearLayout.HORIZONTAL);
                dateHeader.setGravity(Gravity.CENTER_VERTICAL);

                TextView num = textDirect("" + day, 14, true);
                num.setPadding(0, 0, 0, 0);
                num.setTextColor(color);
                dateHeader.addView(num);

                if (isMultiSelectMode && selectedDays.contains(day)) {
                    TextView checkBadge = textDirect("✓", 10, true);
                    checkBadge.setTextColor(Color.WHITE);
                    checkBadge.setBackground(cellBg(Color.rgb(239, 68, 68), Color.rgb(239, 68, 68), dp(1)));
                    checkBadge.setPadding(dp(4), 0, dp(4), 0);
                    LinearLayout.LayoutParams cbLp = new LinearLayout.LayoutParams(-2, -2);
                    cbLp.setMargins(dp(4), 0, 0, 0);
                    dateHeader.addView(checkBadge, cbLp);
                }

                String extraInfo = getLunarOrSolarTerm(y, m + 1, day);
                if (!extraInfo.isEmpty()) {
                    boolean isTerm = isSolarTerm(y, m + 1, day);
                    TextView lun = textDirect(" " + extraInfo, 9, isTerm);
                    lun.setTextColor(isTerm ? (isDark() ? Color.rgb(110, 220, 150) : Color.rgb(18, 130, 65)) : colorSub());
                    lun.setPadding(0, 0, 0, 0);
                    dateHeader.addView(lun);
                }
                cell.addView(dateHeader);

                String workBadge = "";
                int badgeBg = 0;
                int badgeText = 0;

                double nightH = dayHours(day, 7);
                boolean isAnnualDay = mode.equals("annual");
                boolean isSummerDay = mode.equals("summer");
                boolean isHalfDay = mode.equals("half_am") || mode.equals("half_pm");
                if (isAnnualDay || isSummerDay || isHalfDay) {
                    // 연차·하계휴가는 유급 8h가 자동 인정되어 '8h'만 찍히던 결함 → 도장처럼 [연차 8h] 뱃지
                    String leaveLabel = isAnnualDay ? "연차" : (isSummerDay ? "휴가" : "반차");
                    double leaveH = (isHalfDay) ? dayHours(day, 1) : normal;
                    if (leaveH <= 0) leaveH = 8;
                    workBadge = leaveLabel + " " + hoursShort(leaveH) + "h";
                    badgeBg = isDark() ? Color.rgb(6, 78, 59) : Color.rgb(209, 250, 229);
                    badgeText = isDark() ? Color.rgb(167, 243, 208) : Color.rgb(4, 120, 87);
                } else if (hol + holOt > 0) {
                    // 휴일특근 8h + 특근연장분은 '특근 8+2h' 처럼 분리 표기 (소프트 레드 캡슐 칩)
                    String holPart = hoursShort(hol);
                    workBadge = (nightH > 0 ? "🌙특근 " : "특근 ")
                            + (holOt > 0 ? holPart + "+" + hoursShort(holOt) : holPart) + "h";
                    badgeBg = isDark() ? Color.rgb(90, 20, 25) : Color.rgb(254, 226, 226);
                    badgeText = isDark() ? Color.rgb(254, 202, 202) : Color.rgb(185, 28, 28);
                } else if (nightH > 0) {
                    workBadge = "야간 " + hoursShort(normal + ot) + "h";
                    badgeBg = isDark() ? Color.rgb(48, 24, 78) : Color.rgb(243, 232, 255);
                    badgeText = isDark() ? Color.rgb(216, 180, 254) : Color.rgb(126, 34, 206);
                } else if (ot > 0) {
                    workBadge = hoursShort(normal) + "+" + hoursShort(ot) + "h";
                    badgeBg = isDark() ? Color.rgb(24, 46, 85) : Color.rgb(219, 234, 254);
                    badgeText = isDark() ? Color.rgb(191, 219, 254) : Color.rgb(29, 78, 216);
                } else if (normal > 0) {
                    workBadge = hoursShort(normal) + "h";
                    badgeBg = isDark() ? Color.rgb(35, 45, 75) : Color.rgb(238, 242, 255);
                    badgeText = isDark() ? Color.rgb(224, 231, 255) : Color.rgb(67, 56, 202);
                } else if (c != 0 && totalWork <= 0 && nightH <= 0 && !"none".equals(mode) && (c == 6 || holiday != null)) {
                    // 출근카드 OCR 저장이 빈 토·공휴일에 mode="work"를 남겨도 유급 8h 뱃지는 그대로 보인다
                    workBadge = "유급 8h";
                    badgeBg = isDark() ? Color.rgb(30, 41, 59) : Color.rgb(241, 245, 249);
                    badgeText = isDark() ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105);
                } else if (c == 0 && totalWork <= 0 && nightH <= 0 && !"none".equals(mode)) {
                    workBadge = "주차 8h";
                    badgeBg = isDark() ? Color.rgb(60, 20, 25) : Color.rgb(254, 242, 242);
                    badgeText = isDark() ? Color.rgb(254, 202, 202) : Color.rgb(185, 28, 28);
                }

                String dayMemoAll = prefs.getString(dayKey(day, "memo"), "");
                String slimTag = memoTag(dayMemoAll);
                if (!slimTag.isEmpty()) {
                    if (workBadge.isEmpty()) {
                        workBadge = slimTag;
                        boolean early = slimTag.contains("조퇴");
                        badgeBg = isDark() ? (early ? Color.rgb(66, 32, 6) : Color.rgb(8, 47, 73))
                                           : (early ? Color.rgb(255, 247, 237) : Color.rgb(240, 249, 255));
                        badgeText = isDark() ? (early ? Color.rgb(253, 186, 116) : Color.rgb(125, 211, 252))
                                             : (early ? Color.rgb(194, 65, 12) : Color.rgb(3, 105, 161));
                    } else {
                        workBadge = workBadge + " " + slimTag;
                    }
                }

                if (!workBadge.isEmpty()) {
                    TextView wb = textDirect(workBadge, 10, true);
                    wb.setGravity(Gravity.CENTER);
                    wb.setTextColor(badgeText);
                    wb.setBackground(cellBg(badgeBg, badgeBg, dp(1)));
                    wb.setPadding(dp(4), dp(1), dp(4), dp(1));
                    // '특근 8+2h' 처럼 긴 표기도 좁은 칸 폭에 맞춰 7~10sp 사이에서 자동 축소 (잘림 방지)
                    wb.setSingleLine(true);
                    wb.setIncludeFontPadding(false);
                    wb.setAutoSizeTextTypeUniformWithConfiguration(7, 10, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
                    LinearLayout.LayoutParams wbLp = new LinearLayout.LayoutParams(-2, -2);
                    wbLp.gravity = Gravity.CENTER_HORIZONTAL;
                    wbLp.setMargins(0, dp(1), 0, 0);
                    cell.addView(wb, wbLp);
                }

                if (holiday != null) {
                    TextView h = textDirect(holiday, 10, true);
                    h.setGravity(Gravity.CENTER);
                    h.setMaxLines(2);
                    h.setEllipsize(TextUtils.TruncateAt.END);
                    h.setTextColor(colorRed());
                    h.setPadding(0, 0, 0, 0);
                    cell.addView(h);
                }

                String dayMemo = memoTextOnly(dayMemoAll);
                if (!dayMemo.isEmpty()) {
                    TextView mTv = textDirect("✎ " + dayMemo, 9, false);
                    mTv.setGravity(Gravity.CENTER);
                    mTv.setMaxLines(1);
                    mTv.setEllipsize(TextUtils.TruncateAt.END);
                    mTv.setTextColor(isDark() ? Color.rgb(110, 231, 183) : Color.rgb(5, 150, 105));
                    mTv.setPadding(0, 0, 0, 0);
                    cell.addView(mTv);
                }

                Calendar nowCal = Calendar.getInstance();
                boolean isCurrentMonth = (y == nowCal.get(Calendar.YEAR) && m == nowCal.get(Calendar.MONTH));
                if (isCurrentMonth && day == nowCal.get(Calendar.DAY_OF_MONTH)) {
                    // '오늘' 두 글자만으로 조밀하게 — ● 기호와 넓은 여백이 좁은 칸의 글자를 잘라먹던 현상 교정
                    TextView todayTag = textDirect("오늘", 8, true);
                    todayTag.setTextColor(Color.WHITE);
                    todayTag.setSingleLine(true);
                    todayTag.setIncludeFontPadding(false);
                    todayTag.setLetterSpacing(-0.03f);
                    todayTag.setBackground(cellBg(colorBlue(), colorBlue(), dp(1)));
                    todayTag.setPadding(dp(4), dp(1), dp(4), dp(1));
                    LinearLayout.LayoutParams ttLp = new LinearLayout.LayoutParams(-2, -2);
                    ttLp.gravity = Gravity.CENTER_HORIZONTAL;
                    ttLp.setMargins(0, 0, 0, dp(1));
                    cell.addView(todayTag, 0, ttLp);
                }

                final int currentDay = day;
                if (isMultiSelectMode) {
                    cell.setOnClickListener(v -> {
                        vibrateTick();
                        if (selectedDays.contains(currentDay)) {
                            selectedDays.remove(currentDay);
                            if (selectedDays.isEmpty()) {
                                isMultiSelectMode = false;
                            }
                        } else {
                            selectedDays.add(currentDay);
                        }
                        showMain();
                    });
                    cell.setOnLongClickListener(null);
                } else {
                    // v1.4.1 ② — 1회 터치: 파란 선택 테두리만 그 날짜로 이동 (입력창은 열지 않는다)
                    //              같은 날짜를 한 번 더 터치: 비로소 퀵 프리셋 바텀시트가 열린다
                    cell.setOnClickListener(v -> {
                        vibrateTick();
                        if (currentDay != chosenDay) {
                            if (mainScrollView != null) pendingScrollY = mainScrollView.getScrollY();
                            chosenDay = currentDay;
                            showMain();          // 선택 활성화만 이동 — [빠른 근무 입력 (N일)] 문구도 함께 동기화
                        } else {
                            showBottomSheet(currentDay);
                        }
                    });
                    cell.setOnLongClickListener(v -> {
                        vibrateTick();
                        isMultiSelectMode = true;
                        selectedDays.clear();
                        selectedDays.add(currentDay);
                        showMain();
                        return true;
                    });
                }
            }
            calParent.addView(row);
        }
    }


    // 급여명세서 OCR 처리 및 역산 대조 로직
    //  v1.4.3 ④-3: 사진을 그대로 넘기지 않고 흑백 명암비 자동 보정(조명 얼룩 제거) 후 인식한다.
    void recognizePayslip(final Uri uri) {
        Toast.makeText(this, "급여명세서 분석 중... (명암 자동 보정)", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            Bitmap enhanced = null;
            try { enhanced = OcrImageEnhancer.enhance(this, uri); } catch (Throwable ignored) {}
            final Bitmap ready = enhanced;
            runOnUiThread(() -> {
                try {
                    InputImage img = (ready != null) ? InputImage.fromBitmap(ready, 0)
                                                     : InputImage.fromFilePath(this, uri);
                    TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build())
                        .process(img)
                        .addOnSuccessListener(result -> parseAndShowPayslipComparison(result))
                        .addOnFailureListener(e -> new AlertDialog.Builder(this)
                            .setTitle("명세서 문자인식 실패")
                            .setMessage(e.getMessage())
                            .setPositiveButton("확인", null).show())
                        .addOnCompleteListener(t -> {
                            try { if (ready != null && !ready.isRecycled()) ready.recycle(); } catch (Throwable ignored) {}
                        });
                } catch (Exception ex) {
                    Toast.makeText(this, "명세서 사진 열기 실패: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    // ═══════════════════════════════════════════════════════════════════
    // v1.4.3 ④-PDF — 급여명세서 원본 PDF 직접 읽기 (디지털 텍스트)
    //   ① PdfTextExtractor 로 PDF 내부 텍스트를 1원 단위까지 그대로 추출
    //   ② 텍스트층이 없거나(스캔 PDF) 라벨을 못 찾으면 → PdfRenderer 로 페이지를
    //      고해상도로 그려 ML Kit OCR (조명·기울기 변수가 없는 깨끗한 렌더링)
    // ═══════════════════════════════════════════════════════════════════
    void openPayslipPdfPicker() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            // 일부 파일탐색기는 PDF 를 octet-stream 으로 넘기므로 함께 허용하고, 선택 후 %PDF 서명을 검사한다
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "application/octet-stream"});
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, PAYSLIP_PDF);
        } catch (Exception ex) {
            Toast.makeText(this, "파일 선택기를 열 수 없습니다: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void handlePayslipPdf(final Uri uri) {
        Toast.makeText(this, "명세서 PDF 분석 중...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            byte[] bytes = null;
            try {
                bytes = readUriBytes(uri, 40 * 1024 * 1024);
            } catch (Throwable ignored) {}
            boolean isPdf = bytes != null && bytes.length > 8
                    && bytes[0] == '%' && bytes[1] == 'P' && bytes[2] == 'D' && bytes[3] == 'F';
            if (!isPdf) {
                runOnUiThread(() -> new AlertDialog.Builder(this)
                        .setTitle("PDF 파일이 아닙니다")
                        .setMessage("선택한 파일에서 PDF 서명(%PDF)을 찾지 못했습니다.\n다운로드 폴더의 급여명세서 PDF 를 다시 선택해 주세요.")
                        .setPositiveButton("확인", null).show());
                return;
            }
            PdfTextExtractor.Out out = null;
            try { out = PdfTextExtractor.extract(bytes); } catch (Throwable ignored) {}

            PayslipParser.Result pr = null;
            if (out != null && out.hasTextLayer) {
                pr = PayslipParser.parse(out.toks, out.fullText);
            }
            boolean usable = pr != null && (pr.basePay > 0 || pr.totalPay > 0 || pr.netPay > 0);
            if (usable) {
                final PdfTextExtractor.Out fout = out;
                runOnUiThread(() -> {
                    payslipSourceLabel = "PDF 원본";
                    parseAndShowPayslipText(fout.toks, fout.fullText);
                });
                return;
            }
            // 디지털 텍스트를 못 얻었거나(스캔 PDF·암호화) 라벨을 못 찾으면 고해상도 렌더 + OCR 로 넘어간다
            runOnUiThread(() -> {
                Toast.makeText(this, "텍스트층이 없어 고해상도로 다시 읽습니다...", Toast.LENGTH_SHORT).show();
                renderPdfThenOcr(uri);
            });
        }).start();
    }

    byte[] readUriBytes(Uri uri, int maxBytes) throws IOException {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new IOException("파일을 열 수 없습니다");
        try {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n, total = 0;
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > maxBytes) break;
                bos.write(buf, 0, n);
            }
            return bos.toByteArray();
        } finally {
            try { in.close(); } catch (Throwable ignored) {}
        }
    }

    /** PDF 페이지를 고해상도 비트맵으로 그려 ML Kit 으로 읽는다 (스캔 PDF·암호화 PDF 대비) */
    void renderPdfThenOcr(final Uri uri) {
        new Thread(() -> {
            File tmp = new File(getCacheDir(), "payslip_render.pdf");
            ParcelFileDescriptor pfd = null;
            PdfRenderer renderer = null;
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream os = new java.io.FileOutputStream(tmp)) {
                if (in == null) throw new IOException("파일을 열 수 없습니다");
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) os.write(buf, 0, n);
            } catch (Exception ex) {
                runOnUiThread(() -> new AlertDialog.Builder(this)
                        .setTitle("PDF 열기 실패").setMessage(String.valueOf(ex.getMessage()))
                        .setPositiveButton("확인", null).show());
                return;
            }

            final List<PayslipParser.Tok> toks = new ArrayList<>();
            final StringBuilder full = new StringBuilder();
            final int[] pageDone = {0};
            final int[] pagesTotal = {0};
            try {
                pfd = ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(pfd);
                pagesTotal[0] = Math.min(renderer.getPageCount(), 3);
            } catch (Throwable ex) {
                final String msg = String.valueOf(ex.getMessage());
                runOnUiThread(() -> new AlertDialog.Builder(this)
                        .setTitle("PDF를 열 수 없습니다")
                        .setMessage("이 PDF는 비밀번호가 걸려 있거나 지원하지 않는 형식입니다.\n" + msg)
                        .setPositiveButton("확인", null).show());
                try { if (renderer != null) renderer.close(); } catch (Throwable ignored) {}
                try { if (pfd != null) pfd.close(); } catch (Throwable ignored) {}
                return;
            }

            final PdfRenderer fRenderer = renderer;
            final ParcelFileDescriptor fPfd = pfd;
            Runnable[] next = new Runnable[1];
            next[0] = () -> {
                int pageNo = pageDone[0];
                if (pageNo >= pagesTotal[0]) {
                    try { fRenderer.close(); } catch (Throwable ignored) {}
                    try { fPfd.close(); } catch (Throwable ignored) {}
                    runOnUiThread(() -> {
                        if (full.length() < 20) {
                            new AlertDialog.Builder(this)
                                    .setTitle("명세서를 읽지 못했습니다")
                                    .setMessage("PDF에서 글자를 찾지 못했습니다. 화면 캡처나 사진으로 [급여명세서 카메라 촬영]을 이용해 주세요.")
                                    .setPositiveButton("확인", null).show();
                            return;
                        }
                        payslipSourceLabel = "PDF 원본";
                        parseAndShowPayslipText(toks, full.toString());
                    });
                    return;
                }
                Bitmap bmp = null;
                try {
                    PdfRenderer.Page page = fRenderer.openPage(pageNo);
                    // 긴 변 2400px 정도로 렌더 — 작은 숫자·표 선이 살아나는 해상도
                    int pw = page.getWidth(), ph = page.getHeight();
                    float scale = Math.min(3.0f, 2400f / Math.max(1, Math.max(pw, ph)));
                    if (scale < 1.0f) scale = 1.0f;
                    bmp = Bitmap.createBitmap((int) (pw * scale), (int) (ph * scale), Bitmap.Config.ARGB_8888);
                    bmp.eraseColor(Color.WHITE);
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    page.close();
                } catch (Throwable ex) {
                    pageDone[0]++;
                    next[0].run();
                    return;
                }
                final Bitmap pageBmp = bmp;
                final int pageIndex = pageNo;
                TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build())
                        .process(InputImage.fromBitmap(pageBmp, 0))
                        .addOnSuccessListener(result -> {
                            int yOffset = pageIndex * 100000;
                            for (com.google.mlkit.vision.text.Text.TextBlock block : result.getTextBlocks()) {
                                for (com.google.mlkit.vision.text.Text.Line line : block.getLines()) {
                                    Rect lb = line.getBoundingBox();
                                    if (lb != null) toks.add(new PayslipParser.Tok(line.getText(), lb.left, lb.top + yOffset, lb.right, lb.bottom + yOffset, true));
                                    for (com.google.mlkit.vision.text.Text.Element el : line.getElements()) {
                                        Rect eb = el.getBoundingBox();
                                        if (eb != null) toks.add(new PayslipParser.Tok(el.getText(), eb.left, eb.top + yOffset, eb.right, eb.bottom + yOffset, false));
                                    }
                                }
                            }
                            full.append(result.getText()).append('\n');
                            pageDone[0]++;
                            next[0].run();
                        })
                        .addOnFailureListener(e -> { pageDone[0]++; next[0].run(); })
                        .addOnCompleteListener(t -> {
                            try { if (pageBmp != null && !pageBmp.isRecycled()) pageBmp.recycle(); } catch (Throwable ignored) {}
                        });
            };
            runOnUiThread(() -> next[0].run());
        }).start();
    }

    float extractFloat(String text, String... patterns) {
        for (String pat : patterns) {
            Pattern p = Pattern.compile(pat);
            Matcher m = p.matcher(text);
            if (m.find()) {
                try {
                    String numStr = m.group(1).replace(",", "").trim();
                    return Float.parseFloat(numStr);
                } catch (Exception ignored) {}
            }
        }
        return 0f;
    }

    long extractMoney(String text, String... patterns) {
        for (String pat : patterns) {
            Pattern p = Pattern.compile(pat);
            Matcher m = p.matcher(text);
            if (m.find()) {
                try {
                    String numStr = m.group(1).replace(",", "").trim();
                    return Long.parseLong(numStr);
                } catch (Exception ignored) {}
            }
        }
        return 0;
    }

    LinearLayout buildCompareRow(String col1, String col2, String col3, String col4, boolean isHeader, int textColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(4), 0, dp(4));

        TextView t1 = textDirect(col1, isHeader ? 12 : 13, isHeader);
        t1.setTextColor(isHeader ? colorSub() : textColor);
        row.addView(t1, new LinearLayout.LayoutParams(0, -2, 1.2f));

        TextView t2 = textDirect(col2, isHeader ? 12 : 13, isHeader);
        t2.setTextColor(isHeader ? colorSub() : colorInk());
        t2.setGravity(Gravity.RIGHT);
        row.addView(t2, new LinearLayout.LayoutParams(0, -2, 1.2f));

        TextView t3 = textDirect(col3, isHeader ? 12 : 13, isHeader);
        t3.setTextColor(isHeader ? colorSub() : colorInk());
        t3.setGravity(Gravity.RIGHT);
        row.addView(t3, new LinearLayout.LayoutParams(0, -2, 1.2f));

        TextView t4 = textDirect(col4, isHeader ? 12 : 13, isHeader);
        t4.setTextColor(isHeader ? colorSub() : textColor);
        t4.setGravity(Gravity.RIGHT);
        row.addView(t4, new LinearLayout.LayoutParams(0, -2, 1.2f));

        return row;
    }

    int extractPayslipYear(String text) {
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(20[2-3][0-9])[\\s년.-]+(?:0?[1-9]|1[0-2])[\\s월.-]+(?:급여|명세서|임금|지급)").matcher(text);
            if (m.find()) return Integer.parseInt(m.group(1));
            m = java.util.regex.Pattern.compile("(?:귀속연월|지급연월|급여연월|지급일자|귀속년월)[\\s\\n:]*(20[2-3][0-9])").matcher(text);
            if (m.find()) return Integer.parseInt(m.group(1));
        } catch (Exception ignored) {}
        return Calendar.getInstance().get(Calendar.YEAR);
    }

    void parseAndShowPayslipComparison(com.google.mlkit.vision.text.Text ocrResult) {

        String fullText = ocrResult.getText();

        // ML Kit 요소(칸) 단위 좌표 토큰 수집 — 표의 칸이 칸마다 별개 줄로 떨어져도 라벨과 금액을 2차원으로 잇는다
        List<PayslipParser.Tok> toks = new ArrayList<>();
        for (com.google.mlkit.vision.text.Text.TextBlock block : ocrResult.getTextBlocks()) {
            for (com.google.mlkit.vision.text.Text.Line line : block.getLines()) {
                Rect lb = line.getBoundingBox();
                if (lb != null) toks.add(new PayslipParser.Tok(line.getText(), lb.left, lb.top, lb.right, lb.bottom, true));
                for (com.google.mlkit.vision.text.Text.Element el : line.getElements()) {
                    Rect eb = el.getBoundingBox();
                    if (eb != null) toks.add(new PayslipParser.Tok(el.getText(), eb.left, eb.top, eb.right, eb.bottom, false));
                }
            }
        }
        PayslipParser.Result pr = PayslipParser.parse(toks, fullText);


        // 명세서 귀속 연월 자동 동기화: 대조 연월을 명세서 기준월로 옮긴 뒤 amounts() 로 대조한다
        boolean monthSynced = false;
        if (pr.monthDetected()) {
            int cy = month.get(Calendar.YEAR), cm = month.get(Calendar.MONTH) + 1;
            if (cy != pr.year || cm != pr.month) {
                month.set(Calendar.YEAR, pr.year);
                month.set(Calendar.MONTH, pr.month - 1);
                month.set(Calendar.DAY_OF_MONTH, 1);
                chosenDay = 1;
                monthSynced = true;
            }
        }
        showPayslipReview(fullText, pr, monthSynced);   // v1.4.3 ④: 덮어쓰기 전 검토·수정
    }

    /**
     * v1.4.3 ④ — 좌표 토큰과 평문으로 명세서 검토창을 연다.
     * 사진 OCR(ML Kit)과 PDF 원본(디지털 텍스트) 이 같은 경로를 쓴다.
     */
    void parseAndShowPayslipText(List<PayslipParser.Tok> toks, String fullText) {
        PayslipParser.Result pr = PayslipParser.parse(toks, fullText);
        boolean monthSynced = false;
        if (pr.monthDetected()) {
            int cy = month.get(Calendar.YEAR), cm = month.get(Calendar.MONTH) + 1;
            if (cy != pr.year || cm != pr.month) {
                month.set(Calendar.YEAR, pr.year);
                month.set(Calendar.MONTH, pr.month - 1);
                month.set(Calendar.DAY_OF_MONTH, 1);
                chosenDay = 1;
                monthSynced = true;
            }
        }
        showPayslipReview(fullText, pr, monthSynced);
    }

    // ════════════════════════════════════════════════════════════════
    // v1.4.3 ④-1·② — 명세서 인식 결과 검토·수정 모달
    //   촬영 직후 바로 덮어쓰지 않고, 인식된 기본급·시간외·야간·직무·공제 수치를 표로 보여 준 뒤
    //   터치해서 고치게 한다. 단협 공식과 어긋나는 값에는 원터치 보정 칩을 띄운다.
    // ════════════════════════════════════════════════════════════════
    void showPayslipReview(final String fullText,
                           final PayslipParser.Result pr,
                           final boolean monthSynced) {
        final Dialog d = new Dialog(this);
        try { d.requestWindowFeature(Window.FEATURE_NO_TITLE); } catch (Exception ignored) {}

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackgroundColor(colorSurface());
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(16), dp(18), dp(16));
        sv.addView(col);

        TextView title = textDirect("🧾 명세서 인식 결과 검토 및 수정", 18, true);
        title.setTextColor(colorBlue());
        col.addView(title);

        TextView sub = textDirect(payslipSourceLabel + "에서 읽은 값입니다. 숫자를 터치하면 바로 고칠 수 있어요.\n"
                + "이상치가 감지된 항목은 아래 보정 칩으로 한 번에 되살릴 수 있습니다.", 12, false);
        sub.setTextColor(colorSub());
        sub.setLineSpacing(dp(2), 1.05f);
        sub.setPadding(0, dp(4), 0, dp(10));
        col.addView(sub);

        double[] a = amounts();
        final String[] labels = {"기본급", "평일연장(시간외)", "휴일근무", "휴일연장", "야간근무", "직무수당", "교대수당", "지급총액", "공제총액", "실지급액"};
        final long[] values = {pr.basePay, pr.otPay, pr.holidayPay, pr.holidayOtPay, pr.nightPay, pr.dutyPay, pr.shiftPay,
                pr.totalPay, pr.deduction, pr.netPay};
        final long[] expected = {Math.round(a[0]), Math.round(a[1]), Math.round(a[2]), Math.round(a[3]),
                Math.round(a[4]), Math.round(get("duty")), isShiftWorker() ? 200000L : 0L,
                Math.round(a[6]), Math.round(a[7]), Math.round(a[8])};
        final boolean[] allowOutlier = {true, true, true, true, true, true, true, false, true, false};
        final EditText[] ets = new EditText[labels.length];

        LinearLayout table = new LinearLayout(this);
        table.setOrientation(LinearLayout.VERTICAL);
        table.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        table.setPadding(dp(12), dp(6), dp(12), dp(10));
        col.addView(table, new LinearLayout.LayoutParams(-1, -2));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(5), 0, dp(5));

            TextView lb = textDirect(labels[i], 13, !labels[i].contains("연장"));
            lb.setTextColor(colorInk());
            row.addView(lb, new LinearLayout.LayoutParams(0, -2, 1f));

            final EditText et = new EditText(this);
            et.setText(values[i] > 0 ? String.valueOf(values[i]) : "");
            et.setHint("미인식");
            et.setHintTextColor(colorSub());
            et.setTextColor(values[i] > 0 ? colorInk() : colorRed());
            et.setTextSize(15);
            et.setGravity(Gravity.END);
            et.setSingleLine(true);
            et.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            et.setBackground(cellBg(isDark() ? Color.rgb(24, 33, 47) : Color.rgb(247, 250, 253), colorBorder(), dp(8)));
            et.setPadding(dp(8), dp(8), dp(8), dp(8));
            row.addView(et, new LinearLayout.LayoutParams(dp(132), -2));
            ets[i] = et;
            table.addView(row);

            // 기대값 안내 + 원터치 보정 칩
            long sug = PayslipReviewCore.suggest(values[i], expected[i], allowOutlier[i]);
            String hint = expected[i] > 0 ? "앱 산출 " + won(expected[i]) : "";
            if (sug > 0) {
                if (!hint.isEmpty()) hint += " · ";
                hint += PayslipReviewCore.reason(values[i], expected[i]);
                TextView h = textDirect(hint, 11, false);
                h.setTextColor(colorSub());
                h.setPadding(dp(2), 0, 0, dp(3));
                table.addView(h);
                final long suggest = sug;
                String chipText = (idx == 4 ? "🌙 사내 단협 공식 " : "⚡ 앱 산출값 ") + won(suggest) + "원으로 보정";
                Button chip = button(chipText, () -> {
                    vibrateTick();
                    et.setText(String.valueOf(suggest));
                    Toast.makeText(this, labels[idx] + " " + won(suggest) + "원으로 보정했습니다.", Toast.LENGTH_SHORT).show();
                });
                chip.setTextSize(12);
                chip.setTextColor(colorBlue());
                chip.setBackground(cellBg(isDark() ? Color.rgb(28, 42, 68) : Color.rgb(235, 244, 255), colorBlue(), dp(1)));
                chip.setPadding(dp(10), dp(6), dp(10), dp(6));
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
                clp.setMargins(0, 0, 0, dp(4));
                table.addView(chip, clp);
            } else if (!hint.isEmpty()) {
                TextView h = textDirect(hint, 11, false);
                h.setTextColor(colorSub());
                h.setPadding(dp(2), 0, 0, dp(4));
                table.addView(h);
            }
        }

        TextView tip = textDirect("• 0으로 비어 있는 칸은 인식하지 못한 항목입니다. 명세서를 보며 직접 채워 주세요.\n"
                + "• 금액을 고치면 이어지는 1:1 대조와 설정 동기화에 그 값이 그대로 쓰입니다.", 11, false);
        tip.setTextColor(colorSub());
        tip.setLineSpacing(dp(2), 1.05f);
        tip.setPadding(0, dp(10), 0, dp(6));
        col.addView(tip);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView again = textDirect("↩ 다시 촬영", 13, true);
        again.setTextColor(colorSub());
        again.setPadding(dp(4), dp(12), dp(14), dp(12));
        again.setOnClickListener(v -> { vibrateTick(); d.dismiss(); });
        btnRow.addView(again);

        btnRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));

        Button go = button("이 값으로 대조하기 ➜", () -> {
            vibrateTick();
            pr.basePay = parseIntSafe(ets[0].getText().toString(), 0);
            pr.otPay = parseIntSafe(ets[1].getText().toString(), 0);
            pr.holidayPay = parseIntSafe(ets[2].getText().toString(), 0);
            pr.holidayOtPay = parseIntSafe(ets[3].getText().toString(), 0);
            pr.nightPay = parseIntSafe(ets[4].getText().toString(), 0);
            pr.dutyPay = parseIntSafe(ets[5].getText().toString(), 0);
            pr.shiftPay = parseIntSafe(ets[6].getText().toString(), 0);
            pr.totalPay = parseIntSafe(ets[7].getText().toString(), 0);
            pr.deduction = parseIntSafe(ets[8].getText().toString(), 0);
            pr.netPay = parseIntSafe(ets[9].getText().toString(), 0);
            d.dismiss();
            continuePayslipComparison(fullText, pr, monthSynced);
        });
        styleWizardPrimary(go);
        go.setTextSize(14);
        btnRow.addView(go, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout.LayoutParams brLp = new LinearLayout.LayoutParams(-1, -2);
        brLp.setMargins(0, dp(10), 0, 0);
        col.addView(btnRow, brLp);

        d.setContentView(sv);
        try {
            if (d.getWindow() != null) {
                d.getWindow().setBackgroundDrawable(cellBg(colorSurface(), colorBorder(), dp(22)));
                int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.94);
                d.getWindow().setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
        } catch (Exception ignored) {}
        d.setCanceledOnTouchOutside(false);
        d.show();
    }

    /** 검토·수정된 인식값으로 1:1 대조·역산 화면을 그린다. */
    void continuePayslipComparison(String fullText,
                                   PayslipParser.Result pr, boolean monthSynced) {
        int payslipYear = pr.monthDetected() ? pr.year : extractPayslipYear(fullText);
        long ocrTotalPay = pr.totalPay;
        long ocrDeduction = pr.deduction;
        long ocrNetPay = pr.netPay;

        long ocrBasePay = pr.basePay;
        long ocrOtPay = pr.otPay;
        long ocrHolidayPay = pr.holidayPay;
        long ocrHolidayOtPay = pr.holidayOtPay;
        long ocrNightPay = pr.nightPay;
        long ocrPositionPay = pr.positionPay;
        long ocrDutyPay = pr.dutyPay;
        long ocrRetroPay = pr.retroPay;

        long ocrBaseRate = pr.baseRate;
        long ocrOrdinaryRate = pr.ordinaryRate;
        long ocrBreakPay = pr.breakPay;

        // 급여명세서 연차 [발생]·[잔여] 자동 추출 (v1.3.5: 발생연차수 명칭 일치)
        float ocrAnnualTotal = extractFloat(fullText,
            "(?:발생\\s*연차수?|연차\\s*발생)[\\s\\n:]*([0-9.]+)",
            "(?:연차)[\\s\\n]+([0-9.]+)[\\s\\n]+[0-9.]+[\\s\\n]+[0-9.]+",
            "(?:연차)[\\s\\n]+([0-9.]+)[\\s\\n]+[0-9.]+"
        );
        float ocrAnnualRemain = extractFloat(fullText,
            "(?:연차)[\\s\\n]+(?:[0-9.]+[\\s\\n]+){2}([0-9.]+)",
            "(?:연차[\\s\\S]{0,35}?(?:잔여|남은|잔여일수|잔여누계))[\\s\\n:]*([0-9.]+)",
            "(?:잔여\\s*연차|남은\\s*연차)[\\s\\n:]*([0-9.]+)"
        );
// OCR 인식 직후 잔여 연차 조기 저장 제거 (동기화 버튼 터치 시 역산 가산하여 정확히 저장)

        if (ocrNetPay == 0 && ocrTotalPay > 0 && ocrDeduction > 0) {
            ocrNetPay = ocrTotalPay - ocrDeduction;
        }

        double[] a = amounts();
        long appTotalPay = Math.round(a[6]);
        long appDeduction = Math.round(a[7]);
        long appNetPay = Math.round(a[8]);

        start("급여명세서 대조 및 역산");

        // 상단 상태 안내 카드
        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(14), dp(12), dp(14), dp(12));

        long netDiff = ocrNetPay > 0 ? (ocrNetPay - appNetPay) : 0;
        long totalDiff = ocrTotalPay > 0 ? (ocrTotalPay - appTotalPay) : 0;
        long dedDiff = ocrDeduction > 0 ? (ocrDeduction - appDeduction) : 0;
        boolean matched = (ocrNetPay > 0 && netDiff == 0);

        int statusBg = matched ? (isDark() ? Color.rgb(20, 48, 30) : Color.rgb(236, 253, 245))
                               : (isDark() ? Color.rgb(48, 36, 20) : Color.rgb(254, 249, 195));
        int statusBorder = matched ? (isDark() ? Color.rgb(34, 197, 94) : Color.rgb(16, 185, 129))
                                   : (isDark() ? Color.rgb(234, 179, 8) : Color.rgb(245, 158, 11));
        statusCard.setBackground(cellBg(statusBg, statusBorder, dp(1)));

        TextView statusTitle = textDirect(matched ? "✨ 출근카드(앱 계산값)와 명세서가 100% 일치합니다!" : "💡 급여명세서 인식 완료 (차액 및 역산 분석)", 16, true);
        statusTitle.setTextColor(matched ? (isDark() ? Color.rgb(74, 222, 128) : Color.rgb(21, 128, 61))
                                         : (isDark() ? Color.rgb(250, 204, 21) : Color.rgb(161, 98, 7)));
        statusCard.addView(statusTitle);

        StringBuilder descSb = new StringBuilder();
        if (matched) {
            descSb.append("입력된 출근카드 근무시간과 회사 명세서의 실지급액이 1원 단위까지 완벽하게 일치합니다.");
        } else if (ocrNetPay > 0) {
            descSb.append("실지급액 차이: ").append(signedWon(netDiff));
            if (ocrRetroPay > 0) descSb.append(" (소급분 ").append(won(ocrRetroPay)).append(" 포함)");
        } else {
            descSb.append("명세서 금액을 읽지 못했습니다. 금액이 선명하게 나온 사진으로 다시 시도해 주세요.");
        }
        // 대조 연월: 명세서 귀속 연월로 자동 동기화한 결과를 숨김없이 표시
        descSb.append("\n• 대조 연월: ").append(String.format(Locale.US, "%04d년 %02d월",
                month.get(Calendar.YEAR), month.get(Calendar.MONTH) + 1));
        if (monthSynced) {
            descSb.append(" (명세서 귀속 연월로 자동 이동)");
        } else if (pr.monthDetected()) {
            descSb.append(" (명세서 귀속 연월과 동일)");
        }
        if (ocrTotalPay > 0) descSb.append("\n• 지급총액 차이: ").append(signedWon(totalDiff));
        if (ocrDeduction > 0) descSb.append(" · 공제총액 차이: ").append(signedWon(dedDiff));
        if (pr.totalFromSum || pr.deductionFromSum) {
            descSb.append("\n• 상단 요약표 인식이 어려워 세부 항목 합계로 ")
                  .append(pr.totalFromSum && pr.deductionFromSum ? "지급·공제총액" : (pr.totalFromSum ? "지급총액" : "공제총액"))
                  .append("을 자동 복원했습니다.");
        }
        TextView statusDesc = textDirect(descSb.toString(), 13, false);
        statusDesc.setTextColor(colorInk());
        statusDesc.setPadding(0, dp(4), 0, 0);
        statusCard.addView(statusDesc);

        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.setMargins(0, 0, 0, dp(12));
        root.addView(statusCard, statusLp);

        // 1. 3대 핵심 금액 1:1 대조 카드
        LinearLayout summaryCard = new LinearLayout(this);
        summaryCard.setOrientation(LinearLayout.VERTICAL);
        summaryCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        summaryCard.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView summaryTitle = textDirect("📊 3대 핵심 금액 1:1 대조", 15, true);
        summaryTitle.setTextColor(colorBlue());
        summaryCard.addView(summaryTitle);

        summaryCard.addView(buildCompareRow("구분", "앱 계산값", "실제 명세서", "차액", true, colorSub()));
        summaryCard.addView(buildCompareRow("지급총액", won(appTotalPay), won(ocrTotalPay), won(ocrTotalPay - appTotalPay), false, colorInk()));
        summaryCard.addView(buildCompareRow("공제총액", won(appDeduction), won(ocrDeduction), won(ocrDeduction - appDeduction), false, colorRed()));
        summaryCard.addView(buildCompareRow("실지급액", won(appNetPay), won(ocrNetPay), won(ocrNetPay - appNetPay), true, colorBlue()));

        LinearLayout.LayoutParams sumLp = new LinearLayout.LayoutParams(-1, -2);
        sumLp.setMargins(0, 0, 0, dp(12));
        root.addView(summaryCard, sumLp);

        // 2. 세부 수당별 대조표 카드
        LinearLayout detailCard = new LinearLayout(this);
        detailCard.setOrientation(LinearLayout.VERTICAL);
        detailCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        detailCard.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView detailTitle = textDirect("📝 세부 수당별 1:1 대조표", 15, true);
        detailTitle.setTextColor(colorBlue());
        detailCard.addView(detailTitle);

        detailCard.addView(buildCompareRow("항목", "앱 계산", "명세서", "차액", true, colorSub()));
        if (ocrBasePay > 0) detailCard.addView(buildCompareRow("기본급", won(Math.round(a[0])), won(ocrBasePay), won(ocrBasePay - Math.round(a[0])), false, colorInk()));
        if (ocrOtPay > 0) detailCard.addView(buildCompareRow("평일연장", won(Math.round(a[1])), won(ocrOtPay), won(ocrOtPay - Math.round(a[1])), false, colorInk()));
        if (ocrHolidayPay > 0) detailCard.addView(buildCompareRow("휴일근무", won(Math.round(a[2])), won(ocrHolidayPay), won(ocrHolidayPay - Math.round(a[2])), false, colorInk()));
        if (ocrHolidayOtPay > 0) detailCard.addView(buildCompareRow("휴일연장", won(Math.round(a[3])), won(ocrHolidayOtPay), won(ocrHolidayOtPay - Math.round(a[3])), false, colorInk()));
        if (ocrNightPay > 0) detailCard.addView(buildCompareRow("야간근무", won(Math.round(a[4])), won(ocrNightPay), won(ocrNightPay - Math.round(a[4])), false, colorInk()));
        if (ocrBreakPay > 0) {
            double[] tt = totals();
            long appDays = Math.round((tt[8] > 0) ? tt[8] : countWorkDays());
            long appBreak = Math.round(appDays * get("base"));
            // 명세서 상주휴게수당 ÷ 기본시급 = 명세서 지급일수 (10월 22일, 앱은 31일 특근분 포함 23일)
            long ocrDays = ocrBaseRate > 0 ? Math.round(ocrBreakPay / (double) ocrBaseRate) : 0;
            detailCard.addView(buildCompareRow("상주휴게수당",
                    won(appBreak) + " (" + appDays + "일)",
                    won(ocrBreakPay) + (ocrDays > 0 ? " (" + ocrDays + "일)" : ""),
                    won(ocrBreakPay - appBreak), false, colorInk()));
        }
        if (ocrDutyPay > 0) {
            long appDuty = Math.round(get("duty"));
            detailCard.addView(buildCompareRow("직무수당", won(appDuty), won(ocrDutyPay), won(ocrDutyPay - appDuty), false, colorInk()));
        }
        if (ocrRetroPay > 0) detailCard.addView(buildCompareRow("소급분", "0원", won(ocrRetroPay), "+" + won(ocrRetroPay), false, colorBlue()));

        LinearLayout.LayoutParams detLp = new LinearLayout.LayoutParams(-1, -2);
        detLp.setMargins(0, 0, 0, dp(12));
        root.addView(detailCard, detLp);

        // 3. 역산 및 설정 자동 동기화 카드
        LinearLayout syncCard = new LinearLayout(this);
        syncCard.setOrientation(LinearLayout.VERTICAL);
        syncCard.setBackground(cellBg(isDark() ? Color.rgb(20, 30, 48) : Color.rgb(240, 246, 255), colorBlue(), dp(1)));
        syncCard.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView syncTitle = textDirect("⚡ 명세서 기준 설정값 자동 동기화", 15, true);
        syncTitle.setTextColor(colorBlue());
        syncCard.addView(syncTitle);

        StringBuilder sbInfo = new StringBuilder();
        if (ocrBaseRate > 0) sbInfo.append("• 기본시급: ").append(won(ocrBaseRate)).append("\n");
        if (ocrOrdinaryRate > 0) sbInfo.append("• 통상시급: ").append(won(ocrOrdinaryRate)).append("\n");
        if (ocrPositionPay > 0) sbInfo.append("• 직책수당: ").append(won(ocrPositionPay)).append("\n");
        if (ocrDutyPay > 0) sbInfo.append("• 직무수당: ").append(won(ocrDutyPay)).append("\n");
        if (ocrDeduction > 0) sbInfo.append("• 실제 공제액: ").append(won(ocrDeduction)).append("\n");
        if (pr.incomeTax > 0 || pr.healthIns > 0 || pr.pension > 0 || pr.unionFee > 0) {
            sbInfo.append("   └ 소득세 ").append(won(pr.incomeTax)).append(" · 지방소득세 ").append(won(pr.residentTax))
                  .append(" · 건강보험 ").append(won(pr.healthIns)).append(" · 국민연금 ").append(won(pr.pension))
                  .append(" · 고용보험 ").append(won(pr.employIns)).append(" · 노조회비 ").append(won(pr.unionFee)).append("\n");
        }
        if (ocrAnnualTotal > 0) sbInfo.append("• 명세서 발생연차수: ").append(ocrAnnualTotal).append("일 (자동 연동)\n");
        if (ocrAnnualRemain > 0) sbInfo.append("• 명세서 잔여 연차: ").append(ocrAnnualRemain).append("일 (자동 연동)\n");
        if (sbInfo.length() == 0) sbInfo.append("명세서에서 시급 및 수당 정보가 감지되었습니다.");

        TextView syncDesc = textDirect(sbInfo.toString().trim(), 13, false);
        syncDesc.setTextColor(colorInk());
        syncDesc.setPadding(0, dp(6), 0, dp(10));
        syncCard.addView(syncDesc);

        Button applyBtn = button("⚡ 위 시급·공제액을 앱 설정에 즉시 동기화", () -> {
            vibrateTick();
            SharedPreferences.Editor ed = prefs.edit();
            // 기본 키 + 연도별 키(setting_YYYY_xxx)를 항상 함께 저장하여 get(k)의 연도 우선 조회와 일치시킨다
            int ocrYear = month.get(Calendar.YEAR);
            if (ocrBaseRate > 0) {
                ed.putString("setting_base", String.valueOf(ocrBaseRate));
                ed.putString("setting_" + ocrYear + "_base", String.valueOf(ocrBaseRate));
            }
            if (ocrOrdinaryRate > 0) {
                ed.putString("setting_ordinary", String.valueOf(ocrOrdinaryRate));
                ed.putString("setting_" + ocrYear + "_ordinary", String.valueOf(ocrOrdinaryRate));
            }
            if (ocrPositionPay > 0) {
                ed.putString("setting_position", String.valueOf(ocrPositionPay));
                ed.putString("setting_" + ocrYear + "_position", String.valueOf(ocrPositionPay));
            }
            if (ocrDutyPay > 0) {
                ed.putString("setting_duty", String.valueOf(ocrDutyPay));
                ed.putString("setting_" + ocrYear + "_duty", String.valueOf(ocrDutyPay));
            }
            if (ocrDeduction > 0) {
                ed.putString("setting_deduction", String.valueOf(ocrDeduction));
                ed.putString("setting_" + ocrYear + "_deduction", String.valueOf(ocrDeduction));
                // v1.3.5: 다음 달 공제액 자동 예측이 실제 원천징수액을 학습하도록 6개 항목을 함께 저장
                ed.putLong("ded_l_total", ocrDeduction);
                ed.putLong("ded_l_gross", ocrTotalPay);
                ed.putLong("ded_l_income", pr.incomeTax);
                ed.putLong("ded_l_local", pr.residentTax);
                ed.putLong("ded_l_health", pr.healthIns);
                ed.putLong("ded_l_pension", pr.pension);
                ed.putLong("ded_l_employ", pr.employIns);
                ed.putLong("ded_l_union", pr.unionFee);
            }
            // 소급분은 일회성 수당이므로 매월 고정되는 setting_other에 영구 가산하지 않음
            if (ocrAnnualTotal > 0) {
                // [발생] 칸을 읽었으면 그 값이 발생연차수 그 자체 — 잔여는 앱이 사용일수를 빼서 자동 표시
                ed.putFloat("user_annual_leave_base", ocrAnnualTotal);
            } else if (ocrAnnualRemain > 0) {
                // [잔여] 칸만 읽었으면 사용 연차를 역산 가산해 발생연차수를 복원 (이중 차감 방지)
                float used = getUsedAnnualLeaveDays(payslipYear);
                ed.putFloat("user_annual_leave_base", ocrAnnualRemain + used);
            }
            ed.apply();
            Toast.makeText(this, "명세서 기준 시급·수당·공제액이 설정에 자동 반영되었습니다!", Toast.LENGTH_SHORT).show();
            showMain();
        });
        applyBtn.setBackground(bg(colorBlue()));
        applyBtn.setTextColor(Color.WHITE);
        applyBtn.setTextSize(14);
        applyBtn.setPadding(dp(12), dp(10), dp(12), dp(10));
        syncCard.addView(applyBtn);

        LinearLayout.LayoutParams syncLp = new LinearLayout.LayoutParams(-1, -2);
        syncLp.setMargins(0, 0, 0, dp(12));
        root.addView(syncCard, syncLp);

        Button closeBtn = button("확인 및 메인 화면으로 돌아가기", this::showMain);
        root.addView(closeBtn);
    }

    void recognize(Uri uri) {
        try {
            InputImage img = InputImage.fromFilePath(this, uri);
            TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build())
                .process(img)
                .addOnSuccessListener(result -> previewOcr(result))
                .addOnFailureListener(e -> new AlertDialog.Builder(this)
                    .setTitle("문자인식 실패")
                    .setMessage(e.getMessage())
                    .setPositiveButton("확인", null).show());
        } catch (Exception ex) {
            Toast.makeText(this, "사진 열기 실패: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    static class OcrToken {
        String text;
        Rect rect;
        OcrToken(String t, Rect r) { text = t; rect = r; }
        int cx() { return (rect.left + rect.right) / 2; }
        int cy() { return (rect.top + rect.bottom) / 2; }
    }

    Double numericToken(String raw) {
        String s = raw.replace(",", ".").replace("O", "0").replace("o", "0").replace("l", "1").replace("I", "1");
        Matcher m = Pattern.compile("(?<![0-9])([0-9]{1,2}(?:\\.[0-9]{1,3})?)(?![0-9])").matcher(s);
        if (!m.find()) return null;
        try {
            double v = Double.parseDouble(m.group(1));
            return (v >= 0 && v <= 365) ? v : null;
        } catch (Exception e) {
            return null;
        }
    }

    Map<Integer, double[]> extractAttendance(com.google.mlkit.vision.text.Text result) {
        Map<Integer, double[]> output = new TreeMap<>();
        List<OcrToken> tokens = new ArrayList<>();
        for (com.google.mlkit.vision.text.Text.TextBlock block : result.getTextBlocks()) {
            for (com.google.mlkit.vision.text.Text.Line line : block.getLines()) {
                for (com.google.mlkit.vision.text.Text.Element element : line.getElements()) {
                    if (element.getBoundingBox() != null) {
                        tokens.add(new OcrToken(element.getText(), new Rect(element.getBoundingBox())));
                    }
                }
            }
        }
        if (tokens.isEmpty()) return output;

        Map<Integer, OcrToken> dayAnchors = new TreeMap<>();
        // 1차: 또렷한 날짜 숫자만 앵커로 수집
        for (OcrToken t : tokens) {
            String clean = t.text.trim();
            if (clean.matches("^[1-9]$|^[1-2][0-9]$|^3[0-1]$")) {
                int d = Integer.parseInt(clean);
                if (!dayAnchors.containsKey(d) || t.cx() < dayAnchors.get(d).cx()) {
                    dayAnchors.put(d, t);
                }
            }
        }

        int maxDay = month.getActualMaximum(Calendar.DAY_OF_MONTH);
        int[] rowY = new int[maxDay + 1];
        int tableLeft = 0;
        double avgRowHeight = dp(24);

        if (dayAnchors.size() >= 3) {
            List<Integer> sortedDays = new ArrayList<>(dayAnchors.keySet());
            int minD = sortedDays.get(0);
            int maxD = sortedDays.get(sortedDays.size() - 1);
            avgRowHeight = (dayAnchors.get(maxD).cy() - dayAnchors.get(minD).cy()) / (double) (maxD - minD);
            if (avgRowHeight <= 0) avgRowHeight = dp(24);
            int sumX = 0;
            for (OcrToken t : dayAnchors.values()) sumX += t.cx();
            tableLeft = sumX / dayAnchors.size();

            // 2차: 월말 29~31일처럼 희미하게 번진 숫자도 앵커로 보강 (날짜 열 근처에 있는 토큰만)
            double dayColTolerance = Math.max(dp(52), avgRowHeight * 1.1);
            for (OcrToken t : tokens) {
                int d = dayAnchorNumber(t.text);
                if (d < 1 || d > maxDay) continue;
                if (dayAnchors.containsKey(d)) continue;
                if (Math.abs(t.cx() - tableLeft) > dayColTolerance) continue;
                double baseY = dayAnchors.get(minD).cy() + (d - minD) * avgRowHeight;
                if (Math.abs(t.cy() - baseY) > avgRowHeight * 1.8) continue;
                dayAnchors.put(d, t);
            }

            // 보강된 앵커 기준으로 행 높이 재산출
            sortedDays = new ArrayList<>(dayAnchors.keySet());
            minD = sortedDays.get(0);
            maxD = sortedDays.get(sortedDays.size() - 1);
            double refined = (dayAnchors.get(maxD).cy() - dayAnchors.get(minD).cy()) / (double) (maxD - minD);
            if (refined > 0) avgRowHeight = refined;
            sumX = 0;
            for (OcrToken t : dayAnchors.values()) sumX += t.cx();
            tableLeft = sumX / dayAnchors.size();

            // 앵커 사이는 선형 보간, 바깥은 평균 행 높이로 외삼 — 하단부로 갈수록 커지는 왜곡까지 따라간다
            for (int d = 1; d <= maxDay; d++) {
                if (dayAnchors.containsKey(d)) {
                    rowY[d] = dayAnchors.get(d).cy();
                    continue;
                }
                int lo = -1, hi = -1;
                for (int k = d - 1; k >= 1; k--) {
                    if (dayAnchors.containsKey(k)) { lo = k; break; }
                }
                for (int k = d + 1; k <= maxDay; k++) {
                    if (dayAnchors.containsKey(k)) { hi = k; break; }
                }
                if (lo > 0 && hi > 0) {
                    double y1 = dayAnchors.get(lo).cy(), y2 = dayAnchors.get(hi).cy();
                    rowY[d] = (int) Math.round(y1 + (y2 - y1) * (d - lo) / (double) (hi - lo));
                } else if (lo > 0) {
                    rowY[d] = (int) Math.round(dayAnchors.get(lo).cy() + (d - lo) * avgRowHeight);
                } else if (hi > 0) {
                    rowY[d] = (int) Math.round(dayAnchors.get(hi).cy() - (hi - d) * avgRowHeight);
                }
            }
        }

        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
        for (OcrToken t : tokens) {
            minX = Math.min(minX, t.rect.left);
            maxX = Math.max(maxX, t.rect.right);
        }
        if (tableLeft > 0) minX = tableLeft;
        int tableWidth = Math.max(dp(260), maxX - minX);

        double[] colRatios = {0.035, 0.105, 0.185, 0.260, 0.335, 0.415, 0.495, 0.575, 0.655, 0.735, 0.820, 0.915};
        double[] centers = new double[12];
        for (int c = 0; c < 12; c++) {
            centers[c] = minX + tableWidth * colRatios[c];
        }

        // 사진이 기울면 하단 행일수록 가로 위치가 밀린다 — 행별 날짜 앵커 x와 날짜 열 중심의 차이를 보정
        double[] rowShift = new double[maxDay + 1];
        if (tableLeft > 0) {
            boolean[] hasShift = new boolean[maxDay + 1];
            for (int d = 1; d <= maxDay; d++) {
                OcrToken a = dayAnchors.get(d);
                if (a != null) {
                    // 평균 날짜 앵커 x 대비 편차 = 그 행이 기울어 밀린 정도 (평균이면 보정값 0)
                    rowShift[d] = a.cx() - tableLeft;
                    hasShift[d] = true;
                }
            }
            for (int d = 1; d <= maxDay; d++) {
                if (hasShift[d]) continue;
                int lo = -1, hi = -1;
                for (int k = d - 1; k >= 1; k--) {
                    if (hasShift[k]) { lo = k; break; }
                }
                for (int k = d + 1; k <= maxDay; k++) {
                    if (hasShift[k]) { hi = k; break; }
                }
                if (lo > 0 && hi > 0) {
                    rowShift[d] = rowShift[lo] + (rowShift[hi] - rowShift[lo]) * (d - lo) / (double) (hi - lo);
                } else if (lo > 0) {
                    rowShift[d] = rowShift[lo];
                } else if (hi > 0) {
                    rowShift[d] = rowShift[hi];
                }
            }
            double maxShift = Math.max(dp(8), tableWidth * 0.05);
            for (int d = 1; d <= maxDay; d++) {
                if (Math.abs(rowShift[d]) > maxShift) rowShift[d] = 0;
            }
        }

        // 기본 허용오차 55%, 28일 이후 하단 행은 40% 완화한 75%까지 받아준다 (종이 말림·그림자 대응)
        double baseTolerance = (dayAnchors.size() >= 3) ? avgRowHeight * 0.55 : dp(16);
        double endTolerance = Math.max(baseTolerance, avgRowHeight * 0.75);

        Map<Integer, double[]> rowValsByDay = new TreeMap<>();
        java.util.Set<Integer> rowsWithValue = new java.util.HashSet<>();
        // 6번 열 [휴일가급]은 근무시간이 아니라 가산 표기값이다. 근무시간 칸(rowVals)에는 절대 넣지 않고,
        // 휴일근로 칸이 흐리게 번져 읽히지 않은 날의 역산 근거로만 쓴다.
        Map<Integer, Double> holidayPremiumByDay = new TreeMap<>();

        // 토큰을 가장 가까운 날짜 행 하나에만 배정 — 허용오차를 넓혀도 윗행·아랫행에 중복 저장되지 않는다
        for (OcrToken t : tokens) {
            int bestDay = -1;
            double bestDist = Double.MAX_VALUE;
            for (int d = 1; d <= maxDay; d++) {
                if (rowY[d] == 0) continue;
                double dist = Math.abs(t.cy() - rowY[d]);
                if (dist < bestDist) {
                    bestDist = dist;
                    bestDay = d;
                }
            }
            if (bestDay < 0) continue;
            double tolerance = (bestDay >= 28) ? endTolerance : baseTolerance;
            if (bestDist > tolerance) continue;

            double[] rowVals = rowValsByDay.get(bestDay);
            if (rowVals == null) {
                // keys[] 9칸 + 마지막 1칸은 출근카드 '연차' 열 전용 (OCR_ANNUAL)
                rowVals = new double[keys.length + 1];
                Arrays.fill(rowVals, Double.NaN);
                rowValsByDay.put(bestDay, rowVals);
            }

            if (t.text.contains("조합") || t.text.contains("설명회")) {
                rowVals[3] = 2.0;
                rowsWithValue.add(bestDay);
                continue;
            }

            Double v = numericToken(t.text);
            if (v == null) continue;

            int bestCol = -1;
            double minDiff = Double.MAX_VALUE;
            double shift = rowShift[bestDay];
            for (int c = 0; c < 12; c++) {
                double diff = Math.abs(t.cx() - (centers[c] + shift));
                if (diff < minDiff) {
                    minDiff = diff;
                    bestCol = c;
                }
            }

            if (bestCol == 1) { rowVals[0] = v; rowsWithValue.add(bestDay); }
            else if (bestCol == 2) { rowVals[4] = v; rowsWithValue.add(bestDay); }
            else if (bestCol == 3) { rowVals[8] = v; rowsWithValue.add(bestDay); }
            else if (bestCol == 4) { rowVals[7] = v; rowsWithValue.add(bestDay); }   // 4번 열 [심야]
            else if (bestCol == 5) {                                                 // 5번 열 [휴일근로]
                // 종이 카드의 휴일근로는 실제 근무시간이다. 8h를 넘는 순간부터는 회사 명세서와 같이
                // 휴일근로 8h(150%) + 휴일연장 초과분(200%)으로 처음부터 자동 분리해 저장한다.
                if (v > PayCore.HOLIDAY_BASE_HOURS) {
                    rowVals[5] = PayCore.HOLIDAY_BASE_HOURS;
                    double prevOt = Double.isNaN(rowVals[6]) ? 0.0 : rowVals[6];
                    rowVals[6] = Math.max(prevOt, v - PayCore.HOLIDAY_BASE_HOURS);
                } else {
                    rowVals[5] = v;
                    if (Double.isNaN(rowVals[6])) rowVals[6] = 0.0;
                }
                rowsWithValue.add(bestDay);
            }
            else if (bestCol == 6) {                                                 // 6번 열 [휴일가급]
                // 가산 표기값(8h 특근 4.00 / 10h 특근 6.00) — 근무시간으로 저장하면 특근연장이 뻥튀기된다.
                holidayPremiumByDay.put(bestDay, v);
                rowsWithValue.add(bestDay);
            }
            else if (bestCol == 7) { rowVals[OCR_ANNUAL] = v; rowsWithValue.add(bestDay); }  // 7번 열 [연차]
            else if (bestCol == 8) { rowVals[1] = v; rowsWithValue.add(bestDay); }
            else if (bestCol == 9) { rowVals[2] = v; rowsWithValue.add(bestDay); }
        }

        // 휴일가급 역산 안전망: 휴일근로 칸이 잘 읽히지 않은 날은 가급값으로 근로시간을 되살린다.
        //   휴일가급 = 휴일근로×0.5 + 휴일연장  →  휴일근로 = 휴일가급 + 4  (8h=4.00, 10h=6.00)
        for (Map.Entry<Integer, Double> e : holidayPremiumByDay.entrySet()) {
            int d = e.getKey();
            double premium = e.getValue() == null ? 0 : e.getValue();
            double[] rv = rowValsByDay.get(d);
            if (rv == null || premium < 4.0) continue;
            if (!Double.isNaN(rv[5]) && rv[5] > 0) continue;
            double hol = premium + 4.0;
            if (hol > PayCore.HOLIDAY_BASE_HOURS) {
                rv[5] = PayCore.HOLIDAY_BASE_HOURS;
                rv[6] = hol - PayCore.HOLIDAY_BASE_HOURS;
            } else {
                rv[5] = hol;
                if (Double.isNaN(rv[6])) rv[6] = 0.0;
            }
            rowsWithValue.add(d);
        }

        for (Map.Entry<Integer, double[]> e : rowValsByDay.entrySet()) {
            int d = e.getKey();
            double[] rowVals = e.getValue();
            if (!rowsWithValue.contains(d)) continue;
            if (!Double.isNaN(rowVals[3]) && rowVals[3] > 0) {
                if (!Double.isNaN(rowVals[4]) && rowVals[4] <= 2.0) {
                    rowVals[4] = 0;
                }
            }
            output.put(d, rowVals);
        }
        return output;
    }

    // 희미하게 번진 날짜 숫자 보정: '29일'→29, '3O'→30, '2g'→29 처럼 인쇄 번짐·꼬리 문자를 정제
    int dayAnchorNumber(String raw) {
        if (raw == null) return -1;
        String s = raw.trim().replace("일", "").replace(" ", "");
        if (s.isEmpty() || s.length() > 4) return -1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') sb.append(c);
            else if (c == 'O' || c == 'o' || c == 'Q') sb.append('0');
            else if (c == 'g' || c == 'q') sb.append('9');
            else if (c == 'l' || c == 'I' || c == '|' || c == 'i') sb.append('1');
            else if (c == 'S' || c == 's') sb.append('5');
            else if (c == 'Z' || c == 'z') sb.append('2');
            else if (c == 'B') sb.append('8');
            else if (c == 'G') sb.append('6');
        }
        if (sb.length() < 1 || sb.length() > 2) return -1;
        try {
            int d = Integer.parseInt(sb.toString());
            return (d >= 1 && d <= 31) ? d : -1;
        } catch (Exception e) {
            return -1;
        }
    }

    void previewOcr(com.google.mlkit.vision.text.Text result) {
        Map<Integer, double[]> parsed = extractAttendance(result);
        start("출근카드 1:1 맞춤 검토표");
        root.addView(text("종이 출근카드와 동일한 열 순서로 인식된 표입니다. 대조 후 [캘린더에 전체 저장]을 누르면 반영됩니다.", 14, false));

        int maxDay = month.getActualMaximum(Calendar.DAY_OF_MONTH);
        root.addView(text("인식된 날짜: " + parsed.size() + "일 / 전체 " + maxDay + "일", 15, true));

        // 월말 평일 누락 감지 뱃지 — 29~31일 왜곡·공백을 저장 전에 미리 잡아준다
        final List<Integer> missingWeekdays = new ArrayList<>();
        int cy = month.get(Calendar.YEAR), cm = month.get(Calendar.MONTH) + 1;
        Map<String, String> holMap = holidayMap(cy);
        for (int day = 1; day <= maxDay; day++) {
            int wd = weekdaySundayZero(cy, cm, day);
            if (wd == 0 || wd == 6) continue;
            if (holMap.containsKey(iso(cy, cm, day))) continue;
            double[] vals = parsed.get(day);
            // 근무 기록이 정말 비어 있는 날만 누락으로 본다 — 조퇴(정취 4h)·야간조(심야만)·연차일을
            // '누락'으로 잘못 잡아 [주간 10h로 채우기]가 덮어쓰는 사고를 막는다.
            boolean hasWork = false;
            if (vals != null) {
                int[] workCols = {0, 4, 5, 7, OCR_ANNUAL};   // 정취·연장·휴일근로·심야·연차
                for (int wc : workCols) {
                    if (!Double.isNaN(vals[wc]) && vals[wc] > 0) { hasWork = true; break; }
                }
            }
            boolean missing = !hasWork;
            if (missing) missingWeekdays.add(day);
        }

        LinearLayout missCard = new LinearLayout(this);
        missCard.setOrientation(LinearLayout.VERTICAL);
        missCard.setPadding(dp(12), dp(9), dp(12), dp(9));
        LinearLayout.LayoutParams missLp = new LinearLayout.LayoutParams(-1, -2);
        missLp.setMargins(0, dp(6), 0, dp(8));
        root.addView(missCard, missLp);

        CheckBox all = new CheckBox(this);
        all.setText("전체 날짜 한 번에 선택 / 해제");
        all.setTextColor(colorInk());
        all.setTextSize(14);
        root.addView(all);

        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setFillViewport(false);
        LinearLayout table = new LinearLayout(this);
        table.setOrientation(LinearLayout.VERTICAL);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setBackgroundColor(isDark() ? Color.rgb(38, 50, 72) : Color.rgb(220, 230, 242));

        String[] colLabels = {"일", "정취", "연장", "가급", "심야", "휴일근로", "휴일연장", "유급", "주차", "연차"};
        int[] colWidths = {dp(50), dp(42), dp(40), dp(38), dp(38), dp(56), dp(56), dp(38), dp(38), dp(40)};
        int[] keyIndices = {-1, 0, 4, 8, 7, 5, 6, 1, 2, -2};   // -2 = 연차(모드 annual)

        for (int c = 0; c < colLabels.length; c++) {
            TextView h = textDirect(colLabels[c], 11, true);
            h.setGravity(Gravity.CENTER);
            h.setSingleLine(true);
            h.setPadding(0, dp(4), 0, dp(4));
            headerRow.addView(h, new LinearLayout.LayoutParams(colWidths[c], dp(36)));
        }
        table.addView(headerRow);

        Map<Integer, EditText[]> editors = new TreeMap<>();
        Map<Integer, CheckBox> checks = new TreeMap<>();

        for (int day = 1; day <= maxDay; day++) {
            double[] vals = parsed.get(day);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            if (day % 2 == 0) row.setBackgroundColor(isDark() ? Color.rgb(22, 30, 44) : Color.rgb(248, 250, 252));

            LinearLayout first = new LinearLayout(this);
            first.setOrientation(LinearLayout.HORIZONTAL);
            first.setGravity(Gravity.CENTER_VERTICAL);
            first.setPadding(dp(1), 0, 0, 0);

            CheckBox check = new CheckBox(this);
            check.setButtonTintList(ColorStateList.valueOf(colorBlue()));
            check.setScaleX(0.75f);
            check.setScaleY(0.75f);
            check.setChecked(vals != null);
            first.addView(check, new LinearLayout.LayoutParams(dp(22), dp(30)));

            String[] dayNames = {"일", "월", "화", "수", "목", "금", "토"};
            int wd = weekdaySundayZero(month.get(Calendar.YEAR), month.get(Calendar.MONTH) + 1, day);
            TextView dateTv = textDirect(day + dayNames[wd], 10, true);
            dateTv.setGravity(Gravity.CENTER);
            dateTv.setPadding(0, 0, 0, 0);
            dateTv.setTextColor(wd == 0 ? colorRed() : wd == 6 ? colorBlue() : colorInk());
            first.addView(dateTv, new LinearLayout.LayoutParams(dp(28), dp(30)));

            row.addView(first, new LinearLayout.LayoutParams(colWidths[0], dp(32)));
            checks.put(day, check);

            EditText[] rowFields = new EditText[keyIndices.length];
            for (int c = 1; c < colLabels.length; c++) {
                int kIdx = keyIndices[c];
                EditText input = new EditText(this);
                input.setSingleLine(true);
                input.setTextSize(11);
                input.setGravity(Gravity.CENTER);
                input.setTextColor(colorInk());
                input.setPadding(0, 0, 0, 0);
                input.setMinHeight(0);
                input.setMinimumHeight(0);
                input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                input.setSelectAllOnFocus(true);
                input.setBackgroundTintList(ColorStateList.valueOf(colorBorder()));

                if (vals != null && !Double.isNaN(vals[kIdx < 0 ? OCR_ANNUAL : kIdx]) && vals[kIdx < 0 ? OCR_ANNUAL : kIdx] > 0) {
                    input.setText(new DecimalFormat("0.##", DecimalFormatSymbols.getInstance(Locale.US)).format(vals[kIdx < 0 ? OCR_ANNUAL : kIdx]));
                }

                row.addView(input, new LinearLayout.LayoutParams(colWidths[c], dp(32)));
                rowFields[c] = input;
            }
            editors.put(day, rowFields);
            table.addView(row);

            View divider = new View(this);
            divider.setBackgroundColor(colorBorder());
            table.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
        }

        all.setOnCheckedChangeListener((v, checked) -> {
            for (CheckBox c : checks.values()) c.setChecked(checked);
        });

        // 감지 결과를 검토표 위쪽 뱃지 카드에 표시
        if (missingWeekdays.isEmpty()) {
            missCard.setBackground(cellBg(isDark() ? Color.rgb(18, 44, 34) : Color.rgb(236, 253, 245), Color.rgb(16, 185, 129), dp(1)));
            TextView okTitle = textDirect("✅ 월말 평일 누락 없음", 12, true);
            okTitle.setTextColor(Color.rgb(5, 150, 105));
            missCard.addView(okTitle);
            TextView okBody = textDirect("평일 근무가 말일까지 모두 인식됐습니다. 인식 결과만 한 번 더 대조해 주세요.", 11, false);
            okBody.setTextColor(colorSub());
            okBody.setPadding(0, dp(2), 0, 0);
            missCard.addView(okBody);
        } else {
            missCard.setBackground(cellBg(isDark() ? Color.rgb(52, 42, 12) : Color.rgb(255, 248, 225), Color.rgb(245, 158, 11), dp(1)));
            TextView warnTitle = textDirect("⚠️ 월말 평일 누락 확인", 12, true);
            warnTitle.setTextColor(Color.rgb(180, 100, 0));
            missCard.addView(warnTitle);
            StringBuilder missSb = new StringBuilder();
            for (int i = 0; i < missingWeekdays.size(); i++) {
                if (i > 0) missSb.append(", ");
                missSb.append(missingWeekdays.get(i)).append("일");
            }
            TextView warnBody = textDirect("평일인데 근무 기록이 비어 있는 날: " + missSb
                    + "\n실제 출근카드와 대조한 뒤 아래 버튼을 누르면 주간 10h(정상 8h+연장 2h)와 가급 1h로 채워집니다.", 11, false);
            warnBody.setTextColor(colorSub());
            warnBody.setPadding(0, dp(2), 0, dp(2));
            missCard.addView(warnBody);

            Button fillBtn = button("누락 " + missingWeekdays.size() + "일을 주간 10h로 채우기", () -> {
                for (int day : missingWeekdays) {
                    CheckBox cb = checks.get(day);
                    if (cb != null) cb.setChecked(true);
                    EditText[] fields = editors.get(day);
                    if (fields == null) continue;
                    for (int c = 1; c < colLabels.length; c++) {
                        if (keyIndices[c] == 0) fields[c].setText("8");
                        else if (keyIndices[c] == 4) fields[c].setText("2");
                        else if (keyIndices[c] == 8) fields[c].setText("1");
                    }
                }
                Toast.makeText(this, "누락된 평일 " + missingWeekdays.size() + "일을 채웠습니다. 저장 전에 확인해 주세요.", Toast.LENGTH_SHORT).show();
            });
            fillBtn.setBackground(bg(Color.rgb(245, 158, 11)));
            fillBtn.setTextColor(Color.WHITE);
            LinearLayout.LayoutParams fbLp = new LinearLayout.LayoutParams(-1, dp(40));
            fbLp.setMargins(0, dp(4), 0, 0);
            missCard.addView(fillBtn, fbLp);
        }

        horizontal.addView(table);
        root.addView(horizontal);

        Button saveBtn = button("캘린더에 전체 저장", () -> {
            SharedPreferences.Editor ed = prefs.edit();
            int savedCount = 0;
            int autoDays = 0;
            for (int day = 1; day <= maxDay; day++) {
                CheckBox cb = checks.get(day);
                if (cb == null || !cb.isChecked()) continue;
                EditText[] fields = editors.get(day);
                if (fields == null) continue;

                // 먼저 이 날의 입력값을 모두 읽어 '실근무가 있는 날'인지 판정한다.
                // 출근카드에 도장이 없어 0/빈칸인 토·일·공휴일을 mode="work"로 덮으면
                // 자동 인정되는 유급 8h·주차 8h 뱃지가 가려지므로, 그런 날은 auto 상태를 유지한다.
                double workSum = 0;
                boolean annualDay = false;
                for (int c = 1; c < colLabels.length; c++) {
                    int kIdx = keyIndices[c];
                    String textVal = fields[c].getText().toString().trim();
                    if (textVal.isEmpty()) continue;
                    double v;
                    try { v = Double.parseDouble(textVal); } catch (Exception e) { continue; }
                    if (v <= 0) continue;
                    if (kIdx == -2 || kIdx == 1 || kIdx == 2 || kIdx == 8) {
                        // 7번 열 [연차]·유급·주차·가급은 실근무가 아니다 (자동/유급 인정 시간)
                        if (kIdx == -2) annualDay = true;
                        continue;
                    }
                    workSum += v;
                }

                if (annualDay) {
                    savedCount++;
                    ed.putString(dayKey(day, "mode"), "annual");
                    for (int c = 1; c < colLabels.length; c++) {
                        int kIdx = keyIndices[c];
                        if (kIdx >= 0) ed.remove(dayKey(day, keys[kIdx]));
                        if (kIdx != -2) continue;
                        String textVal = fields[c].getText().toString().trim();
                        if (!textVal.isEmpty()) {
                            try {
                                double v = Double.parseDouble(textVal);
                                if (v > 0) ed.putString(dayKey(day, keys[0]), Double.toString(v));
                            } catch (Exception ignored) {}
                        }
                    }
                    continue;
                }

                if (workSum <= 0) {
                    // 실근무 0h — 근무(mode=work)로 덮지 않고 기본 자동 인정 상태 유지
                    ed.remove(dayKey(day, "mode"));
                    for (int c = 1; c < colLabels.length; c++) {
                        int kIdx = keyIndices[c];
                        if (kIdx >= 0) ed.remove(dayKey(day, keys[kIdx]));
                    }
                    autoDays++;
                    continue;
                }

                savedCount++;
                ed.putString(dayKey(day, "mode"), "work");
                for (int c = 1; c < colLabels.length; c++) {
                    int kIdx = keyIndices[c];
                    String textVal = fields[c].getText().toString().trim();
                    if (kIdx < 0) continue;
                    if (!textVal.isEmpty()) {
                        try {
                            double v = Double.parseDouble(textVal);
                            ed.putString(dayKey(day, keys[kIdx]), Double.toString(v));
                        } catch (Exception ignored) {}
                    } else {
                        ed.remove(dayKey(day, keys[kIdx]));
                    }
                }
            }
            ed.apply();
            Toast.makeText(this, savedCount + "일의 근무기록이 캘린더에 저장되었습니다."
                    + (autoDays > 0 ? "\n(실근무 없는 " + autoDays + "일은 자동 인정 상태로 유지)" : ""), Toast.LENGTH_LONG).show();
            showMain();
        });
        saveBtn.setBackground(bg(Color.rgb(20, 83, 153)));
        saveBtn.setTextColor(Color.WHITE);
        root.addView(saveBtn);

        root.addView(button("다시 촬영 / 사진 선택", this::showOcrOptions));
        root.addView(button("돌아가기", this::showMain));
    }

    // ── 캘린더 좌우 스와이프 (밀어서 월 넘기기) ──
    // 왼쪽으로 밀면 다음 달, 오른쪽으로 밀면 이전 달. 날짜 셀 클릭과 겹치지 않게 처리한다.
    float swipeDownX, swipeDownY;
    boolean swipeTracking = false;

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (mainContainer == null) return super.dispatchTouchEvent(ev);
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                swipeTracking = false;
                if (!inSubScreen && activeDrawer == null && !isMultiSelectMode
                        && calendarBlock != null && calendarBlock.getVisibility() == View.VISIBLE
                        && calendarBlock.getWidth() > 0 && calendarBlock.getHeight() > 0) {
                    int[] loc = new int[2];
                    calendarBlock.getLocationOnScreen(loc);
                    float rx = ev.getRawX(), ry = ev.getRawY();
                    if (rx >= loc[0] && rx <= loc[0] + calendarBlock.getWidth()
                            && ry >= loc[1] && ry <= loc[1] + calendarBlock.getHeight()) {
                        swipeTracking = true;
                        swipeDownX = rx;
                        swipeDownY = ry;
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                if (swipeTracking) {
                    swipeTracking = false;
                    // 제스처 도중 길게누르기로 다중 선택에 들어갔거나 화면이 바뀐 경우에는 월 이동을 건너뛴다
                    if (isMultiSelectMode || inSubScreen || activeDrawer != null) break;
                    float dx = ev.getRawX() - swipeDownX;
                    float dy = ev.getRawY() - swipeDownY;
                    if (Math.abs(dx) > dp(60) && Math.abs(dx) > Math.abs(dy) * 1.3f) {
                        // 날짜 셀 클릭/길게누르기가 이어지지 않도록 취소 이벤트를 먼저 보낸다
                        MotionEvent cancel = MotionEvent.obtain(ev);
                        cancel.setAction(MotionEvent.ACTION_CANCEL);
                        super.dispatchTouchEvent(cancel);
                        cancel.recycle();
                        vibrateTick();
                        changeMonth(dx < 0 ? 1 : -1);
                        return true;
                    }
                }
                break;
            case MotionEvent.ACTION_CANCEL:
                swipeTracking = false;
                break;
        }
        return super.dispatchTouchEvent(ev);
    }

    void changeMonth(int delta) {
        // 갤러리 사진을 넘기듯이: 현재 달력이 밀려 나가고 새 달력이 반대편에서 미끄러져 들어온다.
        final LinearLayout oldCal = calendarBlock;
        if (oldCal != null && oldCal.getWidth() > 0 && !inSubScreen && activeDrawer == null) {
            final int w = oldCal.getWidth();
            pendingCalSlide = delta;
            oldCal.animate().translationX(-delta * w * 0.55f).alpha(0.15f).setDuration(160)
                    .setInterpolator(new AccelerateInterpolator())
                    .withEndAction(() -> {
                        month.set(Calendar.DAY_OF_MONTH, 1);
                        month.add(Calendar.MONTH, delta);
                        chosenDay = 1;
                        showMain();
                    }).start();
            return;
        }
        month.set(Calendar.DAY_OF_MONTH, 1);
        month.add(Calendar.MONTH, delta);
        chosenDay = 1;
        showMain();
    }

    // 상업용 카드형 월간 근무 집계 및 급여 정산 카드 UI (요청사항 1, 3 반영)
    void refreshSummary() {
        if (summaryContainer == null) return;
        summaryContainer.removeAllViews();

        double[] t = totals(), a = amounts();

        // 1. 월간 근무 시간 집계 카드
        LinearLayout hoursCard = new LinearLayout(this);
        hoursCard.setOrientation(LinearLayout.VERTICAL);
        hoursCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        hoursCard.setPadding(dp(14), dp(12), dp(14), dp(14));
        LinearLayout.LayoutParams hoursLp = new LinearLayout.LayoutParams(-1, -2);
        hoursLp.setMargins(0, 0, 0, dp(12));
        summaryContainer.addView(hoursCard, hoursLp);
        spotStatsCard = hoursCard;   // v1.4.0 스팟라이트 3번 대상 (출카드 1:1 · 근무 통계)

        // ── 현대스틸파이프 출근카드 실물 1:1 매칭 (다크 네이비 라운드 카드) ──
        double[] cb = cardBreakdown();
        hoursCard.setBackground(cellBg(cardBg(), cardBorder(), dp(1)));
        hoursCard.setPadding(dp(13), dp(13), dp(13), dp(13));

        LinearLayout cardHead = new LinearLayout(this);
        cardHead.setOrientation(LinearLayout.HORIZONTAL);
        cardHead.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout cardHeadCol = new LinearLayout(this);
        cardHeadCol.setOrientation(LinearLayout.VERTICAL);
        TextView hoursHeader = textDirect("📇 출근카드 1:1 월간 집계", 15, true);
        hoursHeader.setTextColor(cardInk());
        cardHeadCol.addView(hoursHeader);
        TextView cardSub = textDirect(ym() + " · 현대스틸파이프 출근카드 기준", 10, false);
        cardSub.setTextColor(cardSub());
        cardSub.setPadding(0, dp(2), 0, 0);
        cardHeadCol.addView(cardSub);
        cardHead.addView(cardHeadCol, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView cardStamp = textDirect("카드 1:1", 9, true);
        cardStamp.setTextColor(cardAccent());
        cardStamp.setBackground(cellBg(cardCellBg(), cardAccent(), dp(1)));
        cardStamp.setPadding(dp(7), dp(3), dp(7), dp(3));
        cardHead.addView(cardStamp);

        // 📊 근무 통계 (v1.3.4): 출근카드 1:1 집계와 통계를 한곳에 모아 자연스럽게 연동
        Button statsCardBtn = button("📊 근무 통계", () -> {
            vibrateTick();
            showStatsModal();
        });
        statsCardBtn.setMinWidth(0);
        statsCardBtn.setMinimumWidth(0);
        statsCardBtn.setMinHeight(0);
        statsCardBtn.setMinimumHeight(0);
        statsCardBtn.setTextColor(cardAccent());
        statsCardBtn.setTextSize(10);
        statsCardBtn.setSingleLine(true);
        statsCardBtn.setPadding(dp(7), dp(3), dp(7), dp(3));
        statsCardBtn.setBackground(cellBg(cardCellBg(), cardAccent(), dp(1)));
        LinearLayout.LayoutParams statsCardLp = new LinearLayout.LayoutParams(-2, -2);
        statsCardLp.setMargins(dp(6), 0, 0, 0);
        cardHead.addView(statsCardBtn, statsCardLp);

        hoursCard.addView(cardHead);

        // 상단 요약 뱃지 3종 — 출근 일수 · 실제 근로 · 출근카드 환산
        LinearLayout topBadgeRow = new LinearLayout(this);
        topBadgeRow.setOrientation(LinearLayout.HORIZONTAL);
        addCardBadge(topBadgeRow, "출근", hoursShort(cb[PayCore.CB_DAYS]) + "일", cardSub(), cardInk());
        addCardBadge(topBadgeRow, "실제 근로", hoursShort(cb[PayCore.CB_ACTUAL]) + "h", cardSub(), Color.rgb(96, 165, 250));
        addCardBadge(topBadgeRow, "카드 환산", hoursShort(cb[PayCore.CB_CONVERT]) + "h", cardSub(), Color.rgb(52, 211, 153));
        LinearLayout.LayoutParams tbLp = new LinearLayout.LayoutParams(-1, -2);
        tbLp.setMargins(0, dp(10), 0, 0);
        hoursCard.addView(topBadgeRow, tbLp);

        // ① 기본 인정 (정취·유급·주차·연차)
        LinearLayout g1 = addCardGroup(hoursCard, "①  기본 인정", "기본급 인정 " + hoursShort(cb[PayCore.CB_BASE]) + "h",
                Color.rgb(96, 165, 250));
        LinearLayout g1r = new LinearLayout(this);
        g1r.setOrientation(LinearLayout.HORIZONTAL);
        addCardCell(g1r, "정취", hoursShort(cb[PayCore.CB_NORMAL]) + "h", null, cardInk());
        addCardCell(g1r, "유급", hoursShort(cb[PayCore.CB_PAID]) + "h", null, cardInk());
        addCardCell(g1r, "주차", hoursShort(cb[PayCore.CB_WEEKLY]) + "h", null, cardInk());
        addCardCell(g1r, "연차", hoursShort(cb[PayCore.CB_ANNUAL]) + "h",
                cb[PayCore.CB_ANNUAL] > 0 ? "유급 인정" : null, cb[PayCore.CB_ANNUAL] > 0 ? Color.rgb(110, 231, 183) : cardInk());
        g1.addView(g1r);
        if (cb[PayCore.CB_UNION] > 0) {
            LinearLayout uRow = new LinearLayout(this);
            uRow.setOrientation(LinearLayout.HORIZONTAL);
            addCardCell(uRow, "조합설명회", hoursShort(cb[PayCore.CB_UNION]) + "h", "정상 인정", cardInk());
            g1.addView(uRow);
        }

        // ② 시간외·특근 (연장·휴일근로·휴일연장·심야)
        double otSum = cb[PayCore.CB_OT] + cb[PayCore.CB_HOL] + cb[PayCore.CB_HOLOT];
        LinearLayout g2 = addCardGroup(hoursCard, "②  시간외 · 특근", "합계 " + hoursShort(otSum) + "h",
                Color.rgb(251, 191, 36));
        LinearLayout g2r = new LinearLayout(this);
        g2r.setOrientation(LinearLayout.HORIZONTAL);
        addCardCell(g2r, "연장", hoursShort(cb[PayCore.CB_OT]) + "h", null, Color.rgb(253, 230, 138));
        addCardCell(g2r, "휴일근로", hoursShort(cb[PayCore.CB_HOL]) + "h", null, Color.rgb(252, 165, 165));
        addCardCell(g2r, "휴일연장", hoursShort(cb[PayCore.CB_HOLOT]) + "h", null, Color.rgb(252, 165, 165));
        addCardCell(g2r, "심야", hoursShort(cb[PayCore.CB_NIGHT]) + "h", null,
                cb[PayCore.CB_NIGHT] > 0 ? Color.rgb(196, 181, 253) : cardInk());
        g2.addView(g2r);

        // ③ 가급 및 환산 (가급·휴일가급·환산시간)
        LinearLayout g3 = addCardGroup(hoursCard, "③  가급 및 환산", "급여 인정 " + hoursShort(cb[PayCore.CB_PAY]) + "h",
                Color.rgb(52, 211, 153));
        LinearLayout g3r = new LinearLayout(this);
        g3r.setOrientation(LinearLayout.HORIZONTAL);
        addCardCell(g3r, "가급", hoursShort(cb[PayCore.CB_GAGEUB]) + "h",
                isShiftWorker() ? "교대수당" : hoursShort(cb[PayCore.CB_GAGEUB]) + "일", Color.rgb(110, 231, 183));
        addCardCell(g3r, "휴일가급", hoursShort(cb[PayCore.CB_HOLPREMIUM]) + "h",
                cb[PayCore.CB_HOLPREMIUM] > 0 ? "할증 포함" : null, Color.rgb(252, 165, 165));
        addCardCell(g3r, "환산시간", hoursShort(cb[PayCore.CB_CONVERT]) + "h", "실물 카드 합계",
                Color.rgb(52, 211, 153), true);
        g3.addView(g3r);

        TextView cardNote = textDirect(
            "실제 근로 " + hoursShort(cb[PayCore.CB_ACTUAL]) + "h(정취+연장+휴일특근) · 유급 인정 "
            + hoursShort(cb[PayCore.CB_PAID] + cb[PayCore.CB_WEEKLY] + cb[PayCore.CB_ANNUAL]) + "h · 급여 인정 "
            + hoursShort(cb[PayCore.CB_PAY]) + "h\n환산 " + hoursShort(cb[PayCore.CB_CONVERT])
            + "h = 급여 인정 − 특근일 가급 " + hoursShort(Math.max(0, cb[PayCore.CB_GAGEUB] - cb[PayCore.CB_GAGEUB_WEEKDAY]))
            + "h + 휴일가급 " + hoursShort(cb[PayCore.CB_HOLPREMIUM]) + "h"
            + (isShiftWorker() && cb[PayCore.CB_NIGHT] > 0 ? " + 심야 " + hoursShort(cb[PayCore.CB_NIGHT]) + "h" : ""), 9, false);
        cardNote.setTextColor(cardSub());
        cardNote.setLineSpacing(dp(1), 1f);
        LinearLayout.LayoutParams cnLp = new LinearLayout.LayoutParams(-1, -2);
        cnLp.setMargins(0, dp(9), 0, 0);
        hoursCard.addView(cardNote, cnLp);

        // 2. 예상 급여 정산 카드 (Hero 배너 + 상세 산출식)
        LinearLayout salaryCard = new LinearLayout(this);
        salaryCard.setOrientation(LinearLayout.VERTICAL);
        salaryCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        salaryCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams salaryLp = new LinearLayout.LayoutParams(-1, -2);
        salaryLp.setMargins(0, 0, 0, dp(12));
        summaryContainer.addView(salaryCard, salaryLp);

        // 상단 Hero 배너 (예상 실수령액 & 세전 총액) — v1.3.4: 우측 가운데에 [소급 ON/OFF]·[성과격려금]
        LinearLayout heroBanner = new LinearLayout(this);
        heroBanner.setOrientation(LinearLayout.HORIZONTAL);
        heroBanner.setGravity(Gravity.CENTER_VERTICAL);
        heroBanner.setBackground(cellBg(isDark() ? Color.rgb(20, 36, 64) : Color.rgb(235, 243, 255), colorBlue(), dp(1)));
        heroBanner.setPadding(dp(14), dp(12), dp(12), dp(12));

        LinearLayout heroTextCol = new LinearLayout(this);
        heroTextCol.setOrientation(LinearLayout.VERTICAL);

        TextView netLabel = textDirect("💰 예상 실수령액", 13, true);
        netLabel.setTextColor(colorBlue());
        heroTextCol.addView(netLabel);

        TextView netAmount = textDirect(won(a[8]), 22, true);
        heroNetTv = netAmount;
        netAmount.setTextColor(isDark() ? Color.rgb(147, 197, 253) : Color.rgb(20, 78, 154));
        netAmount.setPadding(0, dp(2), 0, dp(4));
        netAmount.setSingleLine(true);
        netAmount.setEllipsize(TextUtils.TruncateAt.END);
        // 좁은 화면에서도 금액이 잘리지 않도록 자동 축소 (API 26+)
        try {
            netAmount.setAutoSizeTextTypeUniformWithConfiguration(dp(11), dp(22) - dp(2), 1, android.util.TypedValue.COMPLEX_UNIT_PX);
        } catch (Throwable ignored) {}
        heroTextCol.addView(netAmount);

        TextView grossTv = textDirect("세전 총지급액: " + won(a[6]), 11, true);
        grossTv.setTextColor(colorInk());
        heroTextCol.addView(grossTv);
        heroGrossTv = grossTv;

        TextView dedTv = textDirect("예상 공제액: -" + won(a[7]), 11, true);
        dedTv.setTextColor(colorRed());
        dedTv.setPadding(0, dp(1), 0, 0);
        heroTextCol.addView(dedTv);
        heroDedTv = dedTv;

        heroBanner.addView(heroTextCol, new LinearLayout.LayoutParams(0, -2, 1f));

        // 우측 가운데 정렬 액션: [소급 ON/OFF] + [🏆 성과격려금] 캡슐 버튼
        LinearLayout heroActions = new LinearLayout(this);
        heroActions.setOrientation(LinearLayout.VERTICAL);
        heroActions.setGravity(Gravity.CENTER);

        boolean isRetroOn = isRetroActiveThisMonth();
        Button retroBtn = button(isRetroOn ? "소급 ON" : "소급 OFF", () -> {
            vibrateTick();
            // v1.3.6 ①: 화면을 다시 그리지 않고 금액 텍스트만 핀포인트 갱신 → 스크롤·포커스 튐 0
            toggleRetroActiveThisMonth();
            refreshRetroInPlace();
        });
        retroBtn.setFocusable(false);
        retroBtn.setFocusableInTouchMode(false);
        heroRetroBtn = retroBtn;
        retroBtn.setOnLongClickListener(v -> {
            vibrateTick();
            showRetroPaySettingsDialog();
            return true;
        });
        retroBtn.setMinWidth(0);
        retroBtn.setMinimumWidth(0);
        retroBtn.setMinHeight(0);
        retroBtn.setMinimumHeight(0);
        retroBtn.setTextSize(11);
        retroBtn.setSingleLine(true);
        retroBtn.setPadding(dp(6), dp(5), dp(6), dp(5));
        if (isRetroOn) {
            retroBtn.setTextColor(Color.rgb(180, 100, 0));
            retroBtn.setBackground(cellBg(isDark() ? Color.rgb(44, 34, 18) : Color.rgb(255, 246, 224), Color.rgb(230, 160, 40), dp(1)));
        } else {
            retroBtn.setTextColor(colorSub());
            retroBtn.setBackground(cellBg(isDark() ? Color.rgb(24, 28, 36) : Color.rgb(240, 243, 248), colorBorder(), dp(1)));
        }
        heroActions.addView(retroBtn, new LinearLayout.LayoutParams(dp(92), -2));

        Button bonusBtn = button("🏆 성과격려금", () -> {
            vibrateTick();
            if (mainScrollView != null) pendingScrollY = mainScrollView.getScrollY();
            showBonusCalculator();
        });
        bonusBtn.setMinWidth(0);
        bonusBtn.setMinimumWidth(0);
        bonusBtn.setMinHeight(0);
        bonusBtn.setMinimumHeight(0);
        bonusBtn.setTextSize(10);
        bonusBtn.setSingleLine(true);
        bonusBtn.setTextColor(colorBlue());
        bonusBtn.setPadding(dp(4), dp(5), dp(4), dp(5));
        bonusBtn.setBackground(cellBg(isDark() ? Color.rgb(20, 36, 64) : Color.rgb(232, 242, 255), colorBlue(), dp(1)));
        LinearLayout.LayoutParams bonusLp = new LinearLayout.LayoutParams(dp(92), -2);
        bonusLp.setMargins(0, dp(5), 0, 0);
        heroActions.addView(bonusBtn, bonusLp);

        LinearLayout.LayoutParams heroActLp = new LinearLayout.LayoutParams(-2, -2);
        heroActLp.setMargins(dp(8), 0, 0, 0);
        heroBanner.addView(heroActions, heroActLp);

        salaryCard.addView(heroBanner);
        spotHeroCard = heroBanner;   // v1.4.0 스팟라이트 4번 대상 (예상 실수령액 · 소급 · 격려금)

        // 깔끔한 영수증 요약 리스트 & 접이식 산출식 (전문가 개선 3)
        TextView detailHeader = textDirect("🧾 이번 달 급여 정산 내역", 14, true);
        detailHeader.setTextColor(colorInk());
        detailHeader.setPadding(0, dp(14), 0, dp(6));
        salaryCard.addView(detailHeader);

        double baseHours = t[0] + t[1] + t[2] + t[3];
        String f1 = hours(baseHours) + " × " + won(get("base")) + " (정상 " + hoursShort(t[0]) + " + 유급 " + hoursShort(t[1]) + " + 주차 " + hoursShort(t[2]) + (t[3] > 0 ? " + 조합 " + hoursShort(t[3]) : "") + ")";

        double otH = Math.max(0, t[4] - t[3]);
        double otUnit = Math.round(get("ordinary") * get("otRate"));
        String f2 = hours(otH) + " × " + won(otUnit) + " (통상시급 " + won(get("ordinary")) + " × 1.5배)";

        double holUnit = Math.round(get("ordinary") * get("holidayRate"));
        String f3 = hours(t[5]) + " × " + won(holUnit) + " (통상시급 " + won(get("ordinary")) + " × 1.5배)";

        double holOtUnit = Math.round(get("ordinary") * get("holidayOTRate"));
        String f4 = hours(t[6]) + " × " + won(holOtUnit) + " (8시간 초과분 통상시급 × 200%)";

        String fNight = "";
        // 교대조 야간 할증은 종이 카드의 심야 3.5h(가산시간)가 아니라 1일 7.0h로 되돌려 계산한다
        double nightPayH = PayCore.nightPayHours(this, isShiftWorker());
        int nightDays = PayCore.nightWorkDays(this);
        String nightPerDay = new DecimalFormat("0.0").format(PayCore.SHIFT_NIGHT_HOURS_PER_DAY);
        if (t[7] > 0) {
            double nightUnit = Math.round(get("ordinary") * get("nightRate"));
            if (isShiftWorker()) {
                fNight = new DecimalFormat("0.0").format(nightPayH) + "h (야간 " + nightDays + "일 × " + nightPerDay + "h) × "
                        + won(get("ordinary")) + " × 0.5 = " + won(a[4]);
            } else {
                fNight = hours(t[7]) + " × " + won(nightUnit) + " (통상시급 × 0.5배)";
            }
        }

        double gageubDays = (t.length > 8 && t[8] > 0) ? t[8] : countWorkDays();
        boolean isShift = isShiftWorker();
        double breakPay = isShift ? 0 : (gageubDays * get("base"));
        double shiftPay = isShift ? 200000 : 0;
        StringBuilder fixSb = new StringBuilder();
        if (isShift) {
            fixSb.append("교대수당 ").append(won(shiftPay)).append(" (단협 제42조 5호)\n");
        } else {
            fixSb.append("상주휴게수당 ").append(won(breakPay)).append(" (실근무 ").append((int)gageubDays).append("일 × ").append(won(get("base"))).append(")\n");
        }
        fixSb.append("근속 ").append(won(get("tenure"))).append(" + 본인가족 ").append(won(get("familySelf"))).append(" + 가족 ").append(won(get("familyOther")))
                .append(isFamilyAllowanceLinked() ? " (부양가족 " + getDeductionDependents() + "명 → 본인 외 " + Math.max(0, getDeductionDependents() - 1) + "명 × 10,000원)" : " (직접 입력)")
                .append("\n└ 직책수당 ").append(won(get("position"))).append(" + 직무수당 ").append(won(get("duty")));
        if (month.get(Calendar.MONTH) >= 6 && month.get(Calendar.MONTH) <= 8) {
            fixSb.append(" + 하계지원비 ").append(won(get("summer")));
        }
        String fFixed = fixSb.toString();

        // 1) 깔끔한 영수증 요약 리스트
        addPayReceiptRow(salaryCard, "1. 기본급", won(a[0]));
        addPayReceiptRow(salaryCard, "2. 평일연장근로수당", won(a[1]));
        addPayReceiptRow(salaryCard, "3. 휴일근로수당(특근)", won(a[2]));
        addPayReceiptRow(salaryCard, "4. 휴일연장수당(가급)", won(a[3]));
        if (t[7] > 0) {
            addPayReceiptRow(salaryCard, "5. 야간 추가수당 (" + new DecimalFormat("0.0").format(nightPayH) + "h)", won(a[4]));
        }
        addPayReceiptRow(salaryCard, (t[7] > 0 ? "6." : "5.") + (isShift ? " 고정 및 교대수당" : " 고정 및 상주휴게수당"), won(a[5]));
        // [직책수당]과 [직무수당]을 각각 별도 행으로 노출 (단협 제42조 — 사원도 직무수당 55,000원 유지)
        addPaySubRow(salaryCard, "└ 직책수당 (직급 연동)", won(get("position")));
        addPaySubRow(salaryCard, "└ 직무수당 (고정수당)", won(get("duty")));
        // 💰 소급분 행 — 토글 시 전체 화면을 다시 그리지 않고 이 행만 보이기/숨기기 한다 (v1.3.6)
        LinearLayout retroRowBox = new LinearLayout(this);
        retroRowBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout retroRowInner = new LinearLayout(this);
        retroRowInner.setOrientation(LinearLayout.HORIZONTAL);
        retroRowInner.setGravity(Gravity.CENTER_VERTICAL);
        retroRowInner.setPadding(0, dp(6), 0, dp(6));
        TextView retroRowTitle = textDirect("💰 소급분 (임단협 타결)", 14, false);
        retroRowTitle.setTextColor(colorInk());
        retroRowInner.addView(retroRowTitle, new LinearLayout.LayoutParams(0, -2, 1));
        TextView retroRowAmount = textDirect(won(getRetroPayAmount()), 14, true);
        retroRowAmount.setTextColor(colorInk());
        retroRowInner.addView(retroRowAmount);
        retroRowBox.addView(retroRowInner);
        View retroRowDiv = new View(this);
        retroRowDiv.setBackgroundColor(isDark() ? Color.rgb(35, 45, 60) : Color.rgb(238, 241, 246));
        retroRowBox.addView(retroRowDiv, new LinearLayout.LayoutParams(-1, dp(1)));
        retroRowBox.setVisibility(isRetroActiveThisMonth() ? View.VISIBLE : View.GONE);
        salaryCard.addView(retroRowBox);
        retroRowView = retroRowBox;

        // 2) 상세 산출 계산식 접이식 컨테이너
        LinearLayout formulaContainer = new LinearLayout(this);
        formulaContainer.setOrientation(LinearLayout.VERTICAL);
        formulaContainer.setVisibility(View.GONE);
        formulaContainer.setBackground(cellBg(isDark() ? Color.rgb(20, 30, 48) : Color.rgb(244, 248, 254), colorBorder(), dp(1)));
        formulaContainer.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams fcLp = new LinearLayout.LayoutParams(-1, -2);
        fcLp.setMargins(0, dp(8), 0, 0);

        TextView fHeader = textDirect("📐 항목별 단체협약 계산 산출식", 13, true);
        fHeader.setTextColor(colorBlue());
        fHeader.setPadding(0, 0, 0, dp(6));
        formulaContainer.addView(fHeader);

        addPayFormulaDetail(formulaContainer, "1. 기본급 산출식", f1);
        addPayFormulaDetail(formulaContainer, "2. 평일연장 산출식", f2);
        addPayFormulaDetail(formulaContainer, "3. 휴일근로(특근) 산출식", f3);
        addPayFormulaDetail(formulaContainer, "4. 휴일연장(휴일가급) 산출식", f4);
        if (t[7] > 0) {
            addPayFormulaDetail(formulaContainer, "5. 야간근로 산출식", fNight);
        }
        addPayFormulaDetail(formulaContainer, (t[7] > 0 ? "6." : "5.") + (isShift ? " 고정·교대수당 산출식" : " 고정·상주휴게 산출식"), fFixed);
        retroFormulaView = addPayFormulaDetail(formulaContainer, "💰 소급분 산출식", "시급 인상분 516원 × 누적 소급시간(약 2,815.5h / 8개월) = " + won(getRetroPayAmount()) + " (2026 임단협 타결 전월 소급 지급분)");
        if (retroFormulaView != null) retroFormulaView.setVisibility(isRetroActiveThisMonth() ? View.VISIBLE : View.GONE);

        // 아코디언 토글 버튼
        Button accordionBtn = button("▾ 상세 산출 계산식 펼치기", null);
        accordionBtn.setBackground(cellBg(isDark() ? Color.rgb(25, 38, 60) : Color.rgb(234, 242, 254), colorBlue(), dp(1)));
        accordionBtn.setTextColor(colorBlue());
        accordionBtn.setTextSize(13);
        accordionBtn.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams accLp = new LinearLayout.LayoutParams(-1, -2);
        accLp.setMargins(0, dp(8), 0, 0);

        accordionBtn.setOnClickListener(v -> {
            vibrateTick();
            if (formulaContainer.getVisibility() == View.VISIBLE) {
                formulaContainer.setVisibility(View.GONE);
                accordionBtn.setText("▾ 상세 산출 계산식 펼치기");
            } else {
                formulaContainer.setVisibility(View.VISIBLE);
                accordionBtn.setText("▴ 상세 산출 계산식 접기");
            }
        });

        salaryCard.addView(accordionBtn, accLp);
        salaryCard.addView(formulaContainer, fcLp);

        // ── v1.3.6: 공제 내역은 홀더에 담아 두고 소급 토글 시 이 부분만 국소 갱신한다 ──
        deductSectionHolder = new LinearLayout(this);
        deductSectionHolder.setOrientation(LinearLayout.VERTICAL);
        salaryCard.addView(deductSectionHolder);
        addDeductionSection(deductSectionHolder, Math.round(a[6]));

        // 3. 안내 및 백업 권장 카드
        LinearLayout noticeCard = new LinearLayout(this);
        noticeCard.setOrientation(LinearLayout.VERTICAL);
        noticeCard.setBackground(cellBg(isDark() ? Color.rgb(20, 28, 42) : Color.rgb(245, 247, 250), colorBorder(), dp(1)));
        noticeCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView noticeTv = textDirect(
            "※ 금액은 2026년 단체협약 및 산출방식 기준 추정치입니다. 실제 급여는 회사의 최종 정산에 따릅니다.\n※ 기록은 앱 내부에 저장됩니다. 앱 삭제 전 반드시 엑셀 백업을 해 주세요.",
            11, false
        );
        noticeTv.setTextColor(colorSub());
        noticeCard.addView(noticeTv);
        summaryContainer.addView(noticeCard);
    }

    // ── 출근카드 1:1 카드 팔레트 (v1.3.3: 라이트/다크 테마 자동 연동) ──
    //  라이트 모드에서도 짙은 밤색으로 고정돼 있던 결함을 고쳐, 라이트에서는 흰 서피스 카드로 보인다.
    int cardBg()     { return isDark() ? 0xFF101A2B : 0xFFFFFFFF; }
    int cardBorder() { return isDark() ? 0xFF2A3B57 : 0xFFE2E8F0; }
    int cardCellBg() { return isDark() ? 0xFF17233A : 0xFFF1F5F9; }
    int cardInk()    { return isDark() ? 0xFFF1F5F9 : 0xFF0F172A; }
    int cardSub()    { return isDark() ? 0xFF93A4BE : 0xFF64748B; }
    int cardAccent() { return isDark() ? 0xFF38BDF8 : 0xFF0369A1; }
    int cardHighlightBg()    { return isDark() ? 0xFF0F2A29 : 0xFFECFDF5; }
    int cardHighlightSub()   { return isDark() ? 0xFF6EE7B7 : 0xFF047857; }

    LinearLayout addCardGroup(LinearLayout parent, String title, String summary, int accent) {
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.VERTICAL);
        group.setBackground(cellBg(cardCellBg(), cardBorder(), dp(1)));
        group.setPadding(dp(9), dp(8), dp(9), dp(8));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView t = textDirect(title, 12, true);
        t.setTextColor(accent);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView s = textDirect(summary, 10, true);
        s.setTextColor(cardSub());
        head.addView(s);
        group.addView(head);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, 0);
        parent.addView(group, lp);
        return group;
    }

    void addCardBadge(LinearLayout row, String label, String value, int labelColor, int valColor) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(cellBg(cardCellBg(), cardBorder(), dp(1)));
        box.setPadding(dp(8), dp(5), dp(8), dp(5));

        TextView l = textDirect(label, 9, false);
        l.setTextColor(labelColor);
        box.addView(l);

        TextView v = textDirect(value, 12, true);
        v.setTextColor(valColor);
        v.setPadding(dp(5), 0, 0, 0);
        box.addView(v);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        row.addView(box, lp);
    }

    void addCardCell(LinearLayout row, String label, String value, String sub, int valColor) {
        addCardCell(row, label, value, sub, valColor, false);
    }

    void addCardCell(LinearLayout row, String label, String value, String sub, int valColor, boolean highlight) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setBackground(cellBg(highlight ? cardHighlightBg() : cardBg(),
                highlight ? (isDark() ? Color.rgb(16, 185, 129) : Color.rgb(5, 150, 105)) : cardBorder(), dp(1)));
        cell.setPadding(dp(4), dp(6), dp(4), dp(6));

        TextView l = textDirect(label, 10, false);
        l.setTextColor(cardSub());
        l.setGravity(Gravity.CENTER);
        l.setSingleLine(true);
        cell.addView(l);

        TextView v = textDirect(value, highlight ? 16 : 14, true);
        v.setTextColor(valColor);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setPadding(0, dp(2), 0, 0);
        cell.addView(v);

        if (sub != null) {
            TextView s = textDirect(sub, 8, false);
            s.setTextColor(highlight ? cardHighlightSub() : cardSub());
            s.setGravity(Gravity.CENTER);
            s.setSingleLine(true);
            cell.addView(s);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(2), dp(3), dp(2), 0);
        row.addView(cell, lp);
    }

    void addWorkChip(LinearLayout row, String label, String value, int valColor) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.VERTICAL);
        chip.setBackground(cellBg(isDark() ? Color.rgb(22, 32, 48) : Color.rgb(243, 246, 252), colorBorder(), dp(1)));
        chip.setPadding(dp(6), dp(6), dp(6), dp(6));

        TextView lbl = textDirect(label, 11, false);
        lbl.setTextColor(colorSub());
        chip.addView(lbl);

        TextView val = textDirect(value, 13, true);
        val.setTextColor(valColor);
        chip.addView(val);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        row.addView(chip, lp);
    }

    void addPayReceiptRow(LinearLayout parent, String title, String amount) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));

        TextView tTv = textDirect(title, 14, false);
        tTv.setTextColor(colorInk());
        row.addView(tTv, new LinearLayout.LayoutParams(0, -2, 1));

        TextView aTv = textDirect(amount, 14, true);
        aTv.setTextColor(colorInk());
        row.addView(aTv);

        parent.addView(row);

        View div = new View(this);
        div.setBackgroundColor(isDark() ? Color.rgb(35, 45, 60) : Color.rgb(238, 241, 246));
        parent.addView(div, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    void addPaySubRow(LinearLayout parent, String title, String amount) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(3), 0, dp(3));

        TextView tTv = textDirect(title, 12, false);
        tTv.setTextColor(colorSub());
        row.addView(tTv, new LinearLayout.LayoutParams(0, -2, 1));

        TextView aTv = textDirect(amount, 12, true);
        aTv.setTextColor(colorSub());
        row.addView(aTv);

        parent.addView(row);
    }

    /** 공제 내역 블록 — v1.3.6: 소급 토글 때 이 블록만 다시 만들어 스크롤 튐 없이 갱신한다. */
    void addDeductionSection(LinearLayout parent, long gross) {
        // ── 공제 내역 상세 + [▾ 상세 공제 계산식 펼치기] ──
        DeductionCore.Result ded = deductionResult(gross);
        final boolean dedAutoOn = isAutoDeduction();
        final long usedDeduction = dedAutoOn ? ded.total : Math.round(get("deduction"));
        TextView dedHead = textDirect("🧾 공제 내역 (" + (dedAutoOn ? ded.basisNote : "직접 입력 공제액") + ")", 14, true);
        dedHead.setTextColor(colorInk());
        dedHead.setPadding(0, dp(14), 0, dp(6));
        parent.addView(dedHead);

        if (dedAutoOn && ded.learnedIgnored) {
            TextView learnedWarn = textDirect("📋 직전 명세서 실측 공제값은 참고용으로만 보관 — 자동 예측에서는 채택하지 않고 법정 요율·간이세액표로 계산합니다.", 10, false);
            learnedWarn.setTextColor(colorSub());
            learnedWarn.setLineSpacing(dp(1), 1.04f);
            learnedWarn.setPadding(0, 0, 0, dp(4));
            parent.addView(learnedWarn);
        }

        if (ded.incomeTax > 0) addPayReceiptRow(parent, "소득세", "-" + won(ded.incomeTax));
        if (ded.localTax > 0) addPayReceiptRow(parent, "지방소득세 (소득세의 10%)", "-" + won(ded.localTax));
        if (ded.pension > 0) addPayReceiptRow(parent, "국민연금 (" + won(ded.pensionBase) + " × 4.5%)", "-" + won(ded.pension));
        if (ded.health > 0) addPayReceiptRow(parent,
                "건강보험 (" + won(ded.healthBase) + " × 3.545%)",
                "-" + won(ded.health));
        if (ded.longterm > 0) addPayReceiptRow(parent, "장기요양보험 (건강보험료 × 12.95%)", "-" + won(ded.longterm));
        if (ded.employ > 0) addPayReceiptRow(parent, "고용보험 (과세급여 × 0.9%)", "-" + won(ded.employ));
        if (ded.unionFee > 0) addPayReceiptRow(parent, "노조회비 (통상시급 × 3h + 1,200원)", "-" + won(ded.unionFee));
        addPayReceiptRow(parent, "공제 합계", "-" + won(usedDeduction));

        LinearLayout dedFormula = new LinearLayout(this);
        dedFormula.setOrientation(LinearLayout.VERTICAL);
        dedFormula.setVisibility(View.GONE);
        dedFormula.setBackground(cellBg(isDark() ? Color.rgb(20, 30, 48) : Color.rgb(244, 248, 254), colorBorder(), dp(1)));
        dedFormula.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView dh = textDirect("🧮 공제액 산출 계산식", 13, true);
        dh.setTextColor(colorBlue());
        dh.setPadding(0, 0, 0, dp(6));
        dedFormula.addView(dh);

        if (!dedAutoOn) {
            TextView manualWarn = textDirect("⚠ 직접 입력 공제액 " + won(usedDeduction)
                    + "을 사용 중입니다. 아래는 자동 예측 참고값입니다.", 11, true);
            manualWarn.setTextColor(Color.rgb(180, 100, 0));
            manualWarn.setPadding(0, 0, 0, dp(6));
            dedFormula.addView(manualWarn);
        }

        // v1.4.2 — 국세청 간이세액표 · 자녀 세액공제를 카드 한 장에 한 항목씩 (심플·투명)
        int no = 1;
        int pct = (int) Math.round(ded.advanceRate * 100);
        java.util.List<String> bTax = new java.util.ArrayList<>();
        if (ded.learned) {
            bTax.add("직전 명세서(세전 " + won(ded.learnedGross) + ")의 실측 소득세를 이번 달 세전 " + won(ded.gross) + " 비율로 보정");
            bTax.add("참고 국세청 간이세액표 (월급여 " + ded.tableBand + " · 부양가족 " + ded.dependents + "명): " + won(ded.tableTax));
            if (ded.childTaxCredit > 0) bTax.add("자녀 세액공제 (8~20세 자녀 " + ded.children + "명): −" + won(ded.childTaxCredit));
        } else {
            bTax.add("국세청 간이세액표 (월급여 " + ded.tableBand + " · 부양가족 " + ded.dependents + "명): " + won(ded.tableTax));
            if (ded.childTaxCredit > 0) bTax.add("자녀 세액공제 (8~20세 자녀 " + ded.children + "명): −" + won(ded.childTaxCredit));
            if (pct != 100) bTax.add("선공제율 " + pct + "% 적용: " + won(ded.statutoryIncomeTax) + " × " + pct + "% = " + won(ded.incomeTax));
            else bTax.add("최종 결정 소득세: " + won(ded.incomeTax) + " (선공제율 100%)");
        }
        addDeductionFormulaCard(dedFormula, (no++) + ". 소득세", won(ded.incomeTax), bTax);
        addDeductionFormulaCard(dedFormula, (no++) + ". 지방소득세", won(ded.localTax),
                java.util.Collections.singletonList("소득세 " + won(ded.incomeTax) + " × 10% (10원 미만 절사) = " + won(ded.localTax)));
        addDeductionFormulaCard(dedFormula, (no++) + ". 국민연금", won(ded.pension),
                java.util.Collections.singletonList("기준 보수월액 " + won(ded.pensionBase) + " × 4.5% = " + won(ded.pension)));
        if (ded.learned) {
            addDeductionFormulaCard(dedFormula, (no++) + ". 건강보험·장기요양", won(ded.health),
                    java.util.Collections.singletonList("직전 명세서 실측값(장기요양 포함)을 세전 비율로 보정"));
        } else {
            addDeductionFormulaCard(dedFormula, (no++) + ". 건강보험", won(ded.health),
                    java.util.Collections.singletonList("보수월액 " + won(ded.healthBase) + " × 3.545% = " + won(ded.health)));
            addDeductionFormulaCard(dedFormula, (no++) + ". 장기요양보험", won(ded.longterm),
                    java.util.Collections.singletonList("건강보험료 " + won(ded.health) + " × 12.95% = " + won(ded.longterm)));
        }
        addDeductionFormulaCard(dedFormula, (no++) + ". 고용보험", won(ded.employ),
                java.util.Collections.singletonList("과세급여(세전) " + won(ded.gross) + " × 0.9% = " + won(ded.employ)));
        addDeductionFormulaCard(dedFormula, (no++) + ". 노조회비", won(ded.unionFee),
                java.util.Collections.singletonList("(통상시급 " + won(get("ordinary")) + " × 3h) + 1,200원 = "
                        + won(Math.round(get("ordinary") * 3 + 1200)) + " → 100원 단위 반올림"));
        addDeductionFormulaCard(dedFormula, "공제 합계", won(ded.total),
                java.util.Collections.singletonList("1~" + (no - 1) + "항 합계 = " + won(ded.total)));

        Button dedAccBtn = button("▾ 상세 공제 계산식 펼치기", null);
        dedAccBtn.setBackground(cellBg(isDark() ? Color.rgb(25, 38, 60) : Color.rgb(234, 242, 254), colorBlue(), dp(1)));
        dedAccBtn.setTextColor(colorBlue());
        dedAccBtn.setTextSize(13);
        dedAccBtn.setPadding(dp(12), dp(8), dp(12), dp(8));
        dedAccBtn.setOnClickListener(v -> {
            vibrateTick();
            if (dedFormula.getVisibility() == View.VISIBLE) {
                dedFormula.setVisibility(View.GONE);
                dedAccBtn.setText("▾ 상세 공제 계산식 펼치기");
            } else {
                dedFormula.setVisibility(View.VISIBLE);
                dedAccBtn.setText("▴ 상세 공제 계산식 접기");
            }
        });
        LinearLayout.LayoutParams dedAccLp = new LinearLayout.LayoutParams(-1, -2);
        dedAccLp.setMargins(0, dp(8), 0, 0);
        LinearLayout.LayoutParams dedFLp = new LinearLayout.LayoutParams(-1, -2);
        dedFLp.setMargins(0, dp(6), 0, 0);
        parent.addView(dedAccBtn, dedAccLp);
        parent.addView(dedFormula, dedFLp);
    }

    /** v1.4.2 — 상세 공제 계산식 카드: 제목·금액 한 줄 + 근거 불릿 (설치형·웹 공통 디자인) */
    void addDeductionFormulaCard(LinearLayout parent, String title, String amount, java.util.List<String> bullets) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(cellBg(isDark() ? Color.rgb(25, 37, 58) : Color.rgb(255, 255, 255), colorBorder(), dp(1)));
        card.setPadding(dp(11), dp(8), dp(11), dp(8));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = textDirect(title, 12, true);
        t.setTextColor(colorInk());
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView a = textDirect(amount, 13, true);
        a.setTextColor(colorRed());
        head.addView(a);
        card.addView(head);

        if (bullets != null) {
            for (String b : bullets) {
                TextView bl = textDirect("• " + b, 11, false);
                bl.setTextColor(colorSub());
                bl.setPadding(dp(3), dp(3), 0, 0);
                bl.setLineSpacing(dp(1), 1.06f);
                card.addView(bl);
            }
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, 0);
        parent.addView(card, lp);
    }

    View addPayFormulaDetail(LinearLayout parent, String title, String formula) {
        if (formula == null || formula.trim().isEmpty()) return null;
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(0, dp(4), 0, dp(6));

        TextView tTv = textDirect(title, 12, true);
        tTv.setTextColor(colorBlue());
        item.addView(tTv);

        TextView fTv = textDirect("• " + formula, 11, false);
        fTv.setTextColor(colorSub());
        fTv.setPadding(dp(4), dp(2), 0, 0);
        item.addView(fTv);

        parent.addView(item);
        return item;
    }

    void addPayItemRow(LinearLayout parent, String title, String amount, String formula) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(4), 0, dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);

        TextView tTv = textDirect(title, 14, true);
        tTv.setTextColor(colorInk());
        top.addView(tTv, new LinearLayout.LayoutParams(0, -2, 1));

        TextView aTv = textDirect(amount, 14, true);
        aTv.setTextColor(colorInk());
        top.addView(aTv);
        row.addView(top);

        if (formula != null && !formula.isEmpty()) {
            TextView fTv = textDirect("• " + formula, 11, false);
            fTv.setTextColor(colorSub());
            fTv.setPadding(dp(4), dp(1), 0, 0);
            row.addView(fTv);
        }

        View div = new View(this);
        div.setBackgroundColor(colorBorder());
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(-1, dp(1));
        divLp.setMargins(0, dp(6), 0, 0);
        row.addView(div, divLp);

        parent.addView(row);
    }


    double parseHours(String s) {
        if (s == null) return 0;
        String t = s.trim();
        if (t.isEmpty()) return 0;
        try {
            return Double.parseDouble(t);
        } catch (Exception e) {
            return 0;
        }
    }

    EditText createNumberInput(String hint) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setHint(hint);
        e.setTextColor(colorInk());
        e.setHintTextColor(colorSub());
        e.setBackground(null);
        e.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        e.setPadding(dp(4), dp(4), dp(4), dp(4));
        return e;
    }

    void addLabeledInput(LinearLayout parent, String label, EditText input, String unit, float weight) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(4), 0, dp(4), 0);

        TextView lbl = textDirect(label, 11, true);
        lbl.setTextColor(colorSub());
        col.addView(lbl);

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setBackground(cellBg(isDark() ? Color.rgb(18, 30, 48) : Color.WHITE, colorBorder(), dp(1)));
        wrap.setPadding(dp(6), dp(2), dp(8), dp(2));
        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(-1, dp(38));
        wrapLp.setMargins(0, dp(4), 0, 0);

        wrap.addView(input, new LinearLayout.LayoutParams(0, -1, 1f));

        if (unit != null && !unit.isEmpty()) {
            TextView uTv = textDirect(unit, 12, true);
            uTv.setTextColor(colorSub());
            uTv.setPadding(dp(4), 0, 0, 0);
            wrap.addView(uTv);
        }

        col.addView(wrap, wrapLp);
        parent.addView(col, new LinearLayout.LayoutParams(0, -2, weight));
    }

    LinearLayout createSectionCard(String title, String badgeText, int accentColor, int bgColor, int borderColor) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(cellBg(bgColor, borderColor, dp(1)));
        card.setPadding(dp(12), dp(10), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(lp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, 0, 0, dp(8));

        TextView titleTv = textDirect(title, 13, true);
        titleTv.setTextColor(accentColor);
        head.addView(titleTv, new LinearLayout.LayoutParams(0, -2, 1f));

        if (badgeText != null && !badgeText.isEmpty()) {
            TextView badge = textDirect(badgeText, 10, true);
            badge.setTextColor(accentColor);
            GradientDrawable bbg = new GradientDrawable();
            bbg.setColor(isDark() ? Color.argb(80, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)) : Color.argb(30, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)));
            bbg.setCornerRadius(dp(8));
            badge.setBackground(bbg);
            badge.setPadding(dp(6), dp(2), dp(6), dp(2));
            head.addView(badge);
        }

        card.addView(head);
        return card;
    }

    void addQuickChip(LinearLayout parent, String label, int accentColor, Runnable action) {
        TextView chip = textDirect(label, 11, true);
        chip.setTextColor(accentColor);
        chip.setBackground(cellBg(isDark() ? Color.rgb(20, 32, 50) : Color.WHITE, isDark() ? Color.rgb(35, 60, 100) : Color.rgb(220, 230, 245), dp(1)));
        chip.setPadding(dp(10), dp(6), dp(10), dp(6));
        chip.setOnClickListener(v -> action.run());

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, dp(6), 0);
        parent.addView(chip, lp);
    }

    // 초단시간 근무 태그: 메모에 적힌 '조퇴'/'외출'을 달력 뱃지 문구로 바꾼다
    static String memoTag(String memo) {
        if (memo == null) return "";
        if (memo.contains("조퇴")) return "💊조퇴";
        if (memo.contains("외출")) return "🚶외출";
        return "";
    }

    // 태그 낱말을 걷어낸 나머지 메모 (달력 아래 ✎ 줄에 중복 표기하지 않도록)
    static String memoTextOnly(String memo) {
        if (memo == null) return "";
        String s = memo.replace("💊", "").replace("🚶", "").replace("조퇴", "").replace("외출", "");
        s = s.replaceAll("[\\s,]+", " ").trim();
        return s;
    }

    String dayStr(int day) {
        return ym() + "-" + String.format(Locale.US, "%02d", day);
    }

    void showDay(int day) {
        start("세부 시간 직접 입력");
        int wd = weekday(day);
        boolean weekend = isWeekend(day, wd);
        String dateStr = ym() + "-" + String.format(Locale.US, "%02d", day);

        // 상단 날짜 뱃지 행
        LinearLayout dateBadgeRow = new LinearLayout(this);
        dateBadgeRow.setOrientation(LinearLayout.HORIZONTAL);
        dateBadgeRow.setGravity(Gravity.CENTER_VERTICAL);
        dateBadgeRow.setPadding(0, 0, 0, dp(10));

        TextView dateBadge = textDirect(dateStr, 12, true);
        dateBadge.setTextColor(colorBlue());
        dateBadge.setBackground(cellBg(isDark() ? Color.rgb(20, 36, 64) : Color.rgb(235, 244, 255), colorBlue(), dp(1)));
        dateBadge.setPadding(dp(10), dp(4), dp(10), dp(4));
        dateBadgeRow.addView(dateBadge);

        String curMode = dayMode(day);
        if (weekend) {
            String rule = (wd == Calendar.SATURDAY) ? "토요일 (자동 유급 8h)" : "일요일 (자동 주차 8h)";
            TextView ruleTv = textDirect("  " + rule, 11, false);
            ruleTv.setTextColor(colorSub());
            dateBadgeRow.addView(ruleTv);
        }
        root.addView(dateBadgeRow);

        // 1. 빠른 프리셋 칩 (가로 스크롤)
        HorizontalScrollView chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chipRow.setPadding(0, 0, 0, dp(12));

        EditText normEt = createNumberInput("8");
        EditText paidEt = createNumberInput("0");
        EditText otEt = createNumberInput("0");
        EditText holEt = createNumberInput("0");
        EditText holOtEt = createNumberInput("0");
        EditText nightEt = createNumberInput("0");
        EditText gageubEt = createNumberInput("1.0");
        EditText memoEt = new EditText(this);
        memoEt.setInputType(InputType.TYPE_CLASS_TEXT);
        memoEt.setTextSize(13);
        memoEt.setHint("예: 설명회, 조퇴");
        memoEt.setTextColor(colorInk());
        memoEt.setHintTextColor(colorSub());
        memoEt.setBackground(cellBg(isDark() ? Color.rgb(18, 30, 48) : Color.WHITE, colorBorder(), dp(1)));
        memoEt.setPadding(dp(8), dp(6), dp(8), dp(6));

        // ── 초단시간 근무 태그 (v1.3.3 1안): [💊 조퇴]·[🚶 외출]을 누르면 메모에 자동 반영 ──
        LinearLayout tagRow = new LinearLayout(this);
        tagRow.setOrientation(LinearLayout.HORIZONTAL);
        tagRow.setGravity(Gravity.CENTER_VERTICAL);
        tagRow.setPadding(0, 0, 0, dp(10));

        TextView tagHint = textDirect("초단시간 태그", 11, true);
        tagHint.setTextColor(colorSub());
        tagRow.addView(tagHint);

        final TextView[] tagChips = new TextView[2];
        final String[] tagWords = {"조퇴", "외출"};
        final String[] tagLabels = {"💊 조퇴", "🚶 외출"};
        for (int ti = 0; ti < 2; ti++) {
            final int idx = ti;
            TextView chip = textDirect(tagLabels[ti], 12, true);
            chip.setPadding(dp(11), dp(6), dp(11), dp(6));
            chip.setClickable(true);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
            clp.setMargins(dp(6), 0, 0, 0);
            chip.setOnClickListener(v -> {
                vibrateTick();
                String cur = memoEt.getText().toString();
                String word = tagWords[idx];
                StringBuilder sb = new StringBuilder();
                for (String part : cur.replace("💊", "").replace("🚶", "").split("[,/]")) {
                    String p = part.trim();
                    if (p.isEmpty() || p.equals("조퇴") || p.equals("외출")) continue;
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(p);
                }
                if (!cur.contains(word)) {
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(word);
                }
                memoEt.setText(sb.toString());
            });
            tagChips[ti] = chip;
            tagRow.addView(chip, clp);
        }

        final Runnable refreshTags = () -> {
            String memoNow = memoEt.getText().toString();
            for (int ti = 0; ti < 2; ti++) {
                boolean on = memoNow.contains(tagWords[ti]);
                boolean early = ti == 0;
                int toneBgC = isDark() ? (early ? Color.rgb(58, 32, 10) : Color.rgb(10, 44, 68))
                                       : (early ? Color.rgb(255, 247, 237) : Color.rgb(240, 249, 255));
                int toneBdC = isDark() ? (early ? Color.rgb(194, 65, 12) : Color.rgb(3, 105, 161))
                                       : (early ? Color.rgb(253, 186, 116) : Color.rgb(125, 211, 252));
                int toneTxC = isDark() ? (early ? Color.rgb(253, 186, 116) : Color.rgb(125, 211, 252))
                                       : (early ? Color.rgb(194, 65, 12) : Color.rgb(3, 105, 161));
                if (on) {
                    tagChips[ti].setBackground(cellBg(toneTxC, toneTxC, dp(1)));
                    tagChips[ti].setTextColor(Color.WHITE);
                } else {
                    tagChips[ti].setBackground(cellBg(toneBgC, toneBdC, dp(1)));
                    tagChips[ti].setTextColor(toneTxC);
                }
            }
        };
        memoEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) { refreshTags.run(); }
        });
        refreshTags.run();          // 첫 화면에서도 선택 상태 색을 바로 적용
        root.addView(tagRow);

        TextView liveTotalTv = textDirect("0.0h", 16, true);
        liveTotalTv.setTextColor(colorBlue());

        Runnable updateLiveTotal = () -> {
            double n = parseHours(normEt.getText().toString());
            double p = parseHours(paidEt.getText().toString());
            double o = parseHours(otEt.getText().toString());
            double h = parseHours(holEt.getText().toString());
            double ho = parseHours(holOtEt.getText().toString());
            double total = n + p + o + h + ho;
            liveTotalTv.setText(String.format(Locale.US, "%.1fh", total));
        };

        TextWatcher watcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) { updateLiveTotal.run(); }
        };
        normEt.addTextChangedListener(watcher);
        paidEt.addTextChangedListener(watcher);
        otEt.addTextChangedListener(watcher);
        holEt.addTextChangedListener(watcher);
        holOtEt.addTextChangedListener(watcher);

        boolean isShift = isShiftWorker();

        addQuickChip(chipRow, "● 주간 정상 (8h)", Color.rgb(2, 132, 199), () -> {
            vibrateTick();
            normEt.setText("8"); paidEt.setText("0"); otEt.setText("0");
            holEt.setText("0"); holOtEt.setText("0"); nightEt.setText("0");
            gageubEt.setText(isShift ? "0" : "1.0");
            updateLiveTotal.run();
        });
        addQuickChip(chipRow, "⚡ 주간 연장 (10h)", Color.rgb(217, 119, 6), () -> {
            vibrateTick();
            normEt.setText("8"); paidEt.setText("0"); otEt.setText("2");
            holEt.setText("0"); holOtEt.setText("0"); nightEt.setText("0");
            gageubEt.setText(isShift ? "0" : "1.0");
            updateLiveTotal.run();
        });
        addQuickChip(chipRow, "🌙 야간 10h", Color.rgb(124, 58, 237), () -> {
            vibrateTick();
            normEt.setText("8"); paidEt.setText("0"); otEt.setText("2");
            holEt.setText("0"); holOtEt.setText("0"); nightEt.setText("7.5");
            gageubEt.setText("0");
            updateLiveTotal.run();
        });
        addQuickChip(chipRow, "🔥 휴일 특근 (8h)", Color.rgb(220, 38, 38), () -> {
            vibrateTick();
            normEt.setText("0"); paidEt.setText("0"); otEt.setText("0");
            holEt.setText("8"); holOtEt.setText("0"); nightEt.setText("0");
            gageubEt.setText("0");
            updateLiveTotal.run();
        });
        if (isShift) {
            // 교대조 휴일 야간특근 10h — 실물 출근카드(휴일근로 10.00 · 심야 3.500)와 같은 값
            addQuickChip(chipRow, "🔥🌙 야간특근 10h", Color.rgb(220, 38, 38), () -> {
                vibrateTick();
                normEt.setText("0"); paidEt.setText("0"); otEt.setText("0");
                holEt.setText("8"); holOtEt.setText("2"); nightEt.setText("3.5");
                gageubEt.setText("0");
                updateLiveTotal.run();
            });
        }
        addQuickChip(chipRow, "🌴 연차 유급", Color.rgb(5, 150, 105), () -> {
            vibrateTick();
            normEt.setText("0"); paidEt.setText("8"); otEt.setText("0");
            holEt.setText("0"); holOtEt.setText("0"); nightEt.setText("0");
            gageubEt.setText("0");
            updateLiveTotal.run();
        });
        addQuickChip(chipRow, "↺ 0시간 초기화", colorSub(), () -> {
            vibrateTick();
            normEt.setText("0"); paidEt.setText("0"); otEt.setText("0");
            holEt.setText("0"); holOtEt.setText("0"); nightEt.setText("0");
            gageubEt.setText("0"); memoEt.setText("");
            updateLiveTotal.run();
        });
        chipScroll.addView(chipRow);
        root.addView(chipScroll);

        // 기존 저장값 불러오기
        String savedNorm = prefs.getString(dayKey(day, keys[0]), "");
        String savedPaid = prefs.getString(dayKey(day, keys[1]), "");
        String savedOt = prefs.getString(dayKey(day, keys[4]), "");
        String savedHol = prefs.getString(dayKey(day, keys[5]), "");
        String savedHolOt = prefs.getString(dayKey(day, keys[6]), "");
        String savedNight = prefs.getString(dayKey(day, keys[7]), "");
        String savedGageub = prefs.getString(dayKey(day, keys[8]), "");
        String savedMemo = prefs.getString(dayKey(day, "memo"), "");

        if (!savedNorm.isEmpty()) normEt.setText(savedNorm);
        else if (curMode.equals("auto") && !weekend) normEt.setText("8");
        else if (curMode.equals("work")) normEt.setText("8");
        else normEt.setText("0");

        if (!savedPaid.isEmpty()) paidEt.setText(savedPaid);
        else if (curMode.equals("annual") || curMode.equals("summer")) paidEt.setText("8");
        else if (curMode.equals("auto") && weekend) paidEt.setText("8");
        else paidEt.setText("0");

        if (!savedOt.isEmpty()) otEt.setText(savedOt);
        else otEt.setText("0");

        if (!savedHol.isEmpty()) holEt.setText(savedHol);
        else holEt.setText("0");

        if (!savedHolOt.isEmpty()) holOtEt.setText(savedHolOt);
        else holOtEt.setText("0");

        if (!savedNight.isEmpty()) nightEt.setText(savedNight);
        else nightEt.setText("0");

        if (!savedGageub.isEmpty()) gageubEt.setText(savedGageub);
        else if (curMode.equals("auto") && !weekend && !isShift) gageubEt.setText("1.0");
        else gageubEt.setText(isShift ? "0" : "1.0");

        if (!savedMemo.isEmpty()) memoEt.setText(savedMemo);

        // 1. 기본 정상근무 카드 (Blue)
        LinearLayout c1 = createSectionCard("1. 기본 정상근무", "기본 1.0배", Color.rgb(2, 132, 199),
            isDark() ? Color.rgb(12, 34, 56) : Color.rgb(240, 249, 255),
            isDark() ? Color.rgb(7, 89, 133) : Color.rgb(186, 230, 253));
        LinearLayout c1Grid = new LinearLayout(this);
        c1Grid.setOrientation(LinearLayout.HORIZONTAL);
        addLabeledInput(c1Grid, "정상근무 (정취)", normEt, "h", 1f);
        addLabeledInput(c1Grid, "유급 / 주차 인정", paidEt, "h", 1f);
        c1.addView(c1Grid);
        root.addView(c1);

        // 2. 평일 연장근무 카드 (Amber)
        LinearLayout c2 = createSectionCard("2. 평일 연장근무", "할증 1.5배", Color.rgb(217, 119, 6),
            isDark() ? Color.rgb(45, 32, 6) : Color.rgb(255, 251, 235),
            isDark() ? Color.rgb(120, 53, 15) : Color.rgb(253, 230, 138));
        LinearLayout c2Grid = new LinearLayout(this);
        c2Grid.setOrientation(LinearLayout.HORIZONTAL);
        addLabeledInput(c2Grid, "평일 연장 (조합설명회 인정 포함)", otEt, "h", 1f);
        c2.addView(c2Grid);
        root.addView(c2);

        // 3. 휴일 특근근무 카드 (Rose)
        LinearLayout c3 = createSectionCard("3. 휴일 특근근무", "특근 1.5배 / 연장 2.0배", Color.rgb(220, 38, 38),
            isDark() ? Color.rgb(51, 17, 20) : Color.rgb(255, 241, 242),
            isDark() ? Color.rgb(136, 19, 55) : Color.rgb(254, 205, 211));
        LinearLayout c3Grid = new LinearLayout(this);
        c3Grid.setOrientation(LinearLayout.HORIZONTAL);
        addLabeledInput(c3Grid, "휴일 특근 (최대 8h)", holEt, "h", 1f);
        addLabeledInput(c3Grid, "특근 연장 (8h 초과분)", holOtEt, "h", 1f);
        c3.addView(c3Grid);
        root.addView(c3);

        // 4. 야간 및 심야할증 카드 (Purple)
        LinearLayout c4 = createSectionCard("4. 야간 및 심야할증", "0.5배 가산 (22~06시)", Color.rgb(124, 58, 237),
            isDark() ? Color.rgb(38, 20, 59) : Color.rgb(250, 245, 255),
            isDark() ? Color.rgb(88, 28, 135) : Color.rgb(233, 213, 255));
        LinearLayout c4Grid = new LinearLayout(this);
        c4Grid.setOrientation(LinearLayout.HORIZONTAL);
        addLabeledInput(c4Grid, "심야 근로시간 (야간조 10h 시 7.5h)", nightEt, "h", 1f);
        c4.addView(c4Grid);
        root.addView(c4);

        // 5. 가급 & 특이사항 메모 카드 (Emerald)
        LinearLayout c5 = createSectionCard("5. 가급 & 특이사항 메모", "상주휴게 가급", Color.rgb(5, 150, 105),
            isDark() ? Color.rgb(6, 42, 30) : Color.rgb(236, 253, 245),
            isDark() ? Color.rgb(6, 95, 70) : Color.rgb(167, 243, 208));
        LinearLayout c5Grid = new LinearLayout(this);
        c5Grid.setOrientation(LinearLayout.HORIZONTAL);
        addLabeledInput(c5Grid, "상주휴게 가급", gageubEt, "h", 1f);

        LinearLayout memoCol = new LinearLayout(this);
        memoCol.setOrientation(LinearLayout.VERTICAL);
        memoCol.setPadding(dp(4), 0, dp(4), 0);
        TextView memoLbl = textDirect("특이사항 메모", 11, true);
        memoLbl.setTextColor(colorSub());
        memoCol.addView(memoLbl);
        LinearLayout.LayoutParams memoLp = new LinearLayout.LayoutParams(-1, dp(38));
        memoLp.setMargins(0, dp(4), 0, 0);
        memoCol.addView(memoEt, memoLp);
        c5Grid.addView(memoCol, new LinearLayout.LayoutParams(0, -2, 1.2f));
        c5.addView(c5Grid);
        root.addView(c5);

        // 실시간 총 근로시간 집계 바
        LinearLayout totalBar = new LinearLayout(this);
        totalBar.setOrientation(LinearLayout.HORIZONTAL);
        totalBar.setGravity(Gravity.CENTER_VERTICAL);
        totalBar.setBackground(cellBg(isDark() ? Color.rgb(20, 36, 64) : Color.rgb(238, 245, 255), isDark() ? Color.rgb(35, 65, 115) : Color.rgb(186, 220, 255), dp(1)));
        totalBar.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams tbLp = new LinearLayout.LayoutParams(-1, -2);
        tbLp.setMargins(0, dp(6), 0, dp(14));

        TextView tbTitle = textDirect("당일 총 인정 근로시간", 13, true);
        tbTitle.setTextColor(colorBlue());
        totalBar.addView(tbTitle, new LinearLayout.LayoutParams(0, -2, 1f));

        totalBar.addView(liveTotalTv);
        root.addView(totalBar, tbLp);

        // 액션 버튼 행 (취소 & 저장)
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setPadding(0, 0, 0, dp(24));

        Button cancelBtn = button("취소", this::showMain);
        cancelBtn.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        cancelBtn.setTextColor(colorSub());
        cancelBtn.setTextSize(14);
        cancelBtn.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, -2, 1f);
        cancelLp.setMargins(0, 0, dp(6), 0);
        actionRow.addView(cancelBtn, cancelLp);

        Button saveBtn = button("✓ 설정 저장하기", () -> {
            vibrateTick();
            SharedPreferences.Editor ed = prefs.edit();

            double nVal = parseHours(normEt.getText().toString());
            double pVal = parseHours(paidEt.getText().toString());
            double oVal = parseHours(otEt.getText().toString());
            double hVal = parseHours(holEt.getText().toString());
            double hoVal = parseHours(holOtEt.getText().toString());
            double niVal = parseHours(nightEt.getText().toString());
            double gVal = parseHours(gageubEt.getText().toString());
            String memoVal = memoEt.getText().toString().trim();

            if (nVal > 0) ed.putString(dayKey(day, keys[0]), Double.toString(nVal));
            else ed.remove(dayKey(day, keys[0]));

            if (pVal > 0) ed.putString(dayKey(day, keys[1]), Double.toString(pVal));
            else ed.remove(dayKey(day, keys[1]));

            if (oVal > 0) ed.putString(dayKey(day, keys[4]), Double.toString(oVal));
            else ed.remove(dayKey(day, keys[4]));

            if (hVal > 0) ed.putString(dayKey(day, keys[5]), Double.toString(hVal));
            else ed.remove(dayKey(day, keys[5]));

            if (hoVal > 0) ed.putString(dayKey(day, keys[6]), Double.toString(hoVal));
            else ed.remove(dayKey(day, keys[6]));

            if (niVal > 0) ed.putString(dayKey(day, keys[7]), Double.toString(niVal));
            else ed.remove(dayKey(day, keys[7]));

            if (gVal > 0) ed.putString(dayKey(day, keys[8]), Double.toString(gVal));
            else ed.remove(dayKey(day, keys[8]));

            if (!memoVal.isEmpty()) ed.putString(dayKey(day, "memo"), memoVal);
            else ed.remove(dayKey(day, "memo"));

            double totalWork = nVal + pVal + oVal + hVal + hoVal;
            if (pVal > 0 && nVal == 0 && oVal == 0 && hVal == 0) {
                ed.putString(dayKey(day, "mode"), "annual");
            } else if (totalWork > 0) {
                ed.putString(dayKey(day, "mode"), "work");
            } else {
                ed.putString(dayKey(day, "mode"), "none");
            }

            ed.apply();
            triggerAutoBackup();
            Toast.makeText(this, dayStr(day) + " 근무 설정이 저장되었습니다.", Toast.LENGTH_SHORT).show();
            showMain();
        });
        saveBtn.setBackground(cellBg(colorBlue(), colorBlue(), dp(1)));
        saveBtn.setTextColor(Color.WHITE);
        saveBtn.setTextSize(14);
        saveBtn.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(0, -2, 2f);
        saveLp.setMargins(dp(6), 0, 0, 0);
        actionRow.addView(saveBtn, saveLp);

        root.addView(actionRow);

        updateLiveTotal.run();
    }

    // 급여 및 화면 설정 화면 (2열 그리드 재배분 + 제목/숫자입력칸 색상 명확 구분) (요청사항 4 반영)

    void confirmResetSettings(EditText nameEt, EditText birthEt, EditText joinEt, EditText deptEt, EditText annualEt, Button rankBtn, EditText[] fields, TextView ddayBanner) {
        new AlertDialog.Builder(this)
            .setTitle("⚙️ 설정 내용 리셋")
            .setMessage("나의 기본정보와 아래 입력된 모든 급여/수당 설정값을 빈칸으로 리셋할까요?")
            .setPositiveButton("빈칸으로 리셋", (d, w) -> {
                vibrateTick();
                if (nameEt != null) nameEt.setText("");
                if (birthEt != null) birthEt.setText("");
                if (joinEt != null) joinEt.setText("");
                if (deptEt != null) deptEt.setText("");
                if (annualEt != null) annualEt.setText("");
                if (rankBtn != null) rankBtn.setText("직급 선택 (터치)");
                if (ddayBanner != null) ddayBanner.setText("입사년월일과 생년월일을 입력해 주세요.");

                if (fields != null) {
                    for (EditText f : fields) {
                        if (f != null) f.setText("");
                    }
                }

                SharedPreferences.Editor ed = prefs.edit();
                ed.remove("user_name");
                ed.remove("user_birth");
                ed.remove("user_join_date");
                ed.remove("user_dept");
                ed.remove("user_rank");
                ed.remove("user_annual_leave_base");
                for (String k : settingsKeys) {
                    ed.putString("setting_" + k, "");
                    for (int y = 2018; y <= 2036; y++) {
                        ed.remove("setting_" + y + "_" + k);
                    }
                }
                ed.apply();

                Toast.makeText(this, "모든 입력 내용이 빈칸으로 리셋되었습니다.", Toast.LENGTH_SHORT).show();
            })
            .setNeutralButton("2026 단협 기본값 복구", (d, w) -> {
                vibrateTick();
                // 개인정보는 복구하지 않고 공란 유지! (단협 시급/수당 기본값만 복구)
                if (nameEt != null) nameEt.setText("");
                if (birthEt != null) birthEt.setText("");
                if (joinEt != null) joinEt.setText("");
                if (deptEt != null) deptEt.setText("");
                if (annualEt != null) annualEt.setText("15");
                if (rankBtn != null) rankBtn.setText("직급 선택 ▾");
                if (ddayBanner != null) ddayBanner.setText(getCombinedDdayBannerText("", ""));

                SharedPreferences.Editor ed = prefs.edit();
                ed.remove("user_name");
                ed.remove("user_birth");
                ed.remove("user_join_date");
                ed.remove("user_dept");
                ed.remove("user_rank");
                ed.putFloat("user_annual_leave_base", 15.0f);
                int defYear = month.get(Calendar.YEAR);
                for (int i = 0; i < settingsKeys.length; i++) {
                    ed.putString("setting_" + settingsKeys[i], String.valueOf(defaults[i]));
                    ed.putString("setting_" + defYear + "_" + settingsKeys[i], String.valueOf(defaults[i]));
                    if (fields != null && fields[i] != null) {
                        fields[i].setText(String.valueOf(defaults[i]));
                    }
                }
                ed.apply();
                Toast.makeText(this, "2026년 단체협약 기본값으로 복구되었습니다.", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("취소", null)
            .show();
    }

    void showSettings() {
        try {
            start("급여 및 화면 설정");

        // 1. 나의 기본정보 카드 (성명, 생년월일, 입사년월일, 소속부서, 근무공장, 직급, 기준연차, 정년/근속/연차 배너) (요청사항 1 반영)
        LinearLayout infoCard = new LinearLayout(this);
        infoCard.setOrientation(LinearLayout.VERTICAL);
        infoCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        infoCard.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView infoTitle = textDirect("👤 나의 기본정보", 16, true);
        infoTitle.setTextColor(colorBlue());
        infoCard.addView(infoTitle);

        // 1행: 이름 & 생년월일
        LinearLayout rInfo1 = new LinearLayout(this);
        rInfo1.setOrientation(LinearLayout.HORIZONTAL);
        rInfo1.setPadding(0, dp(8), 0, dp(4));

        LinearLayout nameCol = new LinearLayout(this);
        nameCol.setOrientation(LinearLayout.VERTICAL);
        TextView nameLbl = textDirect("성명 (이름)", 12, true);
        nameLbl.setTextColor(colorSub());
        nameCol.addView(nameLbl);
        EditText nameEt = new EditText(this);
        nameEt.setText(prefs.getString("user_name", ""));
        nameEt.setHint("예: 홍길동");
        nameEt.setTextSize(14);
        nameEt.setTextColor(colorInk());
        nameEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        nameEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        nameCol.addView(nameEt);
        rInfo1.addView(nameCol, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout birthCol = new LinearLayout(this);
        birthCol.setOrientation(LinearLayout.VERTICAL);
        birthCol.setPadding(dp(8), 0, 0, 0);
        TextView birthLbl = textDirect("생년월일 (8자리 숫자)", 12, true);
        birthLbl.setTextColor(colorSub());
        birthCol.addView(birthLbl);
        EditText birthEt = new EditText(this);
        birthEt.setInputType(InputType.TYPE_CLASS_PHONE);
        birthEt.setText(prefs.getString("user_birth", ""));
        birthEt.setHint("예: 19800101");
        birthEt.setTextSize(14);
        birthEt.setTextColor(colorInk());
        birthEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        birthEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        birthCol.addView(birthEt);
        rInfo1.addView(birthCol, new LinearLayout.LayoutParams(0, -2, 1f));

        infoCard.addView(rInfo1);

        // 2행: 입사년월일 & 소속부서
        LinearLayout rInfo2 = new LinearLayout(this);
        rInfo2.setOrientation(LinearLayout.HORIZONTAL);
        rInfo2.setPadding(0, dp(4), 0, dp(4));

        LinearLayout joinCol = new LinearLayout(this);
        joinCol.setOrientation(LinearLayout.VERTICAL);
        TextView joinLbl = textDirect("입사년월일 (8자리 숫자)", 12, true);
        joinLbl.setTextColor(colorSub());
        joinCol.addView(joinLbl);
        EditText joinEt = new EditText(this);
        joinEt.setInputType(InputType.TYPE_CLASS_PHONE);
        joinEt.setText(prefs.getString("user_join_date", ""));
        joinEt.setHint("예: 20200101");
        joinEt.setTextSize(14);
        joinEt.setTextColor(colorInk());
        joinEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        joinEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        joinCol.addView(joinEt);
        rInfo2.addView(joinCol, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout deptCol = new LinearLayout(this);
        deptCol.setOrientation(LinearLayout.VERTICAL);
        deptCol.setPadding(dp(8), 0, 0, 0);
        TextView deptLbl = textDirect("소속부서", 12, true);
        deptLbl.setTextColor(colorSub());
        deptCol.addView(deptLbl);
        EditText deptEt = new EditText(this);
        deptEt.setText(prefs.getString("user_dept", ""));
        deptEt.setHint("예: 생산1팀");
        deptEt.setTextSize(14);
        deptEt.setTextColor(colorInk());
        deptEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        deptEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        deptCol.addView(deptEt);
        rInfo2.addView(deptCol, new LinearLayout.LayoutParams(0, -2, 1f));

        infoCard.addView(rInfo2);

        // 3행: 근무공장 & 직급
        LinearLayout rInfo3 = new LinearLayout(this);
        rInfo3.setOrientation(LinearLayout.HORIZONTAL);
        rInfo3.setPadding(0, dp(4), 0, dp(4));

        LinearLayout factoryCol = new LinearLayout(this);
        factoryCol.setOrientation(LinearLayout.VERTICAL);
        TextView factoryLbl = textDirect("근무 공장 (선택)", 12, true);
        factoryLbl.setTextColor(colorSub());
        factoryCol.addView(factoryLbl);
        Button factorySelectBtn = button(getFactoryName(), () -> showFactorySelectorDialog());
        factorySelectBtn.setTextSize(13);
        factorySelectBtn.setTextColor(colorBlue());
        factorySelectBtn.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        factorySelectBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
        factoryCol.addView(factorySelectBtn);
        rInfo3.addView(factoryCol, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout rankCol = new LinearLayout(this);
        rankCol.setOrientation(LinearLayout.VERTICAL);
        rankCol.setPadding(dp(8), 0, 0, 0);
        TextView rankLbl = textDirect("직급 (직책수당 연동)", 12, true);
        rankLbl.setTextColor(colorSub());
        rankCol.addView(rankLbl);
        String currentRank = prefs.getString("user_rank", "직급 선택 ▾");
        Button rankBtn = button(currentRank, null);
        rankBtn.setTextSize(13);
        rankBtn.setTextColor(colorBlue());
        rankBtn.setBackground(cellBg(isDark() ? Color.rgb(28, 42, 68) : Color.rgb(228, 238, 252), colorBlue(), dp(1)));
        rankBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
        rankCol.addView(rankBtn);
        rInfo3.addView(rankCol, new LinearLayout.LayoutParams(0, -2, 1f));

        infoCard.addView(rInfo3);

        // 3.5행: 근무 형태 설정 (상주근무 / 교대근무)
        LinearLayout rInfoShift = new LinearLayout(this);
        rInfoShift.setOrientation(LinearLayout.HORIZONTAL);
        rInfoShift.setGravity(Gravity.CENTER_VERTICAL);
        rInfoShift.setPadding(0, dp(4), 0, dp(6));

        LinearLayout shiftCol = new LinearLayout(this);
        shiftCol.setOrientation(LinearLayout.VERTICAL);
        TextView shiftLbl = textDirect("근무 형태 (수당 및 프리셋 연동)", 12, true);
        shiftLbl.setTextColor(colorSub());
        shiftCol.addView(shiftLbl);

        Button shiftBtn = button(isShiftWorker() ? "🔄 교대근무 (주야 10h • 교대수당 20만원) ▾" : "🏢 상주근무 (주간 8h • 상주휴게수당) ▾", null);
        shiftBtn.setTextSize(13);
        shiftBtn.setTextColor(colorBlue());
        shiftBtn.setBackground(cellBg(isDark() ? Color.rgb(28, 42, 68) : Color.rgb(228, 238, 252), colorBlue(), dp(1)));
        shiftBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
        shiftBtn.setOnClickListener(v -> showShiftTypeSelectorDialog(shiftBtn));
        shiftCol.addView(shiftBtn);
        rInfoShift.addView(shiftCol, new LinearLayout.LayoutParams(-1, -2));

        infoCard.addView(rInfoShift);

        // 3.6행: 임단협 소급분 설정 버튼
        LinearLayout rInfoRetro = new LinearLayout(this);
        rInfoRetro.setOrientation(LinearLayout.HORIZONTAL);
        rInfoRetro.setGravity(Gravity.CENTER_VERTICAL);
        rInfoRetro.setPadding(0, dp(4), 0, dp(6));

        LinearLayout retroCol = new LinearLayout(this);
        retroCol.setOrientation(LinearLayout.VERTICAL);
        TextView retroLbl = textDirect("임단협 소급분 (타결 시급 인상 및 반영월)", 12, true);
        retroLbl.setTextColor(colorSub());
        retroCol.addView(retroLbl);

        Button retroSettingBtn = button("💰 2026 임단협 소급분 설정 (" + (int)(getRetroPayAmount()/10000) + "만 원) ❯", this::showRetroPaySettingsDialog);
        retroSettingBtn.setTextSize(13);
        retroSettingBtn.setTextColor(Color.rgb(180, 100, 0));
        retroSettingBtn.setBackground(cellBg(isDark() ? Color.rgb(44, 34, 18) : Color.rgb(255, 246, 224), Color.rgb(230, 160, 40), dp(1)));
        retroSettingBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
        retroCol.addView(retroSettingBtn);
        rInfoRetro.addView(retroCol, new LinearLayout.LayoutParams(-1, -2));

        infoCard.addView(rInfoRetro);

        // 4행: 기준 연차 일수 설정
        LinearLayout rInfo4 = new LinearLayout(this);
        rInfo4.setOrientation(LinearLayout.HORIZONTAL);
        rInfo4.setGravity(Gravity.CENTER_VERTICAL);
        rInfo4.setPadding(0, dp(4), 0, dp(6));

        LinearLayout annualCol = new LinearLayout(this);
        annualCol.setOrientation(LinearLayout.VERTICAL);
        TextView annualLbl = textDirect("발생연차수 (급여명세서 발생 연차)", 12, true);
        annualLbl.setTextColor(colorSub());
        annualCol.addView(annualLbl);

        EditText annualEt = new EditText(this);
        float currentBaseAnnual = getBaseAnnualLeave();
        String currentBaseStr = (currentBaseAnnual == (long)currentBaseAnnual) ? String.valueOf((long)currentBaseAnnual) : String.format(Locale.US, "%.1f", currentBaseAnnual);
        annualEt.setText(currentBaseStr);
        annualEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        annualEt.setTextSize(14);
        annualEt.setTextColor(colorInk());
        annualEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        annualEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        annualCol.addView(annualEt);
        rInfo4.addView(annualCol, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout annualNoteCol = new LinearLayout(this);
        annualNoteCol.setOrientation(LinearLayout.VERTICAL);
        annualNoteCol.setPadding(dp(8), 0, 0, 0);
        TextView annualNoteTv = textDirect("💡 명세서의 [발생] 칸을 촬영하면 발생연차수가, [잔여] 칸을 읽으면 잔여 연차가 자동 입력됩니다. 캘린더 연차 등록 시 자동 차감됩니다.", 11, false);
        annualNoteTv.setTextColor(colorSub());
        annualNoteCol.addView(annualNoteTv);
        rInfo4.addView(annualNoteCol, new LinearLayout.LayoutParams(0, -2, 1.2f));

        infoCard.addView(rInfo4);

        // 노란색 배너: 만 60세 정년 퇴직 D-Day + 입사년차 및 근속일수 + 현재 남은 연차 일수 (3줄) (요청사항 1 반영)
        TextView retireDdayBanner = textDirect(getCombinedDdayBannerText(birthEt.getText().toString(), joinEt.getText().toString()), 13, true);
        retireDdayBanner.setTextColor(isDark() ? Color.rgb(250, 204, 21) : Color.rgb(180, 83, 9));
        retireDdayBanner.setBackground(cellBg(isDark() ? Color.rgb(36, 32, 20) : Color.rgb(254, 249, 195), isDark() ? Color.rgb(161, 98, 7) : Color.rgb(251, 191, 36), dp(1)));
        retireDdayBanner.setPadding(dp(12), dp(10), dp(12), dp(10));
        retireDdayBanner.setGravity(Gravity.CENTER);
        retireDdayBanner.setLineSpacing(dp(3), 1.15f);
        LinearLayout.LayoutParams ddayLp = new LinearLayout.LayoutParams(-1, -2);
        ddayLp.setMargins(0, dp(6), 0, 0);
        infoCard.addView(retireDdayBanner, ddayLp);

        // 텍스트 실시간 저장 리스너
        nameEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int count, int after) {}
            public void afterTextChanged(Editable s) {
                prefs.edit().putString("user_name", s.toString().trim()).apply();
            }
        });

        birthEt.addTextChangedListener(new DateAutoHyphenWatcher(birthEt, () -> {
            String norm = normalizeDateString(birthEt.getText().toString());
            prefs.edit().putString("user_birth", norm).apply();
            retireDdayBanner.setText(getCombinedDdayBannerText(norm, joinEt.getText().toString()));
        }));

        joinEt.addTextChangedListener(new DateAutoHyphenWatcher(joinEt, () -> {
            String norm = normalizeDateString(joinEt.getText().toString());
            prefs.edit().putString("user_join_date", norm).apply();
            retireDdayBanner.setText(getCombinedDdayBannerText(birthEt.getText().toString(), norm));
        }));

        deptEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int count, int after) {}
            public void afterTextChanged(Editable s) {
                prefs.edit().putString("user_dept", s.toString().trim()).apply();
            }
        });

        annualEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int count, int after) {}
            public void afterTextChanged(Editable s) {
                try {
                    float f = Float.parseFloat(s.toString().trim());
                    prefs.edit().putFloat("user_annual_leave_base", f).apply();
                    retireDdayBanner.setText(getCombinedDdayBannerText(birthEt.getText().toString(), joinEt.getText().toString()));
                } catch (Exception ignored) {}
            }
        });

        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1, -2);
        infoLp.setMargins(0, 0, 0, dp(12));
        root.addView(infoCard, infoLp);

        // 근무 공장 드론 배너 카드 (다크모드 스위치 제거 후 동일 위치·사이즈 대체) (요청사항 2 반영)
        LinearLayout factoryCard = new LinearLayout(this);
        factoryCard.setOrientation(LinearLayout.VERTICAL);
        factoryCard.setGravity(Gravity.CENTER);
        factoryCard.setBackground(getFactoryBannerDrawable(dp(85), false));
        factoryCard.setPadding(dp(14), dp(16), dp(14), dp(16));
        factoryCard.setClickable(true);
        factoryCard.setOnClickListener(v -> showFactorySelectorDialog());

        TextView fTitle = textDirect("🏭 " + getFactoryName(), 17, true);
        fTitle.setTextColor(Color.WHITE);
        fTitle.setShadowLayer(dp(3), 0, dp(1), Color.argb(220, 0, 0, 0));
        fTitle.setGravity(Gravity.CENTER);
        factoryCard.addView(fTitle);

        TextView fSub = textDirect("터치하여 근무 공장 변경 (1·2·3공장 드론 항공사진 실시간 연동)", 12, false);
        fSub.setTextColor(Color.rgb(220, 238, 255));
        fSub.setShadowLayer(dp(2), 0, dp(1), Color.argb(200, 0, 0, 0));
        fSub.setGravity(Gravity.CENTER);
        fSub.setPadding(0, dp(4), 0, 0);
        factoryCard.addView(fSub);

        LinearLayout.LayoutParams factoryCardLp = new LinearLayout.LayoutParams(-1, -2);
        factoryCardLp.setMargins(0, 0, 0, dp(12));
        root.addView(factoryCard, factoryCardLp);

        TextView sectionTitle = textDirect("⚙️ 시급 및 수당 기준 (2026년 단협)", 15, true);
        sectionTitle.setTextColor(colorBlue());
        sectionTitle.setPadding(dp(4), dp(4), dp(4), dp(8));
        root.addView(sectionTitle);

        // 2열 그리드 레이아웃 (세로 스크롤 최소화)
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);

        final Runnable[] refreshFamLink = new Runnable[1];

        int[][] pairs = {
            {0, 1},   // 기본시급, 통상시급
            {2, 3},   // 평일연장 배율, 휴일근로 배율
            {4, 5},   // 휴일연장 배율, 야간 추가 배율
            {6, 9},   // 근속수당, 직책수당
            {7, 8},   // 가족수당(본인), 가족수당(가족)
            {10, 11}  // 직무수당, 하계건강지원비
        };

        EditText[] fields = new EditText[settingsKeys.length];

        rankBtn.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                .setTitle("직급 선택 (직책수당 자동 연동)")
                .setItems(RANK_NAMES, (d, which) -> {
                    vibrateTick();
                    String selectedRank = RANK_NAMES[which];
                    rankBtn.setText(selectedRank);
                    prefs.edit().putString("user_rank", selectedRank).apply();
                    int positionAmt = RANK_POSITION_AMOUNTS[which];
                    if (fields[9] != null) {
                        fields[9].setText(String.valueOf(positionAmt));
                    }
                    prefs.edit()
                        .putString("setting_position", String.valueOf(positionAmt))
                        .putString("setting_" + month.get(Calendar.YEAR) + "_position", String.valueOf(positionAmt))
                        .apply();
                    Toast.makeText(this, selectedRank + " 선택: 직책수당 " + won(positionAmt) + " (직무수당은 별도 유지)", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("취소", null)
                .show();
        });

        // 타이틀 우측 끝 리셋 버튼 (요청사항 반영: 누르면 아래 모든 내용 빈칸 리셋)
        if (subHeaderBar != null) {
            Button resetBtn = button("🔄 리셋", () -> confirmResetSettings(nameEt, birthEt, joinEt, deptEt, annualEt, rankBtn, fields, retireDdayBanner));
            resetBtn.setTextSize(12);
            resetBtn.setTextColor(colorRed());
            resetBtn.setBackground(cellBg(isDark() ? Color.rgb(40, 24, 24) : Color.rgb(254, 242, 242), colorRed(), dp(1)));
            resetBtn.setPadding(dp(10), dp(5), dp(10), dp(5));
            subHeaderBar.addView(resetBtn);
        }

        for (int[] pair : pairs) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            View v1 = createSettingField(pair[0], fields);
            LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, -2, 1f);
            lp1.setMargins(0, 0, dp(4), dp(6));
            row.addView(v1, lp1);

            View v2 = createSettingField(pair[1], fields);
            LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1f);
            lp2.setMargins(dp(4), 0, 0, dp(6));
            row.addView(v2, lp2);

            grid.addView(row);
        }

        // 기타수당·소급분 (단독 행)
        LinearLayout otherRow = new LinearLayout(this);
        otherRow.setOrientation(LinearLayout.HORIZONTAL);
        View vOther = createSettingField(12, fields);
        LinearLayout.LayoutParams lpOther = new LinearLayout.LayoutParams(0, -2, 1f);
        lpOther.setMargins(0, 0, dp(4), dp(6));
        otherRow.addView(vOther, lpOther);
        grid.addView(otherRow);

        // 마지막 13번: 예상 공제액 (좌측) + 공제액 안내 카드 (우측)
        LinearLayout deductionRow = new LinearLayout(this);
        deductionRow.setOrientation(LinearLayout.HORIZONTAL);

        View vDed = createSettingField(13, fields);
        LinearLayout.LayoutParams lpDed = new LinearLayout.LayoutParams(0, -2, 1f);
        lpDed.setMargins(0, 0, dp(4), dp(6));
        deductionRow.addView(vDed, lpDed);

        LinearLayout dedInfo = new LinearLayout(this);
        dedInfo.setOrientation(LinearLayout.VERTICAL);
        dedInfo.setBackground(cellBg(isDark() ? Color.rgb(20, 30, 48) : Color.rgb(240, 245, 252), colorBorder(), dp(1)));
        dedInfo.setPadding(dp(10), dp(8), dp(10), dp(8));
        TextView dedInfoTitle = textDirect("💡 공제액 안내", 12, true);
        dedInfoTitle.setTextColor(colorBlue());
        dedInfo.addView(dedInfoTitle);
        TextView dedInfoSub = textDirect("국민연금, 건강보험, 고용보험, 세금 등 명세서 총 공제액", 11, false);
        dedInfoSub.setTextColor(colorSub());
        dedInfo.addView(dedInfoSub);
        LinearLayout.LayoutParams lpDedInfo = new LinearLayout.LayoutParams(0, -1, 1f);
        lpDedInfo.setMargins(dp(4), 0, 0, dp(6));
        deductionRow.addView(dedInfo, lpDedInfo);

        grid.addView(deductionRow);
        root.addView(grid);

        // 🔗 가족수당 연동 카드 (v1.3.6) — 부양가족 수(본인 포함)와 본인 외 1인당 10,000원 자동 연동
        LinearLayout famLinkCard = new LinearLayout(this);
        famLinkCard.setOrientation(LinearLayout.VERTICAL);
        famLinkCard.setBackground(cellBg(isDark() ? Color.rgb(20, 32, 30) : Color.rgb(238, 250, 245), isDark() ? Color.rgb(30, 70, 60) : Color.rgb(167, 224, 204), dp(1)));
        famLinkCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView famLinkTitle = textDirect("🔗 가족수당 연동 (부양가족 수 × 1인당 10,000원)", 13, true);
        famLinkTitle.setTextColor(colorGreen());
        famLinkCard.addView(famLinkTitle);
        final TextView famLinkTv = new TextView(this);
        famLinkTv.setTextSize(11);
        famLinkTv.setTextColor(colorSub());
        famLinkTv.setPadding(0, dp(4), 0, dp(6));
        famLinkTv.setLineSpacing(dp(2), 1.05f);
        famLinkCard.addView(famLinkTv);
        final Button famLinkBtn = button("", null);
        famLinkBtn.setTextSize(12);
        famLinkBtn.setTextColor(colorBlue());
        famLinkBtn.setBackground(cellBg(isDark() ? Color.rgb(22, 40, 64) : Color.rgb(232, 242, 255), colorBlue(), dp(1)));
        famLinkBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
        famLinkCard.addView(famLinkBtn, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams famLinkLp = new LinearLayout.LayoutParams(-1, -2);
        famLinkLp.setMargins(0, dp(10), 0, 0);
        root.addView(famLinkCard, famLinkLp);

        refreshFamLink[0] = () -> {
            boolean linked = isFamilyAllowanceLinked();
            famLinkTv.setText((linked
                    ? "🔗 부양가족 수와 자동 연동 중입니다."
                    : "🔓 연동이 해제되어 가족수당(가족) 칸의 입력값을 그대로 씁니다.")
                    + "\n" + familyAllowanceNote()
                    + (linked ? "\n부양가족 수를 바꾸면 가족수당(가족)도 자동으로 다시 계산됩니다."
                              : "\n부양가족 수(세법)와 가족수당 인정 가족 수가 다를 때 쓰는 독립 입력입니다."));
            famLinkBtn.setText(linked
                    ? "🔓 연동 해제하고 직접 입력"
                    : "🔗 기본 연동 적용 (부양가족 수 − 본인) × 10,000원");
            if (linked && fields[8] != null) fields[8].setText(String.valueOf(Math.round(linkedFamilyAllowance())));
        };
        famLinkBtn.setOnClickListener(v -> {
            vibrateTick();
            boolean next = !isFamilyAllowanceLinked();
            prefs.edit().putBoolean("setting_family_link", next).apply();
            if (refreshFamLink[0] != null) refreshFamLink[0].run();
            Toast.makeText(this, next
                    ? "부양가족 수와 가족수당을 다시 연동했습니다."
                    : "가족수당을 독립 입력으로 전환했습니다. 금액을 직접 고치세요.", Toast.LENGTH_SHORT).show();
        });
        refreshFamLink[0].run();

        // 🧾 공제액 자동 예측 (v1.3.5) — 4대보험 법정 요율 + 소득세 간이세액표 + 노조회비 공식
        LinearLayout dedCard = new LinearLayout(this);
        dedCard.setOrientation(LinearLayout.VERTICAL);
        dedCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        dedCard.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView dedTitle = textDirect("🧾 공제액 자동 예측", 15, true);
        dedTitle.setTextColor(colorBlue());
        dedCard.addView(dedTitle);

        TextView dedSub = textDirect("4대보험 법정 요율 · 국세청 간이세액표 · 자녀 세액공제 · 노조회비 공식으로 매달 자동 계산합니다.", 11, false);
        dedSub.setTextColor(colorSub());
        dedSub.setPadding(0, dp(4), 0, dp(8));
        dedCard.addView(dedSub);

        final Runnable[] refreshDed = new Runnable[1];
        Button autoDedBtn = button(isAutoDeduction() ? "⚡ 자동 예측 ON" : "자동 예측 OFF (직접 입력 사용)", null);
        autoDedBtn.setTextSize(13);
        autoDedBtn.setTextColor(isAutoDeduction() ? Color.WHITE : colorSub());
        autoDedBtn.setBackground(bg(isAutoDeduction() ? colorBlue() : (isDark() ? Color.rgb(30, 41, 59) : Color.rgb(241, 245, 249))));
        autoDedBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
        dedCard.addView(autoDedBtn, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout dedRow1 = new LinearLayout(this);
        dedRow1.setOrientation(LinearLayout.HORIZONTAL);
        dedRow1.setPadding(0, dp(6), 0, 0);

        LinearLayout depCol = new LinearLayout(this);
        depCol.setOrientation(LinearLayout.VERTICAL);
        TextView depLbl = textDirect("부양가족 수 (본인 포함)", 12, true);
        depLbl.setTextColor(colorSub());
        depCol.addView(depLbl);
        EditText depEt = new EditText(this);
        depEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        depEt.setText(String.valueOf(getDeductionDependents()));
        depEt.setTextSize(14);
        depEt.setTextColor(colorInk());
        depEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        depEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        depCol.addView(depEt);
        dedRow1.addView(depCol, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout rateCol = new LinearLayout(this);
        rateCol.setOrientation(LinearLayout.VERTICAL);
        rateCol.setPadding(dp(8), 0, 0, 0);
        TextView rateLbl = textDirect("소득세 선공제율", 12, true);
        rateLbl.setTextColor(colorSub());
        rateCol.addView(rateLbl);
        final String[] rateLabel = { Math.round(getDeductionAdvanceRate() * 100) + "% ▾" };
        Button rateBtn = button(rateLabel[0], null);
        rateBtn.setTextSize(14);
        rateBtn.setTextColor(colorBlue());
        rateBtn.setBackground(cellBg(isDark() ? Color.rgb(28, 42, 68) : Color.rgb(228, 238, 252), colorBlue(), dp(1)));
        rateBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
        rateCol.addView(rateBtn);
        dedRow1.addView(rateCol, new LinearLayout.LayoutParams(0, -2, 1f));
        dedCard.addView(dedRow1);

        // v1.4.2 — 부양가족 수 바로 아래에 [8세~20세 자녀 수] (자녀 세액공제용)
        LinearLayout dedRowChild = new LinearLayout(this);
        dedRowChild.setOrientation(LinearLayout.HORIZONTAL);
        dedRowChild.setPadding(0, dp(6), 0, 0);

        LinearLayout childCol = new LinearLayout(this);
        childCol.setOrientation(LinearLayout.VERTICAL);
        TextView childLbl = textDirect("8세~20세 자녀 수", 12, true);
        childLbl.setTextColor(colorSub());
        childCol.addView(childLbl);
        EditText childEt = new EditText(this);
        childEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        childEt.setText(String.valueOf(getDeductionChildren()));
        childEt.setHint("0 (자녀세액공제용)");
        childEt.setHintTextColor(colorSub());
        childEt.setTextSize(14);
        childEt.setTextColor(colorInk());
        childEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        childEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        childCol.addView(childEt);
        dedRowChild.addView(childCol, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout creditCol = new LinearLayout(this);
        creditCol.setOrientation(LinearLayout.VERTICAL);
        creditCol.setPadding(dp(8), 0, 0, 0);
        TextView creditLbl = textDirect("자녀 세액공제", 12, true);
        creditLbl.setTextColor(colorSub());
        creditCol.addView(creditLbl);
        final TextView creditTv = textDirect(childCreditText(), 14, true);
        creditTv.setTextColor(colorBlue());
        creditTv.setPadding(dp(2), dp(11), 0, dp(9));
        creditCol.addView(creditTv);
        dedRowChild.addView(creditCol, new LinearLayout.LayoutParams(0, -2, 1f));
        dedCard.addView(dedRowChild);

        LinearLayout dedRow2 = new LinearLayout(this);
        dedRow2.setOrientation(LinearLayout.HORIZONTAL);
        dedRow2.setPadding(0, dp(6), 0, 0);

        LinearLayout penCol = new LinearLayout(this);
        penCol.setOrientation(LinearLayout.VERTICAL);
        TextView penLbl = textDirect("국민연금 기준 보수월액", 12, true);
        penLbl.setTextColor(colorSub());
        penCol.addView(penLbl);
        EditText penEt = new EditText(this);
        penEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        penEt.setHint("비우면 세전 급여");
        penEt.setText(getDeductionPensionBase() > 0 ? String.valueOf(getDeductionPensionBase()) : "");
        penEt.setTextSize(14);
        penEt.setTextColor(colorInk());
        penEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        penEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        penCol.addView(penEt);
        dedRow2.addView(penCol, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout heaCol = new LinearLayout(this);
        heaCol.setOrientation(LinearLayout.VERTICAL);
        heaCol.setPadding(dp(8), 0, 0, 0);
        TextView heaLbl = textDirect("건강보험 보수월액", 12, true);
        heaLbl.setTextColor(colorSub());
        heaCol.addView(heaLbl);
        EditText heaEt = new EditText(this);
        heaEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        heaEt.setHint("비우면 세전 급여");
        heaEt.setText(getDeductionHealthBase() > 0 ? String.valueOf(getDeductionHealthBase()) : "");
        heaEt.setTextSize(14);
        heaEt.setTextColor(colorInk());
        heaEt.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(244, 247, 252), colorBorder(), dp(1)));
        heaEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        heaCol.addView(heaEt);
        dedRow2.addView(heaCol, new LinearLayout.LayoutParams(0, -2, 1f));
        dedCard.addView(dedRow2);

        TextView dedNote = textDirect("", 11, false);
        dedNote.setTextColor(colorSub());
        dedNote.setPadding(0, dp(8), 0, 0);
        dedNote.setLineSpacing(dp(2), 1.05f);
        dedCard.addView(dedNote);

        refreshDed[0] = () -> {
            StringBuilder sb = new StringBuilder();
            long learnedGross = getLearnedDeductionGross();
            long[] learned = getLearnedDeduction();
            if (learned != null) {
                sb.append("📋 직전 급여명세서 실측 공제 내역은 참고용으로 보관합니다 (세전 ").append(won(learnedGross)).append(").\n");
                sb.append("   실측 소득세 ").append(won(learned[0])).append(" · 지방소득세 ").append(won(learned[1]))
                  .append(" · 건강보험 ").append(won(learned[2])).append(" · 국민연금 ").append(won(learned[3]))
                  .append(" · 고용보험 ").append(won(learned[4])).append(" · 노조회비 ").append(won(learned[5])).append("\n");
                sb.append("   자동 예측은 실측치와 무관하게 법정 요율·국세청 간이세액표로 계산합니다.\n");
            } else {
                sb.append("📋 아직 급여명세서 실측값이 없어 법정 요율과 간이세액표로 예측합니다.\n");
            }
            sb.append("🧮 노조회비 = (통상시급 ").append(won(get("ordinary"))).append(" × 3h) + 1,200원 = ")
              .append(won(DeductionCore.unionFee(get("ordinary")))).append(" (100원 단위 반올림)");
            sb.append("\n💵 소득세 = 국세청 간이세액표(부양가족 ").append(getDeductionDependents()).append("명)");
            if (getDeductionChildren() > 0) sb.append(" − 자녀 세액공제(").append(getDeductionChildren()).append("명) ").append(won(DeductionCore.childCredit(getDeductionChildren())));
            sb.append(" → ").append(won(DeductionCore.statutoryIncomeTax(3000000L, getDeductionDependents(), getDeductionChildren()))).append(" (월 300만 원 기준 예시)");
            creditTv.setText(childCreditText());
            dedNote.setText(sb.toString());
        };
        refreshDed[0].run();

        autoDedBtn.setOnClickListener(v -> {
            vibrateTick();
            boolean next = !isAutoDeduction();
            prefs.edit().putBoolean("ded_auto", next).apply();
            autoDedBtn.setText(next ? "⚡ 자동 예측 ON" : "자동 예측 OFF (직접 입력 사용)");
            autoDedBtn.setTextColor(next ? Color.WHITE : colorSub());
            autoDedBtn.setBackground(bg(next ? colorBlue() : (isDark() ? Color.rgb(30, 41, 59) : Color.rgb(241, 245, 249))));
            Toast.makeText(this, next ? "공제액 자동 예측을 켰습니다." : "공제액 자동 예측을 끄고 직접 입력값을 사용합니다.", Toast.LENGTH_SHORT).show();
        });

        depEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s2, int start, int count, int after) {}
            public void onTextChanged(CharSequence s2, int start, int count, int after) {}
            public void afterTextChanged(Editable s2) {
                try {
                    int v = Integer.parseInt(s2.toString().trim());
                    prefs.edit().putString("ded_dependents", String.valueOf(Math.max(1, v))).apply();
                    if (refreshFamLink[0] != null) refreshFamLink[0].run();
                } catch (Exception ignored) {}
            }
        });

        childEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s2, int start, int count, int after) {}
            public void onTextChanged(CharSequence s2, int start, int count, int after) {}
            public void afterTextChanged(Editable s2) {
                try {
                    int v = Integer.parseInt(s2.toString().trim());
                    prefs.edit().putString("ded_children", String.valueOf(Math.max(0, Math.min(10, v)))).apply();
                    creditTv.setText(childCreditText());
                    if (refreshDed[0] != null) refreshDed[0].run();
                } catch (Exception ignored) {}
            }
        });

        penEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s2, int start, int count, int after) {}
            public void onTextChanged(CharSequence s2, int start, int count, int after) {}
            public void afterTextChanged(Editable s2) {
                prefs.edit().putString("ded_pension_base", s2.toString().replaceAll("[^0-9]", "")).apply();
            }
        });

        heaEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s2, int start, int count, int after) {}
            public void onTextChanged(CharSequence s2, int start, int count, int after) {}
            public void afterTextChanged(Editable s2) {
                prefs.edit().putString("ded_health_base", s2.toString().replaceAll("[^0-9]", "")).apply();
            }
        });

        rateBtn.setOnClickListener(v -> {
            vibrateTick();
            double cur = getDeductionAdvanceRate();
            int pct = (int) Math.round(cur * 100);
            int next = pct == 80 ? 100 : pct == 100 ? 120 : 80;
            prefs.edit().putString("ded_advance_rate", String.valueOf(next / 100.0)).apply();
            rateBtn.setText(next + "% ▾");
            refreshDed[0].run();
        });

        LinearLayout.LayoutParams dedCardLp = new LinearLayout.LayoutParams(-1, -2);
        dedCardLp.setMargins(0, dp(12), 0, 0);
        root.addView(dedCard, dedCardLp);

        // 하단 버튼 영역
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(12), 0, dp(12));

        Button saveBtn = new Button(this);
        saveBtn.setText("💾 설정 저장하기");
        saveBtn.setTextSize(16);
        saveBtn.setTypeface(null, Typeface.BOLD);
        saveBtn.setTextColor(Color.WHITE);
        saveBtn.setBackground(bg(Color.rgb(20, 83, 153)));
        saveBtn.setOnClickListener(v -> {
            SharedPreferences.Editor ed = prefs.edit();
            int currentY = month.get(Calendar.YEAR);
            // v1.3.6: 연동 중인데 가족수당(가족)을 직접 고쳤다면 그 금액을 독립 입력으로 고정한다
            boolean famManual = false;
            if (isFamilyAllowanceLinked() && fields[8] != null) {
                String typed = fields[8].getText().toString().trim().replace(",", "");
                int linkedVal = (int) Math.round(linkedFamilyAllowance());
                if (!typed.isEmpty() && !typed.equals(String.valueOf(linkedVal))) {
                    famManual = true;
                } else {
                    fields[8].setText(String.valueOf(linkedVal));
                }
            }
            ed.putBoolean("setting_family_link", isFamilyAllowanceLinked() && !famManual);
            for (int i = 0; i < settingsKeys.length; i++) {
                String val = fields[i].getText().toString().trim();
                String finalVal = val.isEmpty() ? "" + defaults[i] : val;
                ed.putString("setting_" + settingsKeys[i], finalVal);
                ed.putString("setting_" + currentY + "_" + settingsKeys[i], finalVal);
            }
            ed.apply();
            Toast.makeText(this, currentY + "년 기준 설정이 저장되었습니다."
                    + (famManual ? " (가족수당은 직접 입력값으로 독립 저장)" : ""), Toast.LENGTH_SHORT).show();
            showMain();
        });
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(0, dp(48), 1.2f);
        saveLp.setMargins(0, 0, dp(6), 0);
        btnRow.addView(saveBtn, saveLp);

        Button cancelBtn = button("취소", this::showMain);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(48), 0.8f);
        cancelLp.setMargins(dp(6), 0, 0, 0);
        btnRow.addView(cancelBtn, cancelLp);

        root.addView(btnRow);
        } catch (Throwable t) {
            android.util.Log.e("ShiftPay", "showSettings error", t);
            Toast.makeText(this, "설정 화면을 여는 중 일시적 오류가 발생하여 복구되었습니다.", Toast.LENGTH_SHORT).show();
            showMain();
        }
    }

    // 설정 항목 카드 (제목칸과 숫자입력칸의 명확한 색상 분리) (요청사항 4 반영)
    View createSettingField(int idx, EditText[] fieldsOut) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));

        // 제목칸 (Title/Label Box) - 색 구분이 명확한 배경색!
        LinearLayout labelRow = new LinearLayout(this);
        labelRow.setOrientation(LinearLayout.HORIZONTAL);
        labelRow.setGravity(Gravity.CENTER_VERTICAL);
        int labelBgColor = isDark() ? Color.rgb(32, 46, 70) : Color.rgb(232, 240, 252);
        int labelTextColor = isDark() ? Color.rgb(191, 219, 254) : Color.rgb(24, 58, 107);
        labelRow.setBackground(cellBg(labelBgColor, isDark() ? Color.rgb(45, 62, 90) : Color.rgb(205, 220, 242), dp(1)));
        labelRow.setPadding(dp(8), dp(6), dp(8), dp(6));

        TextView label = new TextView(this);
        label.setText(settingsNames[idx]);
        label.setTextSize(12);
        label.setTypeface(null, Typeface.BOLD);
        label.setTextColor(labelTextColor);
        labelRow.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));

        if (idx == 6) { // 근속수당
            TextView autoTv = new TextView(this);
            autoTv.setText("⚡ 2026 단협 선택");
            autoTv.setTextSize(11);
            autoTv.setTextColor(colorBlue());
            autoTv.setTypeface(null, Typeface.BOLD);
            autoTv.setPadding(dp(4), 0, dp(2), 0);
            labelRow.addView(autoTv);

            labelRow.setClickable(true);
            labelRow.setOnClickListener(v -> showTenureSelectDialog(fieldsOut[6]));
        }

        box.addView(labelRow, new LinearLayout.LayoutParams(-1, -2));

        // 숫자입력칸 (Number Input Box) - 제목칸과 확연히 구분되는 배경색과 테두리!
        EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setSingleLine(true);
        et.setTextSize(15);
        et.setTypeface(null, Typeface.BOLD);
        int inputBgColor = isDark() ? Color.rgb(15, 23, 42) : Color.WHITE;
        int inputBorderColor = isDark() ? Color.rgb(51, 65, 85) : Color.rgb(180, 195, 215);
        et.setBackground(cellBg(inputBgColor, inputBorderColor, dp(1)));
        et.setTextColor(colorInk());
        et.setPadding(dp(8), dp(6), dp(8), dp(6));
        et.setText(getSettingStr(settingsKeys[idx], String.valueOf(defaults[idx])));
        fieldsOut[idx] = et;

        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(-1, -2);
        etLp.setMargins(dp(4), dp(4), dp(4), dp(4));
        box.addView(et, etLp);

        return box;
    }

    void showTenureSelectDialog(EditText tenureEt) {
        String joinStr = getJoinDateStr();
        int calcAmt = getCalculatedTenureAllowance(joinStr);
        int years = getYearsOfService();
        String recMsg = joinStr.isEmpty() ? "" : " (입사일 기준 " + years + "년차 추천: " + won(calcAmt) + ")";

        new AlertDialog.Builder(this)
            .setTitle("2026년 단체협약 근속수당 선택" + recMsg)
            .setItems(TENURE_LABELS, (d, which) -> {
                vibrateTick();
                int amt = TENURE_AMOUNTS[which];
                if (tenureEt != null) {
                    tenureEt.setText(String.valueOf(amt));
                }
                prefs.edit()
                    .putString("setting_tenure", String.valueOf(amt))
                    .putString("setting_" + month.get(Calendar.YEAR) + "_tenure", String.valueOf(amt))
                    .apply();
                Toast.makeText(this, TENURE_LABELS[which] + " 적용: " + won(amt), Toast.LENGTH_SHORT).show();
            })
            .setPositiveButton("입사일 자동계산 적용 (" + won(calcAmt) + ")", (d, which) -> {
                vibrateTick();
                if (tenureEt != null) {
                    tenureEt.setText(String.valueOf(calcAmt));
                }
                prefs.edit()
                    .putString("setting_tenure", String.valueOf(calcAmt))
                    .putString("setting_" + month.get(Calendar.YEAR) + "_tenure", String.valueOf(calcAmt))
                    .apply();
                Toast.makeText(this, "입사일 기준 " + won(calcAmt) + " 적용 완료!", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("취소", null)
            .show();
    }

    // 💰 2026년 성과·격려금 계산기 (2026년 임단협 타결 설명회 공식 반영)
    void showBonusCalculator() {
        start("💰 2026년 성과·격려금 계산기");

        // 상단 헤더 배너
        LinearLayout headerCard = new LinearLayout(this);
        headerCard.setOrientation(LinearLayout.VERTICAL);
        headerCard.setBackground(cellBg(isDark() ? Color.rgb(20, 36, 60) : Color.rgb(238, 245, 255), colorBlue(), dp(1)));
        headerCard.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView hTitle = textDirect("2026년 임단협 타결 성과·격려금 모의 산정", 15, true);
        hTitle.setTextColor(colorBlue());
        headerCard.addView(hTitle);

        TextView hSub = textDirect("지회 임단협 설명회 공식 산출식 (250% + 550만 원 + 온누리 상품권 30만 원)", 12, false);
        hSub.setTextColor(colorSub());
        hSub.setPadding(0, dp(2), 0, 0);
        headerCard.addView(hSub);
        root.addView(headerCard);

        // 산정 변수 로드
        double baseRate = get("base");
        double monthlyBase = Math.round(baseRate * 243.0);
        double famSelf = get("familySelf");
        double duty = get("duty");
        double position = get("position");
        double tenure = get("tenure");
        boolean isShift = isShiftWorker();
        double shiftAllowance = isShift ? 200000.0 : 0.0;
        double gageubAllowance = !isShift ? Math.min(200000.0, baseRate * 22.5) : 0.0;

        double fixedTongsan = famSelf + duty + position + tenure + shiftAllowance;
        double ordinaryHourly = Math.round((monthlyBase + fixedTongsan) / 243.0);

        // 공식: 기본급 ÷ 1.65 + 약정통상수당 + 상주휴게수당(최대 20만) + (약정 통상시급 × 40H)
        double bonus100 = Math.round((monthlyBase / 1.65) + fixedTongsan + gageubAllowance + (ordinaryHourly * 40.0));

        double bonusBiz = Math.round(bonus100 * 1.0) + 1000000.0;     // 100% + 100만
        double bonusSafety = Math.round(bonus100 * 1.5) + 2000000.0;  // 150% + 200만
        double bonusCrisis = 2500000.0;                               // 250만
        double giftVoucher = 300000.0;                                // 상품권 30만
        double totalCash = Math.round(bonus100 * 2.5) + 5500000.0;
        double totalSum = totalCash + giftVoucher;

        // 1. 산정 기초 데이터 카드
        LinearLayout baseCard = new LinearLayout(this);
        baseCard.setOrientation(LinearLayout.VERTICAL);
        baseCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        baseCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams baseCardLp = new LinearLayout.LayoutParams(-1, -2);
        baseCardLp.setMargins(0, dp(10), 0, 0);

        TextView baseTitle = textDirect("📋 산정 기준 정보 (나의 설정 연동)", 14, true);
        baseTitle.setTextColor(colorInk());
        baseCard.addView(baseTitle);

        addCalcRow(baseCard, "• 기본급 (기본시급 × 243h)", won(monthlyBase) + " (" + won(baseRate) + "/h)");
        addCalcRow(baseCard, "• 근무 형태", isShift ? "교대근무 (교대수당 20만 원)" : "상주근무 (상주휴게 22.5일)");
        addCalcRow(baseCard, "• 약정통상수당", won(fixedTongsan) + " (직책+직무/근속/가족/교대)");
        addCalcRow(baseCard, "• 상주휴게수당 산입", isShift ? "0원 (교대수당 산입으로 대체)" : won(gageubAllowance) + " (최대 20만 원 한도)");
        addCalcRow(baseCard, "• 약정 통상시급", won(ordinaryHourly) + " ((기본급+약정통상)÷243h)");
        addCalcRow(baseCard, "• 40h분 인정액", won(Math.round(ordinaryHourly * 40.0)) + " (통상시급 × 40h)");

        // 100% 기준 금액 강조 박스
        LinearLayout p100Box = new LinearLayout(this);
        p100Box.setOrientation(LinearLayout.HORIZONTAL);
        p100Box.setGravity(Gravity.CENTER_VERTICAL);
        p100Box.setBackground(cellBg(isDark() ? Color.rgb(24, 38, 58) : Color.rgb(235, 243, 255), colorBlue(), dp(1)));
        p100Box.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams p100Lp = new LinearLayout.LayoutParams(-1, -2);
        p100Lp.setMargins(0, dp(8), 0, 0);

        TextView p100Lbl = textDirect("🎯 정율 100% 산정 기준액", 14, true);
        p100Lbl.setTextColor(colorBlue());
        p100Box.addView(p100Lbl, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView p100Val = textDirect(won(bonus100), 16, true);
        p100Val.setTextColor(colorBlue());
        p100Box.addView(p100Val);
        baseCard.addView(p100Box, p100Lp);

        TextView fNote = textDirect("※ 공식: 기본급÷1.65 + 약정통상수당 + 상주휴게(한도 20만) + (통상시급×40h)", 11, false);
        fNote.setTextColor(colorSub());
        fNote.setPadding(0, dp(6), 0, 0);
        baseCard.addView(fNote);

        root.addView(baseCard, baseCardLp);

        // 2. 2026년 타결 성과·격려금 지급 명세서 카드
        LinearLayout payCard = new LinearLayout(this);
        payCard.setOrientation(LinearLayout.VERTICAL);
        payCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        payCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams payCardLp = new LinearLayout.LayoutParams(-1, -2);
        payCardLp.setMargins(0, dp(10), 0, 0);

        TextView payTitle = textDirect("🎁 2026년 타결 성과·격려금 지급 명세 (250% + 550만 + 상품권)", 14, true);
        payTitle.setTextColor(colorInk());
        payCard.addView(payTitle);

        addCalcRow(payCard, "1. 경영 성과금 (100% + 100만 원)", won(bonusBiz));
        addCalcRow(payCard, "2. 안전문화 정착 장려금 (150% + 200만 원)", won(bonusSafety));
        addCalcRow(payCard, "3. 위기극복 동참 격려금 (정액)", won(bonusCrisis));
        addCalcRow(payCard, "4. 전통시장 온누리 상품권", won(giftVoucher));

        // 총액 강조 박스
        LinearLayout totalBox = new LinearLayout(this);
        totalBox.setOrientation(LinearLayout.VERTICAL);
        totalBox.setBackground(cellBg(isDark() ? Color.rgb(36, 30, 18) : Color.rgb(254, 252, 232), isDark() ? Color.rgb(180, 120, 20) : Color.rgb(234, 179, 8), dp(1)));
        totalBox.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams totalLp = new LinearLayout.LayoutParams(-1, -2);
        totalLp.setMargins(0, dp(10), 0, 0);

        LinearLayout rTot1 = new LinearLayout(this);
        rTot1.setOrientation(LinearLayout.HORIZONTAL);
        TextView totLbl = textDirect("🏆 성과 및 격려금 총합계 (현금+상품권)", 14, true);
        totLbl.setTextColor(isDark() ? Color.rgb(250, 204, 21) : Color.rgb(161, 98, 7));
        rTot1.addView(totLbl, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView totVal = textDirect(won(totalSum), 18, true);
        totVal.setTextColor(colorRed());
        rTot1.addView(totVal);
        totalBox.addView(rTot1);

        TextView totSub = textDirect("• 현금 지급분: " + won(totalCash) + " (타결 후 5일 이내)\n• 온누리 상품권: " + won(giftVoucher) + " 별도 지급", 12, false);
        totSub.setTextColor(colorSub());
        totSub.setPadding(0, dp(4), 0, 0);
        totalBox.addView(totSub);
        payCard.addView(totalBox, totalLp);

        root.addView(payCard, payCardLp);

        // 3. 임금 인상 소급분 및 비교 안내 카드
        LinearLayout infoCard = new LinearLayout(this);
        infoCard.setOrientation(LinearLayout.VERTICAL);
        infoCard.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        infoCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams infoCardLp = new LinearLayout.LayoutParams(-1, -2);
        infoCardLp.setMargins(0, dp(10), 0, 0);

        TextView infoTitle = textDirect("💡 임금 인상 소급분 & 전년 비교", 13, true);
        infoTitle.setTextColor(colorBlue());
        infoCard.addView(infoTitle);

        TextView retroTv = textDirect(
            "• 2026 기본급 인상 소급분: 약 1,450,000원\n" +
            "  (시급 516원 인상 × 월 평균 340시간 × 8개월 소급)\n\n" +
            "• 전년(2025년) 타결 대비:\n" +
            "  - 2025년: 250% + 530만 원 + 상품권 20만 원 (평균 약 1,300만 원)\n" +
            "  - 2026년: 250% + 550만 원 + 상품권 30만 원 (평균 약 1,330만 원으로 상향)",
            12, false
        );
        retroTv.setTextColor(colorSub());
        retroTv.setPadding(0, dp(4), 0, 0);
        infoCard.addView(retroTv);

        root.addView(infoCard, infoCardLp);

        // 버튼 행
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(12), 0, dp(16));

        Button setBtn = button("⚙️ 나의 수당·시급 변경", this::showSettings);
        LinearLayout.LayoutParams setLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        setLp.setMargins(0, 0, dp(6), 0);
        btnRow.addView(setBtn, setLp);

        Button backBtn = button("돌아가기", this::showMain);
        LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        backLp.setMargins(dp(6), 0, 0, 0);
        btnRow.addView(backBtn, backLp);

        root.addView(btnRow);
    }

    void addCalcRow(LinearLayout parent, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(3), 0, dp(3));

        TextView lTv = textDirect(label, 12, false);
        lTv.setTextColor(colorSub());
        row.addView(lTv, new LinearLayout.LayoutParams(0, -2, 1.4f));

        TextView vTv = textDirect(value, 12, true);
        vTv.setTextColor(colorInk());
        vTv.setGravity(Gravity.END);
        row.addView(vTv, new LinearLayout.LayoutParams(0, -2, 1f));

        parent.addView(row);
    }


    // ════════════════════════════════════════════════════════════════
    // v1.4.3 ① — 캘린더 연·월 빠른 이동
    //   좌우 스와이프 슬라이드 + 연도 숫자 터치 시 연도 휠/미니 그리드 (MonthYearPicker)
    // ════════════════════════════════════════════════════════════════
    void showMonthYearPicker() {
        new MonthYearPicker(this).show();
    }

    void jumpToYearMonth(Dialog d, int y, int m) {
        vibrateTick();
        month.set(Calendar.YEAR, y);
        month.set(Calendar.MONTH, m - 1);
        month.set(Calendar.DAY_OF_MONTH, 1);
        chosenDay = 1;
        if (d != null && d.isShowing()) d.dismiss();
        showMain();
    }

    void addQuickPickerChip(LinearLayout parent, String text, Runnable onClick) {
        Button b = button(text, onClick);
        b.setTextSize(12);
        b.setTextColor(colorBlue());
        b.setBackground(cellBg(isDark() ? Color.rgb(26, 40, 65) : Color.rgb(235, 244, 255), isDark() ? Color.rgb(40, 60, 95) : Color.rgb(205, 225, 250), dp(1)));
        b.setPadding(dp(10), dp(5), dp(10), dp(5));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, dp(6), 0);
        parent.addView(b, lp);
    }

    /** 상주휴게 지급일수 (특근일 산입 포함) — 엑셀 산출식 표기용 */
    double totalGageubDays() {
        return Math.max(cardBreakdown()[PayCore.CB_GAGEUB], countWorkDays());
    }

    void exportPayrollReport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        String userName = prefs != null ? prefs.getString("user_name", "") : "";
        String namePart = userName.isEmpty() ? "" : "_" + userName;
        intent.putExtra(Intent.EXTRA_TITLE, "ShiftPay_급여명세서_" + ym() + namePart + ".xlsx");
        startActivityForResult(intent, EXPORT_REPORT_XLSX);
    }

    void exportPayrollReportToStream(OutputStream out) throws IOException {
        String ymStr = ym();
        String userName = prefs != null ? prefs.getString("user_name", "임직원") : "임직원";
        String rank = prefs != null ? prefs.getString("user_rank", "기술직") : "기술직";
        String dept = prefs != null ? prefs.getString("user_dept", "생산") : "생산";
        String factory = getFactoryName();
        String todayStr = new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(new Date());

        String userInfo = "성명: " + userName + " | 직급: " + rank + " | 소속부서: " + dept + " | 근무공장: " + factory + " | 작성일시: " + todayStr;

        int y = month.get(Calendar.YEAR), m = month.get(Calendar.MONTH);
        int lastDay = month.getActualMaximum(Calendar.DAY_OF_MONTH);
        Map<String, String> holidays = holidayMap(y);
        String[] wLabels = {"일", "월", "화", "수", "목", "금", "토"};

        List<String[]> dailyRows = new ArrayList<>();
        double sumNormal = 0, sumOt = 0, sumHol = 0, sumHolOt = 0, sumNight = 0;

        for (int d = 1; d <= lastDay; d++) {
            String dateStr = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            int wd = weekday(d);
            String weekdayStr = (wd >= 1 && wd <= 7) ? wLabels[wd - 1] : "";
            String mode = dayMode(d);
            String modeStr = "normal".equals(mode) ? "정상근무" :
                             "work".equals(mode) ? "근무일" :
                             "annual".equals(mode) ? "연차휴가" :
                             "summer".equals(mode) ? "하계휴가" :
                             (wd == Calendar.SATURDAY ? "유급휴무" : (wd == Calendar.SUNDAY ? "주휴일" : "평일"));

            double normal = dayHours(d, 0);
            double ot = dayHours(d, 4);
            double hol = dayHours(d, 5);
            double holOt = dayHours(d, 6);
            double night = dayHours(d, 7);

            sumNormal += normal;
            sumOt += ot;
            sumHol += hol;
            sumHolOt += holOt;
            sumNight += night;

            String holName = holidays.get(String.format(Locale.US, "%04d%02d%02d", y, m + 1, d));
            String note = holName != null ? holName : "";
            if ("annual".equals(mode)) note = (note.isEmpty() ? "" : note + " / ") + "연차 8h 차감";

            dailyRows.add(new String[]{
                dateStr, weekdayStr, modeStr,
                hoursShort(normal), hoursShort(ot), hoursShort(hol), hoursShort(holOt), hoursShort(night),
                note
            });
        }

        String[] totalRow = new String[]{
            "월간 총 합계", "", "실근무 " + countWorkDays() + "일",
            hoursShort(sumNormal), hoursShort(sumOt), hoursShort(sumHol), hoursShort(sumHolOt), hoursShort(sumNight),
            "총근무시간: " + hoursShort(sumNormal + sumOt + sumHol + sumHolOt) + "h"
        };

        double[] t = totals(), a = amounts();
        double baseHours = t[0] + t[1] + t[2] + t[3];
        double otH = Math.max(0, t[4] - t[3]);
        double otUnit = Math.round(get("ordinary") * get("otRate"));
        double holUnit = Math.round(get("ordinary") * get("holidayRate"));
        double holOtUnit = Math.round(get("ordinary") * get("holidayOTRate"));
        double nightUnit = Math.round(get("ordinary") * get("nightRate"));

        // 【 2. 출근카드 1:1 월간 집계 & 근무 통계 요약 】 — 실물 출근카드와 1:1로 맞춘 집계
        double[] cb = cardBreakdown();
        List<String[]> cardRows = new ArrayList<>();
        cardRows.add(new String[]{"항목", "시간 / 일수", "구성", "비고"});
        cardRows.add(new String[]{"출근 일수", hoursShort(cb[PayCore.CB_DAYS]) + "일", "실제로 출근한 날",
                "주차·유급 자동 인정일과 연차·하계휴가일 제외"});
        cardRows.add(new String[]{"① 기본 인정", hoursShort(cb[PayCore.CB_BASE]) + "h",
                "정취 " + hoursShort(cb[PayCore.CB_NORMAL]) + " + 유급 " + hoursShort(cb[PayCore.CB_PAID])
                + " + 주차 " + hoursShort(cb[PayCore.CB_WEEKLY]) + " + 연차 " + hoursShort(cb[PayCore.CB_ANNUAL])
                + (cb[PayCore.CB_UNION] > 0 ? " + 조합 " + hoursShort(cb[PayCore.CB_UNION]) : ""),
                "기본급 인정 시간"});
        cardRows.add(new String[]{"② 시간외·특근", hoursShort(cb[PayCore.CB_OT] + cb[PayCore.CB_HOL] + cb[PayCore.CB_HOLOT]) + "h",
                "연장 " + hoursShort(cb[PayCore.CB_OT]) + " + 휴일근로 " + hoursShort(cb[PayCore.CB_HOL])
                + " + 휴일연장 " + hoursShort(cb[PayCore.CB_HOLOT]),
                "휴일근로 8h 초과분은 휴일연장(200%)으로 분리"});
        cardRows.add(new String[]{"심야(가산 전 실근로)", hoursShort(cb[PayCore.CB_NIGHT]) + "h",
                isShiftWorker() ? "야간 " + PayCore.nightWorkDays(this) + "일 × 야간 실근로" : "해당 없음",
                isShiftWorker() ? "야간수당은 1일 7.0h 기준으로 산출(섹션 3 참조)" : ""});
        cardRows.add(new String[]{"③ 가급(상주휴게)", hoursShort(cb[PayCore.CB_GAGEUB]) + "h",
                isShiftWorker() ? "교대수당 200,000원 정액" : hoursShort(cb[PayCore.CB_GAGEUB]) + "일 × 1h 유급",
                isShiftWorker() ? "단협 제42조 5·6호" : "단협 제49조 4항"});
        cardRows.add(new String[]{"휴일가급(할증 환산)", hoursShort(cb[PayCore.CB_HOLPREMIUM]) + "h",
                "휴일근로 50% + 휴일연장 100%", "출근카드 환산에 포함되는 가산시간"});
        cardRows.add(new String[]{"급여 인정", hoursShort(cb[PayCore.CB_PAY]) + "h",
                "기본 인정 " + hoursShort(cb[PayCore.CB_BASE]) + " + 시간외·특근 "
                + hoursShort(cb[PayCore.CB_OT] + cb[PayCore.CB_HOL] + cb[PayCore.CB_HOLOT]) + " + 가급 "
                + hoursShort(cb[PayCore.CB_GAGEUB]), "실근무 + 유급 인정 + 가급"});
        cardRows.add(new String[]{"출근카드 환산", hoursShort(cb[PayCore.CB_CONVERT]) + "h",
                isShiftWorker() ? "급여 인정 − 특근일 가급 + 휴일가급 + 심야 "
                        + hoursShort(cb[PayCore.CB_NIGHT]) : "급여 인정 − 특근일 가급 + 휴일가급",
                "실물 출근카드 합계와 같은 기준"});
        cardRows.add(new String[]{"실근무 vs 급여 인정 분리", "실근무 " + hoursShort(cb[PayCore.CB_ACTUAL]) + "h / 급여 인정 " + hoursShort(cb[PayCore.CB_PAY]) + "h",
                "유급 인정 " + hoursShort(cb[PayCore.CB_PAID] + cb[PayCore.CB_WEEKLY] + cb[PayCore.CB_ANNUAL]) + "h 분리",
                "실제로 일한 시간과 급여로 인정되는 시간은 다릅니다"});

        List<String[]> payRows = new ArrayList<>();
        payRows.add(new String[]{"항목", "인정시간 / 일수", "적용 단가 및 산출식", "지급 금액"});
        payRows.add(new String[]{"1. 기본급", hours(baseHours), hours(baseHours) + " × " + won(get("base")) + " (정상+유급+주차)", won(a[0])});
        payRows.add(new String[]{"2. 평일연장근로수당", hours(otH), hours(otH) + " × " + won(otUnit) + " (통상시급 × 1.5배)", won(a[1])});
        payRows.add(new String[]{"3. 휴일근로수당(특근)", hours(t[5]), hours(t[5]) + " × " + won(holUnit) + " (통상시급 × 1.5배)", won(a[2])});
        payRows.add(new String[]{"4. 휴일연장수당(가급)", hours(t[6]), hours(t[6]) + " × " + won(holOtUnit) + " (8시간 초과분 200%)", won(a[3])});
        if (t[7] > 0) {
            String nightH = isShiftWorker()
                    ? new DecimalFormat("0.0").format(PayCore.nightPayHours(this, true)) + "h (야간 "
                      + PayCore.nightWorkDays(this) + "일 × " + new DecimalFormat("0.0").format(PayCore.SHIFT_NIGHT_HOURS_PER_DAY) + "h)"
                    : hours(t[7]);
            String nightFormula = isShiftWorker()
                    ? nightH + " × " + won(get("ordinary")) + " × 0.5 = " + won(a[4])
                    : nightH + " × " + won(nightUnit) + " (통상시급 × 0.5배)";
            payRows.add(new String[]{"5. 야간 추가수당", nightH, nightFormula, won(a[4])});
        }
        int nextNo = t[7] > 0 ? 6 : 5;
        payRows.add(new String[]{nextNo + ". 고정 및 상주휴게수당", countWorkDays() + "일", "상주휴게 + 교대 + 근속 + 가족 + 직책 + 직무" + (m >= 6 && m <= 8 ? " + 하계지원비" : ""), won(a[5])});
        payRows.add(new String[]{"　└ 상주휴게(가급)", isShiftWorker() ? "해당 없음" : countWorkDays() + "일",
                isShiftWorker() ? "교대근무자는 상주휴게수당 대신 교대수당 적용 (단협 제42조 5·6호)"
                        : "근무일수 " + countWorkDays() + "일 × " + won(get("base")) + " (단협 제49조 4항, 실근무 8h 이상 1일 1h 유급)",
                won(isShiftWorker() ? 0 : totalGageubDays() * get("base"))});
        if (isShiftWorker()) {
            payRows.add(new String[]{"　└ 교대수당", "1개월", "월 정액 200,000원 (단협 제42조 5호 · 6호)", won(200000)});
        }
        payRows.add(new String[]{"　└ 근속수당", "", "근속 구간별 정액 (자회사 전환 기산일 기준)", won(get("tenure"))});
        payRows.add(new String[]{"　└ 가족수당(본인)", "", "본인 1인 정액", won(get("familySelf"))});
        payRows.add(new String[]{"　└ 가족수당(가족)", "", isFamilyAllowanceLinked()
                ? "부양가족 " + getDeductionDependents() + "명(본인 포함) → 본인 외 " + Math.max(0, getDeductionDependents() - 1) + "명 × 10,000원 (연동)"
                : "직접 입력 금액", won(get("familyOther"))});
        payRows.add(new String[]{"　└ 직책수당", "", "직급 연동 (사원 0 / 주임 5만 / 계장 10만 / 기장 20만)", won(get("position"))});
        payRows.add(new String[]{"　└ 직무수당", "", "고정수당 (사원 포함 전 직급 공통)", won(get("duty"))});
        if (m >= 6 && m <= 8) {
            payRows.add(new String[]{"　└ 하계건강지원비", "7~9월", "단협 제91조 (비고열 45,000 / 고열 90,000원)", won(get("summer"))});
        }

        List<String[]> summaryRows = new ArrayList<>();
        summaryRows.add(new String[]{"세전 총지급액 (A)", "", "기본급 + 연장 + 특근 + 가급 + 야간 + 고정/휴게수당", won(a[6])});
        summaryRows.add(new String[]{"예상 총공제액 (B)", "", "4대보험(국민연금, 건강보험, 고용보험) 및 근로소득세 등", "-" + won(a[7])});
        summaryRows.add(new String[]{"예상 실지급액 (A - B)", "", "통장 실제 입금 예정 금액", won(a[8])});

        ExcelBackup.writePayrollReport(out, ymStr, userInfo, dailyRows, totalRow, cardRows, payRows, summaryRows, prefs);
    }

    void exportExcel() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        intent.putExtra(Intent.EXTRA_TITLE, "ShiftPay_백업_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".xlsx");
        startActivityForResult(intent, EXPORT_XLSX);
    }

    void importExcel() {
        File dir = getExternalFilesDir("AutoBackup");
        File autoLatest = (dir != null) ? new File(dir, "ShiftPay_자동백업_최신.xlsx") : null;
        boolean hasAuto = autoLatest != null && autoLatest.exists();

        String[] options = hasAuto
            ? new String[]{"💾 최근 자동 백업본 즉시 복원", "📂 스마트폰 파일에서 직접 선택"}
            : new String[]{"📂 스마트폰 파일에서 직접 선택"};

        new AlertDialog.Builder(this)
            .setTitle("엑셀 불러오기 / 복원")
            .setItems(options, (d, which) -> {
                if (hasAuto && which == 0) {
                    try (InputStream in = new FileInputStream(autoLatest)) {
                        Map<String, String> incoming = ExcelBackup.read(in);
                        confirmRestore(incoming);
                    } catch (Exception ex) {
                        Toast.makeText(this, "자동 백업 열기 실패: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                    }
                } else {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                    startActivityForResult(intent, IMPORT_XLSX);
                }
            })
            .setNegativeButton("취소", null)
            .show();
    }

    void confirmRestore(Map<String, String> incoming) {
        int overlap = 0;
        for (String key : incoming.keySet()) if (prefs.contains(key)) overlap++;
        final int conflicts = overlap;
        new AlertDialog.Builder(this)
            .setTitle("복원 전 확인")
            .setMessage("파일 데이터 " + incoming.size() + "개, 기존 데이터와 중복 " + conflicts + "개입니다.\n\n병합: 중복 키는 파일 값으로 변경하고 나머지 기존 기록은 유지합니다.\n전체 교체: 기존 데이터를 삭제한 뒤 파일 내용만 복원합니다.")
            .setNeutralButton("취소", null)
            .setNegativeButton("병합", (d, w) -> restoreExcel(incoming, false))
            .setPositiveButton("전체 교체", (d, w) -> new AlertDialog.Builder(this)
                .setTitle("전체 교체 확인")
                .setMessage("현재 앱의 모든 기록이 삭제되고 백업 파일의 내용으로 교체됩니다. 계속할까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("교체", (d2, w2) -> restoreExcel(incoming, true)).show()).show();
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK) return;
        if (request == PAYSLIP_CAMERA) {
            if (payslipCameraUri != null) recognizePayslip(payslipCameraUri);
            return;
        }
        if (request == PAYSLIP_GALLERY) {
            if (data != null && data.getData() != null) recognizePayslip(data.getData());
            return;
        }

        if (request == PAYSLIP_PDF) {
            if (data != null && data.getData() != null) handlePayslipPdf(data.getData());
            return;
        }

        if (request == OCR_CAMERA) {
            if (cameraUri != null) recognize(cameraUri);
            return;
        }
        if (request == OCR_GALLERY) {
            if (data != null && data.getData() != null) recognize(data.getData());
            return;
        }
        if (data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (request == EXPORT_REPORT_XLSX) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("파일을 열 수 없습니다");
                exportPayrollReportToStream(out);
                new AlertDialog.Builder(this)
                    .setTitle("📊 정규 급여명세서 엑셀 저장 완료")
                    .setMessage(ym() + "월 일자별 근무현황표 및 단체협약 급여 정산 보고서가 엑셀 파일로 정상 저장되었습니다.\n\n(카카오톡, 메일 전송 또는 PC 엑셀에서 바로 열어보실 수 있습니다)")
                    .setPositiveButton("확인", null)
                    .show();
            } catch (Exception ex) {
                new AlertDialog.Builder(this).setMessage("엑셀 명세서 저장 실패: " + ex.getMessage()).setPositiveButton("확인", null).show();
            }
            return;
        }

        if (request == EXPORT_XLSX) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("파일을 열 수 없습니다");
                ExcelBackup.write(out, prefs);
                new AlertDialog.Builder(this).setMessage("엑셀 백업 파일이 저장되었습니다.").setPositiveButton("확인", null).show();
            } catch (Exception ex) {
                new AlertDialog.Builder(this).setMessage("백업 실패: " + ex.getMessage()).setPositiveButton("확인", null).show();
            }
        } else if (request == IMPORT_XLSX) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("파일을 열 수 없습니다");
                Map<String, String> incoming = ExcelBackup.read(in);
                confirmRestore(incoming);
            } catch (Exception ex) {
                new AlertDialog.Builder(this).setMessage("불러오기 실패: " + ex.getMessage()).setPositiveButton("확인", null).show();
            }
        }
    }

    void restoreExcel(Map<String, String> incoming, boolean replace) {
        SharedPreferences.Editor ed = prefs.edit();
        if (replace) {
            ed.clear();
            ed.putInt("app_version_code", CURRENT_VERSION_CODE);
        }
        // v1.3.6 ⑥: 공제 설정(ded_*)까지 자료형을 보존해 복원한다 (ded_l_* Long, ded_auto Boolean 등)
        ExcelBackup.restoreInto(incoming, new ExcelBackup.Sink() {
            @Override public void putString(String key, String value) { ed.putString(key, value); }
            @Override public void putInt(String key, int value) { ed.putInt(key, value); }
            @Override public void putLong(String key, long value) { ed.putLong(key, value); }
            @Override public void putFloat(String key, float value) { ed.putFloat(key, value); }
            @Override public void putBoolean(String key, boolean value) { ed.putBoolean(key, value); }
        });
        if (ed.commit()) {
            if (replace) {
                // 전체 교체 복원 후 공휴일 즉시 재주입 (commit 이후 실행하여 clear에 의한 소거 방지)
                injectOfficialHolidays(2025);
                injectOfficialHolidays(2026);
                injectOfficialHolidays(2027);
                injectOfficialHolidays(2028);
            }
            Toast.makeText(this, "복원 완료: " + incoming.size() + "개", Toast.LENGTH_LONG).show();
            showMain();
        } else {
            new AlertDialog.Builder(this).setMessage("복원 저장에 실패했습니다").setPositiveButton("확인", null).show();
        }
    }

    // ════════════════════════════════════════════════════════════════
    // 피코(PICO) 스플래시 로딩 화면
    // ════════════════════════════════════════════════════════════════

    // ════════════════════════════════════════════════════════════════
    // v1.4.3 ② — 4스텝 대화형 온보딩 마법사 (최초 설치 · 드로어 다시보기)
    //   1 이름·직급 → 2 생년월일·입사년월일 → 3 근무형태·통상시급 → 4 부양가족·자녀
    //   → 완료 페이지(정적인 피코 이미지 + 안전근무 인사, v1.4.3 손흔들기 애니메이션 제거)
    //   각 단계는 "000 사원님의 입력으로 …하게 되었습니다" 식으로 이유를 먼저 설명한다.
    // ════════════════════════════════════════════════════════════════
    static final int WIZARD_STEPS = 4;

    void showOnboardingWizard() {
        wizardShiftType = isShiftWorker() ? "shift" : "normal";
        wizardRank = prefs != null ? prefs.getString("user_rank", "") : "";
        showWizardStep(1);
    }

    void markOnboardingDone() {
        try {
            prefs.edit().putBoolean("onboarding_v14_completed", true)
                        .putBoolean("onboarding_v143_completed", true)
                        .putBoolean("onboarding_shown", true).apply();
        } catch (Exception ignored) {}
    }

    void closeWizard() {
        wizardStep = 0;
        try {
            for (android.animation.Animator a : wizardAnimators) { if (a != null) a.cancel(); }
            wizardAnimators.clear();
        } catch (Throwable ignored) {}
        if (wizardDialog != null) {
            try { wizardDialog.dismiss(); } catch (Exception ignored) {}
            wizardDialog = null;
        }
    }

    /** 직급 문자열(RANK_NAMES 전체) → 짧은 호칭 (사원·주임·계장·기장·G1 매니저 …) */
    String wizardRankShort() {
        String r = wizardRank == null ? "" : wizardRank;
        if (r.contains("사원")) return "사원";
        if (r.contains("주임")) return "주임";
        if (r.contains("계장")) return "계장";
        if (r.contains("기장")) return "기장";
        if (r.contains("G1")) return "G1 매니저";
        if (r.contains("G2")) return "G2 매니저";
        if (r.contains("G3")) return "G3 책임";
        if (r.contains("G4")) return "G4 책임";
        return r.trim();
    }

    /** "홍길동 사원님" 형태의 호칭 — 이름이 비면 빈 문자열을 돌려준다. */
    String wizardCalling(String name) {
        String n = name == null ? "" : name.trim();
        String rank = wizardRankShort();
        if (n.isEmpty()) return "";
        return rank.isEmpty() ? n : n + " " + rank;
    }

    /** 1단계 실시간 인사말 */
    String wizardGreeting(String name) {
        String call = wizardCalling(name);
        if (call.isEmpty()) return "이름과 직급을 입력하시면 맞춤 급여 계산이 시작됩니다 🙂";
        return call + "님의 입력으로 맞춤 급여 계산을 시작합니다!";
    }

    /** 2단계 정년·근속수당 안내 — 만 60세 생일과 단협 제28조 정년일(도달 연도 12/31)을 함께 보여 준다. */
    String wizardRetirementMessage(String name, String birthStr, String joinStr) {
        String call = wizardCalling(name);
        if (call.isEmpty()) call = "회원";
        String clean = normalizeDateString(birthStr);
        StringBuilder sb = new StringBuilder();
        try {
            String[] parts = clean.split("-");
            if (parts.length != 3) throw new Exception("no birth");
            int y = Integer.parseInt(parts[0]), mo = Integer.parseInt(parts[1]), dd = Integer.parseInt(parts[2]);
            LocalDate birth = LocalDate.of(y, mo, dd);
            LocalDate sixty = birth.plusYears(60);
            // 단협 제28조: 만 60세에 도달하는 해의 12월 31일이 정년
            LocalDate retire = LocalDate.of(y + 60, 12, 31);
            LocalDate today = LocalDate.now();
            long total = ChronoUnit.DAYS.between(today, retire);
            if (total <= 0) {
                sb.append(call).append("님은 이미 정년을 맞이하셨습니다. 그동안의 노고에 감사드립니다 🙇");
            } else {
                Period p = Period.between(today, retire);
                sb.append(call).append("님께서는 만 60세 생일(")
                  .append(sixty.getYear()).append(".").append(String.format(Locale.US, "%02d", sixty.getMonthValue()))
                  .append(".").append(String.format(Locale.US, "%02d", sixty.getDayOfMonth()))
                  .append(") 기준 정년일 ").append(retire.getYear()).append(".12.31까지 ")
                  .append(p.getYears()).append("년 ").append(p.getMonths()).append("개월 ").append(p.getDays()).append("일")
                  .append("(총 ").append(String.format(Locale.US, "%,d", total)).append("일) 남으셨네요!");
            }
        } catch (Exception e) {
            sb.append("생년월일(예: 1990-01-01)을 입력하시면 정년까지 남은 날을 알려 드립니다.");
        }
        String joinClean = normalizeDateString(joinStr);
        try {
            String[] jp = joinClean.split("-");
            if (jp.length == 3) {
                LocalDate join = LocalDate.of(Integer.parseInt(jp[0]), Integer.parseInt(jp[1]), Integer.parseInt(jp[2]));
                if (!LocalDate.now().isBefore(join)) {
                    // 아직 저장 전이므로 prefs 가 아니라 입력한 입사일로 직접 계산한다
                    Period sp = Period.between(join, LocalDate.now());
                    int years = Math.max(1, sp.getYears() + 1);
                    int amt = getCalculatedTenureAllowance(joinClean);
                    sb.append("\n입사 ").append(years).append("년차 근속수당(").append(won(amt))
                      .append(")이 자동 연동되었습니다.");
                }
            }
        } catch (Exception ignored) {}
        return sb.toString();
    }

    /** 4단계 가족수당·자녀세액공제 안내 */
    String wizardFamilyMessage(String name, int dependents, int children) {
        String call = wizardCalling(name);
        if (call.isEmpty()) call = "회원";
        long family = Math.round(PayCore.familyAllowanceFor(dependents));
        long childCredit = DeductionCore.childCredit(children);
        StringBuilder sb = new StringBuilder();
        sb.append(call).append("님의 부양가족 ").append(dependents).append("명(본인 포함) 기준으로\n");
        sb.append("• 가족수당: 본인 ").append(won(get("familySelf"))).append(" + 가족 ")
          .append(Math.max(0, dependents - 1)).append("명 × 10,000원 = ").append(won(family)).append("이 자동 세팅됩니다.\n");
        sb.append("• 8~20세 자녀 ").append(children).append("명 → 자녀 세액공제 ")
          .append(childCredit > 0 ? "−" + won(childCredit) : "해당 없음").append("이 소득세에서 빠집니다.");
        return sb.toString();
    }

    /** 진행표시(1/4 …) + 단계별 카드. 각 단계는 새 Dialog로 그려 상태가 꼬이지 않는다. */
    void showWizardStep(final int step) {
        closeWizard();
        final Dialog d = new Dialog(this);
        wizardDialog = d;
        wizardStep = step;
        try { d.requestWindowFeature(Window.FEATURE_NO_TITLE); } catch (Exception ignored) {}

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackgroundColor(colorSurface());

        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(16), dp(20), dp(16));
        sv.addView(col);

        LinearLayout progRow = new LinearLayout(this);
        progRow.setOrientation(LinearLayout.HORIZONTAL);
        progRow.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 1; i <= WIZARD_STEPS; i++) {
            View dot = new View(this);
            GradientDrawable dg = new GradientDrawable();
            dg.setCornerRadius(dp(4));
            dg.setColor(i <= Math.min(step, WIZARD_STEPS) ? colorBlue() : colorBorder());
            dot.setBackground(dg);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(i == step ? dp(22) : dp(8), dp(6));
            dlp.setMargins(0, 0, dp(5), 0);
            progRow.addView(dot, dlp);
        }
        TextView stepTv = textDirect(step > WIZARD_STEPS ? "완료" : step + " / " + WIZARD_STEPS, 11, true);
        stepTv.setTextColor(colorSub());
        stepTv.setPadding(dp(7), 0, 0, 0);
        progRow.addView(stepTv);
        col.addView(progRow);

        if (step == 1) buildWizardStep1(col);
        else if (step == 2) buildWizardStep2(col);
        else if (step == 3) buildWizardStep3(col);
        else if (step == 4) buildWizardStep4(col);
        else buildWizardStepFinal(col);

        d.setContentView(sv);
        try {
            if (d.getWindow() != null) {
                d.getWindow().setBackgroundDrawable(cellBg(colorSurface(), colorBorder(), dp(24)));
                int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.93);
                d.getWindow().setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
        } catch (Exception ignored) {}
        d.setCanceledOnTouchOutside(false);
        d.show();
    }

    void styleWizardPrimary(Button b) {
        if (b == null) return;
        b.setBackground(cellBg(Color.rgb(20, 83, 153), Color.rgb(10, 60, 120), dp(12)));
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setPadding(dp(20), dp(11), dp(20), dp(11));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
    }

    /** 단계 상단 제목 + "왜 이걸 묻는지" 안내 카드 */
    void buildWizardHeader(LinearLayout col, String title, String sub, String message) {
        TextView t = textDirect(title, 19, true);
        t.setTextColor(colorBlue());
        t.setPadding(0, dp(12), 0, 0);
        col.addView(t);

        TextView s = textDirect(sub, 13, false);
        s.setTextColor(colorSub());
        s.setPadding(0, dp(5), 0, dp(10));
        col.addView(s);

        if (message != null && !message.isEmpty()) {
            TextView msg = textDirect(message, 14, true);
            msg.setTextColor(colorInk());
            msg.setLineSpacing(dp(3), 1.08f);
            msg.setBackground(cellBg(isDark() ? Color.rgb(24, 48, 82) : Color.rgb(232, 242, 255),
                    isDark() ? Color.rgb(38, 70, 115) : Color.rgb(198, 222, 250), dp(1)));
            msg.setPadding(dp(14), dp(12), dp(14), dp(12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, dp(6));
            col.addView(msg, lp);
        }
    }

    EditText buildWizardTextField(LinearLayout col, String label, String hint, String value, int inputType) {
        TextView lb = textDirect(label, 13, true);
        lb.setTextColor(colorInk());
        LinearLayout.LayoutParams lbLp = new LinearLayout.LayoutParams(-1, -2);
        lbLp.setMargins(0, dp(11), 0, dp(4));
        col.addView(lb, lbLp);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(cellBg(isDark() ? Color.rgb(24, 33, 47) : Color.rgb(247, 250, 253), colorBorder(), dp(10)));
        box.setPadding(dp(12), 0, dp(12), 0);

        EditText et = new EditText(this);
        et.setText(value == null ? "" : value);
        et.setHint(hint);
        et.setHintTextColor(colorSub());
        et.setTextColor(colorInk());
        et.setTextSize(16);
        et.setBackgroundColor(Color.TRANSPARENT);
        et.setInputType(inputType);
        et.setSingleLine(true);
        et.setPadding(0, dp(10), 0, dp(10));
        box.addView(et, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(box, new LinearLayout.LayoutParams(-1, -2));
        return et;
    }

    EditText buildWizardField(LinearLayout col, String label, String hint, String value, String suffix) {
        TextView lb = textDirect(label, 13, true);
        lb.setTextColor(colorInk());
        LinearLayout.LayoutParams lbLp = new LinearLayout.LayoutParams(-1, -2);
        lbLp.setMargins(0, dp(11), 0, dp(4));
        col.addView(lb, lbLp);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(cellBg(isDark() ? Color.rgb(24, 33, 47) : Color.rgb(247, 250, 253), colorBorder(), dp(10)));
        box.setPadding(dp(12), 0, dp(12), 0);

        EditText et = new EditText(this);
        et.setText(value);
        et.setHint(hint);
        et.setHintTextColor(colorSub());
        et.setTextColor(colorInk());
        et.setTextSize(15);
        et.setBackgroundColor(Color.TRANSPARENT);
        et.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setSingleLine(true);
        et.setPadding(0, dp(10), 0, dp(10));
        box.addView(et, new LinearLayout.LayoutParams(0, -2, 1f));

        if (suffix != null && !suffix.isEmpty()) {
            TextView sf = textDirect(suffix, 13, true);
            sf.setTextColor(colorSub());
            box.addView(sf);
        }
        col.addView(box, new LinearLayout.LayoutParams(-1, -2));
        return et;
    }

    LinearLayout buildWizardChoiceCard(final String title, final String desc, final String value) {
        final LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(15), dp(18), dp(15));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(lp);

        TextView t = textDirect(title, 18, true);
        card.addView(t);

        TextView dd = textDirect(desc, 13, false);
        dd.setTextColor(colorSub());
        dd.setPadding(0, dp(4), 0, 0);
        card.addView(dd);

        TextView check = textDirect("", 13, true);
        check.setTextColor(colorBlue());
        check.setPadding(0, dp(5), 0, 0);
        card.addView(check);
        if ("normal".equals(value)) wizCardNormalCheck = check; else wizCardShiftCheck = check;

        card.setOnClickListener(v -> {
            vibrateTick();
            wizardShiftType = value;
            refreshWizardChoice();
        });
        return card;
    }

    void refreshWizardChoice() {
        applyWizardChoiceCard(wizCardNormal, wizCardNormalCheck, "normal");
        applyWizardChoiceCard(wizCardShift, wizCardShiftCheck, "shift");
    }

    void applyWizardChoiceCard(LinearLayout card, TextView check, String value) {
        if (card == null) return;
        boolean on = value.equals(wizardShiftType);
        card.setBackground(cellBg(
                on ? (isDark() ? Color.rgb(24, 48, 82) : Color.rgb(232, 242, 255)) : colorSurface(),
                on ? colorBlue() : colorBorder(),
                on ? dp(2) : dp(1)));
        if (check != null) check.setText(on ? "✓ 선택됨" : "");
    }

    String formatInputNumber(double v) {
        if (v == (long) v) return String.valueOf((long) v);
        return String.valueOf(Math.round(v * 100d) / 100d);
    }

    LinearLayout buildWizardNav(LinearLayout col, String nextLabel, Runnable onPrev, Runnable onNext) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        if (onPrev != null) {
            TextView back = textDirect("◀ 이전", 13, true);
            back.setTextColor(colorSub());
            back.setPadding(dp(4), dp(12), dp(14), dp(12));
            back.setOnClickListener(v -> { vibrateTick(); onPrev.run(); });
            row.addView(back);
        }
        row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        Button next = button(nextLabel, null);
        styleWizardPrimary(next);
        next.setOnClickListener(v -> { vibrateTick(); onNext.run(); });
        row.addView(next, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(14), 0, 0);
        col.addView(row, lp);
        return row;
    }

    // ── 1단계 : 이름 · 직급 ──────────────────────────────────────
    void buildWizardStep1(LinearLayout col) {
        final TextView[] greetRef = new TextView[1];
        buildWizardHeader(col, "👤 1단계 · 이름과 직급",
                "급여 계산의 첫걸음이에요. 딱 두 가지만 알려 주세요.",
                null);

        final String savedName = prefs != null ? prefs.getString("user_name", "") : "";
        greetRef[0] = textDirect(wizardGreeting(savedName), 15, true);
        greetRef[0].setTextColor(isDark() ? Color.rgb(147, 197, 253) : Color.rgb(20, 83, 153));
        greetRef[0].setLineSpacing(dp(2), 1.06f);
        greetRef[0].setBackground(cellBg(isDark() ? Color.rgb(20, 34, 58) : Color.rgb(238, 246, 255), colorBlue(), dp(1)));
        greetRef[0].setPadding(dp(14), dp(12), dp(14), dp(12));
        col.addView(greetRef[0], new LinearLayout.LayoutParams(-1, -2));

        final EditText nameEt = buildWizardTextField(col, "이름", "예: 홍길동", savedName,
                android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

        TextView rankLbl = textDirect("직급 (직책수당 자동 연동)", 13, true);
        rankLbl.setTextColor(colorInk());
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.setMargins(0, dp(11), 0, dp(4));
        col.addView(rankLbl, rlp);

        final Button rankBtn = button(wizardRank.isEmpty() ? "직급 선택 ▾" : "✓ " + wizardRank, null);
        rankBtn.setTextSize(14);
        rankBtn.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        rankBtn.setTextColor(colorInk());
        rankBtn.setBackground(cellBg(isDark() ? Color.rgb(24, 33, 47) : Color.rgb(247, 250, 253), colorBorder(), dp(10)));
        rankBtn.setPadding(dp(14), dp(11), dp(14), dp(11));
        col.addView(rankBtn, new LinearLayout.LayoutParams(-1, -2));

        final Runnable refreshGreet = () -> {
            try {
                greetRef[0].setText(wizardGreeting(nameEt.getText().toString()));
            } catch (Exception ignored) {}
        };
        nameEt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { refreshGreet.run(); }
        });
        rankBtn.setOnClickListener(v -> {
            vibrateTick();
            new AlertDialog.Builder(this)
                    .setTitle("직급 선택 (직책수당 자동 연동)")
                    .setItems(RANK_NAMES, (dd, which) -> {
                        wizardRank = RANK_NAMES[which];
                        rankBtn.setText("✓ " + wizardRank);
                        rankBtn.setTextColor(colorBlue());
                        refreshGreet.run();
                    })
                    .setNegativeButton("취소", null)
                    .show();
        });

        buildWizardNav(col, "다음 ➜", null, () -> {
            String nm = nameEt.getText().toString().trim();
            if (nm.isEmpty()) {
                Toast.makeText(this, "이름을 입력해 주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (wizardRank.trim().isEmpty()) {
                Toast.makeText(this, "직급을 선택해 주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString("user_name", nm).putString("user_rank", wizardRank).apply();
            showWizardStep(2);
        });
    }

    // ── 2단계 : 생년월일 · 입사년월일 ───────────────────────────
    void buildWizardStep2(LinearLayout col) {
        final String name = prefs != null ? prefs.getString("user_name", "") : "";
        final TextView[] msgRef = new TextView[1];

        buildWizardHeader(col, "🎂 2단계 · 생년월일과 입사년월일",
                "정년 D-Day와 근속수당·연차를 정확히 계산하기 위해 필요해요.",
                null);

        msgRef[0] = textDirect("생년월일과 입사년월일을 입력하시면 정년까지 남은 날과 근속수당을 계산해 드립니다.",
                14, true);
        msgRef[0].setTextColor(colorInk());
        msgRef[0].setLineSpacing(dp(3), 1.08f);
        msgRef[0].setBackground(cellBg(isDark() ? Color.rgb(24, 48, 82) : Color.rgb(232, 242, 255),
                isDark() ? Color.rgb(38, 70, 115) : Color.rgb(198, 222, 250), dp(1)));
        msgRef[0].setPadding(dp(14), dp(12), dp(14), dp(12));
        col.addView(msgRef[0], new LinearLayout.LayoutParams(-1, -2));

        final EditText birthEt = buildWizardTextField(col, "생년월일 (8자리)", "예: 19900101",
                prefs != null ? prefs.getString("user_birth", "") : "", android.text.InputType.TYPE_CLASS_NUMBER);
        final EditText joinEt = buildWizardTextField(col, "입사년월일 (8자리)", "예: 20200101",
                prefs != null ? prefs.getString("user_join_date", "") : "", android.text.InputType.TYPE_CLASS_NUMBER);

        final Runnable refresh = () -> {
            try {
                msgRef[0].setText(wizardRetirementMessage(name,
                        birthEt.getText().toString(), joinEt.getText().toString()));
            } catch (Exception ignored) {}
        };
        birthEt.addTextChangedListener(new DateAutoHyphenWatcher(birthEt, refresh));
        joinEt.addTextChangedListener(new DateAutoHyphenWatcher(joinEt, refresh));

        buildWizardNav(col, "다음 ➜", () -> showWizardStep(1), () -> {
            String b = normalizeDateString(birthEt.getText().toString());
            String j = normalizeDateString(joinEt.getText().toString());
            if (b.length() < 10) {
                Toast.makeText(this, "생년월일을 8자리로 입력해 주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (j.length() < 10) {
                Toast.makeText(this, "입사년월일을 8자리로 입력해 주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString("user_birth", b).putString("user_join_date", j).apply();
            showWizardStep(3);
        });
    }

    // ── 3단계 : 근무형태 · 통상시급 ─────────────────────────────
    void buildWizardStep3(LinearLayout col) {
        final String name = prefs != null ? prefs.getString("user_name", "") : "";
        buildWizardHeader(col, "🏢 3단계 · 근무형태와 통상시급",
                "근무형태에 따라 수당 계산식이 달라집니다. 통상시급은 모든 수당의 기준이에요.",
                wizardGreeting(name));

        wizCardNormal = buildWizardChoiceCard("🏢 상주근무조", "주간 8시간 근무 · 상주휴게수당(1시간 유급) 자동 인정", "normal");
        wizCardShift = buildWizardChoiceCard("🔄 교대근무조", "주·야 10시간 교대 · 교대수당 20만 원 고정 반영", "shift");
        col.addView(wizCardNormal);
        col.addView(wizCardShift);
        refreshWizardChoice();

        wizOrdinary = buildWizardField(col, "통상시급 (기본 시급)", "예: 14939", formatInputNumber(get("ordinary")), "원");

        buildWizardNav(col, "다음 ➜", () -> showWizardStep(2), () -> {
            try { prefs.edit().putString("user_shift_type", wizardShiftType).apply(); } catch (Exception ignored) {}
            if (wizOrdinary != null) {
                String ord = wizOrdinary.getText().toString().trim().replace(",", "");
                if (!ord.isEmpty()) {
                    try {
                        double v = Double.parseDouble(ord);
                        if (v > 0) {
                            String sv = formatInputNumber(v);
                            prefs.edit().putString("setting_ordinary", sv)
                                    .putString("setting_" + month.get(Calendar.YEAR) + "_ordinary", sv).apply();
                        }
                    } catch (Exception ignored) {}
                }
            }
            showWizardStep(4);
        });
    }

    // ── 4단계 : 부양가족 · 자녀 ─────────────────────────────────
    void buildWizardStep4(LinearLayout col) {
        final String name = prefs != null ? prefs.getString("user_name", "") : "";
        final TextView[] msgRef = new TextView[1];

        buildWizardHeader(col, "👨‍👩‍👧 4단계 · 부양가족과 자녀",
                "가족수당과 자녀 세액공제가 자동으로 계산됩니다.",
                null);

        msgRef[0] = textDirect(wizardFamilyMessage(name, getDeductionDependents(), getDeductionChildren()),
                14, true);
        msgRef[0].setTextColor(colorInk());
        msgRef[0].setLineSpacing(dp(3), 1.08f);
        msgRef[0].setBackground(cellBg(isDark() ? Color.rgb(24, 48, 82) : Color.rgb(232, 242, 255),
                isDark() ? Color.rgb(38, 70, 115) : Color.rgb(198, 222, 250), dp(1)));
        msgRef[0].setPadding(dp(14), dp(12), dp(14), dp(12));
        col.addView(msgRef[0], new LinearLayout.LayoutParams(-1, -2));

        wizDependents = buildWizardField(col, "부양가족 수 (본인 포함)", "기본 1", String.valueOf(getDeductionDependents()), "명");
        wizChildren = buildWizardField(col, "8세~20세 자녀 수", "자녀세액공제용 · 기본 0", String.valueOf(getDeductionChildren()), "명");

        final Runnable refresh = () -> {
            try {
                int dep = parseIntSafe(wizDependents != null ? wizDependents.getText().toString() : "1", 1);
                int kid = parseIntSafe(wizChildren != null ? wizChildren.getText().toString() : "0", 0);
                msgRef[0].setText(wizardFamilyMessage(name, Math.max(1, Math.min(20, dep)), Math.max(0, Math.min(10, kid))));
            } catch (Exception ignored) {}
        };
        final TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { refresh.run(); }
        };
        if (wizDependents != null) wizDependents.addTextChangedListener(tw);
        if (wizChildren != null) wizChildren.addTextChangedListener(tw);

        TextView note = textDirect("• 나중에 [급여 및 화면 설정]에서 언제든 바꿀 수 있습니다.", 11, false);
        note.setTextColor(colorSub());
        note.setPadding(0, dp(10), 0, 0);
        col.addView(note);

        buildWizardNav(col, "거의 다 왔어요 ➜", () -> showWizardStep(3), () -> {
            int dep = parseIntSafe(wizDependents != null ? wizDependents.getText().toString() : "1", 1);
            int kid = parseIntSafe(wizChildren != null ? wizChildren.getText().toString() : "0", 0);
            prefs.edit()
                    .putString("ded_dependents", String.valueOf(Math.max(1, Math.min(20, dep))))
                    .putString("ded_children", String.valueOf(Math.max(0, Math.min(10, kid))))
                    .apply();
            showWizardStep(5);
        });
    }

    int parseIntSafe(String s, int fallback) {
        try {
            String digits = s == null ? "" : s.replaceAll("[^0-9]", "").trim();
            if (digits.isEmpty()) return fallback;
            return Integer.parseInt(digits);
        } catch (Exception e) {
            return fallback;
        }
    }

    // ── 완료 : 정적인 피코 이미지 + 안전근무 인사 (v1.4.3: 손흔들기/바운스 애니메이션 제거) ──
    void buildWizardStepFinal(LinearLayout col) {
        final String name = prefs != null ? prefs.getString("user_name", "") : "";
        String call = wizardCalling(name);
        if (call.isEmpty()) call = "회원";

        FrameLayout stage = new FrameLayout(this);
        stage.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(262)));

        // 은은한 원형 배경
        View glow = new View(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(isDark() ? Color.rgb(22, 44, 76) : Color.rgb(232, 242, 255));
        glow.setBackground(gd);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(dp(238), dp(238), Gravity.CENTER);
        stage.addView(glow, glp);

        // v1.4.3 ③: 새 전신 피코(안전모 + 작업복, 손 흔들기) — 흰 바탕을 살려 단정한 "스티커 카드"로 앉힌다
        FrameLayout badge = new FrameLayout(this);
        GradientDrawable bd = new GradientDrawable();
        bd.setShape(GradientDrawable.RECTANGLE);
        bd.setCornerRadius(dp(26));
        bd.setColor(Color.WHITE);
        badge.setBackground(bd);
        badge.setElevation(dp(6));
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(dp(212), dp(236), Gravity.CENTER);
        stage.addView(badge, blp);

        final ImageView pico = new ImageView(this);
        pico.setImageResource(R.drawable.pico_safety_full);
        pico.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        plp.setMargins(dp(8), dp(8), dp(8), dp(8));
        badge.addView(pico, plp);

        col.addView(stage);

        TextView title = textDirect(call + "님, 준비 완료입니다! 🎉", 19, true);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(colorInk());
        title.setPadding(0, dp(6), 0, 0);
        col.addView(title);

        TextView safety = textDirect("행복한 가정으로 돌아가기 위해\n오늘도 안전근무하세요! 🏠👷‍♂️", 17, true);
        safety.setGravity(Gravity.CENTER);
        safety.setTextColor(isDark() ? Color.rgb(147, 197, 253) : Color.rgb(20, 83, 153));
        safety.setLineSpacing(dp(4), 1.06f);
        safety.setPadding(dp(10), dp(12), dp(10), dp(12));
        safety.setBackground(cellBg(isDark() ? Color.rgb(20, 34, 58) : Color.rgb(238, 246, 255), colorBlue(), dp(1)));
        LinearLayout.LayoutParams sfLp = new LinearLayout.LayoutParams(-1, -2);
        sfLp.setMargins(0, dp(8), 0, dp(10));
        col.addView(safety, sfLp);

        String shiftName = isShiftWorker() ? "교대근무조" : "상주근무조";
        String summary = shiftName + " · 통상시급 " + won(get("ordinary"))
                + " · 부양가족 " + getDeductionDependents() + "명"
                + (getDeductionChildren() > 0 ? " · 자녀 " + getDeductionChildren() + "명" : "");
        TextView sumTv = textDirect(summary, 12, false);
        sumTv.setTextColor(colorSub());
        sumTv.setGravity(Gravity.CENTER);
        sumTv.setBackground(cellBg(isDark() ? Color.rgb(24, 33, 47) : Color.rgb(247, 250, 253), colorBorder(), dp(12)));
        sumTv.setPadding(dp(14), dp(10), dp(14), dp(10));
        LinearLayout.LayoutParams sumLp = new LinearLayout.LayoutParams(-1, -2);
        sumLp.setMargins(0, 0, 0, dp(14));
        col.addView(sumTv, sumLp);

        Button startBtn = button("시작하기", null);
        styleWizardPrimary(startBtn);
        startBtn.setTextSize(16);
        startBtn.setPadding(dp(20), dp(13), dp(20), dp(13));
        startBtn.setOnClickListener(v -> {
            vibrateTick();
            closeWizard();
            markOnboardingDone();
            showMain();
        });
        col.addView(startBtn, new LinearLayout.LayoutParams(-1, -2));

        TextView tour = textDirect("✨ 주요 기능 둘러보기", 13, true);
        tour.setGravity(Gravity.CENTER);
        tour.setTextColor(colorBlue());
        tour.setPadding(0, dp(12), 0, dp(6));
        tour.setOnClickListener(v -> {
            vibrateTick();
            closeWizard();
            markOnboardingDone();
            showMain();
            if (mainContainer != null) mainContainer.postDelayed(this::startSpotlightTour, 420);
        });
        col.addView(tour);
    }

    // ════════════════════════════════════════════════════════════════
    // v1.4.0 ② — 인터랙티브 스팟라이트 코치마크 메뉴 투어 (5곳)
    //   화면 전체 반투명 딤(0.75) + 대상 영역 둥근 컷아웃 + 큰 글자 가이드 카드
    // ════════════════════════════════════════════════════════════════
    static final String[] SPOT_TITLES = {
        "① ⚡ 빠른 근무 3버튼 바",
        "② 📅 캘린더 날짜 셀",
        "③ 📇 출근카드 1:1 · 📊 근무 통계",
        "④ 💰 예상 실수령액 · 소급 · 🏆 격려금",
        "⑤ ☰ 좌측 메뉴 드로어"
    };
    static final String[] SPOT_DESCS = {
        "터치 한 번으로 근무를 기록하거나 출근카드 사진을 찍어 자동 입력합니다.",
        "날짜를 한 번 누르면 선택만 되고, 같은 날짜를 다시 누르면 6대 퀵 버튼과 직접 입력창이 열립니다.",
        "종이 출근카드와 1시간 오차 없는 환산 집계표와 도넛 통계를 확인합니다.",
        "이번 달 세후 실수령액과 소급분 차액을 확인하고 성과격려금을 계산합니다.",
        "시급·공제 설정을 변경하고 소중한 근무 데이터를 엑셀로 백업·복원합니다."
    };

    View spotTarget(int i) {
        switch (i) {
            case 0:  return spotQuickBar;
            case 1:  return spotCalCell != null ? spotCalCell : calendarBlock;
            case 2:  return spotStatsCard;
            case 3:  return spotHeroCard;
            default: return spotMenuIcon;
        }
    }

    void startSpotlightTour() {
        if (mainContainer == null) return;
        spotTourActive = true;
        spotStep = 0;
        hideTopButtonForTour();     // v1.4.3: 투어 중 [▲ TOP] 간섭 원천 차단
        showSpotStep(0);
    }

    /** v1.4.3 ②-3: 스팟라이트 투어·온보딩 중에는 [▲ TOP] 플로팅 버튼을 즉시 숨긴다. */
    void hideTopButtonForTour() {
        if (topFloatBtn == null) return;
        try {
            topFloatBtn.animate().cancel();
            topFloatBtn.setAlpha(0f);
            topFloatBtn.setVisibility(View.GONE);
        } catch (Throwable ignored) {}
    }

    /** 투어가 끝나거나 건너뛰면 스크롤 위치에 맞춰 [▲ TOP]을 원래대로 되돌린다. */
    void restoreTopButtonForTour() {
        if (topFloatBtn == null) return;
        try {
            boolean show = mainScrollView != null && mainScrollView.getScrollY() > dp(320);
            topFloatBtn.setVisibility(show ? View.VISIBLE : View.GONE);
            topFloatBtn.setAlpha(show ? 1f : 0f);
            topFloatBtn.setTranslationY(show ? 0f : dp(8));
        } catch (Throwable ignored) {}
    }

    void showSpotStep(int i) {
        if (!spotTourActive || mainContainer == null) return;
        if (i >= SPOT_TITLES.length) { endSpotTour(); return; }
        spotStep = i;
        removeSpotOverlay();
        final View target = spotTarget(i);
        if (target == null) { showSpotStep(i + 1); return; }
        final int idx = i;
        if (mainScrollView == null) { drawSpotOverlay(target, idx); return; }

        mainScrollView.post(() -> {
            try {
                // 대상이 화면 중앙 부근에 오도록 먼저 스크롤한 뒤 스팟라이트를 그린다
                int[] tl = new int[2];
                int[] sl = new int[2];
                target.getLocationInWindow(tl);
                mainScrollView.getLocationInWindow(sl);
                int vh = mainScrollView.getHeight();
                int relTop = tl[1] - sl[1];
                int th = target.getHeight();
                int delta;
                if (th > vh - dp(240)) delta = relTop - dp(16);            // 화면보다 큰 카드는 상단 기준
                else delta = relTop - Math.max(dp(20), (vh - th) / 2);
                if (Math.abs(delta) >= dp(6)) {
                    // 스크롤 애니메이션과 컷아웃이 어긋나지 않도록 목표 위치로 즉시 이동한 뒤 그린다
                    int newY = Math.max(0, mainScrollView.getScrollY() + delta);
                    mainScrollView.scrollTo(0, newY);
                    mainScrollView.postDelayed(() -> drawSpotOverlay(target, idx), 140);
                } else {
                    drawSpotOverlay(target, idx);
                }
            } catch (Throwable t) {
                drawSpotOverlay(target, idx);
            }
        });
    }

    void drawSpotOverlay(View target, final int idx) {
        try {
            if (!spotTourActive || mainContainer == null || target == null) return;
            removeSpotOverlay();
            final int w = mainContainer.getWidth();
            final int h = mainContainer.getHeight();
            if (w <= 0 || h <= 0) return;

            int[] tl = new int[2];
            int[] cl = new int[2];
            target.getLocationInWindow(tl);
            mainContainer.getLocationInWindow(cl);

            float pad = dp(6);
            float left = tl[0] - cl[0] - pad;
            float top = tl[1] - cl[1] - pad;
            float right = left + target.getWidth() + pad * 2f;
            float bottom = top + target.getHeight() + pad * 2f;

            // 대상이 화면보다 크면 위쪽 54%까지만 컷아웃해 카드 자리를 남긴다
            float maxH = h * 0.54f;
            if (bottom - top > maxH) bottom = top + maxH;
            if (left < dp(6)) left = dp(6);
            if (right > w - dp(6)) right = w - dp(6);
            if (top < dp(6)) top = dp(6);
            if (bottom > h - dp(6)) bottom = h - dp(6);
            if (right - left < dp(60)) right = Math.min(w - dp(6), left + dp(60));
            if (bottom - top < dp(44)) bottom = Math.min(h - dp(6), top + dp(44));

            final RectF hole = new RectF(left, top, right, bottom);

            FrameLayout holder = new FrameLayout(this);
            SpotDimView dim = new SpotDimView(this);
            // v1.4.3 ②-5: 이전 타깃의 구멍에서 새 타깃의 구멍으로 부드럽게 미끄러진다
            if (lastSpotHole != null) {
                dim.setHole(new RectF(lastSpotHole), dp(18));
                dim.animateHoleTo(hole, 360);
            } else {
                dim.setHole(hole, dp(18));
            }
            lastSpotHole = new RectF(hole);
            dim.setClickable(true);          // 딤 뒤 실제 화면은 눌리지 않는다
            holder.addView(dim, new FrameLayout.LayoutParams(-1, -1));

            // v1.4.3 ②-4: 반투명 다크 글래스 카드 + 시원한 큰 글자 (16sp 본문)
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable glass = new GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{ Color.argb(238, 20, 31, 52), Color.argb(244, 12, 20, 36) });
            glass.setCornerRadius(dp(22));
            glass.setStroke(dp(1), Color.argb(150, 96, 165, 250));
            card.setBackground(glass);
            card.setPadding(dp(18), dp(16), dp(18), dp(13));
            card.setElevation(dp(22));

            TextView cnt = textDirect("✨ 스팟라이트 가이드  " + (idx + 1) + " / " + SPOT_TITLES.length, 13, true);
            cnt.setTextColor(Color.rgb(125, 211, 252));
            card.addView(cnt);

            TextView tt = textDirect(SPOT_TITLES[idx], 19, true);
            tt.setTextColor(Color.rgb(248, 250, 252));
            tt.setPadding(0, dp(6), 0, dp(7));
            card.addView(tt);

            TextView ds = textDirect(SPOT_DESCS[idx], 16, false);
            ds.setTextColor(Color.rgb(226, 232, 240));
            ds.setLineSpacing(dp(4), 1.06f);
            card.addView(ds);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView skip = textDirect("건너뛰기", 14, true);
            skip.setTextColor(Color.rgb(148, 163, 184));
            skip.setPadding(dp(4), dp(12), dp(12), dp(12));
            skip.setOnClickListener(v -> { vibrateTick(); endSpotTour(); });
            btnRow.addView(skip);

            View spacer = new View(this);
            btnRow.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

            Button next = button(idx == SPOT_TITLES.length - 1
                    ? "마침"
                    : "다음 (" + (idx + 1) + "/" + SPOT_TITLES.length + ") ➜", null);
            styleWizardPrimary(next);
            next.setTextSize(15);
            next.setPadding(dp(18), dp(11), dp(18), dp(11));
            next.setOnClickListener(v -> {
                vibrateTick();
                if (idx == SPOT_TITLES.length - 1) endSpotTour();
                else showSpotStep(idx + 1);
            });
            btnRow.addView(next, new LinearLayout.LayoutParams(-2, -2));

            LinearLayout.LayoutParams brLp = new LinearLayout.LayoutParams(-1, -2);
            brLp.setMargins(0, dp(11), 0, 0);
            card.addView(btnRow, brLp);

            FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(-1, -2);
            cardLp.setMargins(dp(14), 0, dp(14), 0);
            holder.addView(card, cardLp);

            // 컷아웃 아래에 자리가 있으면 아래, 없으면 위에 카드를 붙인다
            card.post(() -> {
                try {
                    int ch = card.getHeight();
                    float y = (hole.bottom + dp(16) + ch <= h - dp(8))
                            ? hole.bottom + dp(16)
                            : Math.max(dp(8), hole.top - dp(16) - ch);
                    card.setY(y);
                } catch (Throwable ignored) {}
            });
            card.setScaleX(0.94f);
            card.setScaleY(0.94f);
            card.setAlpha(0f);
            card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(200)
                    .setInterpolator(new DecelerateInterpolator()).start();

            mainContainer.addView(holder, new FrameLayout.LayoutParams(-1, -1));
            spotRoot = holder;
        } catch (Throwable ignored) {}
    }

    void endSpotTour() {
        spotTourActive = false;
        removeSpotOverlay();
        restoreTopButtonForTour();
        lastSpotHole = null;
        markOnboardingDone();
    }

    void removeSpotOverlay() {
        try {
            if (mainContainer != null) mainContainer.removeView(spotRoot);
        } catch (Throwable ignored) {}
        spotRoot = null;
        if (!spotTourActive) restoreTopButtonForTour();
    }

    /**
     * 반투명 딤 위에 대상 영역만 둥근 사각형으로 뚫어(CLEAR) 비추고,
     * 그 둘레에 빛나는 포커스 링을 그리는 커스텀 뷰.
     */
    static class SpotDimView extends View {
        final RectF hole = new RectF();
        float radius = 30f;
        float pulse = 0f;                 // 0~1 은은한 숨쉬기
        final Paint dimPaint = new Paint();
        final Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint wavePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        android.animation.ValueAnimator pulseAnim;
        android.animation.ValueAnimator holeAnim;

        SpotDimView(Context c) {
            super(c);
            dimPaint.setColor(Color.argb(191, 0, 0, 0));       // rgba(0,0,0,0.75)
            clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(dp(2.4f));
            ringPaint.setColor(Color.rgb(56, 189, 248));
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth(dp(9f));
            glowPaint.setColor(Color.argb(80, 56, 189, 248));
            wavePaint.setStyle(Paint.Style.STROKE);
            wavePaint.setStrokeWidth(dp(1.6f));
            startPulse();
        }

        float dp(float v) {
            return getResources().getDisplayMetrics().density * v;
        }

        void setHole(RectF r, float rad) {
            hole.set(r);
            radius = rad;
            invalidate();
        }

        /** v1.4.3 ②-5: 포커스 링이 은은하게 숨 쉬는 펄스 애니메이션 */
        void startPulse() {
            if (pulseAnim != null) return;
            try {
                pulseAnim = android.animation.ValueAnimator.ofFloat(0f, 1f);
                pulseAnim.setDuration(1500);
                pulseAnim.setRepeatCount(android.animation.ValueAnimator.INFINITE);
                pulseAnim.setRepeatMode(android.animation.ValueAnimator.REVERSE);
                pulseAnim.setInterpolator(new AccelerateDecelerateInterpolator());
                pulseAnim.addUpdateListener(a -> {
                    Object v = a.getAnimatedValue();
                    pulse = v instanceof Float ? (Float) v : 0f;
                    invalidate();
                });
                pulseAnim.start();
            } catch (Throwable ignored) {}
        }

        /** v1.4.3 ②-5: 다음 타깃 버튼으로 하이라이트 구멍이 트윈 이동 */
        void animateHoleTo(final RectF target, long duration) {
            try {
                if (holeAnim != null) holeAnim.cancel();
                final RectF from = new RectF(hole);
                holeAnim = android.animation.ValueAnimator.ofFloat(0f, 1f);
                holeAnim.setDuration(duration);
                holeAnim.setInterpolator(new DecelerateInterpolator());
                holeAnim.addUpdateListener(a -> {
                    Object v = a.getAnimatedValue();
                    float f = v instanceof Float ? (Float) v : 1f;
                    hole.left = from.left + (target.left - from.left) * f;
                    hole.top = from.top + (target.top - from.top) * f;
                    hole.right = from.right + (target.right - from.right) * f;
                    hole.bottom = from.bottom + (target.bottom - from.bottom) * f;
                    invalidate();
                });
                holeAnim.start();
            } catch (Throwable ignored) {
                hole.set(target);
                invalidate();
            }
        }

        @Override
        protected void onDetachedFromWindow() {
            try {
                if (pulseAnim != null) { pulseAnim.cancel(); pulseAnim = null; }
                if (holeAnim != null) { holeAnim.cancel(); holeAnim = null; }
            } catch (Throwable ignored) {}
            super.onDetachedFromWindow();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (hole.width() <= 0 || hole.height() <= 0) {
                canvas.drawColor(dimPaint.getColor());
                return;
            }
            int layer = -1;
            try {
                layer = canvas.saveLayer(0, 0, getWidth(), getHeight(), null);
            } catch (Throwable ignored) {}
            canvas.drawColor(dimPaint.getColor());
            canvas.drawRoundRect(hole, radius, radius, clearPaint);
            if (layer >= 0) canvas.restoreToCount(layer);

            // 숨쉬는 링: 굵기·밝기가 함께 완만하게 오간다
            ringPaint.setStrokeWidth(dp(2.2f + 1.5f * pulse));
            glowPaint.setAlpha((int) (50 + 105 * pulse));
            canvas.drawRoundRect(hole, radius, radius, glowPaint);
            canvas.drawRoundRect(hole, radius, radius, ringPaint);

            // 바깥으로 퍼지는 은은한 파동
            float grow = dp(6f + 12f * pulse);
            wavePaint.setColor(Color.argb((int) (95 * (1f - pulse)), 125, 211, 252));
            RectF outer = new RectF(hole);
            outer.inset(-grow, -grow);
            canvas.drawRoundRect(outer, radius + grow, radius + grow, wavePaint);
        }
    }

    void showPicoSplash() {
        FrameLayout fl = new FrameLayout(this);
        fl.setBackgroundColor(Color.rgb(13, 52, 112));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(28), 0, dp(28), 0);
        fl.addView(col, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout card = new FrameLayout(this);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(dp(28));
        card.setBackground(cardBg);
        card.setClipToOutline(true);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.setElevation(dp(10));

        ImageView picoIv = new ImageView(this);
        picoIv.setImageResource(R.drawable.pico_splash_anim);
        picoIv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        card.addView(picoIv, new FrameLayout.LayoutParams(-1, -1));

        int cardW = (int) (getResources().getDisplayMetrics().widthPixels * 0.70);
        // 신규 피코 스플래시(276×312) 비율에 카드 종횡비를 정확히 맞춘다 (카드 안쪽 여백 dp10×2 제외)
        int cardInnerW = cardW - dp(20);
        int cardH = (int) (cardInnerW * 312f / 276f) + dp(20);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(cardW, cardH);
        cardLp.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(card, cardLp);

        picoIv.post(() -> {
            try {
                Drawable dw = picoIv.getDrawable();
                if (dw instanceof android.graphics.drawable.AnimationDrawable) {
                    ((android.graphics.drawable.AnimationDrawable) dw).start();
                }
            } catch (Exception ignored) {}
        });

        TextView appName = textDirect("나의 근무·급여 관리", 21, true);
        appName.setTextColor(Color.WHITE);
        appName.setGravity(Gravity.CENTER);
        appName.setPadding(0, dp(22), 0, dp(4));
        col.addView(appName);

        TextView verTv = textDirect("ShiftPay v" + CURRENT_VERSION_LABEL + "  ·  현대스틸파이프", 12, false);
        verTv.setTextColor(Color.rgb(176, 205, 240));
        verTv.setGravity(Gravity.CENTER);
        col.addView(verTv);

        TextView cheer = textDirect("피코와 함께 오늘도 안전하게! 화이팅 💪", 12, true);
        cheer.setTextColor(Color.rgb(120, 190, 255));
        cheer.setGravity(Gravity.CENTER);
        cheer.setPadding(0, dp(18), 0, 0);
        col.addView(cheer);

        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(true);
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(dp(96), dp(4));
        pbLp.gravity = Gravity.CENTER_HORIZONTAL;
        pbLp.setMargins(0, dp(14), 0, 0);
        col.addView(pb, pbLp);

        setContentView(fl);

        fl.postDelayed(() -> {
            try {
                fl.animate().alpha(0f).setDuration(260).withEndAction(this::showMain).start();
            } catch (Exception e) {
                showMain();
            }
        }, 2100);
    }

    // ════════════════════════════════════════════════════════════════
    // 월간 근무 통계 (도넛 차트 + 요일별 누적 막대 그래프)
    // ════════════════════════════════════════════════════════════════
    // 반환값: PayCore.CB_* 17칸 (정취·유급·주차·연차·조합 / 연장·휴일근로·휴일연장·심야 /
    //          가급·휴일가급·평일가급 / 기본인정·실제근로·급여인정·환산시간·근무일수)
    //  — 이번 달 화면(refreshSummary)과 통계 모달이 같은 계산(PayCore.cardBreakdown)을 공유한다.
    double[] statTotals(int year, int month1) {
        return cardBreakdown(year, month1);
    }

    // 상주휴게(가급): 출근카드 OCR로 기록된 값이 있으면 그대로, 없으면 실근무 8시간 이상인 날 1시간 인정
    // 단협 제49조 4항 "실근무 8시간 근무 시 상주휴게 1일 인정" — 평일 정상근무뿐 아니라
    // 휴일특근일(휴일근로 8h 이상)도 실근무 8시간 이상이므로 1시간을 자동 인정한다.
    double gageubOfDay(double[] v, boolean gageubRecorded) {
        if (gageubRecorded) return Math.max(0, v[8]);
        if (isShiftWorker()) return 0;
        return (v[0] >= 8 || (v[5] + v[6]) >= 8) ? 1.0 : 0;
    }

    // 요일별(일~토) 누적 근무시간
    double[] statWeekdayHours(int year, int month1) {
        double[] w = new double[7];
        int maxDay = LocalDate.of(year, month1, 1).lengthOfMonth();
        String prefix = String.format(Locale.US, "%04d-%02d-", year, month1);
        for (int d = 1; d <= maxDay; d++) {
            String dd = String.format(Locale.US, "%02d", d);
            String mode = prefs.getString(prefix + dd + "-mode", "auto");
            boolean leave = mode.equals("annual") || mode.equals("summer");
            int dow = LocalDate.of(year, month1, d).getDayOfWeek().getValue() % 7;
            double[] v = new double[keys.length];
            boolean gageubRecorded = prefs.contains(prefix + dd + "-" + keys[8]);
            for (int j = 0; j < keys.length; j++) {
                String k = prefix + dd + "-" + keys[j];
                if (prefs.contains(k)) {
                    v[j] = num(k);
                } else if (j == 0 && leave) {
                    v[0] = 8;
                } else if (j == 1 && dow == 6) {
                    v[1] = 8;
                } else if (j == 2 && dow == 0) {
                    v[2] = 8;
                }
            }
            // 요일별 누적시간에도 상주휴게(가급)를 포함해야 총 근무시간과 1시간 오차 없이 맞는다
            w[dow] += (v[0] + v[4] + v[5] + v[6] + gageubOfDay(v, gageubRecorded));
        }
        return w;
    }

    class PicoDonutView extends View {
        double[] vals;
        int[] cols;
        String topLabel = "총 근무시간", topValue = "", bottomLabel = "", bottomValue = "";

        PicoDonutView(double[] vals, int[] cols) {
            super(MainActivity.this);
            this.vals = vals;
            this.cols = cols;
        }

        /** 도넛 중앙에 두 개의 숫자를 위·아래로 병기 (실제 근로 / 급여 인정) */
        PicoDonutView(double[] vals, int[] cols, String topLabel, String topValue,
                      String bottomLabel, String bottomValue) {
            this(vals, cols);
            this.topLabel = topLabel;
            this.topValue = topValue;
            this.bottomLabel = bottomLabel;
            this.bottomValue = bottomValue;
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            float size = Math.min(w, h) - dp(6);
            float cx = w / 2f, cy = h / 2f;
            float stroke = size * 0.2f;
            float rad = size / 2f - stroke / 2f;
            RectF oval = new RectF(cx - rad, cy - rad, cx + rad, cy + rad);

            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(stroke);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setColor(isDark() ? Color.rgb(38, 50, 70) : Color.rgb(233, 239, 247));
            c.drawCircle(cx, cy, rad, p);

            double total = 0;
            for (double v : vals) total += v;
            float start = -90f;
            if (total > 0) {
                for (int i = 0; i < vals.length; i++) {
                    if (vals[i] <= 0) continue;
                    float sweep = (float) (vals[i] / total * 360f);
                    p.setColor(cols[i]);
                    c.drawArc(oval, start, sweep, false, p);
                    start += sweep;
                }
            }

            Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
            tp.setTextAlign(Paint.Align.CENTER);
            if (bottomValue == null || bottomValue.isEmpty()) {
                tp.setColor(colorInk());
                tp.setTypeface(Typeface.DEFAULT_BOLD);
                tp.setTextSize(dp(19));
                c.drawText(new DecimalFormat("0.#").format(total) + "h", cx, cy + dp(3), tp);
                tp.setTypeface(Typeface.DEFAULT);
                tp.setTextSize(dp(10));
                tp.setColor(colorSub());
                c.drawText(topLabel, cx, cy + dp(17), tp);
            } else {
                // 상단: 실제 근로(출근해 일한 시간) / 하단: 급여 인정(유급·가급까지 더한 시간)
                tp.setTypeface(Typeface.DEFAULT);
                tp.setTextSize(dp(9));
                tp.setColor(colorSub());
                c.drawText(topLabel, cx, cy - dp(25), tp);

                tp.setTypeface(Typeface.DEFAULT_BOLD);
                tp.setTextSize(dp(16));
                tp.setColor(colorInk());
                c.drawText(topValue, cx, cy - dp(11), tp);

                tp.setTypeface(Typeface.DEFAULT);
                tp.setTextSize(dp(9));
                tp.setColor(colorSub());
                c.drawText(bottomLabel, cx, cy + dp(7), tp);

                tp.setTypeface(Typeface.DEFAULT_BOLD);
                tp.setTextSize(dp(13));
                tp.setColor(Color.rgb(52, 211, 153));
                c.drawText(bottomValue, cx, cy + dp(22), tp);
            }
        }
    }

    class PicoBarChartView extends View {
        double[] vals; // 0=일 ~ 6=토

        PicoBarChartView(double[] vals) {
            super(MainActivity.this);
            this.vals = vals;
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            double max = 0;
            for (double v : vals) max = Math.max(max, v);
            if (max <= 0) max = 1;

            float baseY = h - dp(20);
            float top = dp(22);
            float slot = w / 7f;
            String[] labels = {"일", "월", "화", "수", "목", "금", "토"};

            Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
            track.setColor(isDark() ? Color.rgb(30, 44, 66) : Color.rgb(236, 241, 248));

            Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
            Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
            label.setTextAlign(Paint.Align.CENTER);
            label.setTextSize(dp(10));

            for (int i = 0; i < 7; i++) {
                float barW = slot * 0.5f;
                float x = slot * i + (slot - barW) / 2f;
                c.drawRoundRect(new RectF(x, top, x + barW, baseY), dp(5), dp(5), track);

                if (vals[i] > 0) {
                    float barH = (float) ((baseY - top) * (vals[i] / max));
                    if (barH < dp(5)) barH = dp(5);
                    bar.setColor(i == 0 ? Color.rgb(239, 68, 68) : (i == 6 ? Color.rgb(37, 99, 235) : colorBlue()));
                    c.drawRoundRect(new RectF(x, baseY - barH, x + barW, baseY), dp(5), dp(5), bar);

                    label.setColor(colorInk());
                    label.setTypeface(Typeface.DEFAULT_BOLD);
                    c.drawText(new DecimalFormat("0.#").format(vals[i]), x + barW / 2f, baseY - barH - dp(5), label);
                }

                label.setTypeface(Typeface.DEFAULT);
                label.setColor(i == 0 ? Color.rgb(239, 68, 68) : (i == 6 ? Color.rgb(37, 99, 235) : colorSub()));
                c.drawText(labels[i], x + barW / 2f, baseY + dp(15), label);
            }
        }
    }

    void showStatsModal() {
        final int[] sy = {month.get(Calendar.YEAR)};
        final int[] sm = {month.get(Calendar.MONTH) + 1};

        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(colorSurface());
        shell.setPadding(dp(16), dp(14), dp(16), dp(12));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = textDirect("📊 근무 통계 & 분석", 17, true);
        title.setTextColor(colorBlue());
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView closeTv = textDirect("✕", 18, true);
        closeTv.setTextColor(colorSub());
        closeTv.setPadding(dp(8), dp(2), dp(2), dp(2));
        closeTv.setOnClickListener(v -> d.dismiss());
        titleRow.addView(closeTv);
        shell.addView(titleRow);

        TextView sub = textDirect("정취·연장·휴일특근·가급·유급 비율과 요일별 근무 패턴 · 좌우로 밀어 월 이동", 11, false);
        sub.setTextColor(colorSub());
        sub.setPadding(0, dp(1), 0, dp(8));
        shell.addView(sub);

        // 월 이동 바
        LinearLayout navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setGravity(Gravity.CENTER_VERTICAL);
        navBar.setBackground(cellBg(isDark() ? Color.rgb(24, 34, 52) : Color.rgb(240, 245, 252), colorBorder(), dp(1)));
        navBar.setPadding(dp(6), dp(4), dp(6), dp(4));

        Button prev = button("◀", null);
        prev.setMinWidth(0);
        prev.setMinimumWidth(0);
        prev.setMinHeight(0);
        prev.setMinimumHeight(0);
        prev.setTextSize(12);
        prev.setPadding(dp(8), dp(2), dp(8), dp(2));
        navBar.addView(prev);

        TextView monthLabel = textDirect("", 14, true);
        monthLabel.setTextColor(colorInk());
        monthLabel.setGravity(Gravity.CENTER);
        navBar.addView(monthLabel, new LinearLayout.LayoutParams(0, -2, 1f));

        Button next = button("▶", null);
        next.setMinWidth(0);
        next.setMinimumWidth(0);
        next.setMinHeight(0);
        next.setMinimumHeight(0);
        next.setTextSize(12);
        next.setPadding(dp(8), dp(2), dp(8), dp(2));
        navBar.addView(next);

        shell.addView(navBar);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, dp(10), 0, dp(6));
        sv.addView(body);
        shell.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        Runnable render = () -> {
            body.removeAllViews();
            monthLabel.setText(sy[0] + "년 " + sm[0] + "월");

            double[] t = statTotals(sy[0], sm[0]);
            double[] wd = statWeekdayHours(sy[0], sm[0]);
            double actual = t[PayCore.CB_ACTUAL];          // 실제 근로 (정취+연장+휴일특근)
            double paidOnly = t[PayCore.CB_PAID] + t[PayCore.CB_WEEKLY] + t[PayCore.CB_ANNUAL];  // 유급 인정
            double total = t[PayCore.CB_PAY];              // 급여 인정 (도넛 전체)

            LinearLayout chartCard = new LinearLayout(this);
            chartCard.setOrientation(LinearLayout.HORIZONTAL);
            chartCard.setGravity(Gravity.CENTER_VERTICAL);
            chartCard.setBackground(cellBg(colorBg(), colorBorder(), dp(1)));
            chartCard.setPadding(dp(10), dp(12), dp(12), dp(12));

            if (total <= 0) {
                LinearLayout emptyBox = new LinearLayout(this);
                emptyBox.setOrientation(LinearLayout.VERTICAL);
                emptyBox.setGravity(Gravity.CENTER);
                emptyBox.setPadding(dp(10), dp(26), dp(10), dp(26));
                TextView e1 = textDirect("📊", 28, false);
                e1.setGravity(Gravity.CENTER);
                emptyBox.addView(e1);
                TextView e2 = textDirect("이번 달 등록된 근무 기록이 없습니다.", 13, true);
                e2.setGravity(Gravity.CENTER);
                e2.setPadding(0, dp(6), 0, dp(2));
                emptyBox.addView(e2);
                TextView e3 = textDirect("달력에서 근무를 입력하면 차트가 자동으로 생성됩니다.", 11, false);
                e3.setTextColor(colorSub());
                e3.setGravity(Gravity.CENTER);
                emptyBox.addView(e3);
                chartCard.addView(emptyBox, new LinearLayout.LayoutParams(-1, -2));
            } else {
                int blue = colorBlue();
                int cNormal = Color.rgb(37, 99, 235);
                int cOt = Color.rgb(245, 158, 11);
                int cHol = Color.rgb(239, 68, 68);
                int cGageub = Color.rgb(16, 185, 129);
                int cPaid = Color.rgb(139, 92, 246);   // 유급·주휴 = 보라/인디고 (일한 시간이 아님)
                double holWork = t[PayCore.CB_HOL] + t[PayCore.CB_HOLOT];
                PicoDonutView donut = new PicoDonutView(
                    new double[]{t[PayCore.CB_NORMAL], t[PayCore.CB_OT], holWork, t[PayCore.CB_GAGEUB], paidOnly},
                    new int[]{cNormal, cOt, cHol, cGageub, cPaid},
                    "실제 근로", hoursShort(actual) + "h",
                    "급여 인정", hoursShort(total) + "h");
                LinearLayout.LayoutParams donutLp = new LinearLayout.LayoutParams(dp(126), dp(126));
                chartCard.addView(donut, donutLp);

                LinearLayout legend = new LinearLayout(this);
                legend.setOrientation(LinearLayout.VERTICAL);
                legend.setPadding(dp(10), 0, 0, 0);
                legend.addView(statsLegendRow("정취", t[PayCore.CB_NORMAL], total, cNormal, colorInk()));
                legend.addView(statsLegendRow("연장", t[PayCore.CB_OT], total, cOt, Color.rgb(217, 119, 6)));
                legend.addView(statsLegendRow("휴일특근", holWork, total, cHol, Color.rgb(220, 38, 38)));
                legend.addView(statsLegendRow("가급", t[PayCore.CB_GAGEUB], total, cGageub, Color.rgb(5, 150, 105)));
                legend.addView(statsLegendRow("유급·주휴", paidOnly, total, cPaid, Color.rgb(109, 40, 217)));
                LinearLayout.LayoutParams legendLp = new LinearLayout.LayoutParams(0, -2, 1f);
                chartCard.addView(legend, legendLp);
            }
            LinearLayout.LayoutParams chartLp = new LinearLayout.LayoutParams(-1, -2);
            chartLp.setMargins(0, dp(8), 0, dp(10));
            body.addView(chartCard, chartLp);

            // 실제 근로와 급여 인정의 차이, 출근카드 환산 기준 안내
            {
                double holidayGageub = Math.max(0, t[PayCore.CB_GAGEUB] - t[PayCore.CB_GAGEUB_WEEKDAY]);
                StringBuilder noteSb = new StringBuilder();
                noteSb.append("※ 실제 근로 ").append(hoursShort(actual))
                      .append("h는 출근해 일한 시간(정취+연장+휴일특근), 급여 인정 ").append(hoursShort(total))
                      .append("h는 유급·주차 ").append(hoursShort(paidOnly))
                      .append("h와 가급 ").append(hoursShort(t[PayCore.CB_GAGEUB])).append("h까지 더한 시간입니다.");
                noteSb.append("\n※ 출근카드 환산 ").append(hoursShort(t[PayCore.CB_CONVERT]))
                      .append("h = 급여 인정 ").append(hoursShort(total)).append("h")
                      .append(holidayGageub > 0 ? " − 특근일 가급 " + hoursShort(holidayGageub) + "h" : "")
                      .append(" + 휴일가급 ").append(hoursShort(t[PayCore.CB_HOLPREMIUM]))
                      .append(isShiftWorker() && t[PayCore.CB_NIGHT] > 0 ? "h + 심야 " + hoursShort(t[PayCore.CB_NIGHT]) : "h")
                      .append(" · 실물 출근카드 합계와 같은 기준");
                TextView gageubNote = textDirect(noteSb.toString(), 10, false);
                gageubNote.setTextColor(colorSub());
                gageubNote.setPadding(dp(2), 0, dp(2), dp(8));
                gageubNote.setLineSpacing(dp(1), 1f);
                body.addView(gageubNote);
            }

            // 요약 칩 — 실제 근로 / 유급 인정 / 급여 인정 / 출근카드 환산
            LinearLayout chipRow = new LinearLayout(this);
            chipRow.setOrientation(LinearLayout.HORIZONTAL);
            chipRow.addView(statChip("근무일수", hoursShort(t[PayCore.CB_DAYS]) + "일", colorInk()));
            chipRow.addView(statChip("심야근로", hoursShort(t[PayCore.CB_NIGHT]) + "h", colorInk()));
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(-1, -2);
            chipLp.setMargins(0, 0, 0, dp(6));
            body.addView(chipRow, chipLp);

            LinearLayout chipRow1 = new LinearLayout(this);
            chipRow1.setOrientation(LinearLayout.HORIZONTAL);
            chipRow1.addView(statChip("실제 근로", hoursShort(actual) + "h", Color.rgb(37, 99, 235)));
            chipRow1.addView(statChip("유급 인정", hoursShort(paidOnly) + "h", Color.rgb(139, 92, 246)));
            LinearLayout.LayoutParams chipLp1 = new LinearLayout.LayoutParams(-1, -2);
            chipLp1.setMargins(0, 0, 0, dp(6));
            body.addView(chipRow1, chipLp1);

            LinearLayout chipRow2 = new LinearLayout(this);
            chipRow2.setOrientation(LinearLayout.HORIZONTAL);
            chipRow2.addView(statChip("급여 인정", hoursShort(total) + "h", colorBlue()));
            chipRow2.addView(statChip("출근카드 환산", hoursShort(t[PayCore.CB_CONVERT]) + "h", Color.rgb(16, 185, 129)));
            LinearLayout.LayoutParams chipLp2 = new LinearLayout.LayoutParams(-1, -2);
            chipLp2.setMargins(0, 0, 0, dp(12));
            body.addView(chipRow2, chipLp2);

            // 요일별 막대
            LinearLayout barCard = new LinearLayout(this);
            barCard.setOrientation(LinearLayout.VERTICAL);
            barCard.setBackground(cellBg(colorBg(), colorBorder(), dp(1)));
            barCard.setPadding(dp(10), dp(12), dp(10), dp(8));
            TextView barTitle = textDirect("요일별 누적 근무시간", 13, true);
            barTitle.setTextColor(colorInk());
            barCard.addView(barTitle);

            PicoBarChartView bars = new PicoBarChartView(wd);
            LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, dp(160));
            barLp.setMargins(0, dp(8), 0, 0);
            barCard.addView(bars, barLp);

            body.addView(barCard, new LinearLayout.LayoutParams(-1, -2));
        };

        // ── v1.4.1 ① 근무 통계 창 좌우 스와이프 월 넘김 ──────────────────
        //   왼쪽으로 밀면 다음 달, 오른쪽으로 밀면 이전 달. 메인 캘린더와 똑같이 갤러리 사진을 넘기듯
        //   지금 통계가 밀려 나가고 새 달 통계(도넛 차트 + 요일별 누적 막대)가 반대편에서 미끄러져 들어온다.
        //   네비게이션 바와 본문이 같은 sy/sm 배열을 쓰므로 [◀ YYYY년 M월 ▶] 표기와 100% 동기화된다.
        final boolean[] statsSliding = {false};
        final View statsSlideTarget = sv;
        final java.util.function.IntConsumer statsSlideTo = delta -> {
            if (statsSliding[0]) return;
            statsSliding[0] = true;
            final int slideW = Math.max(dp(200), statsSlideTarget.getWidth());
            statsSlideTarget.animate().translationX(-delta * slideW * 0.55f).alpha(0.12f).setDuration(150)
                    .setInterpolator(new AccelerateInterpolator())
                    .withEndAction(() -> {
                        sm[0] += delta;
                        if (sm[0] < 1) { sm[0] = 12; sy[0]--; }
                        if (sm[0] > 12) { sm[0] = 1; sy[0]++; }
                        render.run();
                        statsSlideTarget.setTranslationX(delta * slideW * 0.55f);
                        statsSlideTarget.setAlpha(0.12f);
                        statsSlideTarget.animate().translationX(0f).alpha(1f).setDuration(190)
                                .setInterpolator(new DecelerateInterpolator())
                                .withEndAction(() -> statsSliding[0] = false).start();
                    }).start();
        };

        prev.setOnClickListener(v -> { vibrateTick(); statsSlideTo.accept(-1); });
        next.setOnClickListener(v -> { vibrateTick(); statsSlideTo.accept(1); });

        // 통계 본문을 손가락으로 쓸어도 월이 넘어간다 (세로 스크롤과 겹치지 않게 수평 우위일 때만 인정)
        final float[] statSwipeX = {0f};
        final float[] statSwipeY = {0f};
        final boolean[] statSwipeTracking = {false};
        sv.setOnTouchListener((v, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    statSwipeX[0] = ev.getX();
                    statSwipeY[0] = ev.getY();
                    statSwipeTracking[0] = true;
                    break;
                case MotionEvent.ACTION_UP:
                    if (statSwipeTracking[0]) {
                        statSwipeTracking[0] = false;
                        float dx = ev.getX() - statSwipeX[0];
                        float dy = ev.getY() - statSwipeY[0];
                        if (Math.abs(dx) > dp(50) && Math.abs(dx) > Math.abs(dy) * 1.25f) {
                            vibrateTick();
                            statsSlideTo.accept(dx < 0 ? 1 : -1);   // 왼쪽으로 밀면 다음 달
                            return true;
                        }
                    }
                    break;
                case MotionEvent.ACTION_CANCEL:
                    statSwipeTracking[0] = false;
                    break;
            }
            return false;
        });

        render.run();

        Button closeBtn = button("닫기", d::dismiss);
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, dp(46));
        closeLp.setMargins(0, dp(8), 0, 0);
        shell.addView(closeBtn, closeLp);

        d.setContentView(shell);
        Window win = d.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            win.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.94), WindowManager.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    LinearLayout statsLegendRow(String name, double value, double total, int dotColor, int valColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(3), 0, dp(3));

        View dot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setColor(dotColor);
        dg.setCornerRadius(dp(3));
        dot.setBackground(dg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(9), dp(9));
        dotLp.setMargins(0, 0, dp(6), 0);
        row.addView(dot, dotLp);

        TextView nm = textDirect(name, 12, true);
        nm.setTextColor(colorInk());
        row.addView(nm, new LinearLayout.LayoutParams(0, -2, 1f));

        String pct = total > 0 ? String.format(Locale.US, "%.0f%%", value / total * 100) : "0%";
        TextView vv = textDirect(new DecimalFormat("0.#").format(value) + "h (" + pct + ")", 12, true);
        vv.setTextColor(valColor);
        row.addView(vv);
        return row;
    }

    LinearLayout statChip(String label, String value, int valueColor) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        box.setPadding(dp(6), dp(8), dp(6), dp(8));

        TextView v = textDirect(value, 15, true);
        v.setTextColor(valueColor);
        v.setGravity(Gravity.CENTER);
        box.addView(v);

        TextView l = textDirect(label, 10, false);
        l.setTextColor(colorSub());
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, dp(2), 0, 0);
        box.addView(l);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        box.setLayoutParams(lp);
        return box;
    }

    // ════════════════════════════════════════════════════════════════
    // 데이터 통합 관리 (엑셀 내보내기 / 전체 백업 / 복원 3종 카드)
    // ════════════════════════════════════════════════════════════════
    void showDataManage() {
        start("데이터 통합 관리");

        TextView head = textDirect("💾 데이터 관리 (백업 & 복원)", 17, true);
        head.setTextColor(colorBlue());
        root.addView(head);

        TextView sub = textDirect("소중한 근무 기록과 설정을 안전하게 보관하세요", 12, false);
        sub.setTextColor(colorSub());
        sub.setPadding(0, dp(2), 0, dp(12));
        root.addView(sub);

        root.addView(dataCard("📄", "급여명세서 엑셀 내보내기", "이번 달 일자별 근무구분·수당 상세 집계표 (.xlsx)",
            Color.rgb(16, 185, 129), () -> exportPayrollReport()));
        root.addView(dataCard("🗂️", "전체 데이터 백업", "근무 기록 + 급여 설정 + 기본정보 + 등록 휴일 (.xlsx)",
            colorBlue(), () -> exportExcel()));
        root.addView(dataCard("♻️", "백업 파일 복원", "저장해 둔 엑셀 파일로 기록과 설정 되살리기",
            Color.rgb(139, 92, 246), () -> importExcel()));

        LinearLayout note = new LinearLayout(this);
        note.setOrientation(LinearLayout.VERTICAL);
        note.setBackground(cellBg(isDark() ? Color.rgb(26, 38, 58) : Color.rgb(238, 245, 255), colorBorder(), dp(1)));
        note.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView noteTitle = textDirect("🛡️ 자동 백업 안내", 12, true);
        noteTitle.setTextColor(colorBlue());
        note.addView(noteTitle);
        TextView noteBody = textDirect("근무를 입력할 때마다 앱 전용 저장소(AutoBackup)에 최신·월별 엑셀 백업이 자동으로 갱신됩니다. 동시 쓰기 충돌을 막기 위해 순차 기록됩니다.", 11, false);
        noteBody.setTextColor(colorSub());
        noteBody.setPadding(0, dp(4), 0, 0);
        note.addView(noteBody);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.setMargins(0, dp(6), 0, dp(8));
        root.addView(note, noteLp);
    }

    // 앱 정보 → 안드로이드 전용 앱(APK) 안내 (웹 서랍의 [안드로이드 전용 앱(APK) 안내] 모달과 동일한 통합 안내)
    void openExternalUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "브라우저를 열 수 없습니다.\n" + url, Toast.LENGTH_LONG).show();
        }
    }

    /** GitHub Pages의 version.json을 읽어 설치 빌드보다 높은 빌드가 있으면 업데이트를 안내한다. */
    void checkForUpdate(boolean manual) {
        new Thread(() -> {
            int latestCode = -1;
            String latestName = "";
            String apkUrl = APK_DOWNLOAD_URL;
            String note = "";
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(VERSION_JSON_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(7000);
                c.setReadTimeout(7000);
                c.setRequestProperty("Cache-Control", "no-cache");
                c.setRequestProperty("User-Agent", "ShiftPay/" + CURRENT_VERSION_NAME);
                if (c.getResponseCode() == 200) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                    }
                    JSONObject j = new JSONObject(sb.toString());
                    latestCode = j.optInt("versionCode", -1);
                    latestName = j.optString("versionName", "");
                    if (j.has("apkUrl")) {
                        String candidate = j.optString("apkUrl", APK_DOWNLOAD_URL);
                        // 공식 도메인(https://realcheol.github.io/)의 APK만 연다 — version.json 변조 대비
                        apkUrl = isOfficialApkUrl(candidate) ? candidate : APK_DOWNLOAD_URL;
                    }
                    note = j.optString("note", "");
                }
                c.disconnect();
            } catch (Throwable ignored) {
            }

            final int fc = latestCode;
            final String fn = latestName;
            final String fa = apkUrl;
            final String fnote = note;
            runOnUiThread(() -> {
                try {
                    if (fc > CURRENT_VERSION_CODE) {
                        // 같은 빌드로 하루에 한 번만 자동 안내 (수동 확인은 항상 표시)
                        String today = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
                        String seen = prefs.getString("update_nag_" + fc, "");
                        if (!manual && today.equals(seen)) return;
                        prefs.edit().putString("update_nag_" + fc, today).apply();
                        new AlertDialog.Builder(this)
                            .setTitle("🚀 새 버전 v" + fn + " (빌드 " + fc + ") 이 나왔습니다")
                            .setMessage("현재 설치된 버전은 v" + CURRENT_VERSION_LABEL + " 입니다.\n\n"
                                + (fnote.isEmpty() ? "새 기능과 결함 수정이 포함된 정식 버전입니다." : fnote)
                                + "\n\n[지금 업데이트]를 누르면 브라우저에서 최신 APK 다운로드가 시작됩니다. 설치 후 기존 기록은 그대로 유지됩니다.")
                            .setPositiveButton("지금 업데이트", (d, w) -> openExternalUrl(fa))
                            .setNegativeButton("나중에", null)
                            .show();
                    } else if (manual) {
                        Toast.makeText(this, fc < 0 ? "업데이트 서버에 연결할 수 없습니다. 잠시 후 다시 시도해 주세요."
                                : "최신 버전을 사용 중입니다. (v" + CURRENT_VERSION_LABEL + ")", Toast.LENGTH_LONG).show();
                    }
                } catch (Throwable ignored) {
                }
            });
        }).start();
    }

    void showApkInfo() {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackground(cellBg(colorSurface(), colorBorder(), dp(1)));
        shell.setPadding(dp(16), dp(16), dp(16), dp(14));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = textDirect("📥 안드로이드 전용 앱(APK) 안내", 16, true);
        title.setTextColor(colorBlue());
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView closeTv = textDirect("✕", 18, true);
        closeTv.setTextColor(colorSub());
        closeTv.setPadding(dp(8), dp(2), dp(2), dp(2));
        closeTv.setOnClickListener(v -> d.dismiss());
        titleRow.addView(closeTv);
        shell.addView(titleRow);

        // 설치된 버전 카드
        LinearLayout verCard = new LinearLayout(this);
        verCard.setOrientation(LinearLayout.VERTICAL);
        verCard.setBackground(cellBg(isDark() ? Color.rgb(20, 36, 64) : Color.rgb(235, 243, 255), colorBlue(), dp(1)));
        verCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView verTv = textDirect("현재 설치된 버전  v" + CURRENT_VERSION_LABEL, 13, true);
        verTv.setTextColor(colorInk());
        verCard.addView(verTv);
        TextView verSub = textDirect("최신 정식 버전도 v" + CURRENT_VERSION_LABEL + " 입니다. 아래 [업데이트 확인]으로 새 빌드를 확인하거나, APK를 직접 받아 덮어쓰기 업데이트할 수 있습니다.", 11, false);
        verSub.setTextColor(colorSub());
        verSub.setPadding(0, dp(4), 0, 0);
        verCard.addView(verSub);
        LinearLayout.LayoutParams verLp = new LinearLayout.LayoutParams(-1, -2);
        verLp.setMargins(0, dp(10), 0, dp(10));
        shell.addView(verCard, verLp);

        TextView desc = textDirect("• 출근카드 OCR·근무 통계·데이터 관리까지 모두 담긴 오프라인 전용 앱입니다.\n"
                + "• 웹 버전은 설치 없이 브라우저에서 바로 사용할 수 있습니다.", 12, false);
        desc.setTextColor(colorInk());
        desc.setLineSpacing(dp(2), 1.1f);
        shell.addView(desc);

        Button apkBtn = button("📥 최신 ShiftPay v" + CURRENT_VERSION_NAME + " APK 다운로드", () -> {
            Toast.makeText(this, "브라우저에서 APK 다운로드를 시작합니다.", Toast.LENGTH_SHORT).show();
            openExternalUrl(APK_DOWNLOAD_URL);
        });
        apkBtn.setBackground(bg(colorBlue()));
        apkBtn.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams apkLp = new LinearLayout.LayoutParams(-1, dp(48));
        apkLp.setMargins(0, dp(12), 0, dp(6));
        shell.addView(apkBtn, apkLp);

        Button checkBtn = button("🔄 업데이트 확인", () -> {
            Toast.makeText(this, "업데이트를 확인하는 중입니다…", Toast.LENGTH_SHORT).show();
            checkForUpdate(true);
        });
        checkBtn.setBackground(cellBg(colorSurface(), colorBlue(), dp(1)));
        checkBtn.setTextColor(colorBlue());
        checkBtn.setTextSize(13);
        LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(-1, dp(40));
        checkLp.setMargins(0, dp(2), 0, dp(6));
        shell.addView(checkBtn, checkLp);

        Button webBtn = button("🌐 웹 버전 바로 열기", () -> openExternalUrl(WEB_APP_URL));
        webBtn.setBackground(cellBg(colorSurface(), colorBlue(), dp(1)));
        webBtn.setTextColor(colorBlue());
        shell.addView(webBtn, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView urlTv = textDirect("직다운로드 주소\n" + APK_DOWNLOAD_URL + "\n\n웹 버전 주소\n" + WEB_APP_URL, 10, false);
        urlTv.setTextColor(colorSub());
        urlTv.setPadding(dp(2), dp(8), dp(2), dp(6));
        shell.addView(urlTv);

        Button closeBtn = button("닫기", d::dismiss);
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, dp(44));
        closeLp.setMargins(0, dp(6), 0, 0);
        shell.addView(closeBtn, closeLp);

        d.setContentView(shell);
        Window win = d.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            win.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.94), WindowManager.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    LinearLayout dataCard(String emoji, String title, String desc, int accent, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackground(cellBg(isDark() ? Color.rgb(24, 36, 56) : Color.rgb(255, 255, 255), cellBorder(accent), dp(1)));
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setClickable(true);
        card.setOnClickListener(v -> {
            vibrateTick();
            action.run();
        });

        TextView icon = textDirect(emoji, 22, false);
        icon.setPadding(0, 0, dp(12), 0);
        card.addView(icon);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView t = textDirect(title, 14, true);
        t.setTextColor(colorInk());
        col.addView(t);
        TextView dd = textDirect(desc, 11, false);
        dd.setTextColor(colorSub());
        dd.setPadding(0, dp(2), 0, 0);
        col.addView(dd);
        card.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView arrow = textDirect("›", 20, true);
        arrow.setTextColor(accent);
        card.addView(arrow);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(9));
        card.setLayoutParams(lp);
        return card;
    }

    int cellBorder(int accent) {
        return isDark() ? Color.rgb(52, 66, 88) : Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent));
    }

    void showHistory() {
        start("업데이트 내역");
        String hist =
            "v1.4.3 — 2026-11-13 (버전 고정 재빌드 · PDF 명세서 직독 · 새 피코 · 공제 정상화)\n" +
            "• 📄 급여명세서 PDF 직접 불러오기: 회사가 발급한 원본 PDF 를 고르면 PDF 내부의 디지털 문자열을 그대로 읽어 기본급·평일연장·휴일근무·휴일연장·야간근무·직무수당·교대수당·지급액계·공제액계·실지급액을 1원 단위까지 채운다 (사진 OCR 처럼 흔들리지 않음). PDF 에 글자가 없으면 고해상도로 다시 그려 자동 재인식\n" +
            "• 🧾 공제 계산 정상화: 자동 예측은 국세청 간이세액표 − 자녀 세액공제와 법정 요율(연금 4.5%·건강 3.545%·장기요양 12.95%·고용 0.9%·노조회비 3h+1,200원)만 사용. v1.3.5 실측치 학습이 간이세액표를 덮어쓰지 못하게 전면 차단\n" +
            "• 🛡️ 오염된 실측치 자동 정화: 소득세 100만원 초과·공제 합계 200만원 초과 학습값은 실행 시 삭제하고, 이상치(소득세가 세전의 30% 초과 등)는 절대 공제액으로 채택하지 않음\n" +
            "• ↩️ 온보딩 뒤로가기 가드: 도중에 뒤로가기를 눌러도 완료 처리되지 않고 앞 단계로 돌아감 — 완료는 마지막 [시작하기]에서만\n" +
            "• 🗓️ 캘린더 연월 빠른 이동 고도화: 월 그리드를 좌우로 밀면 전년도/다음 연도가 갤러리처럼 슬라이드 전환 · 연도 숫자를 누르면 2024~2030 빠른 선택 그리드와 위아래로 굴리는 수직 연도 휠이 그 자리에 열린다\n" +
            "• 🧭 4스텝 대화형 온보딩: ①이름·직급 → ②생년월일·입사년월일 → ③근무형태·통상시급 → ④부양가족·자녀. 각 단계마다 \'000 사원님의 입력으로 …\' 호칭으로 이유를 먼저 설명하고, 정년까지 남은 년·월·일(총 일수)·근속수당·가족수당·자녀 세액공제를 실시간 계산해 보여 준다\n" +
            "• 🧭 완료 페이지: 새 전신 피코(안전모·작업복·손 흔들기)를 흰 스티커 카드에 앉히고 \'행복한 가정으로 돌아가기 위해 오늘도 안전근무하세요! 🏠👷\u200d♂️\' 인사와 [시작하기]만 단정하게 배치\n" +
            "• 🎯 스팟라이트 투어 개편: 투어 중 [▲ TOP] 플로팅 버튼 완전 숨김 · 본문 16sp·제목 19sp 큰 글자 · 반투명 다크 글래스 카드 · 하이라이트 구멍이 다음 타깃으로 트윈 이동 + 포커스 링 펄스\n" +
            "• 🖼️ 새 아이콘 전면 교체: HYUNDAI STEELPIPE 피코·강관·시계 아이콘을 안드로이드 5해상도와 웹 파비콘·PWA 아이콘에 1:1 적용\n" +
            "• 🧾 명세서 OCR 3중 개선: 촬영 직후 [인식 결과 검토 및 수정] 표를 띄워 기본급·시간외·야간·직무·공제를 터치로 교정 · 자릿수 누락(506,898→56,898)을 단협 공식 기대값과 대조해 원터치 보정 칩 제공 · OCR 전 흑백 명암비 자동 보정(조명 얼룩 제거)\n" +
            "• 🔒 v1.4.2의 국세청 간이세액표 646구간·자녀 세액공제와 급여 코어 1원 일치를 그대로 유지\n" +
            "v1.4.2 — 2026-11-12 (국세청 간이세액표 1:1 탑재 · 8~20세 자녀 세액공제 · 공제식 카드 리뉴얼)\n" +
            "• 🧾 국세청 근로소득 간이세액표(소득세법 시행령 별표 2, 2026. 2. 27. 개정) 646개 급여구간 × 공제대상가족 1~11명 전 칸 탑재 — 산식 근사가 아니라 원표 그대로 조회\n" +
            "• 👶 8세~20세 자녀 세액공제: 1명 20,830원 / 2명 45,830원 / 3명 이상 45,830원 + 2명 초과 1명당 33,330원 (표 세액에서 차감, 음수는 0원)\n" +
            "• ✅ 실물 명세서 1원 일치: 5,262,924원·부양가족 4명·자녀 2명 → 252,640 − 45,830 = 206,810원 / 5,513,610원·부양가족 2명 → 376,460원\n" +
            "• ⚙️ 설정 [부양가족 수] 바로 아래 [8세~20세 자녀 수](기본 0) 신설 + 온보딩 2단계에도 컴팩트 배치, 자녀 세액공제액 실시간 표시\n" +
            "• 🎨 [▾ 상세 공제 계산식] 카드 리뉴얼: 항목별 카드에 금액과 근거를 한 줄씩 — 간이세액표 252,640 → 자녀공제 −45,830 → 소득세 206,810원이 단번에 읽힌다\n" +
            "• 🧮 지방소득세 = 소득세 × 10% (10원 미만 절사) · 선공제율 80/100/120%도 10원 미만 절사로 국세청 예시와 동일\n" +
            "v1.4.1 — 2026-11-12 (통계 스와이프 월 넘김 · 날짜 더블탭 입력 · 교대조 8h 특근 카드)\n" +
            "• 📊 근무 통계 창 좌우 스와이프 월 넘김: 왼쪽으로 밀면 다음 달, 오른쪽으로 밀면 이전 달 — 메인 캘린더처럼 지금 통계가 밀려 나가고 새 달 도넛·요일별 막대가 반대편에서 미끄러져 들어온다. 상단 [◀ YYYY년 M월 ▶] 바와 항상 같은 달을 가리킨다\n" +
            "• 📅 달력 날짜 더블탭 입력: 다른 날짜를 한 번 누르면 파란 선택 테두리만 그 날짜로 이동하고 입력창은 열리지 않는다. 이미 선택된 날짜를 한 번 더 누를 때만 퀵 프리셋 바텀시트가 열린다 — 달력 아래 [빠른 근무 입력 (N일)] 버튼은 그대로 동작\n" +
            "• 🔥 교대조 [기타 및 8h 정상근무] 아코디언에 [주간특근 (8h)] · [야간특근 (8h)] 신설: 주간 교대로 들어온 토요일 8시간 특근(휴일근로 150%)을 1초에 입력하고, 야간특근은 심야 6.0h까지 함께 인정된다\n" +
            "• 🔒 v1.4.0의 3스텝 온보딩 마법사·스팟라이트 5곳 투어를 그대로 보존하고 7개 단위 테스트 전수 통과\n" +
            "v1.4.0 — 2026-11-12 (3스텝 온보딩 마법사 · 스팟라이트 5곳 메뉴 투어 · 드로어 다시보기)\n" +
            "• 🧭 최초 설치 시 3스텝 미니 온보딩 마법사: [근무 형태 선택] → [내 급여 기본 설정(통상시급·발생연차·부양가족 수·8~20세 자녀 수)] → [준비 완료 & 투어 안내]\n" +
            "• ✨ 인터랙티브 스팟라이트 코치마크 투어: 화면을 어둡게 딤 처리하고 대상 버튼만 둥근 컷아웃으로 밝게 비추며 5곳의 주요 기능을 큰 글자 카드로 설명한다\n" +
            "• ❓ 좌측 메뉴에 [온보딩 & 기능 투어 다시보기] 신설: 기존 사용자도 언제든 마법사와 투어를 다시 볼 수 있다\n" +
            "• ⏭️ 투어 중 [건너뛰기]·[마침]·뒤로가기 어느 쪽으로도 즉시 종료되며, 설정은 [급여 및 화면 설정]에서 그대로 수정 가능\n" +
            "• 🔒 v1.3.6의 9대 개편(소급 토글 튐 0%·TOP 80dp·플링 스와이프·서브 메뉴 스케일업·필수 권한·엑셀 ded_* 복원·표준세액공제·2027 설날 대체휴무·가족수당 연동)을 그대로 보존\n" +
            "v1.3.6 — 2026-11-12 (소급 토글 튐 제로 · TOP 버튼 상향 · 플링 스와이프 · 서브 메뉴 스케일업 · 공제식 교정)\n" +
            "• 💰 소급 ON/OFF 미세 튐 제로화: 화면을 다시 그리지 않고 예상 실수령액·세전·공제 금액 텍스트와 소급분 행만 핀포인트 갱신 → 스크롤이 0.1초도 흔들리지 않는다\n" +
            "• ▲ [▲ TOP] 버튼을 바닥에서 80dp 위로 상향: 안드로이드 3버튼 내비게이션 바에 가려지지 않는다\n" +
            "• 👈👉 좌우 드로어 플링 감도 개선: 길게 끌지 않고 40~50dp만 살짝 튕겨도 가속도로 끝까지 펼쳐진다\n" +
            "• 🎬 서브 메뉴 스케일업 애니메이션: 급여 설정·성과격려금·사내 복지·데이터 백업을 열면 화면 중앙에서 0.9 → 1.0 으로 0.2초 만에 커지며 페이드인(닫을 때는 스케일다운)\n" +
            "• 🔐 AndroidManifest 필수 권한(INTERNET·VIBRATE) 명시 + 카메라 ACTION_IMAGE_CAPTURE·FileProvider 안전 연동\n" +
            "• 💾 엑셀 백업·복원에 신규 공제 설정(ded_*) 전면 포함: ded_l_*는 Long, ded_auto는 Boolean, ded_dependents·선공제율은 정수/실수형으로 정확히 복원\n" +
            "• 🧾 표준세액공제(13만원) 위치 교정: 과세표준 차감이 아니라 산출세액 차감(세액공제) 단계로 국세청 공식 정밀화\n" +
            "• 🗓️ 2027~2028년 단협 대체휴무 단위 테스트 추가: 2027년 설날 2/10·2/11 '설날 대체휴무' 자동 배정을 영구 검증\n" +
            "• 👨‍👩‍👧 가족수당 연동: 부양가족 수(본인 포함)와 본인 외 1인당 10,000원으로 기본 연동 — 부양가족 수를 바꾸면 가족수당(가족)이 즉시 재계산되고, 금액을 직접 고치면 그 값으로 독립 고정된다\n" +
            "v1.3.5 — 2026-11-12 (단협 제52조 대체휴무 100% 보장 · 공제액 정밀 예측 · 드로어 스와이프 · [▲ TOP])\n" +
            "• 🗓️ 단협 제52조 범용 대체휴무: 유급휴일이 주말·다른 공휴일과 겹친 일수만큼 정부 대체공휴일과 무관하게 익일 평일로 순차 배정 — 2027년 설날은 2/10(수)·2/11(목) '설날 대체휴무'로 6일 연속 휴일\n" +
            "• 🏷️ 회사 단협 유급휴무일 명칭 통일: 10/18 '회사창립일' → 10/19 '회사창립일 대체휴무'\n" +
            "• 👈👉 좌측 메뉴·우측 OCR 서랍 모두 화면 끝에서 밀어 열고, 열린 상태에서 반대쪽으로 밀면 감속하며 닫히는 양방향 스와이프 제스처\n" +
            "• 🧾 공제액 정밀 예측: 4대보험 법정 요율(연금 4.5%·건강 3.545%·장기요양·고용 0.9%) + 소득세 간이세액표(부양가족 수·선공제율 80/100/120%) + 노조회비(통상시급×3h+1,200원) → [▾ 상세 공제 계산식 펼치기]로 항목별 공식 공개\n" +
            "• 🔐 소스 검증 반영: 필수 권한(INTERNET·CAMERA·VIBRATE) 선언 · 야간수당 OCR 고정값 복원 제거(통상시급×야간시간 동적 산출) · 엑셀 복원 sharedStrings/숫자셀 호환 · 인앱 업데이트 APK 주소 공식 도메인 검증\n" +
            "• 👤 개인정보 완전 삭제: 소스 주석·테스트·업데이트 내역의 실명·부서 흔적 익명화\n" +
            "• 📐 설정 상단 기본정보를 2열 균등 그리드로 정돈 · '기준연차일수' → '발생연차수' (명세서 발생/잔여 칸 자동 입력)\n" +
            "• 📌 소급 토글·성과격려금 버튼을 눌러도 스크롤 위치 유지 · 우측 하단 [▲ TOP] 플로팅 버튼\n" +
            "• 🏷️ 출근카드 OCR 저장 후 토·일·공휴일 [유급 8h]·[주차 8h] 뱃지 미노출 결함 수정: 실근무 0h인 날은 mode와 무관하게 자동 인정 뱃지 표시 + OCR 저장 시 빈 날을 mode=work로 덮지 않음\n" +
            "• 🖼️ 달력 좌우 월 넘김을 갤러리 사진처럼 슬라이드 애니메이션으로: 현재 달력이 밀려 나가고 새 달력이 반대편에서 부드럽게 진입 (◀ ▶ 버튼·스와이프 공통)\n" +
            "v1.3.4 — 2026-11-11 (6대 메인 UI·버튼 동선 대개편 · 엑셀 4단 서식 · R8 난독화 · 인앱 업데이트 감지)\n" +
            "• 🧭 6대 메인 UI·버튼 동선 대개편: 매일 쓰는 손가락 동선 기준으로 캘린더·급여·출근카드 카드의 버튼을 다시 배치\n" +
            "• 📸 캘린더 아래 퀵 액션 바에 [스마트 OCR] 복원: [⚡ 빠른 근무 입력 1.2] · [⚡ 선택 모드 1.0] · [📸 스마트 OCR 1.0] 3버튼 나란히 — 한 손으로 1초 만에 사진 스캔 진입\n" +
            "• 💰 소급 ON/OFF 토글을 [예상 실수령액] 카드 내부 우측 가운데로 이동: 토글을 켜고 끄면 바로 옆의 실수령액 숫자가 즉시 바뀌어 변화가 한눈에 보임 (롱클릭 시 소급분 설정)\n" +
            "• 🗓️ 캘린더 상단 바 슬림화: 리셋(↺) · 월 넘김(◀ 2026년 11월 ▾ ▶) · [오늘]만 남겨 정갈하게 정리\n" +
            "• 🏆 [성과격려금] 버튼 신설: 소급 토글 바로 아래에서 2026년 성과·격려금 계산기로 원터치 연결\n" +
            "• 📊 [근무 통계] 버튼을 [출근카드 1:1 월간 집계] 카드 헤더 [카드 1:1] 뱃지 우측으로 이동: 출근카드 집계와 도넛·요일별 통계를 한곳에서 연동\n" +
            "• 📄 급여명세서 엑셀 4단 서식 대개편: ① 일자별 상세 근무 현황표 ② 출근카드 1:1 월간 집계·근무 통계 요약(기본 인정 248h · 실근무 224h vs 급여 인정 343h · 환산 357h/359h) ③ 단체협약 수당별 상세 산출 계산식(야간 63.0h, 상주휴게·교대수당 공식 포함) ④ 최종 정산 요약 — 백업/복원 시트는 그대로 유지\n" +
            "• 🔍 인앱 업데이트 감지: 앱 실행 시 version.json을 비동기로 확인해 더 높은 빌드가 있으면 [지금 업데이트] 안내 → 브라우저에서 최신 APK 원터치 다운로드\n" +
            "• 🔒 R8 난독화·리소스 축소(keep 규칙으로 ML Kit·POI·Gson·MainActivity 보호) 적용\n" +
            "v1.3.3 — 2026-11-11 (홈화면 스퀘어클 아이콘 · 교대조 야간수당 63.0h 정규화 · 6대 퀵 카드 · 테마 연동 · 조퇴/외출 태그)\n" +
            "• 🌙 교대조 야간수당 63.0h 정규화: 종이 출근카드 심야 3.5h는 50% 가산이 이미 곱해진 가산시간 — 실제 인정은 1일 7.0h(22:00~06:00 8h − 휴게 1h). 10월 9일 × 7.0h = 63.0h × 16,092원 × 0.5 = 506,898원으로 급여명세서와 1원 일치 (출근카드 1:1 집계의 심야 35h·환산 359h는 그대로 유지)\n" +
            "• 📐 상세 산출 계산식에 야간 일수·7.0h 공식 표기: '야간 9일 × 7.0h = 63.0h × 16,092원 × 0.5 = 506,898원'\n" +
            "• 🟦 홈화면 아이콘을 삼성 스퀘어클(모서리 곡률 22.5%)로 교정: 원형 강제 태그(roundIcon) 제거 + 어댑티브 아이콘 XML 삭제 → '공수 계산기'·'녹음기'와 같은 둥근 사각형으로 표시\n" +
            "• 🧾 급여명세서 야간수당 56,898원 → 506,898원 복원 안전망 강화: 통상시급을 못 읽어도 기준액의 가운데 0 탈락이면 무조건 복원\n" +
            "• 🖼️ 신규 어댑티브 아이콘 1안(풀블리드) 탑재: 시계 다이얼 + 안전모 쓴 피코 엄지척 원본 비율 그대로, 모서리 흰 여백을 블루 그라데이션으로 연장한 1024 마스터로 mipmap 5종·원형 아이콘·API26+ 어댑티브 레이어(bg/fg) 일괄 교체\n" +
            "• 📇 출근카드 1:1 월간 집계 카드 라이트/다크 자동 연동: 라이트 모드에서 짙은 밤색으로 고정되던 카드 배경을 흰 서피스(#FFFFFF)·테두리 #E2E8F0·글자 #0F172A로, 다크 모드는 기존 딥 네이비(#101A2B) 유지\n" +
            "• 🎛️ 상주조/교대조 전용 3행 6대 퀵 카드로 전면 재편: 상주 [주간 정상 8h·주간 10h / 휴일특근 8h·휴일특근 10h / 연차·삭제], 교대 [주간 10h·야간 10h / 주간특근·야간특근 / 연차·삭제] — 평소 입력 0.5초 컷\n" +
            "• 🎨 4색 프리미엄 시인성 컬러: 주간 Ocean Blue · 야간 Soft Purple · 특근 Coral Red · 휴가 Mint Green (소프트 파스텔 틴트, 라이트/다크 각각 최적화)\n" +
            "• ▾ [기타 및 교대조 근무]/[기타 및 8h 정상근무] 아코디언: 반차·하계휴가·야간 대타·기본값·무급을 접어 두고 필요할 때만 펼침 — 단일 날짜 시트와 선택 일괄 입력 모달 1:1 동일 구조\n" +
            "• 💊 🚶 초단시간 근무 태그: [세부 시간 직접 입력 및 메모] 화면 상단 [조퇴]·[외출] 퀵 태그로 메모에 자동 반영, 달력에 [4h 💊조퇴]·[6h 🚶외출] 뱃지 표시\n" +
            "v1.3.2 — 2026-11-11 (출근카드 OCR 휴일특근 자동분리 · 교대조 환산 359h · 야간수당 복원 · 프리셋 2열 재디자인 · 버전 유지)\n" +
            "• 🧾 출근카드 OCR 6번 열[휴일가급]을 근무시간으로 읽어 특근연장이 8h로 뻥튀기되던 결함 근본 수정: 5번 열[휴일근로]가 8h를 넘으면 처음부터 휴일근로 8h + 휴일연장 2h로 자동 분리 (사진 한 장으로 명세서와 1원 일치)\n" +
            "• 🌙 교대조 출근카드 환산시간에 심야 포함: 정취132 + 연장32 + 가급16 + 심야35 + 휴일근로20 + 휴일가급12 + 연차16 + 유급64 + 주차32 = 환산 359h (상주는 심야 0h로 종전 357h 그대로)\n" +
            "• 🌴 OCR 검토표에 [연차] 열 추가 + 열 이름을 실물 카드와 일치([휴일근로]·[휴일연장]): 연차일은 연차 모드로 저장되고, 조퇴(정취 4h)·야간조(심야만)를 '누락'으로 잘못 잡아 덮어쓰던 위험 제거\n" +
            "• 🧾 급여명세서 야간근무수당 가운데 0 탈락(506,898→56,898원) 자동 복원: 통상시급 × 야간(H) 63h × 0.5 기대값 또는 통상시급 단가로 나누어떨어지는 6자리 금액으로 되돌림\n" +
            "• 🔥🌙 [야간특근 10h (8+2h)] 교대조 전용 원터치 프리셋 신설: 휴일근로 8h(150%) + 휴일연장 2h(200%) + 심야 3.5h — 단일 날짜·선택 일괄 입력 공통, 달력 셀 칩 [🌙특근 8+2h]\n" +
            "• 🎛️ 원터치 프리셋 바텀시트 2열 대칭 재디자인: 주간 라인 → 야간 라인 → 주간특근/야간특근 대칭 → 연차·휴가·기본값 → 무급·삭제 (빈칸 없이 2개씩)\n" +
            "v1.3.2 — 2026-11-10 (출근카드 1:1 집계 카드 · 도넛 실근로/급여인정 분리 · 연차 뱃지 · 버전 유지)\n" +
            "• 📇 메인 [월간 근무 집계]를 출근카드 실물 1:1 3대 그룹 카드로 전면 개편: ① 기본 인정(정취·유급·주차·연차 — 기본급 인정 248h) ② 시간외·특근(연장·휴일근로·휴일연장·심야) ③ 가급 및 환산(가급·휴일가급·환산시간 357h) — 다크 네이비 라운드 카드 + 상단 [출근 23일]·[실제 근로 224h]·[카드 환산 357h] 뱃지\n" +
            "• 🍩 도넛 통계를 실제 근무시간과 급여 인정시간으로 분리: 중앙에 [실제 근로 224h]·[급여 인정 343h] 병기, 유급·주휴 96h를 보라 조각으로 독립 (정취 152 · 연장 38 · 휴일특근 34 · 가급 23 · 유급·주휴 96)\n" +
            "• 🏷️ 요약 칩 4종: 실제 근로 224h / 유급 인정 96h / 급여 인정 343h / 출근카드 환산 357h\n" +
            "• 🌴 달력 연차 뱃지: 연차 입력일이 '8h'로만 보이던 결함을 교정해 [연차 8h] 초록 캡슐 뱃지로 표시 (하계휴가 [휴가 8h] · 반차 [반차 4h])\n" +
            "v1.3.2 — 2026-11-10 (3대 금액 0원 원천 차단 · 특근일 가급 자동산입 · 출근카드 환산 357h · 버전 유지)\n" +
            "• 🧾 급여명세서 3대 금액(지급총액·공제총액·실지급액) 3중 안전망: ① 좌표 탐색(헤더 바로 아래 같은 열·세로 간격 완화) ② 다중행 정규식(라벨 3줄 + 금액 3줄, 글자 사이 공백 허용) ③ 세부 항목 합계 복원(지급 8항목·공제 6항목) — 지급 5,262,924 / 공제 838,690 / 실지급 4,424,234원이 0원으로 잡히던 결함 원천 차단\n" +
            "• 🍚 특근일 상주휴게(가급) 자동 산입 (단협 제49조 4항): 실근무 8시간 이상인 휴일특근일에도 1일 인정 → 10월 상주휴게 19일 → 23일 314,019원, 명세서 22일 300,366원과의 차액 13,653원이 대조표에 그대로 표시\n" +
            "• 📊 근무 통계에 출근카드 실물 환산 병기: '출근카드 환산시간 357h (휴일가급 18h 할증 포함)' 안내와 요약 칩 2종(출근카드 환산·휴일가급) 추가 — 10월 출근카드 357.000h와 1시간 오차 없이 대조\n" +
            "• 🧮 상주휴게수당 대조 행에 지급일수 병기(앱 23일 vs 명세서 22일), 세부 항목 합계로 복원했을 때 안내 문구 표시\n" +
            "v1.3.2 — 2026-11-10 (새 피코 스플래시 · 3대 급여 계산식 · 직책/직무수당 분리 · 버전 유지)\n" +
            "• 🧾 급여명세서 OCR 대조 전면 보강: [지급액계][공제액계][실지급액] 헤더 아래줄에 금액이 놓인 2행 요약표를 좌표(2D)로 읽어 지급총액·공제총액·실지급액이 0원으로 잡히던 결함 해결\n" +
            "• 🗓️ 명세서 귀속 연월 자동 동기화: 명세서의 '2026년 10월'을 감지해 대조 연월을 그 달로 이동한 뒤 출근카드 계산값과 대조 (엉뚱한 달과 비교하던 문제 해결)\n" +
            "• 🔥 휴일특근 10h (8+2h) 원터치 프리셋: 휴일·주말 06:30~17:30 근무를 탭 한 번에 8h 특근(150%) + 2h 특근연장(200%)으로 저장 (단일 날짜 · 선택 일괄 입력 공통)\n" +
            "• 🏷️ 캘린더 셀에 '특근 8+2h' 분리 표기 및 오늘 뱃지 컴팩트화('오늘' 두 글자만)로 좁은 칸 글자 잘림 교정\n" +
            "• 🏗️ 새 피코(PICO) 스플래시 적용: 엄지척 12프레임 애니메이션(276×312)으로 교체, 첫 프레임 650ms + 이후 80ms\n" +
            "• 💼 직책수당/직무수당 완전 분리 (단협 제42조): 직급은 직책수당에만 연동(사원 0·주임 5만·계장 10만·기장 20만), 직무수당 55,000원은 사원 선택 시에도 유지. 설정창·영수증·명세서에 각각 별도 표시\n" +
            "• ① 휴일특근 8시간 초과분 자동 분리: 휴일 10시간 근무 시 8시간 150% + 초과 2시간 200% 자동 계산\n" +
            "• ② 상주휴게수당(가급) 지급일수에 주말·공휴일 특근일(실근무 8시간 이상) 포함\n" +
            "• ③ 토요일·공휴일에 특근해도 당일 유급 8시간(기본급 산입분) 삭감 방지 + 평일 공휴일 유급 8시간 자동 인정\n" +
            "• 📋 10월 실물 급여명세서 1원 단위 검증 완료 (기본급 3,385,944 · 세전 5,262,924원)\n" +
            "v1.3.2 — 2026-11-09 (신규 앱 아이콘 & 달력 좌우 스와이프 · 버전 유지)\n" +
            "• 🎨 신규 앱 아이콘 전면 교체: 딥블루 그라데이션 + 강관 단면 시계 링 + H 끝단 결합 디자인 (사각·둥근 아이콘 5개 밀도 전수 교체)\n" +
            "• 👆 달력 좌우 스와이프로 월 넘기기: 캘린더 화면에서 왼쪽으로 밀면 다음 달, 오른쪽으로 밀면 이전 달 (선택 모드·서랍·다른 화면에서는 비활성)\n" +
            "• 🏗️ 사내 캐릭터 '피코(PICO)' 스플래시 로딩 화면 신설: 안전모+파란 작업복 파이팅 애니메이션 (16프레임)\n" +
            "• 📊 근무 통계 & 분석 차트 신설: 정상·연장·특근 도넛 차트 + 요일별(일~토) 누적 막대 그래프 + 월 이동 조회\n" +
            "• 💾 데이터 통합 관리 카드 신설: 엑셀 내보내기 / 전체 백업 / 복원 3종 원터치 카드 + 자동백업 안내\n" +
            "• 🛡️ 연도별 설정(setting_YYYY_*)·기본 설정(setting_*) 불일치 전수 보정: 설정 저장·초기화·OCR 동기화·직급 직책수당·근속수당 선택 시 두 키를 항상 함께 저장/삭제\n" +
            "• 🗓️ 정년 퇴직일 단협 제28조 반영: 생일 기준 +60년 대신 만 60세 도달 연도의 12월 31일로 정확 산출 (연월 점프 프리셋도 12월 연동)\n" +
            "• ⚖️ 근속수당 20년 경계 교정: 19년차는 84,500원, 20년차부터 89,500원 정상 적용\n" +
            "• 🌙 엑셀 복원 시 다크모드 설정 유지 (ClassCastException 방지)\n" +
            "• 🔒 자동백업 동시 쓰기 스레드 동기화 + 임시파일 원자적 교체로 빠른 연속 입력 시 xlsx 손상 원천 차단\n" +
            "• 📅 휴일 수동 등록 날짜 자동 정규화: 하이픈/점/슬래시 입력도 20261120 형태로 저장\n" +
            "• ⚡ 선택 일괄 입력 정밀 패치: 주간·야간·특근·연차·반차 7종 프리셋을 단일 입력과 100% 동일한 키·모드로 저장 (근무시간 0h·주말 유급 중복·연차 16h 과다·반차 0.5일 미차감 결함 해결)\n" +
            "• 📐 4대 UI 일관성 개편 (웹 버전과 1:1): 캘린더 헤더 [📊 통계] 버튼 신설 · 아래 3버튼(빠른 근무 입력 / ⚡ 선택 모드 / 📊 통계) 높이·폰트·1줄 완전 통일 · 일괄 입력 2열 카드형 프리셋 바텀시트 전면 교체 · [⚡ 선택 모드] 탭 한 번 진입/해제 신설\n" +
            "• 📊 근무 통계에 상주휴게(가급) 반영: 도넛·범례를 정상·연장·상주가급·휴일특근 4종으로 구분하고 총 근무시간·요일별 누적에 가급을 포함해 출근카드 환산 총시간과 같은 기준으로 일치\n" +
            "• 📸 출근카드 OCR 인식률 보강: 28일 이후 하단 행 허용오차 40% 확대 · 번진 날짜 숫자(29·30) 정제 · 기울어진 사진의 행별 가로 밀림 보정 · 검토표 상단 [월말 평일 누락] 뱃지와 원터치 채우기 신설\n" +
            "• 🗂️ 서랍 메뉴 정리: 중복되던 [급여명세서 엑셀 내보내기]·[엑셀 백업]·[엑셀 불러오기]를 [데이터 통합 관리] 하나로 일원화\n" +
            "• 📥 서랍 [앱 정보]에 [안드로이드 전용 앱(APK) 안내] 신설: 설치 버전 안내 + 최신 APK 직다운로드 + 웹 버전 바로가기 통합\n\n" +
            "v1.3.1 — 2026-11-07 (내부 UI 리뉴얼, 캘린더 다중삭제, 단협 200% 정밀 검증)\n" +
            "• 🗑️ 캘린더 다중 선택 일괄 삭제 탑재: 롱클릭 진입 → 톡톡 추가 선택 → 하단 플로팅 바 일괄 삭제\n" +
            "• ⚖️ 단체협약 제51조 5항 휴일특근 12h(8h 150% + 4h 200%) 및 9대 급여항목 무결성 검증 완비\n" +
            "• 🎨 브랜드 메탈릭 스틸 블루(#005BAC) 내부 UI 및 16종 VectorDrawable 모던 아이콘 전면 개편\n" +
            "  - 좌측 서랍 메뉴 12종 메탈릭 블루 원형 뱃지 및 모던 벡터 스타일 100% 통일\n" +
            "  - 근무 프리셋 및 하단 바텀시트 모던 아이콘·시간 뱃지 적용\n" +
            "• 📐 세부 시간 직접 입력 창 5대 근무 영역별 색상 카드 전면 재디자인:\n" +
            "  - 🟦 1. 기본 정상근무 (정상근무 8h, 유급/주차 인정 0h - 기본 1.0배)\n" +
            "  - 🟧 2. 평일 연장근무 (평일연장 - 할증 1.5배)\n" +
            "  - 🟥 3. 휴일 특근근무 (휴일특근 8h, 특근연장 - 1.5배/2.0배)\n" +
            "  - 🟪 4. 야간 및 심야할증 (심야 근로시간 - 0.5배 가산)\n" +
            "  - 🟩 5. 가급 & 특이사항 메모 (상주휴게 가급 1.0h, 특이사항 사내메모)\n" +
            "• ⚡ 세부 시간 직접 입력 상단 1초 퀵 프리셋 칩 연동 ([주간 정상], [주간 10h], [야간 10h], [휴일 특근], [연차 유급], [0h 초기화])\n" +
            "• ⏱️ 실시간 총 인정 근로시간 집계 바 탑재: 입력값 변경 시 당일 총 인정 근로시간 실시간 자동 연산\n" +
            "• ✎ 캘린더 날짜 셀 내 특이사항 사내 메모(설명회, 조퇴 등) 표시 지원\n\n" +
            "v1.3.1 — 2026-11-04 (교대근무 지원 및 기장 직책수당 반영)\n" +
            "• 🔄 상주근무 / 교대근무(주야 격주) 선택 스위치 및 교대수당 연동:\n" +
            "  - 기본정보 설정에서 [상주근무]와 [교대근무]를 1초 만에 원터치 전환\n" +
            "  - 교대근무 선택 시 단협 제42조 5호에 따른 '교대수당 200,000원' 자동 지급 및 상주휴게수당 자동 분리\n" +
            "• 🌙 교대근무조 맞춤 1초 퀵 프리셋 탑재:\n" +
            "  - [🌙 야간 10h (8+2h)] 버튼 터치 즉시 기본 8h + 연장 2h + 심야야간할증 7.5h 일괄 저장\n" +
            "  - [🌌 야간 정상 (8h)], [🔥 야간특근 (10h)] 등 교대조 전용 원터치 바텀시트 지원\n" +
            "• 💼 기장 직책수당 200,000원 교정 (G4 책임매니저 동시 적용)\n" +
            "• 💊 캘린더 야간근무 보라색(Purple) 캡슐 칩 신설: 주간(블루)과 야간(퍼플) 교대 패턴 한눈에 직관적 구별\n\n" +
            "v1.3.1 — 2026-11-03 (마일스톤 완성판)\n" +
            "• 🔄 전체 교체 엑셀 복원 시 공휴일 소거 방지: clear() 커밋 후 공휴일을 즉시 재주입하여 복원 직후 달력 공휴일 공백 원천 차단\n" +
            "• 📝 수동 등록 휴일(holiday_*) 엑셀 백업/복원 100% 완전 보존: 사용자 등록 사내 행사 및 개인 휴일 복원 지원\n" +
            "• 🛡️ XML 파서 파싱 호환성 강화: disallow-doctype-decl 설정 예외 방어로 안드로이드 전 기기 백업 안정성 극대화\n" +
            "• 🌴 연차 계산 및 역산 현재 연도 고정: 과거/미래 연도 달력 탐색 중에도 상단 배너 잔여 연차 및 명세서 역산이 실제 귀속 연도 기준으로 정확히 산출\n" +
            "• 📅 2025·2028년 공식 공휴일 정밀 보강: 2028년 설날/추석/대체공휴일 및 2025년 임시공휴일 공식 탑재\n" +
            "• 🔒 앱 백업 보안 설정(allowBackup=false) 및 FileProvider 경로 정돈으로 개인정보 보호 강화\n\n" +
            "v1.3.0 — 2026-11-03 (마일스톤 릴리즈)\n" +
            "• 📊 3시트 엑셀 백업 복원 완벽 지원: 근무기록(1시트)뿐만 아니라 급여설정 및 기본정보(2시트)를 모두 읽어 100% 복원되도록 ExcelBackup.read() 전면 개편\n" +
            "• 🌴 급여명세서 스캔 시 연차 이중차감 원천 차단: OCR 스캔 직후 조기 덮어쓰기를 제거하고, [설정 동기화] 터치 시 올해 사용 연차를 역산 가산(잔여+사용)하여 정확히 반영\n" +
            "• 🏭 엑셀 복원 후 공장 선택(user_factory_idx) ClassCastException 방어 및 안전 형변환 적용\n" +
            "• 📅 기존 설치 사용자 2027년 대체공휴일(성탄절 대체 추가, 현충일 제외) 및 2028년 공휴일 자동 갱신 적용\n" +
            "• 🔄 전체 교체 복원 직후 공휴일 즉시 재주입으로 캘린더 공휴일 공백 방지\n\n" +
            "v1.2.9 — 2026-11-03\n" +
            "• 👆 좌·우 서랍 날개메뉴 상단 배너 내 '기본정보 미입력 (터치하여 설정)' 터치 연동: 터치 시 설정 화면으로 즉시 이동하여 편리하게 기본정보 입력\n\n" +
            "v1.2.8 — 2026-11-03\n" +
            "• 🛡️ 기본정보 영구 보존 패치: 앱 실행 시 성명/생년월일/입사일/부서/직급 등 기본정보가 초기화되던 치명적 버그 완전 해결\n" +
            "• 📊 엑셀 백업/복원 시 사용자 프로필 및 기준연차(Float) 누락 방지 완전 보존\n" +
            "• 📂 Android 10+ 파일 다운로드 Scoped Storage 충돌 방지 및 안전 저장\n" +
            "• 📅 2027년 대체공휴일 법정 규정 교정(현충일 제외, 성탄절 월요일 대체 추가) 및 미래 연도 양력 공휴일 자동 탑재\n" +
            "• ⚖️ 급여명세서 동기화 시 소급분 매월 가산 방지 및 연차 이중차감 방지 역산식 적용\n\n" +
            "v1.2.7 — 2026-11-03\n" +
            "• 🔢 생년월일·입사년월일 8자리 숫자 자동 하이픈: '19800101', '20200101'처럼 숫자만 연속 입력해도 'YYYY-MM-DD'로 자동 변환 및 즉시 연산 인식\n" +
            "• ⌨️ 숫자 전용 키패드 연동: 하이픈 특수문자를 찾을 필요 없이 편리한 숫자 키패드로 바로 입력\n\n" +
            "v1.2.6 — 2026-11-03\n" +
            "• 🔒 강제종료 긴급 해결: 직급 선택 시 직책수당 저장 형식 호환성 버그 완벽 복구 및 자동 데이터 정화\n" +
            "• 🗓️ 2026-11 ▾ 캘린더 연·월 점프 팝업: 메인 상단 날짜 탭 시 입사년월~정년 범위 내 1초 원터치 이동\n" +
            "• ⚡ 스마트 퀵 점프 프리셋: [🌱 입사 첫 달], [🎯 이번 달 (오늘)], [⏳ 정년퇴직], [◀ 1년 전], [▶ 1년 후] 바로가기\n" +
            "• ⚙️ 연도별 임단협 시급 분리 관리: 매해 바뀌는 임단협 기본시급·통상시급을 연도별로 독립 보존 및 자동 연동\n" +
            "• 📊 정규 근무·급여 명세서 엑셀 내보내기: 1일~31일 일자별 출근대장 및 단체협약 급여 산출 영수증이 담긴 정식 엑셀 서식 출력\n\n" +
            "v1.2.5 — 2026-11-03\n" +
            "• 🔒 개인정보 완벽 초기화: 성명, 생년월일, 입사일, 소속부서, 직급 등 개인 식별 정보를 깨끗하게 빈칸 초기 상태로 전면 리셋\n" +
            "• ✨ 상단 배너 글래스모피즘(Glassmorphism) 적용: 공장 드론 배너 아래 사용자 기본정보 바를 초미세 반투명 테두리의 글래스 카드로 정돈 및 터치 시 설정 바로가기 연동\n" +
            "• 💊 캘린더 근무시간 캡슐 칩(Pill Badge) 디자인: 특근(소프트레드), 연장(소프트블루), 정상(소프트인디고), 연차(소프트에메랄드) 등 모던 캡슐 뱃지화\n" +
            "• 🔵 달력 '오늘' 원형 링(Circle Ring) 인디케이터: 파란색 원형 뱃지로 당일 직관적 하이라이트\n" +
            "• 🧾 급여 정산 카드 접이식(Accordion) 영수증 개편: 기본 영수증 요약과 [▾ 상세 산출 계산식 펼치기/접기] 토글을 분리하여 시각적 정갈함 극대화\n" +
            "• 📱 엄지 조작 최적화 퀵 액션 바: 달력 바로 아래 [⚡ 빠른 근무 입력]과 [📸 OCR 스캔]을 1:1 나란히 배치하여 한 손 1초 진입 지원\n\n" +
            "v1.2.4 — 2026-11-03\n" +
            "• 🗓️ 창립기념일 대체휴무 중복 배정 완벽 해소: 10월 18일(일)에 따른 대체휴무가 19일(월)에만 정확히 단독 표시되도록 중복 연산 교정 및 데이터 정화\n" +
            "• 🗑️ 캘린더 근무 시간 일괄 삭제 & 날짜별 롱클릭 오버레이 선택 삭제:\n" +
            "  - 월 내비게이션 바에 이번 달 전체 근무 초기화 리셋 버튼 신설 (자동 백업 지원)\n" +
            "  - 캘린더 날짜를 길게 꾸욱(롱클릭) 누르면 해당 날짜 위치 위에 [🗑️ 내용삭제] 플로팅 오버레이 버튼 표시\n" +
            "  - 원터치 퀵 바텀시트 하단에도 [🗑️ 입력 내용 삭제] 버튼 추가\n" +
            "• 📂 좌측 메뉴 서랍 순서 재배치: [사내 복지 & 협약]을 [앱 정보] 바로 위로 위치 변경하여 [급여 및 데이터 관리] - [사내 복지 & 협약] - [앱 정보] 순서로 최적화\n" +
            "• 🚀 첫 실행 온보딩 3단계 이용안내 및 기본정보 마법사:\n" +
            "  - 앱 첫 실행 시 3단계 급여 관리 플로우(1단계: 기본정보·시급 설정 → 2단계: 월말 출근카드 OCR → 3단계: 10일 급여명세서 대조) 직관적 팝업 안내\n" +
            "  - 기본정보 미입력 시 메인 상단 가이드 배너 표시 및 서랍 내 [처음 사용자 이용 가이드] 상시 제공\n\n" +
            "v1.2.2 — 2026-11-03\n" +
            "• 💰 급여명세서 OCR 역산 및 1:1 대조 기능 탑재: 카메라 촬영 또는 갤러리 선택으로 급여명세서를 스캔하여 출근카드(앱 계산값)와 실제 명세서(지급총액, 공제액, 실지급액, 세부수당) 1:1 비교\n" +
            "• ⚡ 명세서 기준 설정값 원터치 자동 동기화: 명세서의 기본시급, 통상시급, 직책수당, 실제 공제액을 앱 설정에 버튼 하나로 즉시 반영\n" +
            "• 📸 우측 상단 스마트 OCR 스캐너 메뉴 개편: [종이 출근카드 자동 입력]과 [급여명세서 역산 & 대조]를 직관적으로 선택할 수 있도록 2개 섹션으로 분리\n\n" +
            "v1.2.1 — 2026-11-03\n" +
            "• 🔄 급여 및 화면 설정 타이틀 우측 '리셋' 버튼 신설: 터치 시 기본정보 및 모든 급여/수당 입력값을 빈칸으로 즉시 초기화 (단협 기본값 복구 지원)\n" +
            "• 📱 실행 아이콘 녹음기 앱 1:1 스쿼클 라운딩 전면 적용: 직각 사각형 모서리를 녹음기 앱과 똑같은 곡률의 부드러운 스쿼클로 가공하고 파란 배경은 테두리 여백 없이 꽉 찬 디자인 완성\n\n" +
            "v1.2.0 — 2026-11-03\n" +
            "• 👤 나의 기본정보 및 만 60세 정년 D-Day 연동: 성명, 생년월일, 소속부서, 직급, 공장 관리 및 정년 퇴직일까지 'X년 Y개월 Z일(D-NNNN일)' 실시간 카운트다운\n" +
            "• 💼 직급 체계 및 직책수당 자동 연동: 일반직(G1~G4)/기술직(사원~기장) 선택 시 직책수당(사원 0원, 계장 10만원 등) 급여 계산 자동 반영\n" +
            "• 🏭 현대스틸파이프 공식 1·2·3공장 드론 항공사진 배너: 1공장(ERW), 2공장(LSAW), 3공장(SPIRAL) 실제 드론 사진을 메인 타이틀 바 및 서랍 헤더 배경으로 동적 연동 및 공장 명칭 변경\n" +
            "• 🌙 간편 다크모드 원터치 토글: 메인 상단 바 및 메뉴 서랍에서 1초 만에 전환하는 퀵 토글 버튼 신설\n" +
            "• 🏖️ 하계건강지원비 7·8·9월 한정 적용: 단체협약 및 실지급 기준에 맞춰 해당 3개월간만 정확히 급여에 합산\n" +
            "• 📱 실행 아이콘 꽉 찬 스쿼클 복원: 흰색 여백 테두리 없이 파란색 배경이 끝까지 꽉 차도록 전면 보정\n\n" +
            "v1.1.9 — 2026-11-03\n" +
            "• ⚡ 원터치 퀵 프리셋 바텀시트: 날짜 터치 시 하단 시트에서 [주간 정상], [연장 8+2h], [특근 8/12h], [연차]를 1초 만에 원터치 저장\n" +
            "• 📳 손끝 햅틱(미세 진동) 피드백: 달력 터치, 프리셋 선택, 저장 시 경쾌한 햅틱 진동으로 상용 앱 손맛 구현\n" +
            "• 🎯 오늘(Today) 강조 뱃지 및 바로가기: 달력에서 오늘 날짜 하이라이트 및 상단 '오늘' 버튼 원터치 복귀\n" +
            "• 🛡️ 무인 안심 엑셀 자동 백업: 데이터 저장 시 백그라운드 자동 엑셀 백업 및 간편 복원 지원\n" +
            "• 📱 앱 아이콘 사각 라운딩(스쿼클) 전면 적용: 원형 마스크 잘림 해소 및 시안 100% 원본 반영\n\n" +
            "v1.1.7 — 2026-11-03\n" +
            "• ✨ 상업용 프리미엄 카드 UI 전면 개편: 세련된 카드 레이아웃, 직관적인 시각 위계 및 여백 최적화\n" +
            "• 🚪 좌측 메뉴 서랍(Drawer) 애니메이션: 왼쪽에서 오른쪽으로 부드럽게 펼쳐지는 사이드 드로어 메뉴\n" +
            "• 📷 우측 카메라 메뉴 대칭 슬라이드 애니메이션: 오른쪽에서 왼쪽으로 슬라이드되는 대칭형 촬영/선택 패널\n" +
            "• 🔍 글자 폰트 확대 및 촘촘한 줄간격: 시원한 글자 크기와 컴팩트한 행간으로 한눈에 들어오는 가독성 확보\n" +
            "• ⚙️ 급여 및 화면설정 2열 그리드 재배치: 제목칸(푸른빛)과 숫자입력칸(화이트) 명확한 색상 분리 및 2열 배치로 세로 스크롤 최소화\n" +
            "• 📊 월간 근무 집계 및 급여 정산 카드화: 텍스트 나열에서 깔끔한 독립 카드 위젯 형태로 전면 개편\n\n" +
            "v1.1.6 — 2026-11-03\n" +
            "• 🌙 다크모드 (어두운 화면 테마) 추가: 설정에서 눈 편안한 딥블루 야간 모드 전환\n" +
            "• 전체 글자 크기(폰트 포인트) 확대 및 전면 가독성 개선\n" +
            "• 최상단 및 최하단 안전 여백(Insets) 자동 확보로 버튼·내용 겹침 완전 해소\n" +
            "• 캘린더 근무기록 입력일 하늘색 음영 하이라이트 및 날짜 셀 내 근무시간(8+2h, 특근12h, 연차 등) 직관적 표시\n" +
            "• 하단 예상 급여 항목별 상세 산출식(근무시간 × 적용단가 등 산출근거) 완전 공개\n" +
            "• 공휴일 데이터 갱신 기능 원터치 자동 복구\n" +
            "• 좌측 메뉴 순서 실사용 중심 재배치\n\n" +
            "v1.1.5 — 2026-11-02\n" +
            "• 고화질 적응형 앱 아이콘 적용 (현대스틸파이프 시안 반영, 원형·사각형 런처 호환 및 안전 영역 준수)\n" +
            "• 캘린더 요일 밀림 버그(+1 누락) 수정 (1일 요일 정상 정렬)\n" +
            "• 출근카드 1:1 맞춤 슬림 엑셀 검토표 전면 개편\n" +
            "• 초정밀 출근카드 OCR 매핑 (1~31일 날짜 앵커 및 12개 열 비율 보간)\n" +
            "• 단체협약 기준 급여 계산식 1원 단위 정밀화 (연장·휴일 반올림, 휴일연장 200%, 상주휴게수당 연동)\n" +
            "• 상단 메뉴 3종 문서 뷰어 및 원본 파일 다운로드 추가 (단협, 지원제도, 제휴업체)\n\n" +
            "v1.1.4 — 출근카드 표 구조 기반 OCR, 압축형 편집표, 앱 아이콘 및 요일 계산 개선\n\n" +
            "v1.1.3 — OCR 날짜별 엑셀형 검토 및 전체 선택\n\n" +
            "v1.1.0 — 2026-10-31\n" +
            "• Google ML Kit 한국어 OCR 탑재\n" +
            "• 커스텀 달력 및 공휴일 명칭 표시\n" +
            "• 엑셀(.xlsx) 데이터 백업 및 복원 추가\n" +
            "• 주말 미출근 유급 인정 및 글자 크기 확대\n\n" +
            "v1.0.0 — 최초 버전\n" +
            "• 근무 기록·급여 계산·설정";
        root.addView(text(hist, 14, false));
        root.addView(button("돌아가기", this::showMain));
    }

    void showCompany() {
        start("현대스틸파이프 소개 및 연혁");
        root.addView(text("현대스틸파이프", 20, true));
        root.addView(text("1975년 경일공업에서 시작해 현대강관, 현대하이스코, 현대제철을 거쳐 2024년 독립 출범한 강관 전문기업. 에너지·건설·자동차·친환경 산업용 강관을 생산.", 15, false));
        root.addView(text("주요 연혁", 18, true));
        String[][] history = {
            {"1975", "경일공업㈜ 설립"},
            {"1979", "울산공장 준공"},
            {"1980", "현대강관㈜으로 사명 변경"},
            {"1982", "국내 최초 1억 달러 수출탑 수상"},
            {"1990", "스테인리스 공장 가동"},
            {"2001", "현대하이스코㈜로 사명 변경"},
            {"2015", "현대제철에 합병"},
            {"2018", "대구경 강관 및 자동차용 전용라인 상업생산"},
            {"2023", "10월 18일 현대스틸파이프㈜ 법인 설립"},
            {"2024", "1월 1일 현대스틸파이프 공식 출범"}
        };
        for (String[] entry : history) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            TextView yr = text(entry[0], 14, true);
            yr.setTextColor(colorBlue());
            row.addView(yr, new LinearLayout.LayoutParams(dp(70), -2));
            row.addView(text(entry[1], 14, false), new LinearLayout.LayoutParams(0, -2, 1));
            root.addView(row);
        }
        root.addView(button("돌아가기", this::showMain));
    }
}
