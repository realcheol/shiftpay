package com.example.shiftpay;

/**
 * 순수 급여 계산 코어.
 *
 * 안드로이드 프레임워크에 의존하지 않으므로 같은 소스 파일을 데스크톱 JVM에서 그대로 실행해
 * 실물 급여명세서와 1원 단위까지 대조(단위 테스트)할 수 있다.
 * MainActivity의 totals()/countWorkDays()/amounts()가 이 코어를 호출한다.
 *
 * 반영된 3대 핵심 급여 계산식 (단협 제49조·제51조)
 *  ① 휴일특근 8시간 초과분 자동 분리: 8h까지는 휴일근로 150%, 초과분은 휴일연장 200%
 *  ② 상주휴게수당(가급) 지급일수 = 실근무 8시간 이상인 날 (평일 + 주말/공휴일 특근일 포함)
 *  ③ 휴일(토요일·공휴일)에 특근해도 그날의 유급 8시간(기본급 248h 산입분)은 삭감하지 않음
 */
public final class PayCore {

    private PayCore() {}

    // hours(day, idx)의 idx 순서 — MainActivity.keys 순서와 동일
    public static final int NORMAL = 0;   // 정상근무
    public static final int PAID = 1;     // 유급(휴일 유급 인정)
    public static final int WEEKLY = 2;   // 주차(주휴)
    public static final int UNION = 3;    // 조합설명회(정상 인정)
    public static final int OT = 4;       // 평일연장(조합설명회 포함)
    public static final int HOL = 5;      // 휴일근로(특근) 8h 이내
    public static final int HOLOT = 6;    // 휴일연장(8h 초과분)
    public static final int NIGHT = 7;    // 야간근로(심야 할증 인정시간)
    public static final int GAGEUB = 8;   // 가급(상주휴게) 직접 입력

    /** 휴일근로 8시간 기준 (단협 제51조 5항) */
    public static final double HOLIDAY_BASE_HOURS = 8.0;

    public interface DayData {
        int daysInMonth();
        /** idx: NORMAL..GAGEUB */
        double hours(int day, int idx);
        /** auto / work / annual / summer / none */
        String mode(int day);
    }

    public interface Settings {
        double get(String key);
        boolean isShiftWorker();
        boolean isSummerMonth();
        boolean isRetroActive();
        double retroAmount();
    }

    /**
     * 하루의 인정시간 기본값 (자동 인정 규칙). MainActivity.dayHours()가 이 함수에 위임한다.
     *  - idx=NORMAL(0)  : 연차·하계휴가는 유급 8h 인정
     *  - idx=PAID(1)    : 토요일 8h, 평일 공휴일 8h 자동 인정
     *  - idx=WEEKLY(2)  : 일요일 주차 8h 자동 인정
     *  - ③ 특근(mode="work")해도 토·일·공휴일의 유급/주차 8h는 삭감하지 않는다
     *  - mode="none"(무급)일 때만 모두 0
     *
     * @param hasManual  해당 날짜·항목의 직접 입력값이 있으면 그 값이 우선
     * @param dow        java.util.Calendar 요일 상수 (1=일 … 7=토)
     * @param isHoliday  공휴일(회사 대체휴무 포함) 여부
     * @param isLeaveDay 연차·하계휴가 여부
     */
    public static double dayHours(int idx, boolean hasManual, double manualValue, String mode,
                                  int dow, boolean isHoliday, boolean isLeaveDay) {
        if (hasManual) return manualValue;
        // 연차·하계휴가는 유급 8시간만 인정 (공휴일·주말 자동 인정과 중복되지 않도록 한 번만)
        if (isLeaveDay) return (idx == NORMAL) ? 8 : 0;
        boolean isHolidayDay = (dow == java.util.Calendar.SATURDAY)
                || (dow == java.util.Calendar.SUNDAY) || isHoliday;
        if ("none".equals(mode)) return 0;
        if ("work".equals(mode) && !isHolidayDay) return 0;
        if (idx == PAID && dow == java.util.Calendar.SATURDAY) return 8;                      // 토요일 유급 8h
        if (idx == PAID && dow != java.util.Calendar.SUNDAY && isHoliday) return 8;           // 공휴일 유급 8h
        if (idx == WEEKLY && dow == java.util.Calendar.SUNDAY) return 8;                     // 일요일 주차 8h
        return 0;
    }

    /**
     * 월간 시간 집계. ① 휴일특근 8시간 초과분을 휴일연장으로 자동 분리한다.
     * (예: 10시간 특근 → 휴일근로 8h + 휴일연장 2h)
     */
    public static double[] totals(DayData dd) {
        double[] a = new double[9];
        int n = dd.daysInMonth();
        for (int d = 1; d <= n; d++) {
            double hol = dd.hours(d, HOL);
            double holOt = dd.hours(d, HOLOT);
            if (hol > HOLIDAY_BASE_HOURS) {
                holOt += hol - HOLIDAY_BASE_HOURS;
                hol = HOLIDAY_BASE_HOURS;
            }
            a[NORMAL] += dd.hours(d, NORMAL);
            a[PAID] += dd.hours(d, PAID);
            a[WEEKLY] += dd.hours(d, WEEKLY);
            a[UNION] += dd.hours(d, UNION);
            a[OT] += dd.hours(d, OT);
            a[HOL] += hol;
            a[HOLOT] += holOt;
            a[NIGHT] += dd.hours(d, NIGHT);
            a[GAGEUB] += dd.hours(d, GAGEUB);
        }
        return a;
    }

    /** 상주휴게수당(가급) 지급일수 — ② 실근무 8시간 이상인 날(평일 + 특근일) */
    public static int countWorkDays(DayData dd) {
        int count = 0;
        int n = dd.daysInMonth();
        for (int d = 1; d <= n; d++) {
            double normal = dd.hours(d, NORMAL);
            double holWork = dd.hours(d, HOL) + dd.hours(d, HOLOT);
            if (normal >= 8.0 || holWork >= 8.0) {
                count++;
            }
        }
        return count;
    }

    /** 고정수당 합계 (근속 + 가족본인 + 가족부양 + 직책 + 직무 + 교대/상주휴게 + 기타 + 하계) */
    public static double fixedAllowance(Settings s, DayData dd, double[] t) {
        double gageubDays = (t[GAGEUB] > 0) ? t[GAGEUB] : countWorkDays(dd);
        boolean isShift = s.isShiftWorker();
        double breakPay = isShift ? 0 : (gageubDays * s.get("base"));
        double shiftPay = isShift ? 200000 : 0; // 단협 제42조 5호 교대수당 20만원
        return s.get("tenure") + s.get("familySelf") + s.get("familyOther")
                + breakPay + shiftPay
                + s.get("position") + s.get("duty") + s.get("other")
                + (s.isSummerMonth() ? s.get("summer") : 0);
    }

    /** amounts()와 동일한 9칸 결과: 0기본급 1평일연장 2휴일근로 3휴일연장 4야간 5고정/휴게 6세전 7공제 8실수령 */
    public static double[] amounts(Settings s, DayData dd) {
        double[] t = totals(dd);
        double[] a = new double[9];
        a[0] = (t[NORMAL] + t[PAID] + t[WEEKLY] + t[UNION]) * s.get("base");

        double otUnit = Math.round(s.get("ordinary") * s.get("otRate"));
        a[1] = Math.max(0, t[OT] - t[UNION]) * otUnit;

        double holUnit = Math.round(s.get("ordinary") * s.get("holidayRate"));
        a[2] = t[HOL] * holUnit;

        double holOtUnit = Math.round(s.get("ordinary") * s.get("holidayOTRate"));
        a[3] = t[HOLOT] * holOtUnit;

        double nightUnit = Math.round(s.get("ordinary") * s.get("nightRate"));
        a[4] = t[NIGHT] * nightUnit;

        a[5] = fixedAllowance(s, dd, t);

        for (int i = 0; i <= 5; i++) a[6] += a[i];
        if (s.isRetroActive()) {
            a[6] += s.retroAmount();
        }
        a[7] = s.get("deduction");
        a[8] = a[6] - a[7];
        return a;
    }
}
