import com.example.shiftpay.PayCore;

/**
 * v1.3.6 — 가족수당 ↔ 부양가족 수 연동 테스트.
 *
 * 단협 관행: 본인 외 부양가족 1인당 10,000원.
 *  · 부양가족 수(본인 포함) 1명 → 가족수당 0원
 *  · 4명(본인 + 가족 3명) → 30,000원  (가족 3명 = 3만원)
 *  · 세법상 부양가족 수와 회사 가족수당 인정 가족 수가 다른 예외는 설정에서 연동을 풀고
 *    직접 입력하므로(ExcelBackup.setting_family_link), 코어는 1인당 단가만 책임진다.
 */
public class FamilyAllowanceTest {
    static int fail = 0;

    static void check(String name, double got, double want) {
        boolean ok = Math.abs(got - want) < 0.0001;
        if (!ok) fail++;
        System.out.printf("%-40s 값 %,10.0f  기대 %,10.0f  %s%n", name, got, want, ok ? "OK" : "FAIL");
    }

    public static void main(String[] args) {
        check("1인당 단가", PayCore.FAMILY_ALLOWANCE_PER_PERSON, 10000);
        check("부양가족 1명(본인만)", PayCore.familyAllowanceFor(1), 0);
        check("부양가족 2명(본인+1)", PayCore.familyAllowanceFor(2), 10000);
        check("부양가족 3명(본인+2)", PayCore.familyAllowanceFor(3), 20000);
        check("부양가족 4명(본인+가족3)", PayCore.familyAllowanceFor(4), 30000);
        check("부양가족 5명", PayCore.familyAllowanceFor(5), 40000);
        check("비정상 0명은 0원", PayCore.familyAllowanceFor(0), 0);
        check("음수도 0원", PayCore.familyAllowanceFor(-3), 0);

        System.out.println(fail == 0 ? "\n✅ 가족수당 연동(본인 외 1인당 10,000원) 전 항목 통과" : "\n❌ 실패 " + fail + "건");
        if (fail > 0) System.exit(1);
    }
}
