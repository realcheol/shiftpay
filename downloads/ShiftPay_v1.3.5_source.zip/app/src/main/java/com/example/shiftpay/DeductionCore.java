package com.example.shiftpay;

import java.util.Locale;

/**
 * 공제액 정밀 예측 코어 (안드로이드 비의존 — 데스크톱 JVM에서 그대로 검증 가능).
 *
 *  ① 4대보험 법정 요율
 *     · 국민연금   4.5%      (기준소득월액 × 4.5%)
 *     · 건강보험   3.545%    (보수월액 × 3.545%)
 *     · 장기요양   건강보험료 × 12.95%
 *     · 고용보험   0.9%      (과세 급여 × 0.9%)
 *  ② 소득세 — 국세청 근로소득 간이세액표 방식
 *     연간환산 → 근로소득공제 → 인적공제(부양가족 수) · 연금보험료공제 · 표준세액공제
 *     → 기본세율 → 근로소득세액공제 → 12분의 1 → 10원 절사 → 선공제율(80/100/120%)
 *  ③ 지방소득세 = 소득세 × 10%
 *  ④ 노조회비 = (통상시급 × 3h) + 1,200원 → 100원 단위 반올림
 *     실물 명세서 역산: 14,939×3+1,200=46,017→46,000 / 16,092×3+1,200=49,476→49,500
 *  ⑤ 직전 급여명세서를 OCR로 읽어 두었다면 그 실측 6개 항목을 세전 급여에 맞춰 보정해 쓴다.
 *     (회사가 원천징수하는 실제 소득세·건강보험 정산액은 개인별 연말정산 공제와 보수월액에 따라
 *      법정 요율 단순 곱과 달라지므로, 실측값이 있으면 그것이 가장 정확하다.)
 */
public final class DeductionCore {

    private DeductionCore() {}

    public static final double PENSION_RATE = 0.045;
    public static final double HEALTH_RATE = 0.03545;
    public static final double LONGTERM_OF_HEALTH = 0.1295;
    public static final double EMPLOY_RATE = 0.009;
    public static final double LOCAL_TAX_OF_INCOME = 0.10;
    public static final double UNION_HOURS = 3.0;
    public static final double UNION_FIXED = 1200.0;
    public static final double STANDARD_TAX_CREDIT = 130000.0;   // 표준세액공제
    public static final double PERSONAL_DEDUCTION = 1500000.0;   // 1인당 인적공제

    public static final class Result {
        public long gross;
        public long incomeTax, localTax, pension, health, longterm, employ, unionFee, total;
        public int dependents;
        public double advanceRate;
        public long pensionBase, healthBase;

        public boolean learned;          // 직전 명세서 실측 기준으로 계산했는지
        public long learnedGross;
        public long statutoryIncomeTax;  // 참고: 간이세액표 계산값(실측 사용 시에도 병기)
        public String taxNote = "";      // 소득세 산출 요약
        public String basisNote = "";    // 실측/법정 요율 구분 안내

        // 소득세 산출 과정(투명 공개용)
        public long annualIncome, earnedDeduction, personalDeduction, pensionDeduction, taxBase, taxBeforeCredit, taxCredit;
        public double appliedTaxRate;
    }

    public static long round100(double v) {
        return Math.round(v / 100.0) * 100L;
    }

    /** 노조회비 = 통상시급 × 3h + 1,200원 (100원 단위 반올림) */
    public static long unionFee(double ordinaryRate) {
        if (ordinaryRate <= 0) return 0;
        return round100(ordinaryRate * UNION_HOURS + UNION_FIXED);
    }

    /** 근로소득 간이세액표 방식의 월 소득세(선공제율 반영 전 100% 기준) */
    public static long statutoryIncomeTax(long monthlyGross, Result out) {
        if (monthlyGross <= 0) return 0;
        int deps = out == null ? 1 : Math.max(1, out.dependents);
        double annual = monthlyGross * 12.0;

        double earned;
        if (annual <= 5_000_000) earned = annual * 0.70;
        else if (annual <= 15_000_000) earned = 3_500_000 + (annual - 5_000_000) * 0.40;
        else if (annual <= 45_000_000) earned = 7_500_000 + (annual - 15_000_000) * 0.15;
        else if (annual <= 100_000_000) earned = 12_000_000 + (annual - 45_000_000) * 0.05;
        else earned = 14_750_000 + (annual - 100_000_000) * 0.02;

        double income = annual - earned;
        double personal = deps * PERSONAL_DEDUCTION;
        double pensionDed = monthlyGross * PENSION_RATE * 12.0;
        double base = Math.max(0, income - personal - pensionDed - STANDARD_TAX_CREDIT);
        base = Math.floor(base / 1000.0) * 1000.0;   // 과세표준 1,000원 단위 절사

        double[][] brackets = {
                {14_000_000, 0.06, 0},
                {50_000_000, 0.15, 1_260_000},
                {88_000_000, 0.24, 5_760_000},
                {150_000_000, 0.35, 15_440_000},
                {300_000_000, 0.38, 19_940_000},
                {500_000_000, 0.40, 25_940_000},
                {1_000_000_000, 0.42, 35_940_000},
                {Double.MAX_VALUE, 0.45, 65_940_000}
        };
        double rate = 0.45, progressive = 65_940_000, tax = 0;
        for (double[] b : brackets) {
            if (base <= b[0]) { rate = b[1]; progressive = b[2]; break; }
        }
        tax = Math.max(0, base * rate - progressive);

        double credit;
        if (tax <= 1_300_000) credit = tax * 0.55;
        else credit = 1_300_000 * 0.55 + (tax - 1_300_000) * 0.30;
        double cap = annual <= 33_000_000 ? 740_000 : annual <= 70_000_000 ? 660_000
                : annual <= 120_000_000 ? 500_000 : 200_000;
        credit = Math.min(credit, cap);
        double decided = Math.max(0, tax - credit);
        long monthly = (long) (Math.floor(decided / 12.0 / 10.0) * 10);

        if (out != null) {
            out.annualIncome = Math.round(annual);
            out.earnedDeduction = Math.round(earned);
            out.personalDeduction = Math.round(personal);
            out.pensionDeduction = Math.round(pensionDed);
            out.taxBase = Math.round(base);
            out.appliedTaxRate = rate;
            out.taxBeforeCredit = Math.round(tax);
            out.taxCredit = Math.round(credit);
        }
        return monthly;
    }

    /**
     * @param learnedGross 직전 명세서의 세전 지급총액 (0이면 실측 없음)
     * @param learned      {소득세, 지방소득세, 건강보험(+장기요양), 국민연금, 고용보험, 노조회비} — 없으면 null
     */
    public static Result compute(long gross, double ordinaryRate, int dependents, double advanceRate,
                                 long pensionBase, long healthBase,
                                 long learnedGross, long[] learned) {
        Result r = new Result();
        r.gross = gross;
        r.dependents = Math.max(1, dependents);
        r.advanceRate = advanceRate <= 0 ? 1.0 : advanceRate;
        r.pensionBase = pensionBase > 0 ? pensionBase : gross;
        r.healthBase = healthBase > 0 ? healthBase : gross;
        r.unionFee = unionFee(ordinaryRate);
        r.statutoryIncomeTax = statutoryIncomeTax(gross, r);

        boolean hasLearned = learned != null && learned.length >= 6 && learnedGross > 0
                && (learned[0] > 0 || learned[2] > 0 || learned[3] > 0 || learned[4] > 0);
        double scale = hasLearned ? Math.max(0.5, Math.min(2.0, (double) gross / (double) learnedGross)) : 1.0;

        if (hasLearned) {
            r.learned = true;
            r.learnedGross = learnedGross;
            r.incomeTax = round10(learned[0] * scale);
            r.health = round10(learned[2] * scale);
            r.pension = round10(learned[3] * scale);
            r.employ = round10(learned[4] * scale);
            // 회사 명세서는 지방소득세를 소득세의 10%에서 10원 미만을 절사해 표기한다 (206,810 → 20,680)
            r.localTax = r.incomeTax > 0
                    ? (long) (Math.floor(r.incomeTax * LOCAL_TAX_OF_INCOME / 10.0) * 10)
                    : round10(learned[1] * scale);
            r.longterm = 0;   // 실측 건강보험 금액에 장기요양보험료가 포함되어 있다
            if (r.unionFee <= 0) r.unionFee = learned[5];
            r.basisNote = "직전 급여명세서 실측값 기준";
        } else {
            r.incomeTax = round10(r.statutoryIncomeTax * r.advanceRate);
            r.localTax = (long) (Math.floor(r.incomeTax * LOCAL_TAX_OF_INCOME / 10.0) * 10);
            r.pension = round10(r.pensionBase * PENSION_RATE);
            r.health = round10(r.healthBase * HEALTH_RATE);
            r.employ = round10(gross * EMPLOY_RATE);
            r.basisNote = "법정 요율·간이세액표 기준";
        }
        if (!r.learned) r.longterm = round10(r.health * LONGTERM_OF_HEALTH);

        r.total = r.incomeTax + r.localTax + r.pension + r.health + r.longterm + r.employ + r.unionFee;
        r.taxNote = String.format(Locale.KOREA,
                "과세표준 %,d원 × %.0f%% − 누진공제 = 산출세액 %,d원 → 근로소득세액공제 %,d원 차감 후 12분의 1 (부양가족 %d명, 선공제율 %.0f%%)",
                r.taxBase, r.appliedTaxRate * 100, r.taxBeforeCredit, r.taxCredit, r.dependents, r.advanceRate * 100);
        return r;
    }

    static long round10(double v) {
        return Math.round(v / 10.0) * 10L;
    }
}
