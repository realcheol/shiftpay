import com.example.shiftpay.DeductionCore;

/**
 * 공제액 정밀 예측 코어 검증 (v1.4.2).
 *
 * 실물 명세서 두 장의 공제 6개 항목을 그대로 넣어 합계가 1원까지 맞는지,
 * 노조회비 공식이 두 사람 모두에게 맞는지, 그리고 v1.4.2의 국세청 근로소득
 * 간이세액표(별표 2) 1:1 조회와 8세~20세 자녀 세액공제가 실물 명세서 금액과
 * 정확히 일치하는지 확인한다.
 */
public class DeductionCoreTest {
    static int fail = 0;

    static void check(String name, long got, long want) {
        boolean ok = got == want;
        if (!ok) fail++;
        System.out.printf("%-34s 값 %,12d  기대 %,12d  %s%n", name, got, want, ok ? "OK" : "FAIL");
    }

    public static void main(String[] args) {
        // ── 1. 노조회비 공식: (통상시급 × 3h) + 1,200원 → 100원 단위 반올림 ──
        System.out.println("[1. 노조회비 공식]");
        check("상주 통상시급 14,939원", DeductionCore.unionFee(14939), 46000);
        check("교대 통상시급 16,092원", DeductionCore.unionFee(16092), 49500);

        // ── 2. 국세청 근로소득 간이세액표 1:1 조회 ──
        System.out.println("\n[2. 국세청 간이세액표(별표 2) 조회]");
        check("조견표 행 수(646구간)", DeductionCore.tableRowCount(), 646);
        check("5,262,924원 · 가족 4명", DeductionCore.tableTax(5262924L, 4), 252640);
        check("5,513,610원 · 가족 2명", DeductionCore.tableTax(5513610L, 2), 376460);
        check("5,000,000원 · 가족 4명", DeductionCore.tableTax(5000000L, 4), 219100);
        check("4,500,000원 · 가족 4명", DeductionCore.tableTax(4500000L, 4), 152100);
        check("5,000,000원 · 가족 2명", DeductionCore.tableTax(5000000L, 2), 306710);
        check("조견표 하한(77만원 미만)", DeductionCore.tableTax(700000L, 3), 0);

        // ── 3. 8세~20세 자녀 세액공제 ──
        System.out.println("\n[3. 자녀 세액공제(별표 2 비고 3)]");
        check("자녀 0명", DeductionCore.childCredit(0), 0);
        check("자녀 1명", DeductionCore.childCredit(1), 20830);
        check("자녀 2명", DeductionCore.childCredit(2), 45830);
        check("자녀 3명 (45,830+33,330)", DeductionCore.childCredit(3), 79160);
        check("자녀 4명", DeductionCore.childCredit(4), 112490);
        check("표 − 자녀공제 (5,262,924·4명·2명)", DeductionCore.statutoryIncomeTax(5262924L, 4, 2), 206810);

        // ── 4. 실물 명세서와 1원 일치 (자동 예측 모드) ──
        System.out.println("\n[4. 실물 명세서 1원 일치]");
        DeductionCore.Result me = DeductionCore.compute(5262924L, 14939, 4, 2, 1.0, 0, 0, 0, null);
        check("상주(4인·자녀2) 소득세", me.incomeTax, 206810);
        check("상주(4인·자녀2) 지방소득세", me.localTax, 20680);
        check("상주 간이세액표 세액", me.tableTax, 252640);
        check("상주 자녀 세액공제", me.childTaxCredit, 45830);
        DeductionCore.Result mate = DeductionCore.compute(5513610L, 16092, 2, 0, 1.0, 0, 0, 0, null);
        check("교대(2인·자녀0) 소득세", mate.incomeTax, 376460);
        check("교대(2인·자녀0) 지방소득세", mate.localTax, 37640);

        // ── 5. 실측 학습 모드: 10월 명세서 공제 6항목 그대로 ──
        System.out.println("\n[5. 실측 학습 모드 — 10월 명세서]");
        long gross = 5262924L;
        long[] learned = {206810, 20680, 274300, 245000, 45900, 46000};
        DeductionCore.Result r = DeductionCore.compute(gross, 14939, 4, 2, 1.0, 0, 0, gross, learned);
        check("소득세", r.incomeTax, 206810);
        check("지방소득세", r.localTax, 20680);
        check("건강보험", r.health, 274300);
        check("국민연금", r.pension, 245000);
        check("고용보험", r.employ, 45900);
        check("노조회비", r.unionFee, 46000);
        check("공제 합계", r.total, 838690);

        long[] learned2 = {376460, 37640, 255340, 294070, 56500, 49500};
        DeductionCore.Result r2 = DeductionCore.compute(5513610L, 16092, 2, 0, 1.0, 0, 0, 5513610L, learned2);
        check("교대 공제 합계", r2.total, 1069510);

        // ── 6. 법정 요율 모드 — 각 항목과 합계가 맞물리는지 ──
        System.out.println("\n[6. 법정 요율·간이세액표 모드]");
        DeductionCore.Result r3 = DeductionCore.compute(5262924L, 14939, 4, 2, 1.0, 0, 0, 0, null);
        check("국민연금 4.5%", r3.pension, Math.round(5262924L * 0.045 / 10.0) * 10);
        check("건강보험 3.545%", r3.health, Math.round(5262924L * 0.03545 / 10.0) * 10);
        check("장기요양 12.95%", r3.longterm, Math.round(r3.health * 0.1295 / 10.0) * 10);
        check("고용보험 0.9%", r3.employ, Math.round(5262924L * 0.009 / 10.0) * 10);
        check("지방소득세 = 소득세 10%", r3.localTax, (long)(Math.floor(r3.incomeTax * 0.10 / 10.0) * 10));
        check("노조회비", r3.unionFee, 46000);
        long sum = r3.incomeTax + r3.localTax + r3.pension + r3.health + r3.longterm + r3.employ + r3.unionFee;
        check("공제 합계 = 항목합", r3.total, sum);

        // 선공제율 80% / 120% 는 소득세에만 작용 (10원 미만 절사)
        DeductionCore.Result r80 = DeductionCore.compute(5262924L, 14939, 4, 2, 0.8, 0, 0, 0, null);
        DeductionCore.Result r120 = DeductionCore.compute(5262924L, 14939, 4, 2, 1.2, 0, 0, 0, null);
        check("선공제율 80% 소득세", r80.incomeTax, 165440);   // 206,810 × 0.8 = 165,448 → 10원 절사
        check("선공제율 120% 소득세", r120.incomeTax, 248170); // 206,810 × 1.2 = 248,172 → 10원 절사
        check("80% 국민연금 불변", r80.pension, r3.pension);

        // ── 7. 조견표 경계: 1,000만원 초과 산식 · 11명 초과 ──
        System.out.println("\n[7. 조견표 경계]");
        DeductionCore.Result rBig = DeductionCore.compute(12000000L, 14939, 1, 0, 1.0, 0, 0, 0, null);
        check("1,000만원·1명 표 마지막 칸", DeductionCore.tableTax(10000000L, 1), 1507400);
        check("1,200만원·1명 소득세", rBig.incomeTax, DeductionCore.tableTax(12000000L, 1));
        DeductionCore.Result rMany = DeductionCore.compute(5262924L, 14939, 12, 3, 1.0, 0, 0, 0, null);
        check("12명(비고 4) 세액", rMany.tableTax, 121390 - (140140 - 121390));
        check("12명·자녀 3명 소득세", rMany.statutoryIncomeTax, 102640 - 79160);

        // ── 8. 실측값은 세전 급여 변화에 비례 보정 ──
        System.out.println("\n[8. 실측 학습 — 세전 급여 변동 보정]");
        DeductionCore.Result r4 = DeductionCore.compute(Math.round(gross * 1.1), 14939, 4, 2, 1.0, 0, 0, gross, learned);
        check("소득세 10% 인상 보정", r4.incomeTax, Math.round(206810 * 1.1 / 10.0) * 10);
        check("국민연금 10% 인상 보정", r4.pension, Math.round(245000 * 1.1 / 10.0) * 10);

        System.out.println(fail == 0 ? "\n✅ 공제액 정밀 예측 코어 전 항목 통과" : "\n❌ 실패 " + fail + "건");
        if (fail > 0) System.exit(1);
    }
}
