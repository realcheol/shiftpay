package com.example.shiftpay;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * v1.6.0 ② — 월간 근무 패턴 자동 채우기 코어 (안드로이드 비의존).
 *
 * 달력 한 달치를 다음 두 방식으로 한 번에 채울 근무일 계획을 만든다.
 *
 *  ① 요일 기반(상주조)  — 월~금 중 공휴일·회사 대체휴무를 뺀 날에만 적용
 *  ② 순환 기반(교대조)  — 기준 시작일 + N일 주기 슬롯. 2조 2교대 주야 맞교대
 *                         주5·비2·야5·비2(14일)와 8시간 변형 정5·비2·심5·비2(14일),
 *                         사용자 정의(주/야/정/심/비 문자열) 지원
 *
 * 계획은 '어느 날에 어떤 프리셋을 쓸지'만 정하고, 실제 저장(SharedPreferences /
 * localStorage)은 화면 계층이 한다. 그래서 데스크톱 JVM 단위 테스트로 그대로 검증할 수 있고
 * 안드로이드와 웹이 같은 함수를 1:1 로 옮겨 쓴다.
 *
 * 안전 장치 — 이미 입력해 둔 날(연차·특근·조합설명회 등)을 덮어쓰지 않도록
 * 기본값은 '빈 날만 채우기(skipExisting=true)'이며, 계획 단계에서
 * 적용일수·건너뛴 일수·덮어쓸 일수를 미리 세어 준다.
 */
public final class PatternFillCore {

    private PatternFillCore() {}

    // ── 프리셋 id (플랫폼 중립 이름) ───────────────────────────────────
    //  화면 계층이 자기 프리셋 이름으로 옮겨 쓴다.
    //    설치형: norm→normal / night8→night_normal / night10→night_ot
    //    웹   : norm→norm   / night8→night_8      / night10→night_10
    public static final String NORM = "norm";                 // 정상 8h
    public static final String OT = "ot";                     // 정상 8h + 연장 2h
    public static final String NIGHT8 = "night8";             // 정상 8h + 심야 6.0h
    public static final String NIGHT10 = "night10";           // 정상 8h + 연장 2h + 심야 7.5h
    public static final String HOL8 = "hol8";                 // 휴일특근 8h
    public static final String HOL10 = "hol10";               // 휴일특근 8h + 휴일연장 2h
    public static final String HOLNIGHT8 = "holnight8";       // 휴일특근 8h + 심야 6.0h
    public static final String HOLNIGHT10 = "holnight10";     // 휴일특근 8h + 연장 2h + 심야 3.5h

    /** 프리셋 한글 이름 (미리보기·요약 문구) */
    public static String presetLabel(String preset) {
        if (preset == null) return "휴무";
        switch (preset) {
            case NORM: return "정상 8h";
            case OT: return "주간 8+2h";
            case NIGHT8: return "야간 8h";
            case NIGHT10: return "야간 10h";
            case HOL8: return "휴일특근 8h";
            case HOL10: return "휴일특근 10h";
            case HOLNIGHT8: return "휴일 야간 8h";
            case HOLNIGHT10: return "휴일 야간 10h";
            default: return preset;
        }
    }

    // ── 패턴 정의 ─────────────────────────────────────────────────────
    public static final class Pattern {
        public final String id;
        public final String label;
        public final String desc;
        /** 주기 슬롯 (null = 휴무). null 배열이면 요일 기반 패턴 */
        public final String[] slots;
        /** 기준 시작일이 필요한지 (순환 패턴) */
        public final boolean needsAnchor;
        /** 평일(월~금)에만 채우는 상주 패턴인지 */
        public final boolean weekdayOnly;
        /** 요일 기반 패턴이 실제로 쓰는 프리셋 */
        public final String weekdayPreset;
        /** 사용자 정의 패턴인지 */
        public final boolean custom;

        Pattern(String id, String label, String desc, String[] slots, String weekdayPreset, boolean custom) {
            this.id = id;
            this.label = label;
            this.desc = desc;
            this.slots = slots;
            this.needsAnchor = slots != null;
            this.weekdayOnly = slots == null;
            this.weekdayPreset = weekdayPreset;
            this.custom = custom;
        }
    }

    /** 2조 2교대 주야 맞교대 — 주5(8+2h)·비2 / 야5(10h)·비2 (14일 주기) */
    static final String[] SLOTS_5_2_5_2 = {
            OT, OT, OT, OT, OT, null, null,
            NIGHT10, NIGHT10, NIGHT10, NIGHT10, NIGHT10, null, null
    };
    /** 2조 2교대 주야 맞교대의 8시간(정·심) 변형 — 연장 없이 8h만 뛰는 조 */
    static final String[] SLOTS_5_2_5_2_NORM = {
            NORM, NORM, NORM, NORM, NORM, null, null,
            NIGHT8, NIGHT8, NIGHT8, NIGHT8, NIGHT8, null, null
    };

    public static final Pattern[] PATTERNS = {
            new Pattern("resident_ot", "상주조 기본 · 평일 8+2h",
                    "월~금(공휴일·대체휴무 제외)에 8시간 + 연장 2시간", null, OT, false),
            new Pattern("resident_norm", "상주조 정취 · 평일 8h",
                    "월~금(공휴일·대체휴무 제외)에 정상 8시간", null, NORM, false),
            new Pattern("shift_5_2_5_2", "2조 2교대 · 주야 맞교대 (주5·비2·야5·비2)",
                    "14일 주기 · 주간 8+2h 5일 → 휴무 2일 → 야간 10h 5일 → 휴무 2일",
                    SLOTS_5_2_5_2, null, false),
            new Pattern("shift_5_2_5_2_norm", "2조 2교대 · 주야 맞교대 8h (정5·비2·심5·비2)",
                    "14일 주기 · 주간 8h 5일 → 휴무 2일 → 야간 8h 5일 → 휴무 2일",
                    SLOTS_5_2_5_2_NORM, null, false),
            new Pattern("custom", "사용자 정의 (주/야/정/심/비)",
                    "예: 주주비비야야비비 → 8일 주기. 주=8+2h · 야=야간 10h · 정=8h · 심=야간 8h · 비=휴무",
                    new String[0], null, true),
    };

    public static Pattern pattern(String id) {
        for (Pattern p : PATTERNS) if (p.id.equals(id)) return p;
        return PATTERNS[0];
    }

    // ── 사용자 정의 문자열 → 슬롯 ──────────────────────────────────────
    /**
     * "주주야야비비" 처럼 한 글자씩 이어 붙인 패턴을 슬롯 배열로 바꾼다.
     *  주 = 8+2h · 야 = 야간 10h · 정 = 8h · 야정 = 야간 8h(문자 '심') · 비·휴·-·공백 = 휴무
     * 잘못된 글자가 있거나 근무일이 하나도 없으면 null 을 돌려준다.
     */
    public static String[] parseCustom(String text) {
        if (text == null) return null;
        String s = text.replace("-", "").replace(",", "").replace(" ", "").trim();
        if (s.isEmpty()) return null;
        List<String> out = new ArrayList<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '주': out.add(OT); break;
                case '야': out.add(NIGHT10); break;
                case '정': out.add(NORM); break;
                case '심': out.add(NIGHT8); break;
                case '비': case '휴': case '0': out.add(null); break;
                default: return null;
            }
        }
        boolean anyWork = false;
        for (String v : out) if (v != null) anyWork = true;
        if (!anyWork) return null;
        return out.toArray(new String[0]);
    }

    /** 사용자 정의 문자열이 올바른지 (미리보기 검증용) */
    public static boolean validCustom(String text) {
        return parseCustom(text) != null;
    }

    // ── 계획 ──────────────────────────────────────────────────────────
    public static final class Plan {
        public int year, month, days;
        public String patternId = "";
        /** index 1..days (0번 칸은 쓰지 않는다) */
        public String[] preset = new String[32];
        /** index 1..days — 주말·공휴일 여부 */
        public boolean[] holiday = new boolean[32];
        /** index 1..days — 패턴상 근무일인지 */
        public boolean[] workDay = new boolean[32];
        /** index 1..days — 기존 입력이 있는 날인지 */
        public boolean[] existed = new boolean[32];
        /** index 1..days — 실제로 기록할 날인지 */
        public boolean[] applied = new boolean[32];

        public int fillDays;        // 패턴이 채우려는 근무일 수
        public int keptDays;        // 기존 입력이 있어 건너뛴 날 수
        public int applyDays;       // 실제로 기록할 날 수
        public int overwriteDays;   // 기존 입력을 덮어쓸 날 수
        public int holidayDays;     // 적용 대상 중 휴일특근으로 들어가는 날 수
        public int cycle = 0;
        public int anchorIndex = -1;
        public final Map<String, Integer> byPreset = new LinkedHashMap<>();
        public final List<Integer> applyList = new ArrayList<>();

        public boolean isEmpty() { return applyDays == 0; }

        /** "주간 8+2h 18일 · 휴일특근 10h 4일" 형태의 요약 */
        public String summary() {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Integer> e : byPreset.entrySet()) {
                if (sb.length() > 0) sb.append(" · ");
                sb.append(presetLabel(e.getKey())).append(' ').append(e.getValue()).append("일");
            }
            return sb.toString();
        }
    }

    /**
     * 한 달치 채우기 계획을 만든다.
     *
     * @param year          대상 연도
     * @param month         대상 월 (1~12)
     * @param patternId     {@link #PATTERNS} 의 id
     * @param anchorYmd     순환 패턴의 기준 시작일 "YYYY-MM-DD" (요일 기반 패턴은 무시)
     * @param holidays      그 달 공휴일·회사 대체휴무 "YYYYMMDD" 집합 (null 허용)
     * @param holidayAware  순환 패턴의 주말·공휴일 근무일을 휴일특근 프리셋으로 바꿀지
     * @param skipExisting  true = 기존 입력이 있는 날은 건너뛴다 (기본값)
     * @param hasInput      index 1..days — 그 날에 이미 저장된 근무 입력이 있는지
     * @param customText    사용자 정의 패턴 문자열 (patternId="custom" 일 때만 사용)
     */
    public static Plan plan(int year, int month, String patternId, String anchorYmd,
                            Set<String> holidays, boolean holidayAware, boolean skipExisting,
                            boolean[] hasInput, String customText) {
        Plan p = new Plan();
        p.year = year;
        p.month = month;
        p.patternId = patternId;
        p.days = LocalDate.of(year, month, 1).lengthOfMonth();
        int n = p.days;
        if (p.preset.length < n + 1) {
            p.preset = new String[n + 1];
            p.holiday = new boolean[n + 1];
            p.workDay = new boolean[n + 1];
            p.existed = new boolean[n + 1];
            p.applied = new boolean[n + 1];
        }

        Pattern pat = pattern(patternId);
        String[] slots = pat.slots;
        if (pat.custom) {
            slots = parseCustom(customText);
        }
        if (slots == null) slots = new String[0];

        LocalDate anchor = null;
        if (pat.needsAnchor && anchorYmd != null && !anchorYmd.trim().isEmpty()) {
            try {
                String s = anchorYmd.trim().replace('.', '-').replace('/', '-');
                anchor = LocalDate.parse(s);
            } catch (Exception ignored) {
                anchor = null;
            }
        }
        if (slots.length > 0) {
            p.cycle = slots.length;
            p.anchorIndex = anchor != null ? anchor.getDayOfMonth() : 1;
        }

        for (int d = 1; d <= n; d++) {
            LocalDate date = LocalDate.of(year, month, d);
            int dow = date.getDayOfWeek().getValue();          // 1=월 … 7=일
            boolean isWeekend = dow >= 6;
            boolean isHol = holidays != null && holidays.contains(String.format(java.util.Locale.US, "%04d%02d%02d", year, month, d));
            p.holiday[d] = isWeekend || isHol;
            p.existed[d] = hasInput != null && d < hasInput.length && hasInput[d];

            String preset = null;
            if (pat.weekdayOnly) {
                // 상주조 — 평일 가운데 공휴일·대체휴무가 아닌 날만
                if (!p.holiday[d]) preset = pat.weekdayPreset;
            } else if (slots.length > 0) {
                int idx;
                if (anchor != null) {
                    long diff = ChronoUnit.DAYS.between(anchor, date);
                    idx = (int) (((diff % slots.length) + slots.length) % slots.length);
                } else {
                    // 기준일이 없으면 그 달 1일을 주기의 첫날로 본다.
                    idx = (d - 1) % slots.length;
                }
                String slot = slots[idx];
                // 주말·공휴일에 실제로 근무하는 날만 휴일특근 프리셋으로 바꾼다
                if (slot != null) {
                    preset = (holidayAware && p.holiday[d]) ? holidayVariant(slot) : slot;
                }
            }

            if (preset == null) continue;
            p.workDay[d] = true;
            p.preset[d] = preset;
            p.fillDays++;

            boolean write;
            if (p.existed[d]) {
                if (skipExisting) {
                    p.keptDays++;
                    write = false;
                } else {
                    p.overwriteDays++;
                    write = true;
                }
            } else {
                write = true;
            }
            if (write) {
                p.applied[d] = true;
                p.applyDays++;
                p.applyList.add(d);
                Integer c = p.byPreset.get(preset);
                p.byPreset.put(preset, c == null ? 1 : c + 1);
                if (isHolidayPreset(preset)) p.holidayDays++;
            }
        }
        return p;
    }

    /** 주간 프리셋 → 휴일특근 프리셋 (주말·공휴일 근무일) */
    public static String holidayVariant(String preset) {
        if (preset == null) return null;
        switch (preset) {
            case OT: return HOL10;
            case NORM: return HOL8;
            case NIGHT10: return HOLNIGHT10;
            case NIGHT8: return HOLNIGHT8;
            case HOL8: case HOL10: case HOLNIGHT8: case HOLNIGHT10: return preset;
            default: return preset;
        }
    }

    public static boolean isHolidayPreset(String preset) {
        return HOL8.equals(preset) || HOL10.equals(preset)
                || HOLNIGHT8.equals(preset) || HOLNIGHT10.equals(preset);
    }

    /** 미리보기 문구 — "이번 달 총 22일 적용 (기존 입력 3일 유지)" */
    public static String previewText(Plan p, boolean skipExisting) {
        if (p == null) return "";
        if (p.applyDays == 0) {
            if (p.fillDays == 0) return "이번 달에는 적용할 근무일이 없습니다.";
            return "이미 입력된 " + p.fillDays + "일을 그대로 둡니다. (새로 채울 날 없음)";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("이번 달 총 ").append(p.applyDays).append("일 적용");
        if (skipExisting && p.keptDays > 0) {
            sb.append(" (기존 입력 ").append(p.keptDays).append("일 유지)");
        } else if (!skipExisting && p.overwriteDays > 0) {
            sb.append(" (기존 입력 ").append(p.overwriteDays).append("일 덮어쓰기)");
        }
        String sum = p.summary();
        if (!sum.isEmpty()) sb.append('\n').append(sum);
        if (p.holidayDays > 0) sb.append('\n').append("주말·공휴일 근무일 ").append(p.holidayDays).append("일은 휴일특근(150%)으로 들어갑니다.");
        return sb.toString();
    }
}
