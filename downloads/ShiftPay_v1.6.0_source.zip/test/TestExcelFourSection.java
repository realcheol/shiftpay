import com.example.shiftpay.ExcelBackup;

import android.content.SharedPreferences;

import java.io.*;
import java.lang.reflect.Proxy;
import java.util.*;

/** v1.3.4 엑셀 급여명세서 4단 서식 검증 (데스크톱 JVM). */
public class TestExcelFourSection {

    public static void main(String[] args) throws Exception {
        Map<String, Object> store = new LinkedHashMap<>();
        store.put("setting_base", "13653");
        store.put("setting_ordinary", "14939");
        store.put("user_name", "테스트");
        store.put("2026-10-01-mode", "work");
        store.put("app_version_code", 26);

        SharedPreferences prefs = (SharedPreferences) Proxy.newProxyInstance(
                TestExcelFourSection.class.getClassLoader(),
                new Class[]{SharedPreferences.class},
                (p, m, a) -> {
                    if ("getAll".equals(m.getName())) return new TreeMap<>(store);
                    Class<?> r = m.getReturnType();
                    if (r == boolean.class) return false;
                    if (r == int.class) return 0;
                    if (r == long.class) return 0L;
                    if (r == float.class) return 0f;
                    if (r == String.class) return a != null && a.length > 1 ? a[1] : null;
                    return null;
                });

        List<String[]> daily = new ArrayList<>();
        daily.add(new String[]{"2026-10-01", "목", "정상근무", "8.0", "2.0", "0", "0", "0", ""});
        daily.add(new String[]{"2026-10-17", "토", "근무일", "0", "0", "8.0", "0", "0", "특근"});
        String[] total = {"월간 총 합계", "", "실근무 23일", "152.0", "38.0", "20.0", "2.0", "0", "총근무시간: 224.0h"};

        List<String[]> card = new ArrayList<>();
        card.add(new String[]{"항목", "시간 / 일수", "구성", "비고"});
        card.add(new String[]{"출근 일수", "23일", "실제로 출근한 날", "주차·유급 자동 인정일 제외"});
        card.add(new String[]{"① 기본 인정", "248h", "정취 152 + 유급 64 + 주차 32 + 연차 0", "기본급 인정 시간"});
        card.add(new String[]{"급여 인정", "343h", "기본 인정 + 시간외·특근 + 가급", "실근무 + 유급 인정 + 가급"});
        card.add(new String[]{"출근카드 환산", "357h", "급여 인정 − 특근일 가급 + 휴일가급", "실물 출근카드 합계"});

        List<String[]> pay = new ArrayList<>();
        pay.add(new String[]{"항목", "인정시간 / 일수", "적용 단가 및 산출식", "지급 금액"});
        pay.add(new String[]{"1. 기본급", "248.0h", "248.0h × 13,653원 (정상+유급+주차)", "3,385,944원"});
        pay.add(new String[]{"　└ 상주휴게(가급)", "23일", "근무일수 23일 × 13,653원 (단협 제49조 4항)", "314,019원"});

        List<String[]> summary = new ArrayList<>();
        summary.add(new String[]{"세전 총지급액 (A)", "", "기본급 + 연장 + 특근 + 가급 + 야간 + 고정/휴게수당", "5,262,924원"});
        summary.add(new String[]{"예상 실지급액 (A - B)", "", "통장 실제 입금 예정 금액", "4,424,234원"});

        // 외부 환경 이식성: 고정 경로 대신 JVM 임시 폴더(java.io.tmpdir) 아래에 출력한다
        File outDir = new File(System.getProperty("java.io.tmpdir"), "shiftpay_test");
        outDir.mkdirs();
        File outFile = new File(outDir, "ShiftPay_급여명세서_검증.xlsx");
        try (OutputStream out = new FileOutputStream(outFile)) {
            ExcelBackup.writePayrollReport(out, "2026-10", "성명: 테스트 | 직급: 사원", daily, total, card, pay, summary, prefs);
        }

        String xml = sheetXml(outFile, "xl/worksheets/sheet1.xml");
        String[] must = {
                "【 1. 일자별 상세 근무 현황표 】",
                "【 2. 출근카드 1:1 월간 집계 & 근무 통계 요약 】",
                "【 3. 단체협약 급여 수당별 상세 산출 계산식 】",
                "【 4. 최종 정산 요약 】",
                "출근카드 환산", "343h", "357h", "248h", "상주휴게(가급)", "5,262,924원", "4,424,234원"
        };
        int fail = 0;
        for (String m : must) {
            boolean ok = xml.contains(m.replace("&", "&amp;"));
            System.out.println((ok ? "OK   " : "FAIL ") + m);
            if (!ok) fail++;
        }
        // 섹션 순서 확인
        int i1 = xml.indexOf("【 1."), i2 = xml.indexOf("【 2."), i3 = xml.indexOf("【 3."), i4 = xml.indexOf("【 4.");
        boolean ordered = i1 >= 0 && i1 < i2 && i2 < i3 && i3 < i4;
        System.out.println((ordered ? "OK   " : "FAIL ") + "섹션 1→2→3→4 순서");
        if (!ordered) fail++;

        // 백업/복원 시트(sheet2) 보존 + 복원 파싱
        Map<String, String> restored = ExcelBackup.read(new FileInputStream(outFile));
        boolean restoreOk = "13653".equals(restored.get("setting_base")) && "테스트".equals(restored.get("user_name"))
                && "work".equals(restored.get("2026-10-01-mode"));
        System.out.println((restoreOk ? "OK   " : "FAIL ") + "복원 시트 파싱(setting_base·user_name·근무기록) — " + restored.keySet());
        if (!restoreOk) fail++;

        System.out.println(fail == 0 ? "\n✅ 엑셀 4단 서식·백업 복원 전 항목 통과 (" + outFile.length() + " bytes)"
                : "\n❌ 실패 " + fail + "건");
        if (fail > 0) System.exit(1);
    }

    static String sheetXml(File f, String name) throws Exception {
        try (java.util.zip.ZipFile z = new java.util.zip.ZipFile(f)) {
            java.util.zip.ZipEntry e = z.getEntry(name);
            try (InputStream in = z.getInputStream(e)) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) b.write(buf, 0, n);
                return new String(b.toByteArray(), "UTF-8");
            }
        }
    }
}
