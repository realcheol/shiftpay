package com.example.shiftpay;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 급여명세서 OCR 2차원(좌표) 대조 파서 — 안드로이드 비의존 순수 클래스.
 *
 * 현대스틸파이프 명세서의 상단 요약부는 [지급액계][공제액계][실지급액] 헤더가 한 줄에 있고
 * 금액(5,262,924 / 838,690 / 4,424,234)은 그 아래 줄에 놓인 2행 구조다.
 * ML Kit은 표의 칸을 칸마다 별개의 줄(Line)로 떼어 주는 일이 잦아, 라벨 뒤에 곧바로 숫자를
 * 기대하는 1줄 정규식으로는 세 금액이 모두 0원으로 읽혔다.
 *
 * 그래서 다음 3중 경로로 읽는다.
 *  ① 좌표 탐색: 라벨 칸의 오른쪽(같은 행) 또는 바로 아래(같은 열)에 붙은 금액 토큰
 *  ② 표 행 구조: 라벨 여러 개가 한 칸/한 줄에 뭉친 경우 라벨 순서 = 금액 순서로 매핑
 *  ③ 평문 정규식: 라벨과 금액이 같은 줄에 함께 있는 경우
 *
 * 같은 클래스를 데스크톱 JVM에서 그대로 실행해 실물 명세서 OCR 형태로 단위 검증한다.
 */
public final class PayslipParser {

    private PayslipParser() {}

    /** OCR 토큰(텍스트 + 바운딩박스). line=true 이면 ML Kit Line 단위. */
    public static final class Tok {
        public final String text;
        public final int l, t, r, b;
        public final boolean line;

        public Tok(String text, int l, int t, int r, int b, boolean line) {
            this.text = text == null ? "" : text;
            this.l = l; this.t = t; this.r = r; this.b = b;
            this.line = line;
        }

        public int cx() { return (l + r) / 2; }
        public int cy() { return (t + b) / 2; }
        public int w() { return Math.max(1, r - l); }
        public int h() { return Math.max(1, b - t); }
        public String key() { return norm(text); }
        public String toString() { return text + "(" + l + "," + t + "," + r + "," + b + ")"; }
    }

    /** 파싱 결과 (0 = 미검출) */
    public static final class Result {
        public long totalPay;        // 지급액계
        public long deduction;       // 공제액계
        public long netPay;          // 실지급액
        public long basePay;         // 기본급
        public long otPay;           // 평일연장
        public long holidayPay;      // 휴일근무
        public long holidayOtPay;    // 휴일연장
        public long nightPay;        // 야간근무
        public long positionPay;     // 직책수당
        public long dutyPay;         // 직무수당
        public long retroPay;        // 소급분
        public long baseRate;        // 기본시급
        public long ordinaryRate;    // 통상시급
        public long tenurePay;       // 근속수당
        public long familySelf;      // 가족수당(본인)
        public long familyOther;     // 가족수당(가족)
        public long breakPay;        // 상주휴게수당
        public int year, month;      // 귀속 연월
        public final StringBuilder trace = new StringBuilder();

        public boolean monthDetected() { return year >= 2020 && year <= 2035 && month >= 1 && month <= 12; }
        void note(String s) { if (trace.length() < 600) trace.append(s).append(' '); }
    }

    // ── 라벨 묶음 ──────────────────────────────────────────────
    static final String[] SUM_LABELS   = {"지급액계", "지급총액", "지급액합계", "총지급액", "급여총액", "지급합계", "지급계"};
    static final String[] DED_LABELS   = {"공제액계", "공제총액", "공제액합계", "총공제액", "공제합계", "공제계"};
    static final String[] NET_LABELS   = {"실지급액", "차인지급액", "실수령액", "실지급"};
    static final String[] ALL_SUM      = {"지급액계", "지급총액", "지급액합계", "총지급액", "공제액계", "공제총액", "공제액합계", "총공제액", "실지급액", "차인지급액", "실수령액"};

    // ── 진입점 ────────────────────────────────────────────────
    public static Result parse(List<Tok> tokens, String fullText) {
        Result res = new Result();
        String text = fullText == null ? "" : fullText;

        List<Tok> cells = new ArrayList<>();
        List<Tok> lines = new ArrayList<>();
        if (tokens != null) {
            for (Tok t : tokens) {
                if (t == null || t.text.trim().isEmpty()) continue;
                if (t.line) lines.add(t); else cells.add(t);
            }
        }
        if (cells.isEmpty()) cells.addAll(lines);   // 요소 박스가 없으면 줄 박스로 대체

        // ① 상단 3대 요약 금액
        res.totalPay  = amountNear(cells, text, SUM_LABELS);
        res.deduction = amountNear(cells, text, DED_LABELS);
        res.netPay    = amountNear(cells, text, NET_LABELS);

        if (res.totalPay == 0 || res.deduction == 0 || res.netPay == 0) {
            long[] rows = summaryFromRows(cells, text);
            if (res.totalPay == 0 && rows[0] > 0) res.totalPay = rows[0];
            if (res.deduction == 0 && rows[1] > 0) res.deduction = rows[1];
            if (res.netPay == 0 && rows[2] > 0) res.netPay = rows[2];
        }
        if (res.netPay == 0 && res.totalPay > 0 && res.deduction > 0) {
            res.netPay = res.totalPay - res.deduction;
        }

        // ② 세부 항목
        res.basePay      = item(cells, text, res, "기본급", "기본급", "기본급여");
        res.otPay        = item(cells, text, res, "평일연장", "평일연장", "평일연장수당", "시간외수당");
        res.holidayPay   = item(cells, text, res, "휴일근무", "휴일근무", "휴일근로수당", "휴일특근", "휴일수당");
        res.holidayOtPay = item(cells, text, res, "휴일연장", "휴일연장", "휴일연장수당", "특근연장");
        res.nightPay     = item(cells, text, res, "야간근무", "야간근무", "야간근로", "야간수당", "심야수당");
        res.positionPay  = item(cells, text, res, "직책수당", "직책수당", "직책", "직위수당");
        res.dutyPay      = item(cells, text, res, "직무수당", "직무수당", "직무");
        res.retroPay     = item(cells, text, res, "소급분", "소급분", "소급액", "소급");
        res.tenurePay    = item(cells, text, res, "근속수당", "근속수당", "근속");
        res.familySelf   = item(cells, text, res, "가족(본인)", "가족수당본인", "가족본인", "가족수당(본인)");
        res.familyOther  = item(cells, text, res, "가족(가족)", "가족수당가족", "가족부양", "가족수당(가족)");
        res.breakPay     = item(cells, text, res, "상주휴게수당", "상주휴게수당", "상주휴게");
        res.baseRate     = item(cells, text, res, "기본시급", "기본시급", "기본급시급");
        res.ordinaryRate = item(cells, text, res, "통상시급", "통상시급", "통상임금시급");

        // ③ 귀속 연월
        int[] ymv = detectYearMonth(text, cells);
        res.year = ymv[0];
        res.month = ymv[1];
        res.note("YM=" + res.year + "-" + res.month);

        return res;
    }

    // ── 금액 문자열 파싱 ─────────────────────────────────────
    /** 라벨 비교용 정규화: 공백·괄호·가운뎃점·콜론 제거 */
    static String norm(String s) {
        if (s == null) return "";
        return s.replaceAll("[\\s()\\[\\]{}:,.\u00b7-]", "");
    }

    /**
     * 금액 토큰이면 값(원), 아니면 null.
     *  · 콤마/점 3자리 구분, 원/₩ 기호 허용: "5,262,924" "5.262.924" "5262924원"
     *  · 시간값("24.0", "2.00", "7.5")은 금액이 아니므로 제외 (소수부가 3자리가 아님)
     *  · 연도·시간으로 흔한 4자리 무구분 숫자(2026, 1365)는 금액으로 보지 않는다
     *  · 1,000원 미만·10억 이상은 금액으로 보지 않는다
     */
    public static Long money(String raw) {
        if (raw == null) return null;
        String s = raw.replace("원", "").replace("₩", "").replace("￦", "").replace(" ", "").trim();
        if (s.isEmpty()) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= '0' && c <= '9') || c == ',' || c == '.') sb.append(c);
        }
        String n = sb.toString();
        if (n.isEmpty()) return null;

        boolean hasComma = n.indexOf(',') >= 0;
        boolean hasDot = n.indexOf('.') >= 0;
        if (hasDot) {
            String last = n.substring(n.lastIndexOf('.') + 1);
            boolean dotIsThousand = last.length() == 3;
            if (!dotIsThousand) return null;               // 24.0 / 7.5 / 2.00 같은 시간값
            if (hasComma && n.lastIndexOf(',') > n.lastIndexOf('.')) return null;
            n = n.replace(".", "");
        }
        if (hasComma) {
            // 3자리 그룹이 아닌 콤마는 숫자 구분 오인식이므로 콤마만 제거하고 판단
            n = n.replace(",", "");
        }
        if (n.length() < 4 || n.length() > 9) return null;
        if (n.length() == 4 && !hasComma && !hasDot) return null;   // 2026·1365 같은 연도/시간값 배제
        try {
            long v = Long.parseLong(n);
            return (v >= 1000) ? v : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** 텍스트 안의 모든 금액을 좌→우 순서로 */
    static List<Long> moneyList(String text) {
        List<Long> out = new ArrayList<>();
        if (text == null) return out;
        Matcher m = Pattern.compile("[0-9][0-9,\\.]{2,14}").matcher(text);
        while (m.find()) {
            Long v = money(m.group());
            if (v != null) out.add(v);
        }
        return out;
    }

    /** 텍스트의 마지막 금액 */
    static Long lastMoney(String text) {
        List<Long> v = moneyList(text);
        return v.isEmpty() ? null : v.get(v.size() - 1);
    }

    static boolean containsAny(String key, String[] labels) {
        if (key == null || key.isEmpty()) return false;
        for (String l : labels) if (key.contains(norm(l))) return true;
        return false;
    }

    static int vOverlap(Tok a, Tok b) {
        int top = Math.max(a.t, b.t), bot = Math.min(a.b, b.b);
        return Math.max(0, bot - top);
    }

    /** a(금액)의 가로 폭 중 b(라벨)의 가로 범위와 겹치는 비율 */
    static double hOverlapRatio(Tok label, Tok amount) {
        int left = Math.max(label.l, amount.l), right = Math.min(label.r, amount.r);
        int ov = Math.max(0, right - left);
        return ov / (double) Math.max(1, amount.w());
    }

    // ── ① 라벨 하나의 금액 (직접 → 좌표 → 평문) ─────────────
    static long amountNear(List<Tok> cells, String text, String[] labels) {
        // (a) 한 칸에 라벨과 금액이 함께: "지급액계 5,262,924"
        for (Tok c : cells) {
            String k = c.key();
            if (!containsAny(k, labels)) continue;
            Long v = lastMoney(c.text);
            if (v != null) return v;
        }
        // (b) 좌표: 같은 행 오른쪽 → 바로 아래 같은 열
        long best = 0;
        double bestScore = Double.MAX_VALUE;
        for (Tok L : cells) {
            if (!containsAny(L.key(), labels)) continue;
            // 여러 요약 라벨이 한 칸에 뭉친 칸은 행 구조 경로가 전담한다 (좌표만으로는 어느 라벨의 값인지 가릴 수 없음)
            if (labelOrder(L.text).length >= 2) continue;
            for (Tok A : cells) {
                if (A == L) continue;
                if (moneyList(A.text).size() != 1) continue;   // 여러 숫자가 뭉친 칸은 행 구조 경로로
                Long v = money(A.text);
                if (v == null) continue;

                // 같은 행 오른쪽
                if (vOverlap(L, A) * 2 >= Math.min(L.h(), A.h()) && A.l >= L.r - L.w() / 3) {
                    double score = (A.l - L.r) / (double) Math.max(1, L.h());
                    if (score < bestScore) { bestScore = score; best = v; }
                    continue;
                }
                // 바로 아래 같은 열 (헤더 → 금액 2행 구조)
                // 바로 아래 같은 열 — 두 줄까지만 본다(더 아래 표의 다른 금액을 끌어오지 않도록)
                if (A.t >= L.b - L.h() * 0.35 && A.t <= L.b + L.h() * 2.0
                        && hOverlapRatio(L, A) >= 0.30) {
                    double score = 2.0 + (A.t - L.b) / (double) Math.max(1, L.h());
                    if (score < bestScore) { bestScore = score; best = v; }
                }
            }
        }
        if (best > 0) return best;
        // (c) 평문 같은 줄: 라벨 뒤 첫 금액
        return sameLineAmount(text, labels);
    }

    // ── 세부 항목 ────────────────────────────────────────────
    static long item(List<Tok> cells, String text, Result res, String tag, String... labels) {
        long v = amountNear(cells, text, labels);
        if (v > 0) res.note(tag + "=" + v);
        return v;
    }

    /** 라벨과 금액이 같은 줄에 있는 경우(표 칸이 한 줄로 합쳐진 OCR) */
    static long sameLineAmount(String text, String[] labels) {
        if (text == null) return 0;
        String[] ls = text.split("\n");
        for (String lineRaw : ls) {
            String line = lineRaw;
            for (String lab : labels) {
                int idx = line.indexOf(lab);
                if (idx < 0) continue;
                String tail = line.substring(idx + lab.length());
                // 같은 줄 앞쪽에 다른 요약 라벨이 먼저 있으면 그 라벨의 값이므로 건너뛴다
                Long v = firstMoneyIn(tail);
                if (v != null) return v;
            }
        }
        return 0;
    }

    /** 문자열 앞부분에서 처음 나오는 금액 (최대 60자 이내) */
    static Long firstMoneyIn(String s) {
        if (s == null) return null;
        Matcher m = Pattern.compile("[0-9][0-9,\\.]{2,14}").matcher(s);
        while (m.find()) {
            if (m.start() > 60) return null;
            Long v = money(m.group());
            if (v != null) return v;
        }
        return null;
    }

    // ── ② 표 행 구조 (라벨 순서 = 금액 순서) ─────────────────
    static long[] summaryFromRows(List<Tok> cells, String text) {
        long[] out = new long[3];
        // (a) 평문 줄: 라벨 2개 이상이 한 줄 → 다음 1~3줄 중 숫자 개수가 같은 줄
        if (text != null) {
            String[] ls = text.split("\n");
            for (int i = 0; i < ls.length; i++) {
                int[] order = labelOrder(ls[i]);
                int n = 0;
                for (int o : order) if (o >= 0) n++;
                if (n < 2) continue;
                for (int j = i + 1; j <= Math.min(i + 3, ls.length - 1); j++) {
                    List<Long> vals = moneyList(ls[j]);
                    if (vals.size() == n) {
                        int p = 0;
                        for (int o : order) if (o >= 0) out[o] = vals.get(p++);
                        if (hasAny(out)) return out;
                    }
                    if (vals.size() > n) break;
                }
            }
        }
        // (b-0) 라벨이 각자 다른 칸이지만 같은 행에 있고, 금액들이 한 칸에 뭉친 경우
        {
            List<Tok> headerCells = new ArrayList<>();
            for (Tok c : cells) if (labelOrder(c.text).length == 1) headerCells.add(c);
            for (Tok H0 : headerCells) {
                List<Tok> rowCells = new ArrayList<>();
                List<Integer> seq = new ArrayList<>();
                for (Tok c : headerCells) {
                    if (vOverlap(c, H0) * 2 < Math.min(c.h(), H0.h())) continue;
                    int idx = labelOrder(c.text)[0];
                    if (seq.contains(idx)) continue;
                    seq.add(idx); rowCells.add(c);
                }
                if (seq.size() < 2) continue;
                // seq 를 x 순서로 정렬
                List<int[]> pairs = new ArrayList<>();
                for (int i = 0; i < rowCells.size(); i++) pairs.add(new int[]{rowCells.get(i).cx(), seq.get(i)});
                pairs.sort((x, y) -> Integer.compare(x[0], y[0]));
                List<Integer> ordered = new ArrayList<>();
                for (int[] p : pairs) ordered.add(p[1]);

                int top = Integer.MAX_VALUE, bot = 0, leftMost = Integer.MAX_VALUE, rightMost = 0;
                for (Tok c : rowCells) {
                    top = Math.min(top, c.t); bot = Math.max(bot, c.b);
                    leftMost = Math.min(leftMost, c.l); rightMost = Math.max(rightMost, c.r);
                }
                for (Tok B : cells) {
                    if (B.t < bot - H0.h() * 0.35 || B.t > bot + H0.h() * 3.2) continue;
                    if (B.cx() < leftMost - H0.w() || B.cx() > rightMost + H0.w()) continue;
                    List<Long> mv = moneyList(B.text);
                    if (mv.size() != ordered.size()) continue;
                    for (int k = 0; k < ordered.size(); k++) out[ordered.get(k)] = mv.get(k);
                    if (hasAny(out)) return out;
                }
            }
        }
        // (b) 좌표: 라벨 2개 이상이 한 칸에 뭉친 경우 → 그 칸 아래 밴드의 금액을 x 순서로 매핑
        for (Tok H : cells) {
            int[] order = labelOrder(H.text);
            List<Integer> seq = new ArrayList<>();
            for (int o : order) if (o >= 0) seq.add(o);
            if (seq.size() < 2) continue;

            List<Tok> band = new ArrayList<>();
            for (Tok A : cells) {
                if (A == H) continue;
                if (A.t < H.b - H.h() * 0.35 || A.t > H.b + H.h() * 3.2) continue;
                if (A.cx() < H.l - H.w() * 0.15 || A.cx() > H.r + H.w() * 0.15) continue;
                if (!moneyList(A.text).isEmpty()) band.add(A);
            }
            if (band.isEmpty()) continue;
            band.sort((x, y) -> x.t != y.t ? Integer.compare(x.t, y.t) : Integer.compare(x.l, y.l));

            // 가장 가까운 y 줄에서 금액 개수가 라벨 개수와 같은 줄을 찾는다
            int i = 0;
            while (i < band.size()) {
                List<Tok> row = new ArrayList<>();
                int y = band.get(i).t;
                int j = i;
                while (j < band.size() && Math.abs(band.get(j).t - y) <= band.get(i).h()) { row.add(band.get(j)); j++; }
                if (row.size() == seq.size()) {
                    row.sort((x, y2) -> Integer.compare(x.l, y2.l));
                    for (int k = 0; k < row.size(); k++) {
                        List<Long> mv = moneyList(row.get(k).text);
                        if (!mv.isEmpty()) out[seq.get(k)] = mv.get(mv.size() - 1);
                    }
                    if (hasAny(out)) return out;
                }
                i = Math.max(j, i + 1);
            }
        }
        return out;
    }

    /** 한 줄/칸에 나타난 요약 라벨을 등장 순서대로 (0=지급, 1=공제, 2=실지급, -1=없음) */
    static int[] labelOrder(String line) {
        if (line == null) return new int[0];
        String s = line.replaceAll("\\s+", "");
        List<int[]> hits = new ArrayList<>();
        collect(s, SUM_LABELS, 0, hits);
        collect(s, DED_LABELS, 1, hits);
        collect(s, NET_LABELS, 2, hits);
        if (hits.isEmpty()) return new int[0];
        hits.sort((a, b) -> Integer.compare(a[0], b[0]));
        int[] order = new int[hits.size()];
        for (int i = 0; i < order.length; i++) order[i] = hits.get(i)[1];
        return order;
    }

    static void collect(String s, String[] labels, int idx, List<int[]> hits) {
        for (String l : labels) {
            int p = s.indexOf(l);
            if (p >= 0) { hits.add(new int[]{p, idx}); return; }
        }
    }

    static boolean hasAny(long[] a) {
        for (long v : a) if (v > 0) return true;
        return false;
    }

    // ── ③ 귀속 연월 ──────────────────────────────────────────
    /** 명세서 귀속 연월 자동 감지. 못 찾으면 {0,0} */
    static int[] detectYearMonth(String text, List<Tok> cells) {
        if (text == null) text = "";
        Pattern pYearMonth = Pattern.compile("(20[2-3][0-9])\\s*[년]\\s*(1[0-2]|0?[1-9])\\s*월?");
        Pattern pDash = Pattern.compile("(20[2-3][0-9])\\s*[.\\-/]\\s*(1[0-2]|0?[1-9])(?![0-9])");
        int[] best = new int[]{0, 0};
        int bestScore = -1;

        for (Pattern p : new Pattern[]{pYearMonth, pDash}) {
            Matcher m = p.matcher(text);
            while (m.find()) {
                int y, mo;
                try {
                    y = Integer.parseInt(m.group(1));
                    mo = Integer.parseInt(m.group(2));
                } catch (Exception e) { continue; }
                if (mo < 1 || mo > 12) continue;

                int score = (p == pYearMonth) ? 2 : 1;
                // 주변에 '급여/명세서/귀속/지급/임금' 단어가 있으면 명세서 귀속월일 확률이 높다
                int from = Math.max(0, m.start() - 30), to = Math.min(text.length(), m.end() + 30);
                String around = text.substring(from, to);
                if (around.contains("급여") || around.contains("명세서") || around.contains("귀속")
                        || around.contains("임금") || around.contains("지급")) score += 3;
                if (m.end() < text.length() && text.charAt(m.end() - 1) == '월') score += 1;
                if (score > bestScore) { bestScore = score; best[0] = y; best[1] = mo; }
            }
        }
        return best;
    }
}
