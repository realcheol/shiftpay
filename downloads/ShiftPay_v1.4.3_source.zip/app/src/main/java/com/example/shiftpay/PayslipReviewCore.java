package com.example.shiftpay;

/**
 * v1.4.3 ④ — 급여명세서 OCR 인식값 검토·교정용 순수 계산 (안드로이드 비의존).
 *
 * 명세서 숫자를 OCR이 흘리는 대표 유형은 두 가지다.
 *  ① 가운데 0 탈락 — 506,898 → 56,898 (교대조 실물 명세서 야간수당)
 *  ② 앞자리·일부 자리 누락 — 5,262,924 → 262,924
 * 두 경우 모두 "기대값의 숫자열에서 1~2글자만 빠진 형태"라서, 사내 단협 공식으로 계산한
 * 기대값과 비교하면 원래 금액을 되살릴 수 있다. 여기서는 그 판정과 복원만 담당하고,
 * 화면(원터치 보정 칩)은 MainActivity가 그린다.
 */
public final class PayslipReviewCore {

    private PayslipReviewCore() {}

    /** 사내 단협 공식 야간수당 = 통상시급 × 야간인정시간 × 0.5 (원 단위 반올림) */
    public static long nightPay(long ordinaryRate, double nightHours) {
        if (ordinaryRate <= 0 || nightHours <= 0) return 0;
        return Math.round(ordinaryRate * nightHours * 0.5);
    }

    /** 기대값과 비교해 2% 또는 1,000원을 넘게 벌어지면 이상치로 본다. */
    public static boolean isOutlier(long detected, long expected) {
        if (detected <= 0 || expected <= 0) return false;
        long tolerance = Math.max(1000L, Math.round(expected * 0.02));
        return Math.abs(detected - expected) > tolerance;
    }

    /**
     * 자릿수 누락 복원 — 인식값이 기대값의 숫자열에서 1~2글자만 빠진 형태면 기대값을 돌려준다.
     * 복원할 수 없으면 -1.
     */
    public static long restoreDroppedDigits(long detected, long expected) {
        if (detected <= 0 || expected <= 0 || detected == expected) return -1;
        String d = String.valueOf(detected);
        String e = String.valueOf(expected);
        if (d.length() >= e.length()) return -1;
        // 끝자리(원 단위)는 OCR이 거의 흘리지 않는다 — 엉뚱한 금액을 복원값으로 오인하지 않도록 확인
        if (d.charAt(d.length() - 1) != e.charAt(e.length() - 1)) return -1;
        int di = 0, removed = 0;
        for (int i = 0; i < e.length(); i++) {
            if (di < d.length() && e.charAt(i) == d.charAt(di)) di++;
            else removed++;
        }
        if (di == d.length() && removed >= 1 && removed <= 2) return expected;
        return -1;
    }

    /**
     * 원터치 보정 제안값.
     *  · 자릿수 누락이면 → 복원한 기대값
     *  · allowOutlier 이고 이상치면 → 기대값
     *  · 그 외 → -1 (제안 없음)
     */
    public static long suggest(long detected, long expected, boolean allowOutlier) {
        long restored = restoreDroppedDigits(detected, expected);
        if (restored > 0) return restored;
        if (allowOutlier && isOutlier(detected, expected)) return expected;
        return -1;
    }

    /** 표에 표시할 보정 사유 */
    public static String reason(long detected, long expected) {
        if (restoreDroppedDigits(detected, expected) > 0) return "자릿수 누락 복원";
        if (isOutlier(detected, expected)) return "단협 공식과 오차";
        return "";
    }
}
