import com.example.shiftpay.PayCore;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;

/**
 * 2026년 10월 실물 급여명세서 1원 단위 검증 하네스.
 *
 * 실제 앱에 들어가는 PayCore.java(안드로이드 비의존 순수 계산 코어)를 그대로 컴파일해 실행한다.
 *   · 1근 상주근무, 사원(직책수당 0원 + 직무수당 55,000원)
 *   · 기본시급 13,653원 / 통상시급 14,939원
 *   · 10월 출근카드: 평일 19일 정상 8h + 연장 2h(38h), 특근 10/17 8h / 10/19 10h / 10/24 8h
 *   · 실물 명세서: 기본급 3,385,944 / 평일연장 851,542 / 휴일특근 537,816 / 휴일연장 59,756
 *                  / 상주휴게 22일 300,366 / 고정수당 127,500 / 세전 5,262,924
 */
public class PayCoreOctoberTest {

    // 2026년 10월 공휴일(앱 holidayMap과 동일): 개천절(10/3 토), 개천절 대체(10/5), 한글날(10/9),
    // 회사창립일(10/18 일), 창립기념일 대체휴무(10/19 월 — 단협 제52조 순차 대체)
    static final Set<Integer> HOLIDAYS = new HashSet<>(Arrays.asList(3, 5, 9, 18, 19));

    // 출근카드에 기록된 근무일 (평일 19일 + 특근 3일)
    static final Set<Integer> WEEKDAY_WORK = new HashSet<>(Arrays.asList(
            1, 2, 6, 7, 8, 12, 13, 14, 15, 16, 20, 21, 22, 23, 26, 27, 28, 29, 30));
    static final Map<Integer, double[]> HOLIDAY_WORK = new HashMap<>(); // day -> {hol, holOt}
    static {
        HOLIDAY_WORK.put(17, new double[]{8, 0});
        HOLIDAY_WORK.put(19, new double[]{10, 0});   // 10시간 특근 → 8h(150%) + 2h(200%) 자동 분리
        HOLIDAY_WORK.put(24, new double[]{8, 0});
    }

    static int dow(int day) {
        return LocalDate.of(2026, 10, day).getDayOfWeek().getValue() % 7 + 1; // 1=일 … 7=토
    }

    static final String[] MODE = new String[32];
    static final Double[][] MANUAL = new Double[32][9]; // null = 자동 인정

    static void prepare() {
        for (int d = 1; d <= 31; d++) {
            MODE[d] = "auto";
            for (int i = 0; i < 9; i++) MANUAL[d][i] = null;
        }
        for (int d : WEEKDAY_WORK) {
            MODE[d] = "work";
            MANUAL[d][0] = 8.0;   // 정상 8h
            MANUAL[d][4] = 2.0;   // 평일연장 2h
        }
        for (Map.Entry<Integer, double[]> e : HOLIDAY_WORK.entrySet()) {
            int d = e.getKey();
            MODE[d] = "work";
            MANUAL[d][5] = e.getValue()[0]; // 휴일근로(특근)
            if (e.getValue()[1] > 0) MANUAL[d][6] = e.getValue()[1];
        }
    }

    static class Day implements PayCore.DayData {
        public int daysInMonth() { return 31; }
        public double hours(int day, int idx) {
            boolean manual = MANUAL[day][idx] != null;
            boolean leave = "annual".equals(MODE[day]) || "summer".equals(MODE[day]);
            return PayCore.dayHours(idx, manual, manual ? MANUAL[day][idx] : 0.0,
                    MODE[day], dow(day), HOLIDAYS.contains(day), leave);
        }
        public String mode(int day) { return MODE[day]; }
    }

    static class Cfg implements PayCore.Settings {
        final Map<String, Double> v = new HashMap<>();
        Cfg() {
            v.put("base", 13653.0);
            v.put("ordinary", 14939.0);
            v.put("otRate", 1.5);
            v.put("holidayRate", 1.5);
            v.put("holidayOTRate", 2.0);
            v.put("nightRate", 0.5);
            v.put("tenure", 22500.0);
            v.put("familySelf", 20000.0);
            v.put("familyOther", 30000.0);
            v.put("position", 0.0);     // 사원 → 직책수당 0원
            v.put("duty", 55000.0);     // 직무수당 55,000원 (사원도 유지)
            v.put("summer", 45000.0);
            v.put("other", 0.0);
            v.put("deduction", 948470.0);
        }
        public double get(String k) { return v.containsKey(k) ? v.get(k) : 0.0; }
        public boolean isShiftWorker() { return false; }
        public boolean isSummerMonth() { return false; }
        public boolean isRetroActive() { return false; }
        public double retroAmount() { return 0; }
    }

    /** 하루짜리 DayData로 그날의 시간 집계 (0=휴일근로, 1=휴일연장, 2=유급) */
    static double[] hoursAndPay(int y, int m, int d, String mode, Double holHours) {
        LocalDate date = LocalDate.of(y, m, d);
        final Double[] manual = new Double[9];
        manual[5] = holHours;
        PayCore.DayData one = new PayCore.DayData() {
            public int daysInMonth() { return 1; }
            public double hours(int day, int idx) {
                boolean has = manual[idx] != null;
                return PayCore.dayHours(idx, has, has ? manual[idx] : 0.0, mode,
                        date.getDayOfWeek().getValue() % 7 + 1, HOLIDAYS.contains(d), "annual".equals(mode));
            }
            public String mode(int day) { return mode; }
        };
        double[] t = PayCore.totals(one);
        return new double[]{t[5], t[6], t[1]};
    }

    static double dayTotal(LocalDate date, String mode, Double holHours) {
        int d = date.getDayOfMonth();
        final Double[] manual = new Double[9];
        manual[5] = holHours;
        PayCore.DayData one = new PayCore.DayData() {
            public int daysInMonth() { return 1; }
            public double hours(int day, int idx) {
                boolean has = manual[idx] != null;
                return PayCore.dayHours(idx, has, has ? manual[idx] : 0.0, mode,
                        date.getDayOfWeek().getValue() % 7 + 1, HOLIDAYS.contains(d), "annual".equals(mode));
            }
            public String mode(int day) { return mode; }
        };
        double[] t = PayCore.totals(one);
        double sum = 0;
        for (double v : t) sum += v;
        return sum;
    }

    static int fail = 0;

    // ── 교대조 동료 2026년 10월 교대조 데이터 (실물 출근카드 1000193125 대조) ──
    static final Set<Integer> PEER_PAID = new HashSet<>(Arrays.asList(3, 5, 9, 10, 17, 19, 24, 31));
    static final Set<Integer> PEER_WEEKLY = new HashSet<>(Arrays.asList(4, 11, 18, 25));
    static final Set<Integer> PEER_ANNUAL = new HashSet<>(Arrays.asList(2, 16));
    static final Set<Integer> PEER_WORK = new HashSet<>(Arrays.asList(
            1, 6, 7, 8, 12, 13, 14, 15, 20, 21, 22, 23, 26, 27, 28, 29, 30));  // 28일만 조퇴 4h
    static final Set<Integer> PEER_NIGHT = new HashSet<>(Arrays.asList(5, 6, 7, 8, 9, 19, 20, 21, 22, 23));
    static final Set<Integer> PEER_HOLIDAY_WORK = new HashSet<>(Arrays.asList(9, 19));  // 한글날·창립기념일 대체

    static class PeerDay implements PayCore.DayData {
        final double nightTotal;
        PeerDay(double nightTotal) { this.nightTotal = nightTotal; }
        public int daysInMonth() { return 31; }
        public double hours(int day, int idx) {
            if (PEER_ANNUAL.contains(day) && idx == PayCore.NORMAL) return 8;
            if (PEER_PAID.contains(day) && idx == PayCore.PAID) return 8;
            if (PEER_WEEKLY.contains(day) && idx == PayCore.WEEKLY) return 8;
            if (PEER_WORK.contains(day) && idx == PayCore.NORMAL) return day == 28 ? 4 : 8;
            // 조퇴한 28일은 연장·가급이 없다
            if (PEER_WORK.contains(day) && idx == PayCore.OT) return day == 28 ? 0 : 2;
            if (PEER_WORK.contains(day) && idx == PayCore.GAGEUB) return day == 28 ? 0 : 1;
            if (PEER_HOLIDAY_WORK.contains(day) && idx == PayCore.HOL) return 10;   // 카드에 적힌 그대로 10h
            if (PEER_NIGHT.contains(day) && idx == PayCore.NIGHT) return nightTotal / PEER_NIGHT.size();
            return 0;
        }
        public String mode(int day) {
            if (PEER_ANNUAL.contains(day)) return "annual";
            if (PEER_WORK.contains(day) || PEER_HOLIDAY_WORK.contains(day)) return "work";
            return "auto";
        }
    }

    static void check(String label, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) < 0.5 && Math.round(actual) == Math.round(expected);
        System.out.printf("%-28s 앱 %14s  명세서 %14s  %s%n",
                label, String.format("%,.0f", actual), String.format("%,.0f", expected), ok ? "OK" : "*** MISMATCH ***");
        if (!ok) fail++;
    }

    public static void main(String[] args) {
        prepare();
        Day day = new Day();
        Cfg set = new Cfg();

        double[] t = PayCore.totals(day);
        double[] a = PayCore.amounts(set, day);
        int gageubDays = PayCore.countWorkDays(day);

        System.out.println("=== 2026년 10월 근무 집계 ===");
        System.out.printf("정상 %.0fh / 유급 %.0fh / 주차 %.0fh / 조합 %.0fh / 평일연장 %.0fh / 휴일특근 %.0fh(8h분) / 휴일연장 %.0fh(초과분) / 야간 %.0fh%n",
                t[0], t[1], t[2], t[3], Math.max(0, t[4] - t[3]), t[5], t[6], t[7]);
        System.out.println("기본급 산입시간: " + (t[0] + t[1] + t[2] + t[3]) + "h (명세서 248h)");
        System.out.println("상주휴게 지급일수: " + gageubDays + "일 (명세서 22일)");
        check("기본급 산입시간(h)", t[0] + t[1] + t[2] + t[3], 248);
        check("상주휴게 일수", gageubDays, 22);

        System.out.println("\n=== 실물 명세서 1원 대조 ===");
        check("기본급", a[0], 3385944);
        check("평일연장근로수당", a[1], 851542);
        check("휴일근로수당(특근)", a[2], 537816);
        check("휴일연장수당(가급)", a[3], 59756);
        check("야간 추가수당", a[4], 0);
        check("고정+상주휴게수당", a[5], 427866);
        check("세전 총지급액", a[6], 5262924);
        check("예상 공제액", a[7], 948470);
        check("실수령액", a[8], 4314454);

        System.out.println("\n=== 날짜별 자동 인정 회귀 검증 ===");
        // 토요일·공휴일 연차: 유급 8h 한 번만 (16h 중복 없음)
        check("토요일 연차 합계(h)", dayTotal(LocalDate.of(2026, 10, 17), "annual", null), 8);
        check("공휴일 연차 합계(h)", dayTotal(LocalDate.of(2026, 10, 9), "annual", null), 8);
        // 토요일 특근: 유급 8h 유지 + 휴일근로 8h = 16h (기본급 산입 8h 보존)
        double[] sat = hoursAndPay(2026, 10, 17, "work", 8.0);
        check("토요일 특근 휴일근로(h)", sat[0], 8);
        check("토요일 특근 휴일연장(h)", sat[1], 0);
        check("토요일 특근 유급(h)", sat[2], 8);
        // 공휴일 10h 특근: 휴일근로 8h + 휴일연장 2h 자동 분리 + 유급 8h 유지
        double[] hol = hoursAndPay(2026, 10, 19, "work", 10.0);
        check("공휴일 10h 특근 휴일근로(h)", hol[0], 8);
        check("공휴일 10h 특근 휴일연장(h)", hol[1], 2);
        check("공휴일 10h 특근 유급(h)", hol[2], 8);

        System.out.println("\n=== 직책수당 / 직무수당 분리 확인 ===");
        System.out.println("직책수당 " + String.format("%,.0f", set.get("position")) + "원 + 직무수당 "
                + String.format("%,.0f", set.get("duty")) + "원 (사원 선택 시에도 직무수당 유지)");

        System.out.println("\n=== 10/31 토요일 특근을 앱에 입력한 경우 (명세서는 31일 누락) ===");
        // 사용자 폰의 10월 기록에는 31일(토) 특근 8h가 들어 있고, 회사 명세서에는 빠져 있다(11월 소급 예정).
        // 이때 앱 계산값과 명세서 지급총액의 차이가 192,925원(8h 특근 179,272 + 상주휴게 1일 13,653)으로 떠야 한다.
        MODE[31] = "work";
        MANUAL[31][5] = 8.0;
        double[] a31 = PayCore.amounts(set, day);
        double[] t31 = PayCore.totals(day);
        int g31 = PayCore.countWorkDays(day);
        System.out.printf("휴일근로 %.0fh / 상주휴게 %d일 / 지급총액 %,.0f원 / 실지급액 %,.0f원%n",
                t31[5], g31, a31[6], a31[8]);
        check("31일 포함 지급총액", a31[6], 5455849);
        check("31일 포함 상주휴게 일수", g31, 23);
        check("기본급 산입시간(불변)", t31[0] + t31[1] + t31[2] + t31[3], 248);
        System.out.printf("앱 - 명세서 지급총액 차액: %,.0f원 (대조표에는 명세서-앱 = -192,925원으로 표시)%n", a31[6] - 5262924);
        check("앱-명세서 지급총액 차액", a31[6] - 5262924, 192925);
        check("대조표 표시값(명세서-앱)", 5262924 - a31[6], -192925);
        MODE[31] = "auto";
        MANUAL[31][5] = null;

        System.out.println("\n=== 가급(상주휴게)을 평일 19일에만 직접 입력한 상태 (실기기 10-10 화면) ===");
        // 폰에서는 [주간 10h] 프리셋으로 평일 19일의 가급 1.0h만 저장되어 있고, 특근일(17·19·24·31)의
        // 가급은 저장되어 있지 않다. 이때도 특근일 가급이 누락되지 않아야 한다 (Math.max 안전망).
        for (int d : WEEKDAY_WORK) MANUAL[d][8] = 1.0;
        double[] tManual = PayCore.totals(day);
        double[] aManual = PayCore.amounts(set, day);
        System.out.printf("직접 입력된 가급 합계 %.0fh → 반영된 지급일수 %.0f일 / 상주휴게수당 %,.0f원 / 세전 %,.0f원%n",
                tManual[8], tManual[8], tManual[8] * 13653, aManual[6]);
        check("가급 22일 반영(31일 이전 마감분)", tManual[8], 22);
        check("상주휴게수당(22일)", tManual[8] * 13653, 300366);
        check("세전 지급총액(명세서 일치)", aManual[6], 5262924);
        MANUAL[31][5] = 8.0;
        double[] tManual31 = PayCore.totals(day);
        double[] aManual31 = PayCore.amounts(set, day);
        System.out.printf("31일 특근 포함 → 가급 %.0f일 / 상주휴게수당 %,.0f원 / 세전 %,.0f원%n",
                tManual31[8], tManual31[8] * 13653, aManual31[6]);
        check("가급 23일 반영(특근 4일 포함)", tManual31[8], 23);
        check("상주휴게수당(23일 = 314,019원)", tManual31[8] * 13653, 314019);
        check("세전 지급총액(31일 포함)", aManual31[6], 5455849);
        MANUAL[31][5] = null;
        for (int d : WEEKDAY_WORK) MANUAL[d][8] = null;

        // ── 출근카드 실물 1:1 집계 (v1.3.2 신규) ───────────────────────────────
        System.out.println("\n=== 출근카드 실물 1:1 집계 (10월 카드: 정취152·연장38·가급23·휴일근로32·휴일연장2·유급64·주차32·환산357) ===");
        MODE[31] = "work";   // 사용자 10월 카드에는 31일(토) 특근 8h가 찍혀 있다
        MANUAL[31][5] = 8.0;
        for (int d : WEEKDAY_WORK) MANUAL[d][8] = 1.0;   // 폰처럼 평일 19일에만 가급 1.0h 직접 입력
        double[] card = PayCore.cardBreakdown(day, false);
        System.out.printf("정취 %.0f / 유급 %.0f / 주차 %.0f / 연차 %.0f / 연장 %.0f / 휴일근로 %.0f / 휴일연장 %.0f / 심야 %.0f%n",
                card[PayCore.CB_NORMAL], card[PayCore.CB_PAID], card[PayCore.CB_WEEKLY], card[PayCore.CB_ANNUAL],
                card[PayCore.CB_OT], card[PayCore.CB_HOL], card[PayCore.CB_HOLOT], card[PayCore.CB_NIGHT]);
        System.out.printf("가급 %.0f(평일 %.0f) / 휴일가급 %.1f%n",
                card[PayCore.CB_GAGEUB], card[PayCore.CB_GAGEUB_WEEKDAY], card[PayCore.CB_HOLPREMIUM]);
        check("정취", card[PayCore.CB_NORMAL], 152);
        check("유급", card[PayCore.CB_PAID], 64);
        check("주차", card[PayCore.CB_WEEKLY], 32);
        check("연차", card[PayCore.CB_ANNUAL], 0);
        check("기본급 인정 소계", card[PayCore.CB_BASE], 248);
        check("연장", card[PayCore.CB_OT], 38);
        check("휴일근로", card[PayCore.CB_HOL], 32);
        check("휴일연장", card[PayCore.CB_HOLOT], 2);
        check("가급", card[PayCore.CB_GAGEUB], 23);
        check("휴일가급", card[PayCore.CB_HOLPREMIUM], 18);
        check("실제 근로", card[PayCore.CB_ACTUAL], 224);
        check("급여 인정", card[PayCore.CB_PAY], 343);
        check("출근카드 환산", card[PayCore.CB_CONVERT], 357);
        check("근무일수", card[PayCore.CB_DAYS], 23);

        // 연차 8h를 넣으면 정취에서 빠져 연차 칸으로 가고, 합계(급여 인정)는 그대로여야 한다
        MODE[14] = "annual";
        for (int i = 0; i < 9; i++) MANUAL[14][i] = null;
        double[] cardAnnual = PayCore.cardBreakdown(day, false);
        check("연차일 정취(152-8)", cardAnnual[PayCore.CB_NORMAL], 144);
        check("연차일 연차(8)", cardAnnual[PayCore.CB_ANNUAL], 8);
        check("연차일 기본급 인정(불변 248)", cardAnnual[PayCore.CB_BASE], 248);
        // 연차일은 실근무가 아니므로 그날의 연장 2h와 상주휴게 1일이 빠진다 (기본급은 연차 8h로 유지)
        check("연차일 연장(38-2)", cardAnnual[PayCore.CB_OT], 36);
        check("연차일 가급(23-1)", cardAnnual[PayCore.CB_GAGEUB], 22);
        check("연차일 급여 인정(343-3)", cardAnnual[PayCore.CB_PAY], 340);
        check("연차일 근무일수(23-1)", cardAnnual[PayCore.CB_DAYS], 22);
        MODE[14] = "work";
        MANUAL[14][0] = 8.0;
        MANUAL[14][4] = 2.0;

        // ── 교대조 동료 2026년 10월 교대조 (품질보증팀 · 1공장 야간조 사이클) ───────────
        //  실물 출근카드: 정취132 · 연장32 · 가급16 · 심야35 · 휴일근로20 · 휴일가급12
        //                · 연차16 · 유급64 · 주차32  =  환산 359.00h
        //  실물 명세서: 기본급 3,411,852 / 평일연장 772,416 / 휴일근로 386,208 /
        //              휴일연장 128,736 / 야간 506,898 / 교대수당 200,000 / 세전 5,513,610
        System.out.println("\n=== 교대조 동료 10월 교대조 — 실물 출근카드 1:1 (환산 359h) ===");
        PayCore.DayData peerCard = new PeerDay(35.0);
        double[] pc = PayCore.cardBreakdown(peerCard, true);
        System.out.printf("정취 %.0f / 유급 %.0f / 주차 %.0f / 연차 %.0f / 연장 %.0f / 휴일근로 %.0f / 휴일연장 %.0f / 심야 %.0f%n",
                pc[PayCore.CB_NORMAL], pc[PayCore.CB_PAID], pc[PayCore.CB_WEEKLY], pc[PayCore.CB_ANNUAL],
                pc[PayCore.CB_OT], pc[PayCore.CB_HOL], pc[PayCore.CB_HOLOT], pc[PayCore.CB_NIGHT]);
        System.out.printf("가급 %.0f(평일 %.0f) / 휴일가급 %.1f / 급여인정 %.0f%n",
                pc[PayCore.CB_GAGEUB], pc[PayCore.CB_GAGEUB_WEEKDAY], pc[PayCore.CB_HOLPREMIUM], pc[PayCore.CB_PAY]);
        check("교대조 동료 정취", pc[PayCore.CB_NORMAL], 132);
        check("교대조 동료 유급", pc[PayCore.CB_PAID], 64);
        check("교대조 동료 주차", pc[PayCore.CB_WEEKLY], 32);
        check("교대조 동료 연차", pc[PayCore.CB_ANNUAL], 16);
        check("교대조 동료 기본급 인정 소계", pc[PayCore.CB_BASE], 244);
        check("교대조 동료 연장", pc[PayCore.CB_OT], 32);
        check("교대조 동료 휴일근로(8h분)", pc[PayCore.CB_HOL], 16);
        check("교대조 동료 휴일연장(2h분)", pc[PayCore.CB_HOLOT], 4);
        check("교대조 동료 가급(평일)", pc[PayCore.CB_GAGEUB_WEEKDAY], 16);
        check("교대조 동료 휴일가급", pc[PayCore.CB_HOLPREMIUM], 12);
        check("교대조 동료 심야", pc[PayCore.CB_NIGHT], 35);
        check("교대조 동료 출근카드 환산", pc[PayCore.CB_CONVERT], 359);
        check("교대조 동료 근무일수", pc[PayCore.CB_DAYS], 20);

        System.out.println("\n=== 교대조 동료 10월 교대조 — 실물 명세서 1원 대조 ===");
        // 야간(H) 63.0h = 실제 야간근무일 9일 × 7.0h (종이 카드 4번 열 심야 3.5h는 가산시간 표기)
        PayCore.DayData peerSlip = new PeerDay(35.0);
        int nightDays = PayCore.nightWorkDays(peerSlip);
        double nightH = PayCore.nightPayHours(peerSlip, true);
        System.out.println("야간근무일 " + nightDays + "일 × 7.0h = " + nightH
                + "h (카드 심야 " + pc[PayCore.CB_NIGHT] + "h / 쉬는 날 심야 표기는 제외)");
        check("교대조 야간근무일수", nightDays, 9);
        check("교대조 야간 인정시간(63h)", nightH, 63);
        Cfg peerSet = new Cfg() {
            @Override public boolean isShiftWorker() { return true; }   // 교대근무조: 상주휴게 대신 교대수당 20만원
        };
        peerSet.v.put("base", 13983.0);          // 3,411,852 ÷ 244h
        peerSet.v.put("ordinary", 16092.0);
        peerSet.v.put("familySelf", 0.0);
        peerSet.v.put("familyOther", 30000.0);
        double[] pa = PayCore.amounts(peerSet, peerSlip);
        check("교대조 동료 기본급", pa[0], 3411852);
        check("교대조 동료 평일연장근로수당", pa[1], 772416);
        check("교대조 동료 휴일근로수당", pa[2], 386208);
        check("교대조 동료 휴일연장수당", pa[3], 128736);
        check("교대조 동료 야간근무수당", pa[4], 506898);
        check("교대조 동료 고정수당(교대 200,000 포함)", pa[5], 307500);
        check("교대조 동료 세전 지급총액", pa[6], 5513610);

        // 출근카드만 입력해도(심야 3.5h 표기 그대로) 명세서와 같은 야간수당 506,898원이 나와야 한다
        double[] paCard = PayCore.amounts(peerSet, peerCard);
        check("교대조 동료 카드 입력만으로 야간수당", paCard[4], 506898);
        check("교대조 동료 카드 입력만으로 세전 총액", paCard[6], 5513610);

        // 상주근무자(대타 야간)는 종전대로 입력한 심야시간 그대로 계산한다 (7.5h × 7,470원 = 56,025원)
        PayCore.DayData residentNight = new PeerDay(0.0) {
            @Override public double hours(int day, int idx) {
                if (day == 1 && idx == PayCore.NORMAL) return 8;
                if (day == 1 && idx == PayCore.OT) return 2;
                if (day == 1 && idx == PayCore.NIGHT) return 7.5;
                if (day == 1 && idx == PayCore.GAGEUB) return 1;
                return super.hours(day, idx);
            }
        };
        check("상주 대타 야간 인정시간(7.5h)", PayCore.nightPayHours(residentNight, false), 7.5);
        check("상주 대타 야간수당", PayCore.amounts(new Cfg(), residentNight)[4], 56025);

        System.out.println(fail == 0 ? "\n✅ 10월 명세서 1원 단위 + 출근카드 1:1 전 항목 일치" : "\n❌ 불일치 " + fail + "건");
        if (fail != 0) System.exit(1);
    }
}
