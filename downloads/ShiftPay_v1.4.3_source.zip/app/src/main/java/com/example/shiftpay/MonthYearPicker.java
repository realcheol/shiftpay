package com.example.shiftpay;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * v1.4.3 ① — 캘린더 연·월 빠른 이동 (좌우 스와이프 슬라이드 + 연도 휠/미니 그리드)
 *
 *  · 월 그리드를 좌우로 밀면 전년도/다음 연도로 갤러리처럼 슬라이드 전환된다.
 *  · 연도 숫자(2026년 ▾)를 누르면 그 자리에 연도 미니창이 수직으로 열린다.
 *      - 상단: 2024~2030 빠른 선택 그리드 (한 번 터치로 즉시 이동)
 *      - 하단: 위아래로 굴리는 수직 휠 (가운데 파란 띠에 놓인 연도가 선택 연도)
 *  · 대상 월을 고르면 대화상자를 닫고 달력을 그 달로 이동한다.
 */
class MonthYearPicker {

    private final MainActivity m;
    private final Dialog d;

    private final int todayYear, todayMonth;
    private final int joinYear, joinMonth, retireYear, minYear, maxYear;
    private final int[] pickerYear;

    private LinearLayout gridContainer, yearPanel, quickWrap;
    private TextView yearTv;
    private Button prevYearBtn, nextYearBtn;
    private SwipePager pager;
    private ScrollView wheelScroll;
    private final List<TextView> wheelRows = new ArrayList<>();
    private int itemH;
    private int wheelSel = -1;

    MonthYearPicker(MainActivity activity) {
        this.m = activity;
        this.d = new Dialog(activity);
        Calendar today = Calendar.getInstance();
        todayYear = today.get(Calendar.YEAR);
        todayMonth = today.get(Calendar.MONTH) + 1;

        int jy = 2017, jm = 4;
        String joinStr = m.getJoinDateStr();
        if (!joinStr.isEmpty()) {
            try {
                String[] p = joinStr.replace(".", "-").replace("/", "-").split("-");
                if (p.length == 3) {
                    jy = Integer.parseInt(p[0].trim());
                    jm = Integer.parseInt(p[1].trim());
                }
            } catch (Exception ignored) {}
        }
        joinYear = jy;
        joinMonth = jm;

        // 단협 제28조: 만 60세에 도달하는 해의 12월 31일이 정년
        int ry = todayYear + 9;
        String birthStr = m.prefs != null ? m.prefs.getString("user_birth", "") : "";
        if (!birthStr.isEmpty()) {
            try {
                String[] p = birthStr.replace(".", "-").replace("/", "-").split("-");
                if (p.length == 3) ry = Integer.parseInt(p[0].trim()) + 60;
            } catch (Exception ignored) {}
        }
        retireYear = ry;

        minYear = Math.min(joinYear, todayYear - 10);
        maxYear = Math.max(retireYear, todayYear + 10);
        pickerYear = new int[]{ m.month.get(Calendar.YEAR) };
        itemH = m.dp(42);
    }

    void show() {
        try { d.requestWindowFeature(Window.FEATURE_NO_TITLE); } catch (Exception ignored) {}

        ScrollView sv = new ScrollView(m);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout col = new LinearLayout(m);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(m.dp(18), m.dp(16), m.dp(18), m.dp(18));
        col.setBackground(round(m.colorSurface(), m.colorBorder(), m.dp(1), 22));
        sv.addView(col);

        TextView title = m.textDirect("🗓️ 캘린더 연·월 빠른 이동", 18, true);
        title.setTextColor(m.colorBlue());
        col.addView(title);

        TextView sub = m.textDirect("← → 좌우로 밀면 연도가 넘어갑니다 · 연도 숫자를 누르면 연도 휠이 열립니다", 12, false);
        sub.setTextColor(m.colorSub());
        sub.setPadding(0, m.dp(4), 0, m.dp(10));
        sub.setLineSpacing(m.dp(1), 1.0f);
        col.addView(sub);

        // ── 원터치 프리셋 칩 ──
        HorizontalScrollView hsv = new HorizontalScrollView(m);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout presetRow = new LinearLayout(m);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        presetRow.setPadding(0, 0, 0, m.dp(10));
        addChip(presetRow, "🌱 입사 첫달 (" + joinYear + "." + String.format(Locale.US, "%02d", joinMonth) + ")",
                () -> m.jumpToYearMonth(d, joinYear, joinMonth));
        addChip(presetRow, "🎯 이번 달 (" + todayYear + "." + String.format(Locale.US, "%02d", todayMonth) + ")",
                () -> m.jumpToYearMonth(d, todayYear, todayMonth));
        addChip(presetRow, "⏳ 정년 (" + retireYear + ".12)", () -> m.jumpToYearMonth(d, retireYear, 12));
        addChip(presetRow, "◀ 1년 전", () -> slideTo(pickerYear[0] - 1, -1));
        addChip(presetRow, "▶ 1년 후", () -> slideTo(pickerYear[0] + 1, 1));
        hsv.addView(presetRow);
        col.addView(hsv);

        // ── 월 페이지(연도 바 + 12개월 그리드) — 좌우 스와이프 대상 ──
        pager = new SwipePager(m);
        LinearLayout page = new LinearLayout(m);
        page.setOrientation(LinearLayout.VERTICAL);
        pager.addView(page, new FrameLayout.LayoutParams(-1, -2));

        LinearLayout yearBar = new LinearLayout(m);
        yearBar.setOrientation(LinearLayout.HORIZONTAL);
        yearBar.setGravity(Gravity.CENTER);
        yearBar.setBackground(round(m.isDark() ? Color.rgb(24, 34, 52) : Color.rgb(240, 245, 252), m.colorBorder(), m.dp(1), 14));
        yearBar.setPadding(m.dp(8), m.dp(6), m.dp(8), m.dp(6));

        prevYearBtn = m.button("◀", () -> slideTo(pickerYear[0] - 1, -1));
        prevYearBtn.setTextSize(16);
        prevYearBtn.setPadding(m.dp(14), m.dp(6), m.dp(14), m.dp(6));
        yearBar.addView(prevYearBtn);

        yearTv = m.textDirect(pickerYear[0] + "년 ▾", 20, true);
        yearTv.setTextColor(m.colorInk());
        yearTv.setGravity(Gravity.CENTER);
        yearTv.setPadding(0, m.dp(6), 0, m.dp(6));
        yearTv.setOnClickListener(v -> {
            m.vibrateTick();
            openYearPanel();
        });
        yearBar.addView(yearTv, new LinearLayout.LayoutParams(0, -2, 1f));

        nextYearBtn = m.button("▶", () -> slideTo(pickerYear[0] + 1, 1));
        nextYearBtn.setTextSize(16);
        nextYearBtn.setPadding(m.dp(14), m.dp(6), m.dp(14), m.dp(6));
        yearBar.addView(nextYearBtn);

        page.addView(yearBar, new LinearLayout.LayoutParams(-1, -2));

        gridContainer = new LinearLayout(m);
        gridContainer.setOrientation(LinearLayout.VERTICAL);
        gridContainer.setPadding(0, m.dp(10), 0, m.dp(8));
        page.addView(gridContainer, new LinearLayout.LayoutParams(-1, -2));

        col.addView(pager, new LinearLayout.LayoutParams(-1, -2));

        // ── 연도 미니창 (수직으로 열린다) ──
        yearPanel = buildYearPanel();
        yearPanel.setVisibility(View.GONE);
        LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(-1, -2);
        panelLp.setMargins(0, 0, 0, 0);
        col.addView(yearPanel, panelLp);

        Button closeBtn = m.button("닫기", d::dismiss);
        closeBtn.setTextColor(m.colorSub());
        closeBtn.setTextSize(13);
        closeBtn.setPadding(m.dp(12), m.dp(8), m.dp(12), m.dp(8));
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, -2);
        closeLp.setMargins(0, m.dp(10), 0, 0);
        col.addView(closeBtn, closeLp);

        d.setContentView(sv);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int w = (int) (m.getResources().getDisplayMetrics().widthPixels * 0.93);
            d.getWindow().setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        rebuildGrid();
        d.show();
    }

    // ════════════════ 월 그리드 ════════════════
    private void rebuildGrid() {
        if (gridContainer == null) return;
        gridContainer.removeAllViews();
        yearTv.setText(pickerYear[0] + "년 ▾");
        boolean canPrev = pickerYear[0] > minYear;
        boolean canNext = pickerYear[0] < maxYear;
        prevYearBtn.setEnabled(canPrev);
        prevYearBtn.setAlpha(canPrev ? 1f : 0.35f);
        nextYearBtn.setEnabled(canNext);
        nextYearBtn.setAlpha(canNext ? 1f : 0.35f);

        int currentYear = m.month.get(Calendar.YEAR);
        int currentMonth = m.month.get(Calendar.MONTH) + 1;

        for (int r = 0; r < 3; r++) {
            LinearLayout row = new LinearLayout(m);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, m.dp(3), 0, m.dp(3));
            for (int c = 0; c < 4; c++) {
                final int mm = r * 4 + c + 1;
                boolean isSelected = (pickerYear[0] == currentYear && mm == currentMonth);
                boolean isToday = (pickerYear[0] == todayYear && mm == todayMonth);
                boolean outOfService = (pickerYear[0] < joinYear)
                        || (pickerYear[0] == joinYear && mm < joinMonth)
                        || (pickerYear[0] > retireYear)
                        || (pickerYear[0] == retireYear && mm > 12);

                Button b = new Button(m);
                String label = mm + "월";
                if (isToday) label = "● " + label;
                b.setText(label);
                b.setAllCaps(false);
                b.setTextSize(14);
                b.setTypeface(null, isSelected || isToday ? Typeface.BOLD : Typeface.NORMAL);
                if (isSelected) {
                    b.setTextColor(Color.WHITE);
                    b.setBackground(m.bg(Color.rgb(20, 83, 153)));
                } else if (outOfService) {
                    b.setTextColor(m.isDark() ? Color.rgb(80, 95, 120) : Color.rgb(180, 190, 205));
                    b.setBackground(round(m.isDark() ? Color.rgb(18, 26, 40) : Color.rgb(248, 250, 252),
                            m.isDark() ? Color.rgb(35, 45, 60) : Color.rgb(235, 238, 244), m.dp(1), 10));
                } else if (isToday) {
                    b.setTextColor(m.colorBlue());
                    b.setBackground(round(m.isDark() ? Color.rgb(28, 44, 72) : Color.rgb(232, 242, 255), m.colorBlue(), m.dp(1), 10));
                } else {
                    b.setTextColor(m.colorInk());
                    b.setBackground(round(m.colorSurface(), m.colorBorder(), m.dp(1), 10));
                }
                b.setPadding(0, m.dp(10), 0, m.dp(10));
                final int monthVal = mm;
                b.setOnClickListener(v -> m.jumpToYearMonth(d, pickerYear[0], monthVal));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                lp.setMargins(m.dp(3), 0, m.dp(3), 0);
                row.addView(b, lp);
            }
            gridContainer.addView(row);
        }
    }

    /** 연도 페이지 넘김 — dir +1(다음 연도, 왼쪽으로) / -1(이전 연도) */
    private void slideTo(final int target, final int dir) {
        if (target < minYear || target > maxYear) {
            Toast.makeText(m, minYear + "년 ~ " + maxYear + "년 범위 안에서 선택할 수 있습니다.", Toast.LENGTH_SHORT).show();
            return;
        }
        m.vibrateTick();
        final float w = pagerWidth();
        pager.animate().cancel();
        pager.animate().translationX(-dir * w * 0.55f).alpha(0.05f)
                .setDuration(120).setInterpolator(new AccelerateInterpolator())
                .withEndAction(() -> {
                    pickerYear[0] = target;
                    rebuildGrid();
                    pager.setTranslationX(dir * w * 0.55f);
                    pager.animate().translationX(0f).alpha(1f)
                            .setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
                    yearTv.setScaleX(0.86f);
                    yearTv.setScaleY(0.86f);
                    yearTv.animate().scaleX(1f).scaleY(1f).setDuration(230)
                            .setInterpolator(new DecelerateInterpolator()).start();
                }).start();
    }

    private float pagerWidth() {
        int w = (pager != null) ? pager.getWidth() : 0;
        if (w <= 0) w = (int) (m.getResources().getDisplayMetrics().widthPixels * 0.82f);
        return w;
    }

    // ════════════════ 연도 미니창 ════════════════
    private LinearLayout buildYearPanel() {
        LinearLayout panel = new LinearLayout(m);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(round(m.isDark() ? Color.rgb(20, 30, 48) : Color.rgb(246, 249, 253), m.colorBorder(), m.dp(1), 16));
        panel.setPadding(m.dp(12), m.dp(10), m.dp(12), m.dp(12));

        LinearLayout head = new LinearLayout(m);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = m.textDirect("📅 연도 선택", 15, true);
        t.setTextColor(m.colorBlue());
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = m.textDirect("✕ 닫기", 13, true);
        close.setTextColor(m.colorSub());
        close.setPadding(m.dp(8), m.dp(4), m.dp(4), m.dp(4));
        close.setOnClickListener(v -> {
            m.vibrateTick();
            closeYearPanel();
        });
        head.addView(close);
        panel.addView(head);

        TextView quickLbl = m.textDirect("빠른 선택 (한 번 터치로 바로 이동)", 11, false);
        quickLbl.setTextColor(m.colorSub());
        quickLbl.setPadding(0, m.dp(6), 0, m.dp(4));
        panel.addView(quickLbl);

        quickWrap = new LinearLayout(m);
        quickWrap.setOrientation(LinearLayout.VERTICAL);
        panel.addView(quickWrap, new LinearLayout.LayoutParams(-1, -2));

        TextView wheelLbl = m.textDirect("위아래로 밀어 연도 선택", 11, false);
        wheelLbl.setTextColor(m.colorSub());
        wheelLbl.setPadding(0, m.dp(8), 0, m.dp(4));
        panel.addView(wheelLbl);

        FrameLayout wheelBox = new FrameLayout(m);
        View band = new View(m);
        band.setBackground(round(m.isDark() ? Color.rgb(28, 64, 110) : Color.rgb(226, 239, 255), m.colorBlue(), m.dp(1), 12));
        FrameLayout.LayoutParams bandLp = new FrameLayout.LayoutParams(-1, itemH);
        bandLp.topMargin = itemH * 2;
        wheelBox.addView(band, bandLp);

        wheelScroll = new ScrollView(m);
        wheelScroll.setVerticalScrollBarEnabled(false);
        wheelScroll.setLayoutParams(new FrameLayout.LayoutParams(-1, itemH * 5));
        LinearLayout wheelCol = new LinearLayout(m);
        wheelCol.setOrientation(LinearLayout.VERTICAL);
        wheelScroll.addView(wheelCol);

        View topPad = new View(m);
        wheelCol.addView(topPad, new LinearLayout.LayoutParams(1, itemH * 2));
        wheelRows.clear();
        for (int y = minYear; y <= maxYear; y++) {
            final int yearVal = y;
            TextView row = m.textDirect(y + "년", 16, false);
            row.setGravity(Gravity.CENTER);
            row.setTextColor(m.colorInk());
            row.setAlpha(0.6f);
            row.setOnClickListener(v -> applyYear(yearVal));
            wheelCol.addView(row, new LinearLayout.LayoutParams(-1, itemH));
            wheelRows.add(row);
        }
        View bottomPad = new View(m);
        wheelCol.addView(bottomPad, new LinearLayout.LayoutParams(1, itemH * 2));

        wheelScroll.setOnScrollChangeListener((v, sx, sy, osx, osy) -> {
            int idx = Math.max(0, Math.min(wheelRows.size() - 1, Math.round(sy / (float) itemH)));
            if (idx != wheelSel) setWheelSelection(idx, false);
        });
        final Runnable[] settle = new Runnable[1];
        final int[] lastY = new int[]{-1};
        settle[0] = () -> {
            int sy = wheelScroll.getScrollY();
            if (sy != lastY[0]) {
                lastY[0] = sy;
                wheelScroll.postDelayed(settle[0], 70);
                return;
            }
            int idx = Math.max(0, Math.min(wheelRows.size() - 1, Math.round(sy / (float) itemH)));
            wheelScroll.smoothScrollTo(0, idx * itemH);
            setWheelSelection(idx, false);
        };
        wheelScroll.setOnTouchListener((v, ev) -> {
            int a = ev.getActionMasked();
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                lastY[0] = -1;
                wheelScroll.postDelayed(settle[0], 90);
            }
            return false;
        });
        wheelBox.addView(wheelScroll);
        panel.addView(wheelBox, new LinearLayout.LayoutParams(-1, itemH * 5));

        Button go = m.button("이 연도로 이동", () -> {
            if (wheelSel >= 0 && wheelSel < wheelRows.size()) applyYear(minYear + wheelSel);
        });
        go.setTextColor(Color.WHITE);
        go.setTextSize(14);
        go.setBackground(m.bg(Color.rgb(20, 83, 153)));
        LinearLayout.LayoutParams goLp = new LinearLayout.LayoutParams(-1, -2);
        goLp.setMargins(0, m.dp(10), 0, 0);
        panel.addView(go, goLp);

        return panel;
    }

    private void openYearPanel() {
        buildQuickGrid();
        pager.setVisibility(View.GONE);
        yearPanel.setVisibility(View.VISIBLE);
        yearPanel.setAlpha(0f);
        yearPanel.setTranslationY(-m.dp(14));
        yearPanel.animate().alpha(1f).translationY(0f).setDuration(210)
                .setInterpolator(new DecelerateInterpolator()).start();
        setWheelSelection(Math.max(0, Math.min(wheelRows.size() - 1, pickerYear[0] - minYear)), true);
    }

    private void closeYearPanel() {
        yearPanel.animate().alpha(0f).translationY(-m.dp(10)).setDuration(140)
                .withEndAction(() -> {
                    yearPanel.setVisibility(View.GONE);
                    pager.setVisibility(View.VISIBLE);
                    pager.setAlpha(0f);
                    pager.animate().alpha(1f).setDuration(150).start();
                }).start();
    }

    private void buildQuickGrid() {
        quickWrap.removeAllViews();
        List<Integer> years = new ArrayList<>();
        for (int y = 2024; y <= 2030; y++) {
            if (y >= minYear && y <= maxYear) years.add(y);
        }
        if (years.isEmpty()) {
            for (int y = Math.max(minYear, todayYear - 2); y <= Math.min(maxYear, todayYear + 2); y++) years.add(y);
        }
        LinearLayout row = null;
        for (int i = 0; i < years.size(); i++) {
            if (i % 4 == 0) {
                row = new LinearLayout(m);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(0, m.dp(2), 0, m.dp(2));
                quickWrap.addView(row);
            }
            final int y = years.get(i);
            boolean on = (y == pickerYear[0]);
            Button b = new Button(m);
            b.setText(on ? "● " + y : String.valueOf(y));
            b.setAllCaps(false);
            b.setTextSize(14);
            b.setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
            b.setTextColor(on ? Color.WHITE : m.colorInk());
            b.setBackground(on ? m.bg(Color.rgb(20, 83, 153))
                    : round(m.colorSurface(), m.colorBorder(), m.dp(1), 10));
            b.setPadding(0, m.dp(8), 0, m.dp(8));
            b.setOnClickListener(v -> applyYear(y));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(m.dp(3), 0, m.dp(3), 0);
            row.addView(b, lp);
        }
    }

    private void applyYear(final int y) {
        m.vibrateTick();
        final int dir = (y >= pickerYear[0]) ? 1 : -1;
        pickerYear[0] = y;
        yearPanel.animate().alpha(0f).setDuration(120).withEndAction(() -> {
            yearPanel.setVisibility(View.GONE);
            pager.setVisibility(View.VISIBLE);
            rebuildGrid();
            final float w = pagerWidth();
            pager.setTranslationX(dir * w * 0.5f);
            pager.setAlpha(0f);
            pager.animate().translationX(0f).alpha(1f).setDuration(240)
                    .setInterpolator(new DecelerateInterpolator()).start();
            yearTv.setScaleX(0.86f);
            yearTv.setScaleY(0.86f);
            yearTv.animate().scaleX(1f).scaleY(1f).setDuration(230).start();
        }).start();
    }

    private void setWheelSelection(int idx, boolean scroll) {
        if (wheelRows.isEmpty()) return;
        wheelSel = Math.max(0, Math.min(wheelRows.size() - 1, idx));
        for (int i = 0; i < wheelRows.size(); i++) {
            TextView t = wheelRows.get(i);
            boolean on = (i == wheelSel);
            t.setTextColor(on ? Color.WHITE : m.colorInk());
            t.setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
            t.setTextSize(on ? 20 : 15);
            t.setAlpha(on ? 1f : 0.55f);
        }
        if (scroll) {
            final int y = wheelSel * itemH;
            wheelScroll.post(() -> wheelScroll.scrollTo(0, y));
        }
    }

    // ════════════════ 공용 ════════════════
    private void addChip(LinearLayout parent, String text, Runnable onClick) {
        Button b = m.button(text, onClick);
        b.setTextSize(12);
        b.setTextColor(m.colorBlue());
        b.setBackground(round(m.isDark() ? Color.rgb(26, 40, 65) : Color.rgb(235, 244, 255),
                m.isDark() ? Color.rgb(40, 60, 95) : Color.rgb(205, 225, 250), m.dp(1), 20));
        b.setPadding(m.dp(10), m.dp(5), m.dp(10), m.dp(5));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, m.dp(6), 0);
        parent.addView(b, lp);
    }

    private GradientDrawable round(int fill, int stroke, int strokeW, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(m.dp(radiusDp));
        if (strokeW > 0) g.setStroke(strokeW, stroke);
        return g;
    }

    /** 좌우 스와이프를 감지하는 컨테이너 — 버튼 위에서 밀어도 연도가 넘어간다. */
    private class SwipePager extends FrameLayout {
        private final GestureDetector detector;

        SwipePager(Context c) {
            super(c);
            detector = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }

                @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                    if (e1 == null || e2 == null) return false;
                    float dx = e2.getX() - e1.getX();
                    float dy = e2.getY() - e1.getY();
                    if (Math.abs(dx) > m.dp(34) && Math.abs(dx) > Math.abs(dy) * 1.25f) {
                        if (dx < 0) slideTo(pickerYear[0] + 1, 1);
                        else slideTo(pickerYear[0] - 1, -1);
                        return true;
                    }
                    return false;
                }
            });
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            try { detector.onTouchEvent(ev); } catch (Exception ignored) {}
            return super.dispatchTouchEvent(ev);
        }
    }
}
