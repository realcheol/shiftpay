package com.example.shiftpay;

/**
 * 순수 급여 계산 코어.
 *
 * 안드로이드 프레임워크에 의존하지 않으므로 같은 소스 파일을 데스크톱 JVM에서 그대로 실행해
 * 실물 급여명세서와 1원 단위까지 대조(단위 테스트)할 수 있다.
 * MainActivity의 totals()/countWorkDays()/amounts()가 이 코어를 호출한다.
 *
 * 반영된 3대 핵심 급여 계산식 (단협 제49조·제51조)
 *  ① 휴일특근 8시간 초과분 자동 분리: 8h까지는 휴일근로 150%, 초과분은 휴일연장 200%
 *  ② 상주휴게수당(가급) 지급일수 = 실근무 8시간 이상인 날 (평일 + 주말/공휴일 특근일 포함)
 *  ③ 휴일(토요일·공휴일)에 특근해도 그날의 유급 8시간(기본급 248h 산입분)은 삭감하지 않음
 */
public final class PayCore {

    private PayCore() {}

    // hours(day, idx)의 idx 순서 — MainActivity.keys 순서와 동일
    public static final int NORMAL = 0;   // 정상근무
    public static final int PAID = 1;     // 유급(휴일 유급 인정)
    public static final int WEEKLY = 2;   // 주차(주휴)
    public static final int UNION = 3;    // 조합설명회(정상 인정)
    public static final int OT = 4;       // 평일연장(조합설명회 포함)
    public static final int HOL = 5;      // 휴일근로(특근) 8h 이내
    public static final int HOLOT = 6;    // 휴일연장(8h 초과분)
    public static final int NIGHT = 7;    // 야간근로(심야 할증 인정시간)
    public static final int GAGEUB = 8;   // 가급(상주휴게) 직접 입력

    /** 휴일근로 8시간 기준 (단협 제51조 5항) */
    public static final double HOLIDAY_BASE_HOURS = 8.0;

    /** 한 달치 근무 데이터 — 이번 달(앱)과 다른 달(통계 월 이동) 모두에 쓸 수 있는 최소 인터페이스 */
    public interface MonthData {
        int daysInMonth();
        /** idx: NORMAL..GAGEUB */
        double hours(int day, int idx);
        /** auto / work / annual / summer / half_am / half_pm / none */
        String mode(int day);
        /** 해당 날짜·항목이 직접 입력(저장)되었는지 — 가급 자동 인정 판정에 쓴다 */
        default boolean has(int day, int idx) { return hours(day, idx) > 0; }
    }

    public interface DayData extends MonthData {
    }

    public interface Settings {
        double get(String key);
        boolean isShiftWorker();
        boolean isSummerMonth();
        boolean isRetroActive();
        double retroAmount();
    }

    /**
     * 하루의 인정시간 기본값 (자동 인정 규칙). MainActivity.dayHours()가 이 함수에 위임한다.
     *  - idx=NORMAL(0)  : 연차·하계휴가는 유급 8h 인정
     *  - idx=PAID(1)    : 토요일 8h, 평일 공휴일 8h 자동 인정
     *  - idx=WEEKLY(2)  : 일요일 주차 8h 자동 인정
     *  - ③ 특근(mode="work")해도 토·일·공휴일의 유급/주차 8h는 삭감하지 않는다
     *  - mode="none"(무급)일 때만 모두 0
     *
     * @param hasManual  해당 날짜·항목의 직접 입력값이 있으면 그 값이 우선
     * @param dow        java.util.Calendar 요일 상수 (1=일 … 7=토)
     * @param isHoliday  공휴일(회사 대체휴무 포함) 여부
     * @param isLeaveDay 연차·하계휴가 여부
     */
    public static double dayHours(int idx, boolean hasManual, double manualValue, String mode,
                                  int dow, boolean isHoliday, boolean isLeaveDay) {
        if (hasManual) return manualValue;
        // 연차·하계휴가는 유급 8시간만 인정 (공휴일·주말 자동 인정과 중복되지 않도록 한 번만)
        if (isLeaveDay) return (idx == NORMAL) ? 8 : 0;
        boolean isHolidayDay = (dow == java.util.Calendar.SATURDAY)
                || (dow == java.util.Calendar.SUNDAY) || isHoliday;
        if ("none".equals(mode)) return 0;
        if ("work".equals(mode) && !isHolidayDay) return 0;
        if (idx == PAID && dow == java.util.Calendar.SATURDAY) return 8;                      // 토요일 유급 8h
        if (idx == PAID && dow != java.util.Calendar.SUNDAY && isHoliday) return 8;           // 공휴일 유급 8h
        if (idx == WEEKLY && dow == java.util.Calendar.SUNDAY) return 8;                     // 일요일 주차 8h
        return 0;
    }

    /**
     * 월간 시간 집계. ① 휴일특근 8시간 초과분을 휴일연장으로 자동 분리한다.
     * (예: 10시간 특근 → 휴일근로 8h + 휴일연장 2h)
     */
    public static double[] totals(DayData dd) {
        double[] a = new double[9];
        int n = dd.daysInMonth();
        for (int d = 1; d <= n; d++) {
            double hol = dd.hours(d, HOL);
            double holOt = dd.hours(d, HOLOT);
            if (hol > HOLIDAY_BASE_HOURS) {
                holOt += hol - HOLIDAY_BASE_HOURS;
                hol = HOLIDAY_BASE_HOURS;
            }
            a[NORMAL] += dd.hours(d, NORMAL);
            a[PAID] += dd.hours(d, PAID);
            a[WEEKLY] += dd.hours(d, WEEKLY);
            a[UNION] += dd.hours(d, UNION);
            a[OT] += dd.hours(d, OT);
            a[HOL] += hol;
            a[HOLOT] += holOt;
            a[NIGHT] += dd.hours(d, NIGHT);
            a[GAGEUB] += dd.hours(d, GAGEUB);
        }
        // ② 상주휴게(가급) 지급일수: 직접 입력된 가급이 평일분만 저장되어 있어도(예: 10월 19일),
        //    실근무 8시간 이상인 특근일(17·19·24·31일)이 누락되지 않도록 두 값 중 큰 쪽을 쓴다.
        //    10월 → 23일 = 314,019원 (명세서는 31일 이전 마감분 22일 300,366원)
        a[GAGEUB] = Math.max(a[GAGEUB], countWorkDays(dd));
        return a;
    }

    /**
     * 상주휴게수당(가급) 지급일수 — ② 실근무 8시간 이상인 날(평일 + 특근일)
     * 연차·하계휴가는 실근무가 아니므로 상주휴게 1일 인정에서 제외한다.
     */
    public static int countWorkDays(MonthData dd) {
        int count = 0;
        int n = dd.daysInMonth();
        for (int d = 1; d <= n; d++) {
            String mode = dd.mode(d);
            if ("annual".equals(mode) || "summer".equals(mode)) continue;
            double normal = dd.hours(d, NORMAL);
            double holWork = dd.hours(d, HOL) + dd.hours(d, HOLOT);
            if (normal >= 8.0 || holWork >= 8.0) {
                count++;
            }
        }
        return count;
    }

    /** 고정수당 합계 (근속 + 가족본인 + 가족부양 + 직책 + 직무 + 교대/상주휴게 + 기타 + 하계) */
    public static double fixedAllowance(Settings s, MonthData dd, double[] t) {
        double gageubDays = Math.max(t[GAGEUB], countWorkDays(dd));
        boolean isShift = s.isShiftWorker();
        double breakPay = isShift ? 0 : (gageubDays * s.get("base"));
        double shiftPay = isShift ? 200000 : 0; // 단협 제42조 5호 교대수당 20만원
        return s.get("tenure") + s.get("familySelf") + s.get("familyOther")
                + breakPay + shiftPay
                + s.get("position") + s.get("duty") + s.get("other")
                + (s.isSummerMonth() ? s.get("summer") : 0);
    }

    // ────────────────────────────────────────────────────────────────
    // 현대스틸파이프 출근카드 실물 1:1 집계
    //  ① 기본 인정(정취·유급·주차·연차)  ② 시간외·특근(연장·휴일근로·휴일연장·심야)
    //  ③ 가급 및 환산(가급·휴일가급·환산시간)
    //  · 실제 근로 = 출근해서 일한 시간 (정취 + 연장 + 휴일근로 + 휴일연장)
    //  · 급여 인정 = 기본 인정 + 시간외·특근 + 가급  → 앱 급여 계산의 총 인정시간과 같은 값
    //  · 환산시간 = 급여 인정 − 특근일 가급 + 평일 가급 + 휴일가급(할증) → 실물 출근카드 합계와 같은 값
    // ────────────────────────────────────────────────────────────────
    public static final int CB_NORMAL = 0;          // 정취 (연차일 제외)
    public static final int CB_PAID = 1;            // 유급 (토·평일 공휴일 8h)
    public static final int CB_WEEKLY = 2;          // 주차 (주휴, 일요일 8h)
    public static final int CB_ANNUAL = 3;          // 연차 (연차·하계휴가 8h / 반차 4h)
    public static final int CB_UNION = 4;           // 조합설명회 (정상 인정)
    public static final int CB_OT = 5;              // 연장
    public static final int CB_HOL = 6;             // 휴일근로 (8h 이내)
    public static final int CB_HOLOT = 7;           // 휴일연장 (8h 초과)
    public static final int CB_NIGHT = 8;           // 심야
    public static final int CB_GAGEUB = 9;          // 가급 (상주휴게 지급일수 기준 시간)
    public static final int CB_HOLPREMIUM = 10;     // 휴일가급 (휴일근로 50% + 휴일연장 100%)
    public static final int CB_GAGEUB_WEEKDAY = 11; // 출근카드 '가급' 칸 (평일 실근무 8h 이상인 날)
    public static final int CB_BASE = 12;           // 기본급 인정 소계
    public static final int CB_ACTUAL = 13;         // 실제 근로
    public static final int CB_PAY = 14;            // 급여 인정
    public static final int CB_CONVERT = 15;        // 출근카드 환산시간
    public static final int CB_DAYS = 16;           // 근무일수
    public static final int CB_SIZE = 17;

    /** 출근카드 실물 1:1 집계 (CB_* 순서의 17칸) */
    public static double[] cardBreakdown(MonthData md, boolean shiftWorker) {
        double[] c = new double[CB_SIZE];
        if (md == null) return c;

        double gageubSum = 0;
        for (int d = 1; d <= md.daysInMonth(); d++) {
            String mode = md.mode(d);
            if (mode == null) mode = "auto";
            boolean fullLeave = "annual".equals(mode) || "summer".equals(mode);
            boolean halfLeave = "half_am".equals(mode) || "half_pm".equals(mode);

            double normal = md.hours(d, NORMAL);
            double paid = md.hours(d, PAID);
            double weekly = md.hours(d, WEEKLY);
            double union = md.hours(d, UNION);
            double ot = md.hours(d, OT);
            double hol = md.hours(d, HOL);
            double holOt = md.hours(d, HOLOT);
            if (hol > HOLIDAY_BASE_HOURS) {          // ① 8h 초과분은 휴일연장(200%)
                holOt += hol - HOLIDAY_BASE_HOURS;
                hol = HOLIDAY_BASE_HOURS;
            }
            double night = md.hours(d, NIGHT);
            double holWork = hol + holOt;

            // 가급(상주휴게) — 직접 입력이 있으면 그 값, 없으면 실근무 8h 이상인 날 1시간
            boolean gageubManual = md.has(d, GAGEUB);
            double gageub;
            if (gageubManual) gageub = Math.max(0, md.hours(d, GAGEUB));
            else if (shiftWorker || fullLeave) gageub = 0;
            else gageub = (normal >= 8 || holWork >= 8) ? 1 : 0;
            gageubSum += gageub;
            if (normal >= 8) c[CB_GAGEUB_WEEKDAY] += gageub;

            if (fullLeave) {
                c[CB_ANNUAL] += normal;              // 연차·하계휴가 = 유급 8h (정취에서 빼서 연차 칸으로)
            } else if (halfLeave) {
                c[CB_NORMAL] += normal;              // 4h 근무
                c[CB_ANNUAL] += paid;                // 4h 연차
            } else {
                c[CB_NORMAL] += normal;
                c[CB_PAID] += paid;
            }
            c[CB_WEEKLY] += weekly;
            c[CB_UNION] += union;
            c[CB_OT] += ot;
            c[CB_HOL] += hol;
            c[CB_HOLOT] += holOt;
            c[CB_NIGHT] += night;
            c[CB_HOLPREMIUM] += hol * 0.5 + holOt;
            // 근무일수 = 실제로 출근한 날 (주차·유급 자동 인정일과 연차·하계휴가일은 제외)
            boolean worked = (!fullLeave && normal > 0) || ot > 0 || holWork > 0 || night > 0;
            if (worked) c[CB_DAYS] += 1;
        }
        c[CB_GAGEUB] = Math.max(gageubSum, countWorkDays(md));

        c[CB_BASE] = c[CB_NORMAL] + c[CB_ANNUAL] + c[CB_PAID] + c[CB_WEEKLY] + c[CB_UNION];
        c[CB_ACTUAL] = c[CB_NORMAL] + c[CB_OT] + c[CB_HOL] + c[CB_HOLOT];
        c[CB_PAY] = c[CB_BASE] + c[CB_OT] + c[CB_HOL] + c[CB_HOLOT] + c[CB_GAGEUB];
        c[CB_CONVERT] = c[CB_BASE] + c[CB_OT] + c[CB_HOL] + c[CB_HOLOT]
                + c[CB_GAGEUB_WEEKDAY] + c[CB_HOLPREMIUM];
        return c;
    }

    /** amounts()와 동일한 9칸 결과: 0기본급 1평일연장 2휴일근로 3휴일연장 4야간 5고정/휴게 6세전 7공제 8실수령 */
    public static double[] amounts(Settings s, DayData dd) {
        double[] t = totals(dd);
        double[] a = new double[9];
        a[0] = (t[NORMAL] + t[PAID] + t[WEEKLY] + t[UNION]) * s.get("base");

        double otUnit = Math.round(s.get("ordinary") * s.get("otRate"));
        a[1] = Math.max(0, t[OT] - t[UNION]) * otUnit;

        double holUnit = Math.round(s.get("ordinary") * s.get("holidayRate"));
        a[2] = t[HOL] * holUnit;

        double holOtUnit = Math.round(s.get("ordinary") * s.get("holidayOTRate"));
        a[3] = t[HOLOT] * holOtUnit;

        double nightUnit = Math.round(s.get("ordinary") * s.get("nightRate"));
        a[4] = t[NIGHT] * nightUnit;

        a[5] = fixedAllowance(s, dd, t);

        for (int i = 0; i <= 5; i++) a[6] += a[i];
        if (s.isRetroActive()) {
            a[6] += s.retroAmount();
        }
        a[7] = s.get("deduction");
        a[8] = a[6] - a[7];
        return a;
    }
}
