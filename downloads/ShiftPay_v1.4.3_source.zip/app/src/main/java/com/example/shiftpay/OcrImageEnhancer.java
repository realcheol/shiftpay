package com.example.shiftpay;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.InputStream;

/**
 * v1.4.3 ④-3 — 급여명세서 OCR 전처리 (흑백 명암비 자동 보정)
 *
 * 종이 명세서를 촬영하면 조명 얼룩·손 그림자·접힌 자국 때문에 같은 글자가 화면 위치마다
 * 밝기가 달라져 ML Kit이 숫자를 흘리는 일이 있었다. 사진을 그대로 넘기지 않고
 *  ① 최대 1800px로 축소(메모리·속도 확보)
 *  ② 그레이스케일 변환
 *  ③ 지역 평균(적분 이미지 박스 블러)으로 배경 조명을 추정해 나눗셈 → 얼룩 제거
 *  ④ 남은 명암을 0~255 전 구간으로 스트레치 → 글자/숫자 대비 부스팅
 * 한 흑백 이미지를 만들어 넘긴다. 실패하면 호출부가 원본 사진으로 되돌아간다.
 */
public final class OcrImageEnhancer {

    private static final int MAX_SIDE = 1800;

    private OcrImageEnhancer() {}

    /** URI 사진을 OCR용 흑백 보정 비트맵으로 만든다. 실패하면 null. */
    public static Bitmap enhance(Context ctx, Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in0 = ctx.getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in0, null, bounds);
            if (in0 != null) in0.close();

            int maxSide = Math.max(bounds.outWidth, bounds.outHeight);
            int sample = 1;
            while (maxSide / sample > MAX_SIDE) sample *= 2;

            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inSampleSize = sample;
            opt.inPreferredConfig = Bitmap.Config.RGB_565;
            InputStream in = ctx.getContentResolver().openInputStream(uri);
            Bitmap src = BitmapFactory.decodeStream(in, null, opt);
            if (in != null) in.close();
            if (src == null) return null;

            Bitmap out = flatten(src);
            if (out != src) src.recycle();
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 조명 얼룩 제거 + 대비 스트레치 (테스트에서 직접 호출 가능) */
    public static Bitmap flatten(Bitmap src) {
        int w = src.getWidth();
        int h = src.getHeight();
        if (w <= 0 || h <= 0) return src;
        final int n = w * h;
        int[] px = new int[n];
        src.getPixels(px, 0, w, 0, 0, w, h);

        int[] gray = new int[n];
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
            gray[i] = (r * 77 + g * 151 + b * 28) >> 8;
        }

        // 적분 이미지 (w+1)x(h+1) — 최대 255 × 3.24M ≈ 8.3억이라 int 범위 안
        int iw = w + 1;
        int[] integral = new int[iw * (h + 1)];
        for (int y = 0; y < h; y++) {
            int rowSum = 0;
            int base = (y + 1) * iw;
            int prev = y * iw;
            for (int x = 0; x < w; x++) {
                rowSum += gray[y * w + x];
                integral[base + x + 1] = integral[prev + x + 1] + rowSum;
            }
        }

        int radius = Math.max(12, Math.min(w, h) / 22);
        int[] outPx = new int[n];
        for (int y = 0; y < h; y++) {
            int y0 = Math.max(0, y - radius), y1 = Math.min(h - 1, y + radius);
            int base0 = y0 * iw, base1 = (y1 + 1) * iw;
            for (int x = 0; x < w; x++) {
                int x0 = Math.max(0, x - radius), x1 = Math.min(w - 1, x + radius);
                int sum = integral[base1 + x1 + 1] - integral[base0 + x1 + 1]
                        - integral[base1 + x0] + integral[base0 + x0];
                int count = (x1 - x0 + 1) * (y1 - y0 + 1);
                int mean = sum / Math.max(1, count);
                int g = gray[y * w + x];
                // 배경 조명으로 나눠 얼룩을 없앤다 (종이 210, 글자는 그만큼 어둡게)
                int v = (int) (g * 214.0f / Math.max(40, mean));
                // 남은 명암을 전 구간으로 스트레치
                v = (int) ((v - 55) * 255.0f / 155.0f);
                if (v < 0) v = 0;
                if (v > 255) v = 255;
                outPx[y * w + x] = 0xFF000000 | (v << 16) | (v << 8) | v;
            }
        }

        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(outPx, 0, w, 0, 0, w, h);
        return out;
    }
}
