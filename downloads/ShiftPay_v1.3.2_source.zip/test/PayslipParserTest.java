import com.example.shiftpay.PayslipParser;

import java.util.ArrayList;
import java.util.List;

/**
 * 급여명세서 OCR 파서(PayslipParser) 데스크톱 검증 하네스.
 *
 * 실제 앱에 들어가는 PayslipParser.java(안드로이드 비의존 순수 클래스)를 그대로 컴파일해 실행한다.
 * 좌표는 2026년 10월 실물 명세서 사진(1447×2048)에서 읽은 칸 위치를 옮긴 값이다.
 *
 * 검증하는 OCR 형태 4종 — ML Kit은 표의 칸을 어떤 단위로 묶어 주느냐가 사진마다 달라진다.
 *  A. 칸마다 따로 줄이 되는 경우(현재 폰에서 0원이 잡힌 실제 형태)
 *  B. 헤더 한 줄 + 금액 한 줄 (예전 1줄 정규식이 통하던 형태)
 *  C. 헤더 3칸이 한 칸으로 뭉친 경우
 *  D. 금액 3개가 한 칸으로 뭉친 경우
 */
public class PayslipParserTest {

    static int fail = 0;
    static List<PayslipParser.Tok> toks;

    static void cell(String text, int l, int t, int r, int b) {
        toks.add(new PayslipParser.Tok(text, l, t, r, b, false));
        toks.add(new PayslipParser.Tok(text, l, t, r, b, true));
    }

    static void elem(String text, int l, int t, int r, int b) {
        toks.add(new PayslipParser.Tok(text, l, t, r, b, false));
    }

    static void check(String label, long actual, long expected) {
        boolean ok = (actual == expected);
        System.out.printf("  %-24s 읽은값 %12s  기대값 %12s  %s%n",
                label, String.format("%,d", actual), String.format("%,d", expected), ok ? "OK" : "*** MISMATCH ***");
        if (!ok) fail++;
    }

    /** 명세서 본문(상단 요약 + 지급내역 + 근태 + 기본정보)의 칸 좌표 */
    static void buildSlipCells() {
        toks = new ArrayList<>();
        // 상단 3대 요약 — 헤더 줄과 금액 줄이 2행
        cell("지급액계", 78, 663, 352, 705);
        cell("공제액계", 355, 663, 620, 705);
        cell("실지급액", 622, 663, 900, 705);
        cell("5,262,924", 222, 715, 339, 750);
        cell("838,690", 457, 715, 561, 750);
        cell("4,424,234", 679, 715, 809, 750);

        // 지급내역 표 (항목 | 금액 | 항목 | 금액)
        int y = 783;
        cell("항목", 137, y, 254, 822); cell("금액", 254, y, 463, 822);
        cell("항목", 463, y, 639, 822); cell("금액", 639, y, 842, 822);
        y = 825;
        cell("기본급", 145, y, 250, y + 36);      cell("3,385,944", 313, y, 457, y + 36);
        y = 861;
        cell("근속수당", 145, y, 250, y + 36);     cell("22,500", 330, y, 455, y + 36);
        y = 899;
        cell("가족수당(본인)", 145, y, 250, y + 36); cell("20,000", 330, y, 455, y + 36);
        y = 937;
        cell("가족수당(가족)", 145, y, 250, y + 36); cell("30,000", 330, y, 455, y + 36);
        y = 973;
        cell("상주휴게수당", 145, y, 250, y + 36);  cell("300,366", 313, y, 457, y + 36);
        y = 1011;
        cell("직무수당", 145, y, 250, y + 36);     cell("55,000", 330, y, 455, y + 36);
        y = 1049;
        cell("평일연장", 145, y, 250, y + 36);     cell("851,542", 313, y, 457, y + 36);
        y = 1087;
        cell("휴일근무", 145, y, 250, y + 36);     cell("537,816", 313, y, 457, y + 36);
        y = 1123;
        cell("휴일연장", 145, y, 250, y + 36);     cell("59,756", 313, y, 457, y + 36);

        // 근태상세내역 — 시간(H) 칸. 금액으로 오인하면 안 된다.
        y = 1494;
        cell("정상(H)", 137, y, 248, y + 40);   cell("248.0", 248, y, 391, y + 40);
        cell("평일연장(H)", 508, y, 660, y + 40); cell("38.0", 660, y, 790, y + 40);
        y = 1534;
        cell("유급(H)", 137, y, 248, y + 40);   cell("공상휴직일", 248, y, 391, y + 40);
        cell("휴일근로(H)", 508, y, 660, y + 40); cell("24.0", 660, y, 790, y + 40);
        cell("휴일연장(H)", 790, y, 920, y + 40); cell("2.0", 920, y, 1010, y + 40);
        cell("상주휴게(H)", 1010, y, 1150, y + 40); cell("22.0", 1150, y, 1250, y + 40);

        // 하단 기 본 정 보 — 헤더 아래 값이 오는 또 하나의 2행 구조
        y = 1803;
        cell("기본시급", 326, y, 568, y + 37);
        cell("통상시급", 568, y, 809, y + 37);
        y = 1840;
        cell("13,653", 391, y, 522, y + 39);
        cell("14,939", 639, y, 757, y + 39);
    }

    static String slipText() {
        return "안녕하세요. 조창대님!\n"
             + "조창대님의 2026년10월경 급여 계산 명세서입니다.\n"
             + "지급액계\n공제액계\n실지급액\n5,262,924\n838,690\n4,424,234\n"
             + "지급내역\n기본급\n3,385,944\n근속수당\n22,500\n가족수당(본인)\n20,000\n"
             + "가족수당(가족)\n30,000\n상주휴게수당\n300,366\n직무수당\n55,000\n"
             + "평일연장\n851,542\n휴일근무\n537,816\n휴일연장\n59,756\n"
             + "공제내역\n소득세\n206,810\n지방소득세\n20,680\n건강보험\n237,840\n"
             + "정상(H)\n248.0\n평일연장(H)\n38.0\n휴일근로(H)\n24.0\n휴일연장(H)\n2.0\n상주휴게(H)\n22.0\n"
             + "기본시급\n통상시급\n13,653\n14,939\n";
    }

    static void expectAll(PayslipParser.Result r, String tag) {
        System.out.println("\n[" + tag + "]");
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
        check("기본급", r.basePay, 3385944);
        check("평일연장", r.otPay, 851542);
        check("휴일근무", r.holidayPay, 537816);
        check("휴일연장", r.holidayOtPay, 59756);
        check("상주휴게수당", r.breakPay, 300366);
        check("직무수당", r.dutyPay, 55000);
        check("근속수당", r.tenurePay, 22500);
        check("기본시급", r.baseRate, 13653);
        check("통상시급", r.ordinaryRate, 14939);
        check("귀속 연월", r.year * 100 + r.month, 202610);
    }

    /** A. 칸마다 따로 줄 — 현재 폰에서 0원이 잡히던 실제 형태 */
    static void scenarioA() {
        buildSlipCells();
        PayslipParser.Result r = PayslipParser.parse(toks, slipText());
        expectAll(r, "A. 칸마다 따로 줄 (실기기 형태)");
    }

    /** B. 헤더 한 줄 + 금액 한 줄 */
    static void scenarioB() {
        toks = new ArrayList<>();
        elem("지급액계 공제액계 실지급액", 78, 663, 900, 705);
        elem("5,262,924 838,690 4,424,234", 78, 715, 900, 750);
        elem("기본급 3,385,944", 145, 825, 457, 861);
        elem("평일연장 851,542", 145, 1049, 457, 1085);
        elem("휴일근무 537,816", 145, 1087, 457, 1123);
        elem("휴일연장 59,756", 145, 1123, 457, 1159);
        elem("근속수당 22,500", 145, 861, 457, 897);
        elem("상주휴게수당 300,366", 145, 973, 457, 1009);
        elem("직무수당 55,000", 145, 1011, 457, 1047);
        elem("기본시급 13,653", 326, 1803, 568, 1840);
        elem("통상시급 14,939", 568, 1803, 809, 1840);
        String text = "조창대님의 2026년10월경 급여 계산 명세서입니다.\n"
                + "지급액계 공제액계 실지급액\n5,262,924 838,690 4,424,234\n"
                + "기본급 3,385,944\n근속수당 22,500\n평일연장 851,542\n휴일근무 537,816\n휴일연장 59,756\n"
                + "상주휴게수당 300,366\n직무수당 55,000\n기본시급 13,653\n통상시급 14,939\n";
        expectAll(PayslipParser.parse(toks, text), "B. 헤더 한 줄 + 금액 한 줄");
    }

    /** C. 헤더 3칸이 한 칸으로 뭉치고 금액은 칸마다 */
    static void scenarioC() {
        buildSlipCells();
        toks.removeIf(t -> !t.line && (t.text.equals("지급액계") || t.text.equals("공제액계")
                || t.text.equals("실지급액")));
        elem("지급액계 공제액계 실지급액", 78, 663, 900, 705);
        PayslipParser.Result r = PayslipParser.parse(toks, slipText());
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
    }

    /** D. 금액 3개가 한 칸으로 뭉치고 헤더는 칸마다 */
    static void scenarioD() {
        buildSlipCells();
        toks.removeIf(t -> !t.line && (t.text.equals("5,262,924") || t.text.equals("838,690")
                || t.text.equals("4,424,234")));
        elem("5,262,924 838,690 4,424,234", 78, 715, 900, 750);
        PayslipParser.Result r = PayslipParser.parse(toks, slipText());
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
    }

    /** 금액/시간 구분 단위 검증 */
    static void moneyUnit() {
        System.out.println("\n[금액 문자열 판정]");
        String[] yes = {"5,262,924", "838,690", "13,653", "300,366원", "5.262.924", "22,500"};
        String[] no = {"24.0", "2.0", "7.5", "22.0", "248.0", "2026", "10", "1.00", "0.00"};
        for (String s : yes) {
            Long v = PayslipParser.money(s);
            boolean ok = v != null;
            System.out.printf("  %-14s → %s %s%n", s, ok ? String.format("%,d원", v) : "금액 아님", ok ? "OK" : "*** MISMATCH ***");
            if (!ok) fail++;
        }
        for (String s : no) {
            Long v = PayslipParser.money(s);
            boolean ok = (v == null);
            System.out.printf("  %-14s → %s %s%n", s, ok ? "금액 아님" : String.format("%,d원", v), ok ? "OK" : "*** MISMATCH ***");
            if (!ok) fail++;
        }
    }

    public static void main(String[] args) {
        scenarioA();
        scenarioB();
        scenarioC();
        scenarioD();
        moneyUnit();
        System.out.println(fail == 0 ? "\n✅ 명세서 OCR 파서 4가지 형태 전수 통과" : "\n❌ 불일치 " + fail + "건");
        if (fail != 0) System.exit(1);
    }
}
