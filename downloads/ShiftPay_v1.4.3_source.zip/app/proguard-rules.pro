# ShiftPay v1.3.4 R8 keep rules
# 리플렉션·매니페스트·컴포넌트 발견(registrar)에 쓰이는 라이브러리는 이름을 그대로 보존한다.

-dontoptimize
-dontpreverify
-verbose

-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,Exceptions,SourceFile,LineNumberTable

# 앱 진입점 (매니페스트가 이름으로 참조)
-keep class com.example.shiftpay.MainActivity { *; }
-keepclassmembers class * extends android.app.Activity { public void *(android.view.View); }

# 안드로이드 컴포넌트 / ContentProvider / Service
-keep public class * extends android.content.ContentProvider { *; }
-keep public class * extends android.app.Service { *; }
-keep public class * extends android.content.BroadcastReceiver { *; }

# FileProvider (androidx) — authorities 로 매니페스트에서 참조
-keep class androidx.core.content.FileProvider { *; }

# ML Kit / Firebase / Play Services — 내부 리플렉션·registrar 발견 사용
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.** { *; }
-keep class com.google.firebase.** { *; }
-keep class com.google.android.odml.** { *; }
-keep class com.google.android.libraries.** { *; }
-keep class com.google_mlkit_** { *; }

# Apache POI / XMLBeans (엑셀 XML 처리, 리플렉션 사용)
-keep class org.apache.poi.** { *; }
-keep class org.apache.xmlbeans.** { *; }
-keep class org.openxmlformats.** { *; }
-keep class org.w3c.dom.** { *; }

# JSON / Gson (리플렉션 직렬화)
-keep class com.google.gson.** { *; }
-keep class org.json.** { *; }

# Kotlin / coroutines 런타임 메타데이터
-keep class kotlin.** { *; }
-keep class kotlinx.** { *; }
-keepclassmembers class **$WhenMappings { <fields>; }
-keepclassmembers enum * { *; }

# JNI 로 호출되는 네이티브 연동 클래스 이름 보존
-keepclasseswithmembernames class * { native <methods>; }

-dontwarn **
-dontnote **
