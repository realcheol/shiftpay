import com.example.shiftpay.PayCore;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;

/**
 * 2026년 10월 실물 급여명세서 1원 단위 검증 하네스.
 *
 * 실제 앱에 들어가는 PayCore.java(안드로이드 비의존 순수 계산 코어)를 그대로 컴파일해 실행한다.
 *   · 1근 상주근무, 사원(직책수당 0원 + 직무수당 55,000원)
 *   · 기본시급 13,653원 / 통상시급 14,939원
 *   · 10월 출근카드: 평일 19일 정상 8h + 연장 2h(38h), 특근 10/17 8h / 10/19 10h / 10/24 8h
 *   · 실물 명세서: 기본급 3,385,944 / 평일연장 851,542 / 휴일특근 537,816 / 휴일연장 59,756
 *                  / 상주휴게 22일 300,366 / 고정수당 127,500 / 세전 5,262,924
 */
public class PayCoreOctoberTest {

    // 2026년 10월 공휴일(앱 holidayMap과 동일): 개천절(10/3 토), 개천절 대체(10/5), 한글날(10/9),
    // 회사창립일(10/18 일), 창립기념일 대체휴무(10/19 월 — 단협 제52조 순차 대체)
    static final Set<Integer> HOLIDAYS = new HashSet<>(Arrays.asList(3, 5, 9, 18, 19));

    // 출근카드에 기록된 근무일 (평일 19일 + 특근 3일)
    static final Set<Integer> WEEKDAY_WORK = new HashSet<>(Arrays.asList(
            1, 2, 6, 7, 8, 12, 13, 14, 15, 16, 20, 21, 22, 23, 26, 27, 28, 29, 30));
    static final Map<Integer, double[]> HOLIDAY_WORK = new HashMap<>(); // day -> {hol, holOt}
    static {
        HOLIDAY_WORK.put(17, new double[]{8, 0});
        HOLIDAY_WORK.put(19, new double[]{10, 0});   // 10시간 특근 → 8h(150%) + 2h(200%) 자동 분리
        HOLIDAY_WORK.put(24, new double[]{8, 0});
    }

    static int dow(int day) {
        return LocalDate.of(2026, 10, day).getDayOfWeek().getValue() % 7 + 1; // 1=일 … 7=토
    }

    static final String[] MODE = new String[32];
    static final Double[][] MANUAL = new Double[32][9]; // null = 자동 인정

    static void prepare() {
        for (int d = 1; d <= 31; d++) {
            MODE[d] = "auto";
            for (int i = 0; i < 9; i++) MANUAL[d][i] = null;
        }
        for (int d : WEEKDAY_WORK) {
            MODE[d] = "work";
            MANUAL[d][0] = 8.0;   // 정상 8h
            MANUAL[d][4] = 2.0;   // 평일연장 2h
        }
        for (Map.Entry<Integer, double[]> e : HOLIDAY_WORK.entrySet()) {
            int d = e.getKey();
            MODE[d] = "work";
            MANUAL[d][5] = e.getValue()[0]; // 휴일근로(특근)
            if (e.getValue()[1] > 0) MANUAL[d][6] = e.getValue()[1];
        }
    }

    static class Day implements PayCore.DayData {
        public int daysInMonth() { return 31; }
        public double hours(int day, int idx) {
            boolean manual = MANUAL[day][idx] != null;
            boolean leave = "annual".equals(MODE[day]) || "summer".equals(MODE[day]);
            return PayCore.dayHours(idx, manual, manual ? MANUAL[day][idx] : 0.0,
                    MODE[day], dow(day), HOLIDAYS.contains(day), leave);
        }
        public String mode(int day) { return MODE[day]; }
    }

    static class Cfg implements PayCore.Settings {
        final Map<String, Double> v = new HashMap<>();
        Cfg() {
            v.put("base", 13653.0);
            v.put("ordinary", 14939.0);
            v.put("otRate", 1.5);
            v.put("holidayRate", 1.5);
            v.put("holidayOTRate", 2.0);
            v.put("nightRate", 0.5);
            v.put("tenure", 22500.0);
            v.put("familySelf", 20000.0);
            v.put("familyOther", 30000.0);
            v.put("position", 0.0);     // 사원 → 직책수당 0원
            v.put("duty", 55000.0);     // 직무수당 55,000원 (사원도 유지)
            v.put("summer", 45000.0);
            v.put("other", 0.0);
            v.put("deduction", 948470.0);
        }
        public double get(String k) { return v.containsKey(k) ? v.get(k) : 0.0; }
        public boolean isShiftWorker() { return false; }
        public boolean isSummerMonth() { return false; }
        public boolean isRetroActive() { return false; }
        public double retroAmount() { return 0; }
    }

    static int fail = 0;

    static void check(String label, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) < 0.5 && Math.round(actual) == Math.round(expected);
        System.out.printf("%-28s 앱 %14s  명세서 %14s  %s%n",
                label, String.format("%,.0f", actual), String.format("%,.0f", expected), ok ? "OK" : "*** MISMATCH ***");
        if (!ok) fail++;
    }

    public static void main(String[] args) {
        prepare();
        Day day = new Day();
        Cfg set = new Cfg();

        double[] t = PayCore.totals(day);
        double[] a = PayCore.amounts(set, day);
        int gageubDays = PayCore.countWorkDays(day);

        System.out.println("=== 2026년 10월 근무 집계 ===");
        System.out.printf("정상 %.0fh / 유급 %.0fh / 주차 %.0fh / 조합 %.0fh / 평일연장 %.0fh / 휴일특근 %.0fh(8h분) / 휴일연장 %.0fh(초과분) / 야간 %.0fh%n",
                t[0], t[1], t[2], t[3], Math.max(0, t[4] - t[3]), t[5], t[6], t[7]);
        System.out.println("기본급 산입시간: " + (t[0] + t[1] + t[2] + t[3]) + "h (명세서 248h)");
        System.out.println("상주휴게 지급일수: " + gageubDays + "일 (명세서 22일)");
        check("기본급 산입시간(h)", t[0] + t[1] + t[2] + t[3], 248);
        check("상주휴게 일수", gageubDays, 22);

        System.out.println("\n=== 실물 명세서 1원 대조 ===");
        check("기본급", a[0], 3385944);
        check("평일연장근로수당", a[1], 851542);
        check("휴일근로수당(특근)", a[2], 537816);
        check("휴일연장수당(가급)", a[3], 59756);
        check("야간 추가수당", a[4], 0);
        check("고정+상주휴게수당", a[5], 427866);
        check("세전 총지급액", a[6], 5262924);
        check("예상 공제액", a[7], 948470);
        check("실수령액", a[8], 4314454);

        System.out.println("\n=== 직책수당 / 직무수당 분리 확인 ===");
        System.out.println("직책수당 " + String.format("%,.0f", set.get("position")) + "원 + 직무수당 "
                + String.format("%,.0f", set.get("duty")) + "원 (사원 선택 시에도 직무수당 유지)");

        System.out.println(fail == 0 ? "\n✅ 10월 명세서 1원 단위 전 항목 일치" : "\n❌ 불일치 " + fail + "건");
        if (fail != 0) System.exit(1);
    }
}
