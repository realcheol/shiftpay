import com.example.shiftpay.HolidayCore;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * v1.3.6 ⑧ — 단협 제52조 대체휴무 배정 영구 회귀 방지 테스트.
 *
 * 2027년 설날 2/6(토)~2/11(목) 6일 연속 휴일(2/9 정부 대체공휴일 + 2/10·2/11 회사 대체휴무)이
 * 앞으로의 코드 수정에서도 절대 깨지지 않는지, 2028년 달력까지 함께 검증한다.
 */
public class HolidaySubstituteTest {
    static int fail = 0;

    static void check(String name, String got, String want) {
        boolean ok = (got == null ? want == null : got.equals(want));
        if (!ok) fail++;
        System.out.printf("%-42s 값 %-22s 기대 %-22s %s%n", name, got, want, ok ? "OK" : "FAIL");
    }

    static void checkHoliday(Map<String, String> map, String iso, String want) {
        check(iso + " (" + dow(iso) + ")", map.get(iso), want);
    }

    static String dow(String iso) {
        return LocalDate.of(Integer.parseInt(iso.substring(0, 4)),
                Integer.parseInt(iso.substring(4, 6)),
                Integer.parseInt(iso.substring(6, 8))).getDayOfWeek().toString();
    }

    /** 2027년 공휴일 데이터 (MainActivity.injectOfficialHolidays(2027)와 동일) */
    static Map<String, String> y2027() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("20270101", "신정");
        m.put("20270206", "설날 연휴");
        m.put("20270207", "설날");
        m.put("20270208", "설날 연휴");
        m.put("20270209", "설날 대체공휴일");
        m.put("20270301", "삼일절");
        m.put("20270419", "노조창립일");
        m.put("20270501", "노동절");
        m.put("20270505", "어린이날");
        m.put("20270513", "석가탄신일");
        m.put("20270606", "현충일");
        m.put("20270717", "제헌절");
        m.put("20270719", "제헌절 대체공휴일");
        m.put("20270815", "광복절");
        m.put("20270816", "광복절 대체공휴일");
        m.put("20270914", "추석 연휴");
        m.put("20270915", "추석");
        m.put("20270916", "추석 연휴");
        m.put("20271003", "개천절");
        m.put("20271004", "개천절 대체공휴일");
        m.put("20271009", "한글날");
        m.put("20271011", "한글날 대체공휴일");
        m.put("20271018", "회사창립일");
        m.put("20271225", "성탄절");
        m.put("20271227", "성탄절 대체공휴일");
        return m;
    }

    /** 2028년 공휴일 데이터 (MainActivity.injectOfficialHolidays(2028)와 동일) */
    static Map<String, String> y2028() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("20280101", "신정");
        m.put("20280126", "설날 연휴");
        m.put("20280127", "설날");
        m.put("20280128", "설날 연휴");
        m.put("20280301", "삼일절");
        m.put("20280412", "제23대 국회의원선거");
        m.put("20280419", "노조창립일");
        m.put("20280501", "노동절");
        m.put("20280502", "석가탄신일");
        m.put("20280505", "어린이날");
        m.put("20280606", "현충일");
        m.put("20280717", "제헌절");
        m.put("20280815", "광복절");
        m.put("20281002", "추석 연휴");
        m.put("20281003", "추석·개천절");
        m.put("20281004", "추석 연휴");
        m.put("20281005", "추석·개천절 대체공휴일");
        m.put("20281009", "한글날");
        m.put("20281018", "회사창립일");
        m.put("20281225", "성탄절");
        return m;
    }

    public static void main(String[] args) {
        System.out.println("[1. 2027년 — 설날 6일 연속 휴일]");
        Map<String, String> m27 = y2027();
        HolidayCore.applyCompanySubstituteHolidays(m27, 2027);
        checkHoliday(m27, "20270206", "설날 연휴");
        checkHoliday(m27, "20270207", "설날");
        checkHoliday(m27, "20270208", "설날 연휴");
        checkHoliday(m27, "20270209", "설날 대체공휴일");
        checkHoliday(m27, "20270210", "설날 대체휴무");
        checkHoliday(m27, "20270211", "설날 대체휴무");
        checkHoliday(m27, "20270212", null);
        // 6일 연속 휴일인지 (2/6 ~ 2/11)
        int streak = 0;
        for (int d = 6; d <= 11; d++) {
            if (m27.containsKey(String.format("202702%02d", d))) streak++;
        }
        check("설날 연속 휴일 일수", String.valueOf(streak), "6");
        // 주말과 겹치지 않은 공휴일에는 대체휴무가 붙지 않는다
        checkHoliday(m27, "20271018", "회사창립일");
        checkHoliday(m27, "20271019", null);
        checkHoliday(m27, "20270915", "추석");
        checkHoliday(m27, "20270917", null);

        System.out.println("\n[2. 2028년 — 토요일 신정·겹친 추석·개천절]");
        Map<String, String> m28 = y2028();
        HolidayCore.applyCompanySubstituteHolidays(m28, 2028);
        checkHoliday(m28, "20280101", "신정");
        checkHoliday(m28, "20280103", "신정 대체휴무");
        checkHoliday(m28, "20281003", "추석·개천절");
        checkHoliday(m28, "20281006", "개천절 대체휴무");
        checkHoliday(m28, "20281018", "회사창립일");

        System.out.println("\n[3. 2025·2026년 확정 달력은 종전 방식 유지]");
        Map<String, String> m26 = new LinkedHashMap<>();
        m26.put("20260419", "노조창립일");           // 일요일
        m26.put("20261018", "회사창립일");           // 일요일
        HolidayCore.applyCompanySubstituteHolidays(m26, 2026);
        checkHoliday(m26, "20260420", "노조창립일 대체휴무");
        checkHoliday(m26, "20261019", "회사창립일 대체휴무");
        // 재실행해도 중복 배정되지 않는다 (멱등)
        HolidayCore.applyCompanySubstituteHolidays(m26, 2026);
        int dup = 0;
        for (String v : m26.values()) if (v.endsWith("대체휴무")) dup++;
        check("2026 대체휴무 건수(멱등)", String.valueOf(dup), "2");

        System.out.println(fail == 0 ? "\n✅ 단협 대체휴무 2027~2028 전 항목 통과" : "\n❌ 실패 " + fail + "건");
        if (fail > 0) System.exit(1);
    }
}
