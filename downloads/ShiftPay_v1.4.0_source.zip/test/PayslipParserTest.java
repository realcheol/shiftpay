import com.example.shiftpay.PayslipParser;

import java.util.ArrayList;
import java.util.List;

/**
 * 급여명세서 OCR 파서(PayslipParser) 데스크톱 검증 하네스.
 *
 * 실제 앱에 들어가는 PayslipParser.java(안드로이드 비의존 순수 클래스)를 그대로 컴파일해 실행한다.
 * 좌표는 2026년 10월 실물 명세서 사진(1447×2048)에서 읽은 칸 위치를 옮긴 값이다.
 *
 * 검증하는 OCR 형태 4종 — ML Kit은 표의 칸을 어떤 단위로 묶어 주느냐가 사진마다 달라진다.
 *  A. 칸마다 따로 줄이 되는 경우(현재 폰에서 0원이 잡힌 실제 형태)
 *  B. 헤더 한 줄 + 금액 한 줄 (예전 1줄 정규식이 통하던 형태)
 *  C. 헤더 3칸이 한 칸으로 뭉친 경우
 *  D. 금액 3개가 한 칸으로 뭉친 경우
 */
public class PayslipParserTest {

    static int fail = 0;
    static List<PayslipParser.Tok> toks;

    static void cell(String text, int l, int t, int r, int b) {
        toks.add(new PayslipParser.Tok(text, l, t, r, b, false));
        toks.add(new PayslipParser.Tok(text, l, t, r, b, true));
    }

    static void elem(String text, int l, int t, int r, int b) {
        toks.add(new PayslipParser.Tok(text, l, t, r, b, false));
    }

    static void check(String label, long actual, long expected) {
        boolean ok = (actual == expected);
        System.out.printf("  %-24s 읽은값 %12s  기대값 %12s  %s%n",
                label, String.format("%,d", actual), String.format("%,d", expected), ok ? "OK" : "*** MISMATCH ***");
        if (!ok) fail++;
    }

    /** 명세서 본문(상단 요약 + 지급내역 + 근태 + 기본정보)의 칸 좌표 */
    static void buildSlipCells() {
        toks = new ArrayList<>();
        // 상단 3대 요약 — 헤더 줄과 금액 줄이 2행
        cell("지급액계", 78, 663, 352, 705);
        cell("공제액계", 355, 663, 620, 705);
        cell("실지급액", 622, 663, 900, 705);
        cell("5,262,924", 222, 715, 339, 750);
        cell("838,690", 457, 715, 561, 750);
        cell("4,424,234", 679, 715, 809, 750);

        // 지급내역 표 (항목 | 금액 | 항목 | 금액)
        int y = 783;
        cell("항목", 137, y, 254, 822); cell("금액", 254, y, 463, 822);
        cell("항목", 463, y, 639, 822); cell("금액", 639, y, 842, 822);
        y = 825;
        cell("기본급", 145, y, 250, y + 36);      cell("3,385,944", 313, y, 457, y + 36);
        y = 861;
        cell("근속수당", 145, y, 250, y + 36);     cell("22,500", 330, y, 455, y + 36);
        y = 899;
        cell("가족수당(본인)", 145, y, 250, y + 36); cell("20,000", 330, y, 455, y + 36);
        y = 937;
        cell("가족수당(가족)", 145, y, 250, y + 36); cell("30,000", 330, y, 455, y + 36);
        y = 973;
        cell("상주휴게수당", 145, y, 250, y + 36);  cell("300,366", 313, y, 457, y + 36);
        y = 1011;
        cell("직무수당", 145, y, 250, y + 36);     cell("55,000", 330, y, 455, y + 36);
        y = 1049;
        cell("평일연장", 145, y, 250, y + 36);     cell("851,542", 313, y, 457, y + 36);
        y = 1087;
        cell("휴일근무", 145, y, 250, y + 36);     cell("537,816", 313, y, 457, y + 36);
        y = 1123;
        cell("휴일연장", 145, y, 250, y + 36);     cell("59,756", 313, y, 457, y + 36);

        // 공제내역 표 (오른쪽 칸) — 합계 838,690원. 3중 안전망의 세부 공제항목 합계 검증용
        y = 825;
        cell("소득세", 470, y, 600, y + 36);       cell("206,810", 690, y, 830, y + 36);
        y = 861;
        cell("지방소득세", 470, y, 600, y + 36);   cell("20,680", 700, y, 830, y + 36);
        y = 899;
        cell("건강보험", 470, y, 600, y + 36);     cell("274,300", 680, y, 830, y + 36);
        y = 937;
        cell("국민연금", 470, y, 600, y + 36);     cell("245,000", 680, y, 830, y + 36);
        y = 973;
        cell("고용보험", 470, y, 600, y + 36);     cell("45,900", 690, y, 830, y + 36);
        y = 1011;
        cell("노조회비", 470, y, 600, y + 36);     cell("46,000", 690, y, 830, y + 36);

        // 근태상세내역 — 시간(H) 칸. 금액으로 오인하면 안 된다.
        y = 1494;
        cell("정상(H)", 137, y, 248, y + 40);   cell("248.0", 248, y, 391, y + 40);
        cell("평일연장(H)", 508, y, 660, y + 40); cell("38.0", 660, y, 790, y + 40);
        y = 1534;
        cell("유급(H)", 137, y, 248, y + 40);   cell("공상휴직일", 248, y, 391, y + 40);
        cell("휴일근로(H)", 508, y, 660, y + 40); cell("24.0", 660, y, 790, y + 40);
        cell("휴일연장(H)", 790, y, 920, y + 40); cell("2.0", 920, y, 1010, y + 40);
        cell("상주휴게(H)", 1010, y, 1150, y + 40); cell("22.0", 1150, y, 1250, y + 40);

        // 하단 기 본 정 보 — 헤더 아래 값이 오는 또 하나의 2행 구조
        y = 1803;
        cell("기본시급", 326, y, 568, y + 37);
        cell("통상시급", 568, y, 809, y + 37);
        y = 1840;
        cell("13,653", 391, y, 522, y + 39);
        cell("14,939", 639, y, 757, y + 39);
    }

    static String slipText() {
        return "안녕하세요. 테스트 사용자!\n"
             + "테스트 사용자의 2026년10월경 급여 계산 명세서입니다.\n"
             + "지급액계\n공제액계\n실지급액\n5,262,924\n838,690\n4,424,234\n"
             + "지급내역\n기본급\n3,385,944\n근속수당\n22,500\n가족수당(본인)\n20,000\n"
             + "가족수당(가족)\n30,000\n상주휴게수당\n300,366\n직무수당\n55,000\n"
             + "평일연장\n851,542\n휴일근무\n537,816\n휴일연장\n59,756\n"
             + "공제내역\n소득세 206,810\n지방소득세 20,680\n건강보험 274,300\n"
             + "국민연금 245,000\n고용보험 45,900\n노조회비 46,000\n"
             + "정상(H)\n248.0\n평일연장(H)\n38.0\n휴일근로(H)\n24.0\n휴일연장(H)\n2.0\n상주휴게(H)\n22.0\n"
             + "기본시급\n통상시급\n13,653\n14,939\n";
    }

    static void expectAll(PayslipParser.Result r, String tag) {
        System.out.println("\n[" + tag + "]");
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
        check("기본급", r.basePay, 3385944);
        check("평일연장", r.otPay, 851542);
        check("휴일근무", r.holidayPay, 537816);
        check("휴일연장", r.holidayOtPay, 59756);
        check("상주휴게수당", r.breakPay, 300366);
        check("직무수당", r.dutyPay, 55000);
        check("근속수당", r.tenurePay, 22500);
        check("기본시급", r.baseRate, 13653);
        check("통상시급", r.ordinaryRate, 14939);
        check("귀속 연월", r.year * 100 + r.month, 202610);
    }

    /** A. 칸마다 따로 줄 — 현재 폰에서 0원이 잡히던 실제 형태 */
    static void scenarioA() {
        buildSlipCells();
        PayslipParser.Result r = PayslipParser.parse(toks, slipText());
        expectAll(r, "A. 칸마다 따로 줄 (실기기 형태)");
    }

    /** B. 헤더 한 줄 + 금액 한 줄 */
    static void scenarioB() {
        toks = new ArrayList<>();
        elem("지급액계 공제액계 실지급액", 78, 663, 900, 705);
        elem("5,262,924 838,690 4,424,234", 78, 715, 900, 750);
        elem("기본급 3,385,944", 145, 825, 457, 861);
        elem("평일연장 851,542", 145, 1049, 457, 1085);
        elem("휴일근무 537,816", 145, 1087, 457, 1123);
        elem("휴일연장 59,756", 145, 1123, 457, 1159);
        elem("근속수당 22,500", 145, 861, 457, 897);
        elem("상주휴게수당 300,366", 145, 973, 457, 1009);
        elem("직무수당 55,000", 145, 1011, 457, 1047);
        elem("기본시급 13,653", 326, 1803, 568, 1840);
        elem("통상시급 14,939", 568, 1803, 809, 1840);
        String text = "테스트 사용자의 2026년10월경 급여 계산 명세서입니다.\n"
                + "지급액계 공제액계 실지급액\n5,262,924 838,690 4,424,234\n"
                + "기본급 3,385,944\n근속수당 22,500\n평일연장 851,542\n휴일근무 537,816\n휴일연장 59,756\n"
                + "상주휴게수당 300,366\n직무수당 55,000\n기본시급 13,653\n통상시급 14,939\n";
        expectAll(PayslipParser.parse(toks, text), "B. 헤더 한 줄 + 금액 한 줄");
    }

    /** C. 헤더 3칸이 한 칸으로 뭉치고 금액은 칸마다 */
    static void scenarioC() {
        buildSlipCells();
        toks.removeIf(t -> !t.line && (t.text.equals("지급액계") || t.text.equals("공제액계")
                || t.text.equals("실지급액")));
        elem("지급액계 공제액계 실지급액", 78, 663, 900, 705);
        PayslipParser.Result r = PayslipParser.parse(toks, slipText());
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
    }

    /** D. 금액 3개가 한 칸으로 뭉치고 헤더는 칸마다 */
    static void scenarioD() {
        buildSlipCells();
        toks.removeIf(t -> !t.line && (t.text.equals("5,262,924") || t.text.equals("838,690")
                || t.text.equals("4,424,234")));
        elem("5,262,924 838,690 4,424,234", 78, 715, 900, 750);
        PayslipParser.Result r = PayslipParser.parse(toks, slipText());
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
    }

    /** E. 상단 요약 헤더·금액을 아예 못 잡는 형태 → 세부 항목 합계로 3대 금액 복원 (3중 안전망 ③) */
    static void scenarioE() {
        buildSlipCells();
        // 상단 3대 요약 6칸을 통째로 지운다 (헤더 바운딩박스 매칭 실패 재현)
        toks.removeIf(t -> !t.line && (t.text.equals("지급액계") || t.text.equals("공제액계")
                || t.text.equals("실지급액") || t.text.equals("5,262,924")
                || t.text.equals("838,690") || t.text.equals("4,424,234")));
        String text = slipText().replace("지급액계\n공제액계\n실지급액\n5,262,924\n838,690\n4,424,234\n", "");
        PayslipParser.Result r = PayslipParser.parse(toks, text);
        System.out.println("\n[E. 상단 요약 미검출 → 세부 항목 합계 복원]");
        System.out.println("  지급총액 = 기본급+평일연장+휴일근무+휴일연장+상주휴게+직무+근속+가족(본인/가족)");
        System.out.println("  공제총액 = 소득세+지방소득세+건강보험+국민연금+고용보험+노조회비");
        check("지급액계(합계 복원)", r.totalPay, 5262924);
        check("공제액계(합계 복원)", r.deduction, 838690);
        check("실지급액(차액 복원)", r.netPay, 4424234);
        check("합계 복원 플래그", r.totalFromSum ? 1 : 0, 1);
        check("공제 합계 복원 플래그", r.deductionFromSum ? 1 : 0, 1);
    }

    /** F. 토큰 없이 평문만, 라벨 3줄 + 금액 3줄 → 다중행 정규식 (3중 안전망 ②) */
    static void scenarioF() {
        toks = new ArrayList<>();
        String text = "테스트 사용자의 2026년10월경 급여 계산 명세서입니다.\n"
                + "지급액계\n공제액계\n실지급액\n5,262,924\n838,690\n4,424,234\n근태내역\n";
        PayslipParser.Result r = PayslipParser.parse(toks, text);
        System.out.println("\n[F. 평문 다중행 정규식]");
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
    }

    /** G. OCR이 라벨 글자를 띄어 읽은 형태 ("지급 액 계 5,262,924") */
    static void scenarioG() {
        toks = new ArrayList<>();
        String text = "2026년10월 급여명세서\n지급 액 계 5,262,924\n공제 액 계 838,690\n실 지급 액 4,424,234\n";
        PayslipParser.Result r = PayslipParser.parse(toks, text);
        System.out.println("\n[G. 라벨 띄어 읽기]");
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
    }

    /** H. 헤더와 금액 사이 세로 간격이 넓어진 촬영 각도 (좌표 허용폭 완화) */
    static void scenarioH() {
        toks = new ArrayList<>();
        cell("지급액계", 78, 663, 352, 705);
        cell("5,262,924", 222, 810, 339, 850);      // 헤더 아래 약 2.5행 (기존 2.0행 한도 초과)
        cell("공제액계", 355, 663, 620, 705);
        cell("838,690", 457, 810, 561, 850);
        cell("실지급액", 622, 663, 900, 705);
        cell("4,424,234", 679, 810, 809, 850);
        PayslipParser.Result r = PayslipParser.parse(toks, "2026년10월 급여명세서\n");
        System.out.println("\n[H. 헤더-금액 세로 간격 확대]");
        check("지급액계", r.totalPay, 5262924);
        check("공제액계", r.deduction, 838690);
        check("실지급액", r.netPay, 4424234);
    }

    /** 금액/시간 구분 단위 검증 */
    static void moneyUnit() {
        System.out.println("\n[금액 문자열 판정]");
        String[] yes = {"5,262,924", "838,690", "13,653", "300,366원", "5.262.924", "22,500"};
        String[] no = {"24.0", "2.0", "7.5", "22.0", "248.0", "2026", "10", "1.00", "0.00"};
        for (String s : yes) {
            Long v = PayslipParser.money(s);
            boolean ok = v != null;
            System.out.printf("  %-14s → %s %s%n", s, ok ? String.format("%,d원", v) : "금액 아님", ok ? "OK" : "*** MISMATCH ***");
            if (!ok) fail++;
        }
        for (String s : no) {
            Long v = PayslipParser.money(s);
            boolean ok = (v == null);
            System.out.printf("  %-14s → %s %s%n", s, ok ? "금액 아님" : String.format("%,d원", v), ok ? "OK" : "*** MISMATCH ***");
            if (!ok) fail++;
        }
    }

    /**
     * I. 야간근무수당 가운데 0 탈락 — 506,898원이 56,898원으로 읽힌 실기기 결함 복원.
     *    (교대조 명세서: 통상시급 16,092 × 야간(H) 63.0h × 0.5 = 506,898원)
     */
    static void scenarioI() {
        buildShiftSlip();
        PayslipParser.Result r = PayslipParser.parse(toks, shiftSlipText());
        System.out.println("\n[I. 야간수당 가운데 0 탈락 → 기대값 복원]");
        System.out.println("  " + r.trace);
        check("야간근무수당(복원)", r.nightPay, 506898);
        check("통상시급", r.ordinaryRate, 16092);
        check("기본급", r.basePay, 3411852);

        // (a) 근태 '야간(H) 63.0' 자체를 못 읽어도, 통상시급 단가로 0을 되살린다
        buildShiftSlip();
        toks.removeIf(t -> !t.line && (t.text.equals("야간(H)") || t.text.equals("63.0")));
        PayslipParser.Result r2 = PayslipParser.parse(toks,
                shiftSlipText().replace("야간(H)\n63.0\n", ""));
        System.out.println("[I-a. 야간(H) 시간 미검출 → 단가로 0 복원]  " + r2.trace);
        check("야간근무수당(단가 복원)", r2.nightPay, 506898);

        // (b) 정상적으로 읽힌 금액은 건드리지 않는다
        buildShiftSlip();
        toks.removeIf(t -> !t.line && t.text.equals("56,898"));
        elem("506,898", 320, 1149, 455, 1185);
        PayslipParser.Result r3 = PayslipParser.parse(toks,
                shiftSlipText().replace("56,898", "506,898"));
        System.out.println("[I-b. 정상 금액 보존]");
        check("야간근무수당(정상값 유지)", r3.nightPay, 506898);

        // (c) v1.3.5: 통상시급·야간시간이 모두 없으면 고정 금액(506,898)에 기대지 않는다.
        //     근거 없이 금액을 바꾸는 것보다 원본을 그대로 두는 편이 안전하다.
        buildShiftSlip();
        toks.removeIf(t -> !t.line && (t.text.equals("통상시급") || t.text.equals("16,092")
                || t.text.equals("야간(H)") || t.text.equals("63.0")));
        PayslipParser.Result r4 = PayslipParser.parse(toks,
                shiftSlipText().replace("통상시급\n16,092\n", "").replace("야간(H)\n63.0\n", ""));
        System.out.println("[I-c. 단가·시간 모두 미검출 → 추측하지 않고 원본 유지]  " + r4.trace);
        check("야간근무수당(원본 유지)", r4.nightPay, 56898);

        // (d) 506,898의 0 탈락 형태가 아닌 금액은 건드리지 않는다
        buildShiftSlip();
        toks.removeIf(t -> !t.line && (t.text.equals("통상시급") || t.text.equals("16,092")
                || t.text.equals("야간(H)") || t.text.equals("63.0") || t.text.equals("56,898")));
        elem("123,456", 320, 1149, 455, 1185);
        PayslipParser.Result r5 = PayslipParser.parse(toks,
                shiftSlipText().replace("통상시급\n16,092\n", "").replace("야간(H)\n63.0\n", "")
                        .replace("56,898", "123,456"));
        System.out.println("[I-d. 무관한 금액은 그대로]");
        check("야간근무수당(무관 금액 유지)", r5.nightPay, 123456);
    }

    /** 교대조(교대근무) 명세서 칸 — 야간근무가 56,898로 잘못 읽힌 상태 */
    static void buildShiftSlip() {
        toks = new ArrayList<>();
        cell("지급액계", 78, 663, 352, 705);
        cell("공제액계", 355, 663, 620, 705);
        cell("실지급액", 622, 663, 900, 705);
        cell("5,513,610", 222, 715, 339, 750);
        cell("106,951", 457, 715, 561, 750);
        cell("5,406,659", 679, 715, 809, 750);
        cell("기본급", 145, 825, 250, 861);        cell("3,411,852", 313, 825, 457, 861);
        cell("근속수당", 145, 861, 250, 897);      cell("22,500", 330, 861, 455, 897);
        cell("가족수당(가족)", 145, 899, 250, 935); cell("30,000", 330, 899, 455, 935);
        cell("직무수당", 145, 937, 250, 973);      cell("55,000", 330, 937, 455, 973);
        cell("교대수당", 145, 975, 250, 1011);     cell("200,000", 313, 975, 457, 1011);
        cell("평일연장", 145, 1035, 250, 1071);    cell("772,416", 313, 1035, 457, 1071);
        cell("휴일근무", 145, 1073, 250, 1109);    cell("386,208", 313, 1073, 457, 1109);
        cell("휴일연장", 145, 1111, 250, 1147);    cell("128,736", 313, 1111, 457, 1147);
        cell("야간근무", 145, 1149, 250, 1185);    cell("56,898", 320, 1149, 455, 1185);
        cell("야간(H)", 508, 1534, 660, 1574);     cell("63.0", 660, 1534, 790, 1574);
        cell("기본시급", 326, 1803, 568, 1840);
        cell("통상시급", 568, 1803, 809, 1840);
        cell("13,983", 391, 1840, 522, 1879);
        cell("16,092", 639, 1840, 757, 1879);
    }

    static String shiftSlipText() {
        return "2026년10월 급여 계산 명세서입니다.\n"
             + "지급액계\n공제액계\n실지급액\n5,513,610\n106,951\n5,406,659\n"
             + "기본급\n3,411,852\n근속수당\n22,500\n가족수당(가족)\n30,000\n"
             + "직무수당\n55,000\n교대수당\n200,000\n평일연장\n772,416\n"
             + "휴일근무\n386,208\n휴일연장\n128,736\n야간근무\n56,898\n"
             + "야간(H)\n63.0\n"
             + "기본시급\n통상시급\n13,983\n16,092\n";
    }

    public static void main(String[] args) {
        scenarioA();
        scenarioB();
        scenarioC();
        scenarioD();
        scenarioE();
        scenarioF();
        scenarioG();
        scenarioH();
        scenarioI();
        moneyUnit();
        System.out.println(fail == 0 ? "\n✅ 명세서 OCR 파서 9가지 형태 전수 통과 (3중 안전망 + 야간수당 0 복원 포함)" : "\n❌ 불일치 " + fail + "건");
        if (fail != 0) System.exit(1);
    }
}
