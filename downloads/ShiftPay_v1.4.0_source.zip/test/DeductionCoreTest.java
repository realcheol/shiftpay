import com.example.shiftpay.DeductionCore;

/**
 * 공제액 정밀 예측 코어 검증 (v1.3.5).
 *
 * 실물 명세서 두 장의 공제 6개 항목을 그대로 넣어 합계가 1원까지 맞는지,
 * 노조회비 공식이 두 사람 모두에게 맞는지, 실측값이 없을 때의 법정 요율 계산이
 * 각 항목 합계와 일치하는지 확인한다.
 */
public class DeductionCoreTest {
    static int fail = 0;

    static void check(String name, long got, long want) {
        boolean ok = got == want;
        if (!ok) fail++;
        System.out.printf("%-34s 값 %,12d  기대 %,12d  %s%n", name, got, want, ok ? "OK" : "FAIL");
    }

    public static void main(String[] args) {
        // ── 1. 노조회비 공식: (통상시급 × 3h) + 1,200원 → 100원 단위 반올림 ──
        System.out.println("[1. 노조회비 공식]");
        check("상주 통상시급 14,939원", DeductionCore.unionFee(14939), 46000);
        check("교대 통상시급 16,092원", DeductionCore.unionFee(16092), 49500);

        // ── 2. 실측 학습 모드: 10월 명세서 공제 6항목 그대로 ──
        System.out.println("\n[2. 실측 학습 모드 — 10월 명세서]");
        long gross = 5262924L;   // 상주 세전
        long[] learned = {206810, 20680, 274300, 245000, 45900, 46000};
        DeductionCore.Result r = DeductionCore.compute(gross, 14939, 1, 1.0, 0, 0, gross, learned);
        check("소득세", r.incomeTax, 206810);
        check("지방소득세", r.localTax, 20680);
        check("건강보험", r.health, 274300);
        check("국민연금", r.pension, 245000);
        check("고용보험", r.employ, 45900);
        check("노조회비", r.unionFee, 46000);
        check("공제 합계", r.total, 838690);

        // 교대조 동료 명세서 (세전 5,513,610 / 공제 1,069,510)
        long[] learned2 = {376460, 37640, 255340, 294070, 56500, 49500};
        DeductionCore.Result r2 = DeductionCore.compute(5513610L, 16092, 1, 1.0, 0, 0, 5513610L, learned2);
        check("교대 공제 합계", r2.total, 1069510);

        // ── 3. 법정 요율 모드(실측 없음) — 각 항목과 합계가 맞물리는지 ──
        System.out.println("\n[3. 법정 요율·간이세액표 모드]");
        DeductionCore.Result r3 = DeductionCore.compute(5262924L, 14939, 2, 1.0, 0, 0, 0, null);
        check("국민연금 4.5%", r3.pension, Math.round(5262924L * 0.045 / 10.0) * 10);
        check("건강보험 3.545%", r3.health, Math.round(5262924L * 0.03545 / 10.0) * 10);
        check("장기요양 12.95%", r3.longterm, Math.round(r3.health * 0.1295 / 10.0) * 10);
        check("고용보험 0.9%", r3.employ, Math.round(5262924L * 0.009 / 10.0) * 10);
        check("지방소득세 = 소득세 10%", r3.localTax, (long)(Math.floor(r3.incomeTax * 0.10 / 10.0) * 10));
        check("노조회비", r3.unionFee, 46000);
        long sum = r3.incomeTax + r3.localTax + r3.pension + r3.health + r3.longterm + r3.employ + r3.unionFee;
        check("공제 합계 = 항목합", r3.total, sum);
        System.out.println("  · 간이세액표 소득세(100%) = " + String.format("%,d", r3.statutoryIncomeTax) + "원 (부양가족 2명)");

        // 선공제율 80% / 120% 는 소득세에만 작용
        DeductionCore.Result r80 = DeductionCore.compute(5262924L, 14939, 2, 0.8, 0, 0, 0, null);
        DeductionCore.Result r120 = DeductionCore.compute(5262924L, 14939, 2, 1.2, 0, 0, 0, null);
        check("선공제율 80% 소득세", r80.incomeTax, Math.round(r3.incomeTax * 0.8 / 10.0) * 10);
        check("선공제율 120% 소득세", r120.incomeTax, Math.round(r3.incomeTax * 1.2 / 10.0) * 10);
        check("80% 국민연금 불변", r80.pension, r3.pension);

        // ── 4. 실측값은 세전 급여 변화에 비례 보정 ──
        System.out.println("\n[4. 실측 학습 — 세전 급여 변동 보정]");
        DeductionCore.Result r4 = DeductionCore.compute(Math.round(gross * 1.1), 14939, 1, 1.0, 0, 0, gross, learned);
        check("소득세 10% 인상 보정", r4.incomeTax, Math.round(206810 * 1.1 / 10.0) * 10);
        check("국민연금 10% 인상 보정", r4.pension, Math.round(245000 * 1.1 / 10.0) * 10);

        System.out.println(fail == 0 ? "\n✅ 공제액 정밀 예측 코어 전 항목 통과" : "\n❌ 실패 " + fail + "건");
        if (fail > 0) System.exit(1);
    }
}
